
package com.app.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckForUpdateResponse {

    @SerializedName("android_update")
    private String androidUpdate;
    @SerializedName("android_version")
    private String androidVersion;
    @SerializedName("ios_update")
    private String iosUpdate;
    @SerializedName("ios_version")
    private String iosVersion;
    @Expose
    private String status;

    @SerializedName("antmedia_api_url")
    private String apiUrl;
    @SerializedName("antmedia_base_url")
    private String baseUrl;
    @SerializedName("antmedia_vod_url")
    private String vodUrl;

    public String getAndroidUpdate() {
        return androidUpdate;
    }

    public void setAndroidUpdate(String androidUpdate) {
        this.androidUpdate = androidUpdate;
    }

    public String getAndroidVersion() {
        return androidVersion;
    }

    public void setAndroidVersion(String androidVersion) {
        this.androidVersion = androidVersion;
    }

    public String getIosUpdate() {
        return iosUpdate;
    }

    public void setIosUpdate(String iosUpdate) {
        this.iosUpdate = iosUpdate;
    }

    public String getIosVersion() {
        return iosVersion;
    }

    public void setIosVersion(String iosVersion) {
        this.iosVersion = iosVersion;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getVodUrl() {
        return vodUrl;
    }

    public void setVodUrl(String vodUrl) {
        this.vodUrl = vodUrl;
    }

}
