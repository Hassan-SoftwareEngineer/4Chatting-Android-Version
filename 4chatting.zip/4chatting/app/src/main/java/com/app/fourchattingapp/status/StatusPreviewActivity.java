package com.app.fourchattingapp.status;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.bumptech.glide.Glide;
import com.app.external.keyboard.HeightProvider;
import com.app.helper.StorageManager;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.fourchattingapp.NewGroupActivity;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

import java.util.HashMap;

public class StatusPreviewActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = StatusPreviewActivity.class.getSimpleName();
    private ImageView cameraImage, galleryImage;
    private RelativeLayout titleLay, closeLayout;
    private ConstraintLayout bottomLay;
    private RelativeLayout mainLay;
    private EditText edtMessage;
    private ImageView ivEmoji;
    private ImageView btnSend;
    private StorageManager storageManager;
    private SharedPreferences pref;
    private String filePath, sourceType, beforeText;
    private int bottomNavHeight, bottomMargin = 0;
    private boolean isKeyBoardOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_preview);
        storageManager = StorageManager.getInstance(this);
        pref = getSharedPreferences("SavedPref", MODE_PRIVATE);
        bottomMargin = ApplicationClass.dpToPx(this, 2);
        findViews();

        if (ApplicationClass.isRTL()) {
            btnSend.setRotation(180);
        } else {
            btnSend.setRotation(0);
        }

        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        if (getIntent().hasExtra(Constants.TAG_ATTACHMENT)) {
            filePath = getIntent().getExtras().getString(Constants.TAG_ATTACHMENT);
            Log.d(TAG, "onCreateFilepath: " + filePath);
            sourceType = getIntent().getExtras().getString(Constants.TAG_FROM);
        }

        if (!TextUtils.isEmpty(filePath)) {
            if (sourceType.equals(Constants.TAG_CAMERA)) {
                cameraImage.setVisibility(View.VISIBLE);
                galleryImage.setVisibility(View.GONE);
                loadStatus(cameraImage, sourceType);
            } else {
                cameraImage.setVisibility(View.GONE);
                galleryImage.setVisibility(View.VISIBLE);
                loadStatus(galleryImage, sourceType);
            }
        }
    }

    public void loadStatus(ImageView imageView, String sourceType) {
        if (sourceType.equals(Constants.TAG_CAMERA)) {
            Glide.with(getApplicationContext())
                    .load(filePath)
                    .into(imageView);

        } else {
            Glide.with(getApplicationContext()).load(filePath)
                    .into(imageView);
        }
    }

    private void findViews() {
        mainLay = findViewById(R.id.mainLay);
        cameraImage = findViewById(R.id.camera_image);
        galleryImage = findViewById(R.id.gallery_image);
        titleLay = findViewById(R.id.title_lay);
        closeLayout = findViewById(R.id.close_layout);
        bottomLay = findViewById(R.id.bottomLay);
        edtMessage = findViewById(R.id.edtMessage);
        ivEmoji = findViewById(R.id.iv_emoji);
        edtMessage.setFilters(new InputFilter[]{new InputFilter.LengthFilter(250)});
        edtMessage.setMaxLines(6);
        btnSend = findViewById(R.id.btnSend);

        mainLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + ApplicationClass.dpToPx(StatusPreviewActivity.this, 10);
                initBottomPadding(bottomNavHeight + bottomMargin);
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        new HeightProvider(this).init().setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                if (height > 0) {
                    isKeyBoardOpen = true;
                } else {
                    isKeyBoardOpen = false;
                    if (bottomLay != null)
                        bottomLay.setTranslationY(0);
                }
            }
        });

        edtMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                beforeText = "" + charSequence;
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() >= 250) {
                    edtMessage.setEnabled(false);
                    Toast.makeText(StatusPreviewActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_LONG).show();
                    //      ApplicationClass.showToast(StatusPreviewActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_SHORT);
                } else if ((edtMessage.getLineCount() > 6)) {
                    edtMessage.setText("" + beforeText);
                    edtMessage.setSelection(edtMessage.length() - 1);
                    Toast.makeText(StatusPreviewActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_LONG).show();
                    //,                  ApplicationClass.showToast(StatusPreviewActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_SHORT);
                }
            }
        });

        closeLayout.setOnClickListener(this);
        btnSend.setOnClickListener(this);

    }

    @Override
    protected void onResume() {
        super.onResume();
        initMargins();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void initMargins() {
        int topMargin = pref.getInt(Constants.TAG_STATUS_HEIGHT, 0);
        initTopLayMargins(topMargin);
    }

    private void initTopLayMargins(int topMargin) {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.topMargin = topMargin + 5;
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        titleLay.setLayoutParams(layoutParams);
    }

    private void initBottomPadding(int bottomPadding) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        bottomLay.setPadding(0, ApplicationClass.dpToPx(this, 10), 0, bottomPadding);
        bottomLay.setLayoutParams(params);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        ApplicationClass.showSnack(StatusPreviewActivity.this, findViewById(R.id.mainLay), isConnected);
    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.record_button:
                // Handle clicks for recordButton
                break;
            case R.id.close_layout:
                backPressed();
                break;
            case R.id.btnSend:
                if (NetworkStatus.isConnected()) {
                    HashMap<String, String> map = new HashMap<>();
                    map.put(Constants.TAG_MESSAGE, edtMessage.getText().toString());
                    map.put(Constants.TAG_ATTACHMENT, filePath);
                    map.put(Constants.TAG_TYPE, "image");
                    Intent intent = new Intent(this, NewGroupActivity.class);
                    intent.putExtra(Constants.TAG_FROM, StorageManager.TAG_STATUS);
                    intent.putExtra(Constants.TAG_SOURCE_TYPE, sourceType);
                    intent.putExtra(Constants.TAG_MESSAGE_DATA, map);
                    startActivityForResult(intent, Constants.STATUS_IMAGE_CODE);
                } else {
                    ApplicationClass.showSnack(StatusPreviewActivity.this, findViewById(R.id.mainLay), false);
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == Constants.STATUS_IMAGE_CODE) {
            setResult(Activity.RESULT_OK);
            finish();
        }
    }

}
