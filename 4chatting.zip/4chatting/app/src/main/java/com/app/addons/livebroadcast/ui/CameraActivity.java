package com.app.addons.livebroadcast.ui;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.RECORD_AUDIO;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Insets;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;

import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.controls.Facing;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CameraActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = CameraActivity.class.getSimpleName();
    private Context mContext;
    private CoordinatorLayout parentLay;
    private CameraView previewView;
    private EditText edtTitle;
    private RelativeLayout tipsLay;
    private Button btnGoLive;
    private BottomSheetDialog bottomDialog;
    private LinearLayout frontCameraLay;
    private LinearLayout backCameraLay;
    private ImageView btnCancelTips;
    private Animation fadeOut, shake;
    private ApiInterface apiInterface;
    private String title, streamName, streamToken = null;
    private boolean mPermissionsGranted = false;
    private String[] mRequiredPermissions = new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            READ_EXTERNAL_STORAGE
    };
    public static final double RATIO_4_3_VALUE = 4.0 / 3.0;
    public static final double RATIO_16_9_VALUE = 16.0 / 9.0;
    private int displayHeight, displayWidth;
    private int bottomBarHeight = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        mContext = this;
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        findViews();
        // If running on Android 6 (Marshmallow) and later, check to see if the necessary permissions
        // have been granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mPermissionsGranted = hasPermissions(this, mRequiredPermissions);
            if (!mPermissionsGranted)
                ActivityCompat.requestPermissions(this, mRequiredPermissions, StreamConstants.CAMERA_REQUEST_CODE);
        } else
            mPermissionsGranted = true;

        // return if the user hasn't granted the app the necessary permissions
        if (!mPermissionsGranted) return;
        initView();
    }

    private void findViews() {
        parentLay = findViewById(R.id.parentLay);
        previewView = findViewById(R.id.previewView);
        edtTitle = findViewById(R.id.edtTitle);
        tipsLay = findViewById(R.id.tipsLay);
        btnCancelTips = findViewById(R.id.btnCancelTips);
        btnGoLive = findViewById(R.id.btnGoLive);

        btnGoLive.setOnClickListener(this);
        btnCancelTips.setOnClickListener(this);
    }

    private void initView() {
        fadeOut = AnimationUtils.loadAnimation(mContext, R.anim.fade_out_fast);
        shake = AnimationUtils.loadAnimation(mContext, R.anim.shake);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = this.getWindowManager().getCurrentWindowMetrics();
            Insets insets = windowMetrics.getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            Log.d(TAG, "initView: " + insets.bottom);
            CoordinatorLayout.LayoutParams relativeParams = new CoordinatorLayout.LayoutParams(CoordinatorLayout.LayoutParams.MATCH_PARENT, CoordinatorLayout.LayoutParams.WRAP_CONTENT);
            relativeParams.gravity = Gravity.BOTTOM | Gravity.CENTER;
            relativeParams.setMargins(ApplicationClass.dpToPx(mContext, 30), ApplicationClass.dpToPx(mContext, 0),
                    ApplicationClass.dpToPx(mContext, 30), insets.bottom);
            btnGoLive.setLayoutParams(relativeParams);
        } else {
            ViewCompat.setOnApplyWindowInsetsListener(parentLay, (v, insets) -> {
                Log.d(TAG, "initView: " + insets.getSystemWindowInsetBottom());
                CoordinatorLayout.LayoutParams relativeParams = new CoordinatorLayout.LayoutParams(CoordinatorLayout.LayoutParams.MATCH_PARENT, CoordinatorLayout.LayoutParams.WRAP_CONTENT);
                relativeParams.gravity = Gravity.BOTTOM | Gravity.CENTER;
                relativeParams.setMargins(ApplicationClass.dpToPx(mContext, 30), ApplicationClass.dpToPx(mContext, 0),
                        ApplicationClass.dpToPx(mContext, 30), insets.getSystemWindowInsetBottom() + 10);
                btnGoLive.setLayoutParams(relativeParams);
                return insets.consumeSystemWindowInsets();
            });
        }
    }

    private void setCameraView() {
        setCameraSizes();
        previewView.setLifecycleOwner(this);
        previewView.setUseDeviceOrientation(true);
        previewView.setFacing(Facing.BACK);
    }

    private void getDisplayWidthHeight(Context mContext) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = this.getWindowManager().getCurrentWindowMetrics();
            Insets insets = windowMetrics.getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            displayHeight = windowMetrics.getBounds().height() - insets.bottom - insets.top;
            displayWidth = windowMetrics.getBounds().width() - insets.left - insets.right;
        } else {
            this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            displayHeight = displayMetrics.heightPixels;
            displayWidth = displayMetrics.widthPixels;
        }
    }

    private void setCameraSizes() {
/*int screenAspectRatio = aspectRatio(displayWidth, displayHeight);

        previewView.setPreviewStreamSize(SizeSelectors.aspectRatio(screenAspectRatio, 0f));
        previewView.setVideoSize(SizeSelectors.aspectRatio(com.otaliastudios.cameraview.size.AspectRatio.of(1, 1), 0f));
        previewView.setPictureSize(SizeSelectors.aspectRatio(com.otaliastudios.cameraview.size.AspectRatio.of(1, 1), 0f));*/

    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If running on Android 6 (Marshmallow) or above, check to see if the necessary permissions
        // have been granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mPermissionsGranted = hasPermissions(this, mRequiredPermissions);
        } else {
            mPermissionsGranted = true;
        }
        if (mPermissionsGranted)
            startCamera();
    }

    private void startCamera() {
        setCameraView();
    }

    //    Utility method to check the status of a permissions request for an array of permission identifiers
    private static boolean hasPermissions(Context context, String[] permissions) {
        for (String permission : permissions)
            if (context.checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED)
                return false;

        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnCancelTips:
                tipsLay.setVisibility(View.GONE);
                tipsLay.startAnimation(fadeOut);
                break;
            case R.id.btnGoLive:
                if (TextUtils.isEmpty(edtTitle.getText().toString().trim())) {
                    tipsLay.setVisibility(View.VISIBLE);
                    tipsLay.startAnimation(shake);
                } else if (!checkStreamPermissions()) {
                    requestStreamPermissions();
                } else if (!NetworkStatus.isConnected()) {
                    makeToast(mContext.getString(R.string.no_internet_connection));
                } else {
                    ApplicationClass.hideSoftKeyboard(this);
                    ApplicationClass.pauseExternalAudio(this);
                    btnGoLive.setEnabled(false);
                    openBottomCameraDialog();
                }
                break;
        }
    }

    public void openBottomCameraDialog() {
        if (bottomDialog == null) {
            View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_camera, null);
            bottomDialog = new BottomSheetDialog(CameraActivity.this, R.style.Bottom_HashTagDialog); // Style here
            bottomDialog.setContentView(bottomSheet);
            bottomSheet.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
            frontCameraLay = bottomSheet.findViewById(R.id.frontCameraLay);
            backCameraLay = bottomSheet.findViewById(R.id.backCameraLay);

            frontCameraLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    frontCameraLay.setEnabled(false);
                    backCameraLay.setEnabled(false);
                    ApplicationClass.pauseExternalAudio(mContext);
                    getStreamName(Camera.CameraInfo.CAMERA_FACING_FRONT);
                }
            });

            backCameraLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    frontCameraLay.setEnabled(false);
                    backCameraLay.setEnabled(false);
                    ApplicationClass.pauseExternalAudio(mContext);
                    getStreamName(Camera.CameraInfo.CAMERA_FACING_BACK);
                }
            });

            bottomDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialogInterface) {
                    BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                    View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                    BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                    BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                    BottomSheetBehavior.from(bottomSheet).setHideable(true);
                    frontCameraLay.setEnabled(true);
                    backCameraLay.setEnabled(true);
                    btnGoLive.setEnabled(false);
                }
            });

            bottomDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialogInterface) {
                    BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                    View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                    BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                    BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                    BottomSheetBehavior.from(bottomSheet).setHideable(true);
                    frontCameraLay.setEnabled(true);
                    backCameraLay.setEnabled(true);
                    btnGoLive.setEnabled(true);
                }
            });
        }

        if (!bottomDialog.isShowing()) {
            bottomDialog.show();
        }
    }

    private void getStreamName(final int mLensFacing) {
        if (NetworkStatus.isConnected()) {
            btnGoLive.setEnabled(false);
            showProgress();
            Call<HashMap<String, String>> call = apiInterface.getStreamName(GetSet.getToken(), GetSet.getUserId());
            call.enqueue(new Callback<HashMap<String, String>>() {
                @Override
                public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                    if (response.isSuccessful()) {
                        HashMap<String, String> map = response.body();
                        if (map.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                            Intent stream = new Intent(mContext, PublishActivity.class);
                            stream.putExtra(StreamConstants.TAG_TITLE, edtTitle.getText().toString().trim());
                            stream.putExtra(StreamConstants.TAG_STREAM_NAME, map.get(StreamConstants.TAG_STREAM_NAME));
                            stream.putExtra(StreamConstants.TAG_STREAM_TOKEN, map.get(StreamConstants.TAG_STREAM_TOKEN));
                            stream.putExtra(StreamConstants.TAG_LENS_FACING, mLensFacing);
                            stream.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    edtTitle.getText().clear();
                                    btnGoLive.setEnabled(true);
                                    frontCameraLay.setEnabled(true);
                                    backCameraLay.setEnabled(true);
                                    bottomDialog.dismiss();
                                    startActivityForResult(stream, StreamConstants.PUBLISH_REQUEST_CODE);
                                }
                            }, 1000);
                        }
                    } else {
                        btnGoLive.setEnabled(true);
                    }
                    hideProgress();
                }

                @Override
                public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                    t.printStackTrace();
                    hideProgress();
                    btnGoLive.setEnabled(true);
                }
            });
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == StreamConstants.PUBLISH_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                edtTitle.setText("");
            }
        }
    }

    public void showProgress() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }


    public void hideProgress() {
        /*Enable touch options*/

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    private boolean checkStreamPermissions() {
        return ContextCompat.checkSelfPermission(mContext, CAMERA)
                == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(mContext, RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(mContext, READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStreamPermissions() {
        if (ActivityCompat.checkSelfPermission(mContext,
                CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(mContext,
                        RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(mContext,
                        READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{CAMERA, RECORD_AUDIO, READ_EXTERNAL_STORAGE}, StreamConstants.STREAM_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[],
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mPermissionsGranted = true;
        if (requestCode == StreamConstants.STREAM_REQUEST_CODE || requestCode == StreamConstants.CAMERA_REQUEST_CODE) {
            if (!isPermissionsGranted(permissions)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (shouldShowRequestPermissionRationale(CAMERA) &&
                            shouldShowRequestPermissionRationale(RECORD_AUDIO) &&
                            shouldShowRequestPermissionRationale(READ_EXTERNAL_STORAGE)) {
                        requestPermissions(permissions, StreamConstants.STREAM_REQUEST_CODE);
                    } else {
//                            openPermissionDialog(permissions);
                        makeToast(getString(R.string.camera_microphone_storage_permission_error));
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + this.getPackageName()));
                        startActivity(i);
                    }
                }
            } else {
                if (requestCode == StreamConstants.STREAM_REQUEST_CODE) {
                    btnGoLive.performClick();
                }
            }
        }
    }

    public boolean isPermissionsGranted(String[] permissions) {
        boolean isGranted = false;
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(mContext, permission) != PackageManager.PERMISSION_GRANTED) {
                isGranted = false;
                break;
            } else {
                isGranted = true;
            }
        }
        return isGranted;
    }

    private void openPermissionDialog(String[] permissions) {
        new AlertDialog.Builder(CameraActivity.this)
                .setTitle(R.string.permission)
                .setMessage(getString(R.string.app_doesnot_work_without_permissions))
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        try {
                            //Open the specific App Info page:
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + getApplicationContext().getPackageName()));
                            startActivity(intent);

                        } catch (ActivityNotFoundException e) {
                            //e.printStackTrace();

                            //Open the generic Apps page:
                            Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
                            startActivity(intent);

                        }
                    }
                })
                .show();
    }
}
