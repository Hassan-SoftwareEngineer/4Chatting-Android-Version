package com.app.helper.event;

public class CallReceiveEvent {
    private String callType;

    public CallReceiveEvent(String callType) {
        this.callType = callType;
    }

    public String getCallType() {
        return callType;
    }

    public void setCallType(String callType) {
        this.callType = callType;
    }
}
