package com.app.fourchattingapp;

import static android.Manifest.permission.READ_CONTACTS;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.model.SaveMyContacts;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.JsonArray;
import com.app.apprtc.util.AppRTCUtils;
import com.app.helper.DatabaseHandler;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.Utils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CallContactActivity extends BaseActivity implements SocketConnection.SelectContactListener, View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    TextView title, nullText;
    ImageView backbtn, searchbtn, optionbtn, cancelbtn;
    RecyclerView recyclerView;
    DatabaseHandler dbhelper;
    EditText searchView;
    RelativeLayout searchLay, mainLay;
    LinearLayout nullLay;
    LinearLayout buttonLayout;
    List<ContactsData.Result> contactList = new ArrayList<>();
    List<ContactsData.Result> filteredList = new ArrayList<>();
    static ApiInterface apiInterface;
    LinearLayoutManager linearLayoutManager;
    RecyclerViewAdapter recyclerViewAdapter;
    ProgressDialog progressDialog;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    SocketConnection socketConnection;
    List<ContactsData.Result> userData = new ArrayList<>();
    private ActivityResultLauncher<String[]> callPermissionResult;
    private Utils utils;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_contact);
        pref = CallContactActivity.this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        dbhelper = DatabaseHandler.getInstance(this);
        socketConnection = SocketConnection.getInstance(this);
        SocketConnection.getInstance(this).setSelectContactListener(this);
        utils = new Utils(this);
        initPermissionResult();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        title = findViewById(R.id.title);
        backbtn = findViewById(R.id.backbtn);
        searchbtn = findViewById(R.id.searchbtn);
        optionbtn = findViewById(R.id.optionbtn);
        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);
        buttonLayout = findViewById(R.id.buttonLayout);
        cancelbtn = findViewById(R.id.cancelbtn);
        searchLay = findViewById(R.id.searchLay);
        mainLay = findViewById(R.id.mainLay);
        nullLay = findViewById(R.id.nullLay);
        nullText = findViewById(R.id.nullText);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        title.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        searchbtn.setVisibility(View.VISIBLE);
        optionbtn.setVisibility(View.VISIBLE);

        title.setText(getString(R.string.select_contact));

        linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);

        contactList.addAll(dbhelper.getStoredContacts(this));
        filteredList = new ArrayList<>();
        filteredList.addAll(contactList);

        recyclerViewAdapter = new RecyclerViewAdapter(this);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();

        backbtn.setOnClickListener(this);
        searchbtn.setOnClickListener(this);
        optionbtn.setOnClickListener(this);
        cancelbtn.setOnClickListener(this);

        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    cancelbtn.setVisibility(View.VISIBLE);
                } else {
                    cancelbtn.setVisibility(View.GONE);
                }
                recyclerViewAdapter.getFilter().filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        nullText.setText(getString(R.string.no_contact));
        if (contactList.size() == 0) {
            nullLay.setVisibility(View.VISIBLE);
        } else {
            nullLay.setVisibility(View.GONE);
        }

    }

    private void initPermissionResult() {
        callPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) {
                        granted = false;
                        break;
                    }
                }

                if (granted) {

                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CallContactActivity.this, x.getKey())) {
                                callPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
//                                makeToast(getString(R.string.call_permission_error));
                                PermissionsUtils.openPermissionDialog(CallContactActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        makeToast(getString(R.string.call_permission_error));
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.searchbtn:
                title.setVisibility(View.GONE);
                searchLay.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
                ApplicationClass.showKeyboard(this, searchView);
                break;
            case R.id.optionbtn:
                Display display = this.getWindowManager().getDefaultDisplay();
                ArrayList<String> values = new ArrayList<>();
                values.add(getString(R.string.refresh));

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                        R.layout.option_item, android.R.id.text1, values);
                LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View layout = layoutInflater.inflate(R.layout.option_layout, null);
                final PopupWindow popup = new PopupWindow(CallContactActivity.this);
                popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                popup.setContentView(layout);
                popup.setWidth(display.getWidth() * 60 / 100);
                popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
                popup.setFocusable(true);

                ImageView pinImage = layout.findViewById(R.id.pinImage);
                if (ApplicationClass.isRTL()) {
                    pinImage.setRotation(180);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.START, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                } else {
                    layout.setAnimation(AnimationUtils.loadAnimation(this, R.anim.grow_from_topright_to_bottomleft));
                    pinImage.setRotation(0);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.END, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                }

                final ListView lv = layout.findViewById(R.id.listView);
                lv.setAdapter(adapter);
                popup.showAsDropDown(view);

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        popup.dismiss();
                        if (position == 0) {
                            if (progressDialog != null) progressDialog.show();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    new GetContactTask().execute();
                                }
                            }, 1000);
                        }
                    }
                });
                break;
            case R.id.cancelbtn:
                searchView.setText("");
                break;
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class GetContactTask extends AsyncTask<Void, Integer, Void> {
        JsonArray contactsNum = new JsonArray();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Uri uri = null;
            uri = ContactsContract.CommonDataKinds.Contactables.CONTENT_URI;
            ContentResolver cr = getContentResolver();
            Cursor cur = cr.query(uri, Constants.PROJECTION, Constants.SELECTION, Constants.SELECTION_ARGS, null);

            if (cur != null) {
                try {
                    final int nameIndex = cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                    final int numberIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

                    while (cur.moveToNext()) {
                        ContactsData.Result user = new ContactsData().new Result();
                        String phoneNo = cur.getString(numberIndex).replace(" ", "");
                        String name = cur.getString(nameIndex);
                        user.saved_name = name;
                        String formattedPhoneNumber = utils.getFormattedPhoneNumber(phoneNo);
                        if (!TextUtils.isEmpty(formattedPhoneNumber)) {
                            contactsNum.add(formattedPhoneNumber);
                            user.phone_no = formattedPhoneNumber;
                            userData.add(user);
                        }
                    }
                } finally {
                    cur.close();
                }
                Log.e(TAG, "getContactList: " + contactsNum.size());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            saveMyContacts(contactsNum);
        }
    }


    public void saveMyContacts(JsonArray contacts) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, "" + contacts);
        Log.e("paramForSave","-"+map);
        Call<SaveMyContacts> call = apiInterface.saveMyContacts(GetSet.getToken(), map);
        call.enqueue(new Callback<SaveMyContacts>() {
            @Override
            public void onResponse(Call<SaveMyContacts> call, Response<SaveMyContacts> response) {
                updatemycontacts(contacts);
            }

            @Override
            public void onFailure(Call<SaveMyContacts> call, Throwable t) {
                Log.e(TAG, "saveMyContacts: " + t.getMessage());
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
                call.cancel();
            }
        });
    }

    void updatemycontacts(JsonArray contacts) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, contacts.toString());
        map.put(Constants.TAG_PHONE_NUMBER, GetSet.getphonenumber());
        Log.v("Login params:", "" + map);
        Log.e("paramupdate","-"+map);
        Call<ContactsData> call3 = apiInterface.updateMyContacts(GetSet.getToken(), map);
        call3.enqueue(new Callback<ContactsData>() {
            @Override
            public void onResponse(Call<ContactsData> call, Response<ContactsData> response) {
                try {
//                    Log.v(TAG, "updateMyContacts=" + new Gson().toJson(response.body()));
                    ContactsData data = response.body();
                    if (data.status.equals("true")) {
                        new UpdateContactTask(data).execute();
                    } else if (data.status.equals("false")) {
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                    }
                } catch (Exception e) {

                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ContactsData> call, Throwable t) {
//                Log.e(TAG, "updateMyContacts: " + t.getMessage());
                call.cancel();
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
            }
        });

    }

    @SuppressLint("StaticFieldLeak")
    private class UpdateContactTask extends AsyncTask<Void, Integer, Void> {
        ContactsData data = new ContactsData();
        List<String> tempContacts = new ArrayList<>();

        public UpdateContactTask(ContactsData data) {
            this.data = data;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            tempContacts.add(GetSet.getUserId());
            for (ContactsData.Result result : data.result) {
                String name = "";
                HashMap<String, String> map;
                map = ApplicationClass.getContactOrNot(getApplicationContext(), result.phone_no);
                if (map.get("isAlready").equals("true")) {
                    name = map.get(Constants.TAG_USER_NAME);
                }
                result.isDeletedAccount = "0";
                dbhelper.addContactDetails(name, result);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            updateDeletedContacts(tempContacts);
        }
    }

    private void updateDeletedContacts(List<String> tempContacts) {
        executor.execute(new Runnable() {
            public void run() {
                String array = null;
                array = String.join(",", tempContacts).replaceAll("([^,]+)", "\"$1\"");
                Log.d(TAG, "updateDeletedContacts: " + array);
                dbhelper.updateDeletedContacts(CallContactActivity.this, array);
                filteredList.clear();
                contactList.clear();
                mainHandler.postDelayed(new Runnable() {
                    public void run() {
                        contactList.addAll(dbhelper.getStoredContacts(CallContactActivity.this));
                        filteredList.addAll(contactList);
                        if (recyclerViewAdapter != null)
                            recyclerViewAdapter.notifyDataSetChanged();

                        nullText.setText(getString(R.string.no_contact));
                        if (contactList.size() == 0) {
                            nullLay.setVisibility(View.VISIBLE);
                        } else {
                            nullLay.setVisibility(View.GONE);
                        }
                        if (progressDialog != null && progressDialog.isShowing())
                            progressDialog.dismiss();
                    }
                }, 200);
            }
        });
    }

    public boolean isValidPhoneNumber(CharSequence target) {
        if (target.length() < 7 || target.length() > 15) {
            return false;
        } else {
            return android.util.Patterns.PHONE.matcher(target).matches();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (recyclerViewAdapter != null) {
            recyclerViewAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SocketConnection.getInstance(this).setSelectContactListener(null);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        if (searchLay.getVisibility() == View.VISIBLE) {
            searchView.setText("");
            searchLay.setVisibility(View.GONE);
            title.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.VISIBLE);
            ApplicationClass.hideSoftKeyboard(this, searchView);
        } else {
            finish();
        }
    }

    @Override
    public void onUserImageChange(String user_id, String user_image) {
        Log.v("Chat", "onUserImageChange");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null && filteredList.size() > 0) {
                    for (int i = 0; i < filteredList.size(); i++) {
                        if (user_id.equals(filteredList.get(i).user_id)) {
                            filteredList.get(i).user_image = user_image;
                            recyclerViewAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    @Override
    public void onBlockStatus(JSONObject data) {
        if (recyclerViewAdapter != null && filteredList.size() > 0) {
            try {
                String sender_id = data.getString(Constants.TAG_SENDER_ID);
                String type = data.getString(Constants.TAG_TYPE);
                for (int i = 0; i < filteredList.size(); i++) {
                    if (sender_id.equals(filteredList.get(i).user_id)) {
                        filteredList.get(i).blockedme = type;
                        recyclerViewAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onPrivacyChanged(JSONObject jsonObject) {
//        Log.i(TAG, "onPrivacyChanged: " + jsonObject);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null) {
                    contactList.addAll(dbhelper.getStoredContacts(getApplicationContext()));
                    filteredList.clear();
                    filteredList.addAll(contactList);
                    recyclerViewAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter implements Filterable {

        List<ContactsData.Result> Items;
        Context context;
        private SearchFilter mFilter;

        public RecyclerViewAdapter(Context context) {
            this.context = context;
            mFilter = new SearchFilter(RecyclerViewAdapter.this);
        }

        @Override
        public Filter getFilter() {
            return mFilter;
        }

        public class SearchFilter extends Filter {
            private RecyclerViewAdapter mAdapter;

            private SearchFilter(RecyclerViewAdapter mAdapter) {
                super();
                this.mAdapter = mAdapter;
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                filteredList.clear();
                final FilterResults results = new FilterResults();
                if (constraint.length() == 0) {
                    filteredList.addAll(contactList);
                } else {
                    final String filterPattern = constraint.toString().toLowerCase().trim();
                    for (final ContactsData.Result result : contactList) {
                        if (result.user_name != null) {
                            if (result.user_name.toLowerCase().startsWith(filterPattern)) {
                                filteredList.add(result);
                            }
                        }
                    }
                }
                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                this.mAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = null;

            itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.contact_list_item, parent, false);
            return new MyViewHolder(itemView);

        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            if (ContextCompat.checkSelfPermission(CallContactActivity.this, READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                ((MyViewHolder) holder).name.setText(filteredList.get(position).user_name);
            } else {
                ((MyViewHolder) holder).name.setText(filteredList.get(position).phone_no);
            }

            ((MyViewHolder) holder).about.setText(filteredList.get(position).about != null ? filteredList.get(position).about : "");
            if (filteredList.get(position).blockedme.equals("block")) {
                Glide.with(context).load(R.drawable.temp)
                        .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                        .into(((MyViewHolder) holder).profileimage);
            } else {
                DialogActivity.setProfileImage(dbhelper.getContactDetail(filteredList.get(position).user_id), ((MyViewHolder) holder).profileimage, context);
            }

        }

        @Override
        public int getItemCount() {
            return filteredList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

            LinearLayout parentlay;
            TextView name, about;
            CircleImageView profileimage;
            ImageView btnVoiceCall, btnVideoCall;
            View profileview;
            LinearLayout callLayout;

            public MyViewHolder(View view) {
                super(view);

                parentlay = view.findViewById(R.id.parentlay);
                profileimage = view.findViewById(R.id.profileimage);
                name = view.findViewById(R.id.name);
                about = view.findViewById(R.id.about);
                profileview = view.findViewById(R.id.profileview);
                callLayout = view.findViewById(R.id.callLayout);
                btnVoiceCall = view.findViewById(R.id.btnVoiceCall);
                btnVideoCall = view.findViewById(R.id.btnVideoCall);

                callLayout.setVisibility(View.VISIBLE);
                profileimage.setOnClickListener(this);
                btnVoiceCall.setOnClickListener(this);
                btnVideoCall.setOnClickListener(this);

            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.profileimage:
                        openUserDialog(profileview, filteredList.get(getAbsoluteAdapterPosition()));
                        break;
                    case R.id.btnVoiceCall:
                        ContactsData.Result result = dbhelper.getContactDetail(filteredList.get(getAbsoluteAdapterPosition()).user_id);
                        if (!PermissionsUtils.checkCallPermissions(CallContactActivity.this, Constants.TAG_AUDIO)) {
                            callPermissionResult.launch(AppRTCUtils.MANDATORY_AUDIO_PERMISSIONS);
                        } else if (result.blockedbyme.equals("block")) {
                            blockChatConfirmDialog(result.user_id);
                        } else {
                            if (NetworkStatus.isConnected()) {
                                ApplicationClass.preventMultiClick(btnVoiceCall);
                                utils.makeCall(context, result.user_id, Constants.TAG_SEND, Constants.TAG_AUDIO);
                            } else {
                                makeToast(getString(R.string.no_internet_connection));
                            }
                        }
                        break;
                    case R.id.btnVideoCall:
                        result = dbhelper.getContactDetail(filteredList.get(getAbsoluteAdapterPosition()).user_id);
                        if (!PermissionsUtils.checkCallPermissions(CallContactActivity.this, Constants.TAG_VIDEO)) {
                            callPermissionResult.launch(AppRTCUtils.MANDATORY_VIDEO_PERMISSIONS);
                        } else if (result.blockedbyme.equals("block")) {
                            blockChatConfirmDialog(result.user_id);
                        } else {
                            if (NetworkStatus.isConnected()) {
                                ApplicationClass.preventMultiClick(btnVideoCall);
                                utils.makeCall(context, result.user_id, Constants.TAG_SEND, Constants.TAG_VIDEO);
                            } else {
                                makeToast(getString(R.string.no_internet_connection));
                            }
                        }
                        break;
                }
            }
        }
    }


    private void openUserDialog(View view, ContactsData.Result data) {
        Intent i = new Intent(CallContactActivity.this, DialogActivity.class);
        i.putExtra(Constants.TAG_USER_ID, data.user_id);
        i.putExtra(Constants.TAG_USER_NAME, data.user_name);
        i.putExtra(Constants.TAG_USER_IMAGE, data.user_image);
        i.putExtra(Constants.TAG_BLOCKED_ME, data.blockedme);
        ActivityOptionsCompat options = ActivityOptionsCompat.makeScaleUpAnimation(view, view.getWidth(), view.getHeight(), view.getWidth(), view.getHeight());
        startActivity(i, options.toBundle());
    }

    public static String getURLForResource(int resourceId) {
        return Uri.parse("android.resource://com.app.fourchattingapp/" + resourceId).toString();
    }

    private void blockChatConfirmDialog(String userId) {
        final Dialog dialog = new Dialog(CallContactActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);

        yes.setText(getString(R.string.unblock));
        no.setText(getString(R.string.cancel));
        title.setText(R.string.unblock_message);

        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                    jsonObject.put(Constants.TAG_TYPE, "unblock");
                    Log.v(TAG, "block=" + jsonObject);
                    socketConnection.block(jsonObject);
                    dbhelper.updateBlockStatus(userId, Constants.TAG_BLOCKED_BYME, "unblock");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
