package com.app.helper.callback;

public interface OnLoadMoreListener {
    void onLoadMore();
}
