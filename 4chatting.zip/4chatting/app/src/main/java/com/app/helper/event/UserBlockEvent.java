package com.app.helper.event;

import org.json.JSONObject;

public class UserBlockEvent {
    private JSONObject blockObject;

    public UserBlockEvent(JSONObject blockObject) {
        this.blockObject = blockObject;
    }

    public JSONObject getBlockObject() {
        return blockObject;
    }

    public void setBlockObject(JSONObject blockObject) {
        this.blockObject = blockObject;
    }
}
