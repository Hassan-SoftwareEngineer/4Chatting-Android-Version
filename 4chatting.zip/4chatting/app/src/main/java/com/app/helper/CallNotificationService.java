package com.app.helper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.app.fourchattingapp.CallActivity;
import com.app.fourchattingapp.R;

/**
 * Created by hitasoft on 14/9/18.
 */

public class CallNotificationService extends Service {

    private static final String TAG = CallNotificationService.class.getSimpleName();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service Started");
        setCallNotification(this);
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.e(TAG, "onTaskRemoved");
        //Code here
        SocketConnection socketConnection = SocketConnection.getInstance(this);
        socketConnection.disconnect();
        stopSelf();
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel("hiddycall", 0);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service Destroyed");
    }

    public void setCallNotification(Context context) {
        CallActivity.callPause = true;
        String appName = context.getString(R.string.app_name);
        long when = System.currentTimeMillis();

        Intent intent = new Intent(context, CallActivity.class);
        intent.putExtra("notification", "true");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent resultPendingIntent = null;
            //    PendingIntent.getActivity(context, 0, intent, 0);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            resultPendingIntent = PendingIntent.getActivity(context, 0, intent,  PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_ONE_SHOT);
        } else {
            resultPendingIntent = PendingIntent.getActivity(context, 0, intent,  PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
        }

        Intent intent2 = new Intent(context, CallActivity.class);
        intent2.putExtra("_ACTION_", "endcall");
        intent2.setAction("End Call");
        intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent endIntent = null;
        /*= PendingIntent.getActivity(context, 0, intent2, 0);*/

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            endIntent = PendingIntent.getActivity(context, 0, intent2,  PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_ONE_SHOT);
        } else {
            endIntent = PendingIntent.getActivity(context, 0, intent2,  PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
        }


        String channelId = context.getString(R.string.call_notification_channel_id);
        CharSequence channelName = context.getString(R.string.app_name);
        int importance = NotificationManager.IMPORTANCE_HIGH;

        NotificationManager mNotifyManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, channelId);
        mBuilder.setContentTitle(appName)
                .setContentText("Ongoing call").setTicker(appName).setWhen(when)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Ongoing call"))
                .setContentIntent(resultPendingIntent)
                .setSmallIcon(R.drawable.notification)
                .setColor(ContextCompat.getColor(context, R.color.colorAccent))
                .addAction(R.drawable.notification, "End call", endIntent)
                .setOngoing(true)
                .setAutoCancel(true);
        Notification notification = mBuilder.build();
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.S) {
            startForeground(1000, notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1000, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1000, notification);
        }

    }
}
