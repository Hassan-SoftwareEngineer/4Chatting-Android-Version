package com.app.helper;

import static android.content.Context.MODE_PRIVATE;
import static com.app.utils.Constants.ADMIN;
import static com.app.utils.Constants.MEMBER;
import static com.app.utils.Constants.TAG_ADMIN_ID;
import static com.app.utils.Constants.TAG_CHANNEL_ID;
import static com.app.utils.Constants.TAG_CHANNEL_NAME;
import static com.app.utils.Constants.TAG_CHAT_ID;
import static com.app.utils.Constants.TAG_CONTACT_STATUS;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_ID;
import static com.app.utils.Constants.TAG_MEMBER_ID;
import static com.app.utils.Constants.TAG_MEMBER_ROLE;
import static com.app.utils.Constants.TAG_MESSAGE_ID;
import static com.app.utils.Constants.TAG_PRIVACY_ABOUT;
import static com.app.utils.Constants.TAG_PRIVACY_LAST_SEEN;
import static com.app.utils.Constants.TAG_PRIVACY_PROFILE;
import static com.app.utils.Constants.TAG_SENDER_ID;
import static com.app.utils.Constants.TAG_USER_ID;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.app.apprtc.util.AppRTCUtils;
import com.app.external.RandomString;
import com.app.helper.event.CallReceiveEvent;
import com.app.helper.event.UserBlockEvent;
import com.app.helper.workers.ChannelChatWorker;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.CallActivity;
import com.app.fourchattingapp.CallFragment;
import com.app.model.ChannelMessage;
import com.app.model.ChannelResult;
import com.app.model.GroupData;
import com.app.model.GroupResult;
import com.app.model.MessagesData;
import com.app.model.StatusDatas;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;
import com.app.model.AdminChannel;
import com.app.model.AdminChannelMsg;
import com.app.model.ChannelInfoResponse;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import io.socket.engineio.client.transports.WebSocket;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by hitasoft on 28/6/18.
 */

public class SocketConnection extends Thread {

    private final String TAG = SocketConnection.class.getSimpleName();
    private static Context mContext;
    private static Socket mSocket;
    private static SocketConnection mInstance;
    public static ForegroundListener foregroundListener;
    public static RecentChatReceivedListener recentChatReceivedListener;
    public static ChatCallbackListener chatCallbackListener;
    public static ApplicationClassListener applicationClassListener;
    public static ExternalUploadListener externalUploadListener;
    public static GroupChatCallbackListener groupChatCallbackListener;
    public static GroupRecentReceivedListener groupRecentReceivedListener;
    public static GroupInfoSocketListener groupInfoSocketListener;
    public static ChannelChatCallbackListener channelChatCallbackListener;
    public static ChannelRecentReceivedListener channelRecentReceivedListener;
    public static OnlineCallbackListener onlineCallbackListener;
    public static OnUpdateTabIndication onUpdateTabIndication;
    public static StoryListener storyListener;
    public static StatusUploadListener statusUploadListener;
    private static NewAdminCreatedListener newAdminCreatedListener;
    private static OnGroupCreatedListener onGroupCreatedListener;
    private static ChannelCallbackListener channelCallbackListener;
    private static SelectContactListener selectContactListener;
    private static UserProfileListener userProfileListener;
    DatabaseHandler dbhelper;
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private StorageManager storageManager;
    private DateUtils dateUtils;

    static class GroupEvent {
        private static final String CREATE_GROUP = "creategroup";
        private static final String JOIN_GROUP = "joingroup";
        private static final String EXIT_FROM_GROUP = "exitfromgroup";
        private static final String GROUP_CHAT_RECEIVED = "groupchatreceived";
        private static final String MESSAGE_TO_GROUP = "messagetogroup";
        private static final String GROUP_TYPING = "grouptyping";
        private static final String GROUP_INVITATION = "groupinvitation";
        private static final String CLEAR_GROUP_INVITATION = "cleargroupinvites";
        private static final String CHANGE_USER_IMAGE = "changeuserimage";
        private static final String MESSAGE_FROM_GROUP = "messagefromgroup";
        private static final String MEMBER_EXITED = "memberexited";
        private static final String LISTEN_GROUP_TYPING = "listengrouptyping";
        private static final String GROUP_MODIFIED = "groupmodified";
    }

    static class ChannelEvent {
        private static final String CREATE_CHANNEL = "createchannel";
        private static final String SUBSCRIBE_CHANNEL = "subscribechannel";
        private static final String UNSUBSCRIBE_CHANNEL = "unsubscribechannel";
        private static final String LEAVE_CHANNEL = "leavechannel";
        private static final String SEND_CHANNEL_INVITATION = "sendchannelinvitation";
        private static final String CLEAR_CHANNEL_INVITES = "clearchannelinvites";
        private static final String CHANNEL_CREATED = "channelcreated";
        private static final String MESSAGE_TO_CHANNEL = "messagetochannel";
        private static final String MESSAGE_FROM_CHANNEL = "messagefromchannel";
        private static final String MESSAGE_FROM_ADMIN_CHANNEL = "msgfromadminchannels";
        private static final String DELETE_CHANNEL = "deletechannel";
        private static final String RECEIVE_CHANNEL_INVITATION = "receivechannelinvitation";
        private static final String MAKE_PRIVATE = "makeprivate";
        private static final String BLOCK_CHANNEL = "blockchannel";
    }

    static class StoryEvent {
        private static final String RECEIVE_STORY = "receivestory";
        private static final String STORY_RECEIVED = "storyreceived";
        private static final String DELETE_STORY = "deletestory";
        private static final String STORY_DELETED = "storydeleted";
        private static final String STORY_VIEWED = "storyviewed";
        private static final String CLEAR_STORY_VIEWED = "clearstoryviewed";
        private static final String POST_STORY = "poststory";
        private static final String VIEW_STORY = "viewstory";
        private static final String CLEAR_OFFLINE_STORY_RECEIVED = "clearofflinestoryreceived";
    }

    static class CallEvent {
        private static final String CREATE_CALL = "createcall";
        private static final String CALL_CREATED = "callcreated";
        private static final String RECENT_CALLS = "recentcalls";
    }

    private Emitter.Listener chatBoxJoined = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.v(TAG, "chatBoxJoined: " + args[0]);
            if (foregroundListener != null) {
                foregroundListener.onChatBoxJoined();
            }
            if (chatCallbackListener != null) {
                chatCallbackListener.onChatBoxJoined();
            }
            if (onlineCallbackListener != null) {
                onlineCallbackListener.onChatBoxJoined();
            }
            getReadReceipts();
            joinGroups();
        }
    };

    private Emitter.Listener receiveChat = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.v(TAG, "receiveChat: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                MessagesData mdata = getMessagesByType(data);

                // checking the user already in contacts table
                if (dbhelper.isUserExist(mdata.user_id)) {
                    setMessagesListener(mdata);
                } else {
                    getUserProfile(mdata);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener privateChatSend = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.v(TAG, "privateChatSend: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String senderId = data.getString(TAG_SENDER_ID);
                String userId = data.getString(TAG_USER_ID);
                dbhelper.updateChatSendStatus(senderId, userId);
                if (chatCallbackListener != null) {
                    chatCallbackListener.onPrivateChatReceived(userId, senderId);
                }
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onPrivateChatUpdate(userId);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener receivedStatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "receivedStatus: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String messageId = data.getString(Constants.TAG_MESSAGE_ID);
                String senderId = data.getString(Constants.TAG_SENDER_ID);
                String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                dbhelper.updateMessageSentStatus(messageId);
                if (chatCallbackListener != null) {
                    chatCallbackListener.receivedStatus(messageId, senderId, receiverId);
                }
                if (recentChatReceivedListener != null) {
                    Log.d(TAG, "receivedStatus: onUpdateChatStatus");
                    recentChatReceivedListener.onUpdateChatStatus(receiverId);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener readStatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "onReadStatus: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String chatId = data.getString(Constants.TAG_CHAT_ID);
                String senderId = data.getString(Constants.TAG_SENDER_ID);
                String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                dbhelper.updateMessageReadStatus(chatId, receiverId);
                if (chatCallbackListener != null) {
                    chatCallbackListener.onViewChat(chatId, senderId, receiverId);
                }
                if (recentChatReceivedListener != null) {
                    Log.d(TAG, "onReadStatus: onUpdateChatStatus");
                    recentChatReceivedListener.onUpdateChatStatus(receiverId);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener offlineReceivedStatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d(TAG, "offlineReceivedStatus: " + args[0]);
            try {
                JSONObject jobj = (JSONObject) args[0];
                Iterator<String> it = jobj.keys();
                while (it.hasNext()) {
                    String key = it.next(); //key --> message id
                    JSONObject data = jobj.getJSONObject(key);
                    String senderId = data.getString(Constants.TAG_SENDER_ID);
                    String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                    dbhelper.updateMessageSentStatus(key);
                    clearReceivedMessages(key);
                    if (chatCallbackListener != null) {
                        chatCallbackListener.receivedStatus(key, senderId, receiverId);
                    }
                    if (recentChatReceivedListener != null) {
                        Log.d(TAG, "offlineReceivedStatus: onUpdateChatStatus");
                        recentChatReceivedListener.onUpdateChatStatus(receiverId);
                    }

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener offlinereadstatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "offlineReadStatus: " + args[0]);
            try {
                JSONObject jobj = (JSONObject) args[0];
                Iterator<String> it = jobj.keys();
                while (it.hasNext()) {
                    String key = it.next(); //key --> chat id
                    JSONObject data = jobj.getJSONObject(key);
                    String chatId = data.getString(Constants.TAG_CHAT_ID);
                    String senderId = data.getString(Constants.TAG_SENDER_ID);
                    String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                    dbhelper.updateMessageReadStatus(chatId, receiverId);
                    clearReadMessages(GetSet.getUserId(), chatId);
                    if (chatCallbackListener != null) {
                        chatCallbackListener.onViewChat(chatId, senderId, receiverId);
                    }
                    if (recentChatReceivedListener != null) {
                        Log.d(TAG, "offlineReadStatus: onUpdateChatStatus");
                        recentChatReceivedListener.onUpdateChatStatus(receiverId);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener onlineStatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "onlineStatus: " + args[0]);
            if (chatCallbackListener != null) {
                JSONObject data = (JSONObject) args[0];
                chatCallbackListener.onlineStatus(data);
            }
        }
    };

    private Emitter.Listener listenTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "listenTyping: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                if (chatCallbackListener != null) {
                    chatCallbackListener.onListenTyping(data);
                }
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onListenTyping(data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener listenGroupTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "listenGroupTyping: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                if (groupChatCallbackListener != null) {
                    groupChatCallbackListener.onListenGroupTyping(data);
                }
                if (groupRecentReceivedListener != null) {
                    groupRecentReceivedListener.onListenGroupTyping(data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener blockStatus = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "blockStatus: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String senderId = data.getString(Constants.TAG_SENDER_ID);
                String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                String type = data.getString(Constants.TAG_TYPE);
                dbhelper.updateBlockStatus(senderId, Constants.TAG_BLOCKED_ME, type);
                if (chatCallbackListener != null) {
                    chatCallbackListener.onBlockStatus(data);
                }
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onBlockStatus(data);
                }
                if (selectContactListener != null) {
                    selectContactListener.onBlockStatus(data);
                }
                EventBus.getDefault().post(new UserBlockEvent(data));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener userImageChange = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.v(TAG, "userImageChange: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String user_id = data.getString(Constants.TAG_USER_ID);
                String user_image = data.getString(Constants.TAG_USER_IMAGE);
                dbhelper.updateBlockStatus(user_id, Constants.TAG_USER_IMAGE, user_image);
                if (chatCallbackListener != null) {
                    chatCallbackListener.onUserImageChange(user_id, user_image);
                }
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onUserImageChange(user_id, user_image);
                }
                if (selectContactListener != null) {
                    selectContactListener.onUserImageChange(user_id, user_image);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener groupInvitation = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d(TAG, "groupInvitation= " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String groupId = data.getString(TAG_ID);
                String groupAdminId = data.getString(Constants.TAG_GROUP_ADMIN_ID);
                String modifiedBy = data.optString(Constants.TAG_MODIFIED_BY);
                String groupName = data.getString(Constants.TAG_GROUP_NAME);
                String groupImage = data.getString(Constants.TAG_GROUP_IMAGE);
                String createdAt = data.getString(Constants.TAG_CREATED_AT);
                boolean isNewGroup = !dbhelper.isGroupIdExist(groupId);
                dbhelper.createGroup(groupId, groupAdminId, groupName, createdAt, groupImage);
                if (!isNewGroup) {
                    dbhelper.deleteMembersFromGroup(groupId);
                }
                addGroupId(groupId);
                JSONArray membersArray = new JSONArray(data.getString(Constants.TAG_GROUP_MEMBERS));
                for (int i = 0; i < membersArray.length(); i++) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject = membersArray.getJSONObject(i);
                        String memberId = jsonObject.getString(Constants.TAG_MEMBER_ID);
                        String memberRole = jsonObject.getString(Constants.TAG_MEMBER_ROLE);
                        if (!dbhelper.isUserExist(memberId)) {
                            String memberKey = groupId + memberId;
                            getUserData(memberKey, groupId, memberId, memberRole);
                        } else {
                            String memberKey = groupId + memberId;
                            dbhelper.createGroupMembers(memberKey, groupId, memberId, memberRole);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                RandomString randomString = new RandomString(10);
                String messageId = groupId + randomString.nextString();
                String messageId2 = null;

                if (isNewGroup) {
                    dbhelper.addGroupMessages(messageId, groupId, groupAdminId, groupAdminId, "create_group", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), createdAt, "", "");
                    if (!groupAdminId.equals(GetSet.getUserId()) && !modifiedBy.equals(GetSet.getUserId())) {
                        messageId2 = groupId + randomString.nextString();
                        dbhelper.addGroupMessages(messageId2, groupId, groupAdminId, modifiedBy, "add_member", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), createdAt, ApplicationClass.encryptMessage(""), "");
                    }
                } else if (!groupAdminId.equals(GetSet.getUserId()) && !modifiedBy.equals(GetSet.getUserId())) {
                    messageId2 = groupId + randomString.nextString();
                    dbhelper.addGroupMessages(messageId2, groupId, groupAdminId, modifiedBy, "add_member", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), currentUTCTime, ApplicationClass.encryptMessage(""), "");
                }

                int unseenCount = dbhelper.getUnseenGroupMessagesCount(groupId);
                dbhelper.addGroupRecentMsg(groupId, messageId2 != null ? messageId2 : messageId, groupAdminId, currentUTCTime, "" + unseenCount);
                try {
                    JSONObject jobj = new JSONObject();
                    jobj.put(Constants.TAG_GROUP_ID, data.getString(TAG_ID));
                    jobj.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                    joinGroup(jobj);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (groupRecentReceivedListener != null) {
                    groupRecentReceivedListener.onGroupCreated();
                }

                if (onGroupCreatedListener != null) {
                    onGroupCreatedListener.onGroupCreated(data);
                }

                if (onUpdateTabIndication != null) {
                    onUpdateTabIndication.updateIndication();
                }

                clearGroupInvitations(groupId);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener storyDeleted = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.i(TAG, "storyDeleted: " + args[0]);
            try {
                JSONObject data = new JSONObject(String.valueOf(args[0]));
                /*String id = data.getString(Constants.TAG_STORY_ID).replaceAll("[\\[\\](){}]","");
                id = id.replaceAll("^\"|\"$", "");
                dbhelper.deleteStatus(id);
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onDeleteStatus(id);
                }*/
                deleteStatus(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener storyViewed = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "storyViewed: " + args[0]);
            try {
                JSONObject jobj = (JSONObject) args[0];
                JSONArray array = jobj.getJSONArray("viewers");
                for (int i = 0; i < array.length(); i++) {
                    JSONObject data = array.getJSONObject(i);
                    String id = data.getString(Constants.TAG_STORY_ID);
                    if (dbhelper.isStoryExists(id)) {
                        dbhelper.createStatusView(id, data.getString(Constants.TAG_SENDER_ID));
                        clearStoryViewed(id);
                        if (storyListener != null) {
                            storyListener.onStoryViewed(id);
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener messageFromGroup = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.e(TAG, "messageFromGroup: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                if (!dbhelper.isGroupExist(data.getString(Constants.TAG_GROUP_ID))) {
                    getGroupInfo(data, data.getString(Constants.TAG_GROUP_ID), true);
                } else if (data.getString(Constants.TAG_MESSAGE_TYPE).equals("add_member")) {
                    getGroupInfo(data, data.getString(Constants.TAG_GROUP_ID), false);
                } else {
                    setGroupMsgListener(data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener newAdmin = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject jsonObject = (JSONObject) args[0];
            Log.i(TAG, "newAdmin: " + jsonObject.toString());

            try {
                String memberKey = jsonObject.getString(TAG_GROUP_ID) + jsonObject.getString(TAG_MEMBER_ID);
                dbhelper.updateGroupMembers(memberKey, jsonObject.getString(TAG_GROUP_ID), jsonObject.getString(TAG_MEMBER_ID), jsonObject.getString(TAG_MEMBER_ROLE));

                if (newAdminCreatedListener != null) {
                    newAdminCreatedListener.onNewAdminCreated();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener memberExited = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            try {
                JSONObject data = (JSONObject) args[0];
                Log.i(TAG, "memberExited: " + data.toString());
                String groupId = data.getString(Constants.TAG_GROUP_ID);
                String memberId = data.getString(Constants.TAG_MEMBER_ID);
                dbhelper.deleteFromGroup(groupId, memberId);
                ApplicationClass.groupList.remove(groupId);
                if (memberId.equals(GetSet.getUserId())) {
                    emitMemberLeft(memberId, groupId);
                }
                if (groupInfoSocketListener != null) {
                    groupInfoSocketListener.onMemberExited(data);
                }
                if (groupChatCallbackListener != null) {
                    groupChatCallbackListener.onMemberExited(data);
                }
                if (groupRecentReceivedListener != null) {
                    groupRecentReceivedListener.onMemberExited(data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private void emitMemberLeft(String memberId, String groupId) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("user_id", memberId);
            jsonObject.put(TAG_GROUP_ID, groupId);
            if (mSocket.connected()) {
                Log.d(TAG, "emitMemberLeft: " + jsonObject);
                mSocket.emit("memberleft", jsonObject);
            } else {
                showToast("emitMemberLeft");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private Emitter.Listener groupModified = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "groupModified: " + data);

            /*try {
                dbhelper.updateGroup(data.getString(TAG_ID),
                        data.getString(Constants.TAG_GROUP_ADMIN_ID),
                        data.getString(Constants.TAG_GROUP_NAME),
                        data.getString(Constants.TAG_CREATED_AT),
                        data.has(Constants.TAG_GROUP_IMAGE) ? data.getString(Constants.TAG_GROUP_IMAGE) : "");

                JSONArray jsonArray = new JSONArray(data.getString(Constants.TAG_GROUP_MEMBERS));
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String memberId = jsonObject.getString(Constants.TAG_MEMBER_ID);
                    String memberRole = jsonObject.getString(Constants.TAG_MEMBER_ROLE);
                    if (!dbhelper.isUserExist(memberId)) {
                        getUserInfo(memberId);
                    }
                    String memberKey = data.getString(TAG_ID) + jsonObject.getString(TAG_MEMBER_ID);
                    dbhelper.updateGroupMembers(memberKey, data.getString(Constants.TAG_ID), memberId, memberRole);
                }

                if (groupRecentReceivedListener != null) {
                    groupRecentReceivedListener.onGroupModified(data);
                }
            } catch (JSONException e) {
                Log.e(TAG, "groupModified: " + e.getMessage());
                e.printStackTrace();
            }*/

        }
    };
    private Emitter.Listener makeprivate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "makeprivate: " + data);
            try {
                if (data.getString(TAG_USER_ID).equalsIgnoreCase(GetSet.getUserId())) {
                    editor.putString("privacyprofileimage", data.getString(TAG_PRIVACY_PROFILE));
                    editor.putString("privacylastseen", data.getString(TAG_PRIVACY_LAST_SEEN));
                    editor.putString("privacyabout", data.getString(TAG_PRIVACY_ABOUT));
                    editor.commit();

                    GetSet.setPrivacyprofileimage(pref.getString("privacyprofileimage", Constants.TAG_EVERYONE));
                    GetSet.setPrivacylastseen(pref.getString("privacylastseen", Constants.TAG_EVERYONE));
                    GetSet.setPrivacyabout(pref.getString("privacyabout", Constants.TAG_EVERYONE));
                } else {
                    dbhelper.updateUserPrivacy(data);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (recentChatReceivedListener != null) {
                recentChatReceivedListener.onPrivacyChanged(data);
            }
            if (chatCallbackListener != null) {
                chatCallbackListener.onPrivacyChanged(data);
            }
            if (selectContactListener != null) {
                selectContactListener.onPrivacyChanged(data);
            }
            if (userProfileListener != null) {
                userProfileListener.onPrivacyChanged(data);
            }
        }
    };
    private Emitter.Listener channelCreated = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject jsonObject = (JSONObject) args[0];
            Log.i(TAG, "channelCreated: " + jsonObject);
            try {
                String channelId = jsonObject.getString(TAG_ID);
                String channelName = jsonObject.getString(Constants.TAG_CHANNEL_NAME);
                String channelDes = jsonObject.getString(Constants.TAG_CHANNEL_DES);
                String channelImage = jsonObject.getString(Constants.TAG_CHANNEL_IMAGE);
                String channelType = jsonObject.getString(Constants.TAG_CHANNEL_TYPE);
                String adminId = jsonObject.getString(Constants.TAG_CHANNEL_ADMIN_ID);
                String totalSubscriber = jsonObject.getString(Constants.TAG_TOTAL_SUBSCRIBERS);
                String createdAt = jsonObject.getString(Constants.TAG_CREATED_TIME);

                dbhelper.addChannel(channelId, channelName, channelDes, channelImage, channelType, adminId, "", totalSubscriber, createdAt, Constants.TAG_USER_CHANNEL, "", "", "0");

                String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                RandomString randomString = new RandomString(10);
                String messageId = channelId + randomString.nextString();

                String deliveryStatus = "";
                int unreadCount = 0;
                if (adminId.equalsIgnoreCase(GetSet.getUserId())) {
                    deliveryStatus = "read";
                    unreadCount = 0;
                } else {
                    unreadCount = dbhelper.getUnseenChannelMessagesCount(channelId);
                }

                if (!dbhelper.isChannelIdExistInMessages(channelId)) {
                    dbhelper.addChannelMessages(channelId, Constants.TAG_CHANNEL, messageId, "create_channel", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), currentUTCTime, ApplicationClass.encryptMessage(""), deliveryStatus);

                    dbhelper.addChannelRecentMsgs(channelId, messageId, currentUTCTime, "" + unreadCount);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (channelCallbackListener != null) {
                channelCallbackListener.onChannelCreated(jsonObject);
            }

            if (channelRecentReceivedListener != null) {
                channelRecentReceivedListener.onChannelCreated(jsonObject);
            }
        }
    };
    private Emitter.Listener receiveChannelInvitation = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject jsonObject = (JSONObject) args[0];
            Log.i(TAG, "receiveChannelInvitation: " + jsonObject);
            try {
                if (!dbhelper.isChannelExist(jsonObject.getString(Constants.TAG_ID))) {
                    dbhelper.addChannel(jsonObject.getString(Constants.TAG_ID), jsonObject.getString(Constants.TAG_CHANNEL_NAME), jsonObject.getString(Constants.TAG_CHANNEL_DES), jsonObject.getString(Constants.TAG_CHANNEL_IMAGE), jsonObject.getString(Constants.TAG_CHANNEL_TYPE), jsonObject.getString(Constants.TAG_CHANNEL_ADMIN_ID), "", jsonObject.getString(Constants.TAG_TOTAL_SUBSCRIBERS), jsonObject.getString(Constants.TAG_CREATED_TIME), Constants.TAG_USER_CHANNEL, "", "", "0");
                    String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                    RandomString randomString = new RandomString(10);
                    String messageId = jsonObject.getString(Constants.TAG_ID) + randomString.nextString();

                    dbhelper.addChannelMessages(jsonObject.getString(Constants.TAG_ID), Constants.TAG_CHANNEL, messageId, "create_channel", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), currentUTCTime, ApplicationClass.encryptMessage(""), "");
                    int unseenCount = dbhelper.getUnseenChannelMessagesCount(jsonObject.getString(Constants.TAG_ID));
                    dbhelper.addChannelRecentMsgs(jsonObject.getString(Constants.TAG_ID), messageId, currentUTCTime, "" + unseenCount);
                } else {
                    ChannelResult.Result channelData = dbhelper.getChannelInfo(jsonObject.getString(TAG_ID));
                    dbhelper.addChannel(jsonObject.getString(Constants.TAG_ID), jsonObject.getString(Constants.TAG_CHANNEL_NAME), jsonObject.getString(Constants.TAG_CHANNEL_DES), jsonObject.getString(Constants.TAG_CHANNEL_IMAGE), jsonObject.getString(Constants.TAG_CHANNEL_TYPE), jsonObject.getString(Constants.TAG_CHANNEL_ADMIN_ID), "", jsonObject.getString(Constants.TAG_TOTAL_SUBSCRIBERS), jsonObject.getString(Constants.TAG_CREATED_TIME), Constants.TAG_USER_CHANNEL, channelData.subscribeStatus != null ? channelData.subscribeStatus : "", channelData.blockStatus != null ? channelData.blockStatus : "", channelData.report != null ? channelData.report : "0");
                }
                clearChannelInvites(jsonObject.getString(Constants.TAG_ID));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (channelRecentReceivedListener != null) {
                channelRecentReceivedListener.onChannelInviteReceived(jsonObject);
            }
        }
    };
    private Emitter.Listener msgfromadminchannels = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {

            Log.i(TAG, "msgFromAdminChannels: " + args[0]);
            JSONObject jObj = (JSONObject) args[0];
            try {
                if (!dbhelper.isChannelExist(jObj.getString(Constants.TAG_CHANNEL_ID))) {
                    getAdminChannels(jObj);
                } else {
                    setAdminChannelMessages(jObj);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener receiveStory = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.i(TAG, "receiveStory: " + args[0]);
            JSONObject jObj = (JSONObject) args[0];
            try {
                if (dbhelper.isUserExist(jObj.getString(Constants.TAG_SENDER_ID))) {
                    addStatus(jObj);
                    if (recentChatReceivedListener != null) {
                        recentChatReceivedListener.onStatusReceived();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener channelblocked = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {

            Log.i(TAG, "channelBlocked: " + args[0]);
            JSONObject jObj = (JSONObject) args[0];
            try {
                if (dbhelper.isChannelExist(jObj.getString(Constants.TAG_CHANNEL_ID))) {
                    dbhelper.updateChannelData(jObj.getString(Constants.TAG_CHANNEL_ID), Constants.TAG_BLOCK_STATUS, jObj.getString(Constants.TAG_STATUS));

                    if (channelChatCallbackListener != null) {
                        channelChatCallbackListener.onChannelBlocked(jObj.getString(Constants.TAG_CHANNEL_ID));
                    }

                    if (channelRecentReceivedListener != null) {
                        channelRecentReceivedListener.onChannelBlocked(jObj.getString(Constants.TAG_CHANNEL_ID));
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener deletechannel = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.i(TAG, "deleteChannel: " + args[0]);
            String channelId = "" + args[0];
            dbhelper.deleteChannel(channelId);
            dbhelper.deleteChannelMessages(channelId);
            dbhelper.deleteChannelRecentMessages(channelId);
            if (channelChatCallbackListener != null) {
                channelChatCallbackListener.onChannelDeleted();
            }

            if (channelRecentReceivedListener != null) {
                channelRecentReceivedListener.onChannelDeleted();
            }


        }
    };
    private Emitter.Listener messageFromChannel = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.e(TAG, "messageFromChannel: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                setChannelMsgListener(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private Emitter.Listener groupDeleted = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            JSONObject jsonObject = (JSONObject) args[0];
            Log.i(TAG, "groupDeleted: " + jsonObject);
            try {
                String groupId = jsonObject.getString(TAG_GROUP_ID);
                dbhelper.deleteGroup(groupId);
                dbhelper.deleteMembers(groupId);
                dbhelper.deleteGroupMessages(groupId);
                dbhelper.deleteGroupRecentChats(groupId);
                removeGroupId(groupId);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (groupRecentReceivedListener != null) {
                groupRecentReceivedListener.onGroupDeleted(jsonObject);
            }
        }
    };
    //callCreated created event.
    private Emitter.Listener callCreated = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.i(TAG, "callCreated: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                String userId = data.optString("caller_id", "");
                if (dbhelper.isUserExist(userId)) {
                    ContactsData.Result results = dbhelper.getContactDetail(userId);
                    if (!results.blockedbyme.equals(Constants.TAG_BLOCK)) onCallReceive(data);
                } else {
                    getUserInfo(userId, data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * Listener for receive Status while cback to online
     */

    private Emitter.Listener recentcalls = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "recentCalls: " + args[0]);
            try {
                JSONObject data = (JSONObject) args[0];
                JSONObject messageObject = data.getJSONObject(Constants.TAG_MESSAGE_DATA);
                String userId = messageObject.optString(Constants.TAG_CALLER_ID, "");
                if (dbhelper.isUserExist(userId)) {
                    ContactsData.Result results = dbhelper.getContactDetail(userId);
                    if (!results.blockedbyme.equals(Constants.TAG_BLOCK)) onCallReceive(data);
                } else {
                    getUserInfo(userId, data);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private SocketConnection(Context context) {
        mContext = context;
        dbhelper = DatabaseHandler.getInstance(context);
        storageManager = StorageManager.getInstance(context);
        dateUtils = DateUtils.getInstance(context);
        pref = mContext.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        start();
    }

    public static synchronized SocketConnection getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SocketConnection(context);
        }
        return mInstance;
    }

    public static void resetSocket() {
        if (mSocket != null) {
            mSocket.disconnect();
        }
        mInstance = null;
    }

    public static Socket getMSocket() {
        return mSocket;
    }

    @Override
    public void run() {
        try {

            /*If the Server is SSL enabled please uncomment the below lines*/

            /*SSLContext mySSLContext = SSLContext.getInstance("TLS");
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[]{};
                }

                public void checkClientTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
            }};

            X509TrustManager myX509TrustManager = new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[]{};
                }

                public void checkClientTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
            };

            mySSLContext.init(null, trustAllCerts, null);

            HostnameVerifier myHostnameVerifier = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .hostnameVerifier(myHostnameVerifier)
                    .sslSocketFactory(mySSLContext.getSocketFactory(), myX509TrustManager)
                    .build();

            // default settings for all sockets
            IO.setDefaultOkHttpWebSocketFactory(okHttpClient);
            IO.setDefaultOkHttpCallFactory(okHttpClient);

            // set as an option
            IO.Options opts = new IO.Options();
            opts.callFactory = okHttpClient;
            opts.webSocketFactory = okHttpClient;
             mSocket = IO.socket(Constants.SOCKETURL, opts);*/

            /*Comment the next one line if the server is SSL Enabled*/
            IO.Options opts = new IO.Options();
            opts.transports = new String[]{WebSocket.NAME}; //or Polling.NAME
            opts.reconnection = true;
            mSocket = IO.socket(Constants.SOCKET_URL, opts);
            mSocket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    Log.v(TAG, "EVENT_CONNECT");
                    if (GetSet.isLogged()) {
                        joinChatBox();
                    }
                }
            }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    Log.e(TAG, "EVENT_DISCONNECT");
                }
            });
//            mSocket.on("pong", pong);
            mSocket.on("chatboxjoined", chatBoxJoined);
            mSocket.on("receivechat", receiveChat);
            mSocket.on("privatechatsend", privateChatSend);
            mSocket.on("receivedstatus", receivedStatus);
            mSocket.on("readstatus", readStatus);
            mSocket.on("onlinestatus", onlineStatus);
            mSocket.on("listentyping", listenTyping);
            mSocket.on("blockstatus", blockStatus);
            mSocket.on("offlinereceivedstatus", offlineReceivedStatus);
            mSocket.on("offlinereadstatus", offlinereadstatus);
            mSocket.on(GroupEvent.GROUP_INVITATION, groupInvitation);
            mSocket.on(GroupEvent.CHANGE_USER_IMAGE, userImageChange);
            mSocket.on(GroupEvent.MESSAGE_FROM_GROUP, messageFromGroup);
            mSocket.on(GroupEvent.LISTEN_GROUP_TYPING, listenGroupTyping);
            mSocket.on(GroupEvent.MEMBER_EXITED, memberExited);
            mSocket.on(GroupEvent.GROUP_MODIFIED, groupModified);
            mSocket.on(ChannelEvent.MAKE_PRIVATE, makeprivate);
            mSocket.on(ChannelEvent.CHANNEL_CREATED, channelCreated);
            mSocket.on(ChannelEvent.MESSAGE_FROM_CHANNEL, messageFromChannel);
            mSocket.on(ChannelEvent.MESSAGE_FROM_ADMIN_CHANNEL, msgfromadminchannels);
            mSocket.on(ChannelEvent.DELETE_CHANNEL, deletechannel);
            mSocket.on(ChannelEvent.RECEIVE_CHANNEL_INVITATION, receiveChannelInvitation);
            mSocket.on(ChannelEvent.BLOCK_CHANNEL, channelblocked);
            mSocket.on(StoryEvent.RECEIVE_STORY, receiveStory);
            mSocket.on(StoryEvent.STORY_DELETED, storyDeleted);
            mSocket.on(StoryEvent.STORY_VIEWED, storyViewed);
//            mSocket.on("newAdmin", newAdmin);
            mSocket.on(Socket.EVENT_CONNECT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    if (GetSet.isLogged()) {
                        Log.v(TAG, "EVENT_CONNECT_ERROR: " + args[0]);
                    }
                }
            });
            mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    if (GetSet.isLogged()) {
                        Log.v("EVENT_CONNECT_TIMEOUT", "EVENT_CONNECT_TIMEOUT");
                    }
                }
            });
            mSocket.on(Socket.EVENT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    if (GetSet.isLogged()) {
                        Log.v("EVENT_ERROR", "EVENT_ERROR");
                    }
                }
            });
            mSocket.on("newAdmin", newAdmin);
            mSocket.on("groupDeleted", groupDeleted);
            mSocket.on(CallEvent.CALL_CREATED, callCreated);
            mSocket.on(CallEvent.RECENT_CALLS, recentcalls);
            mSocket.connect();
            Log.v(TAG, "EVENT_SOCKET_CONNECT");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } /*catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }*/
    }

    public void disconnect() {
        mSocket.disconnect();
        mSocket.off("chatboxjoined", chatBoxJoined);
        mSocket.off("receivechat", receiveChat);
        mSocket.off("privatechatsend", privateChatSend);
        mSocket.off("receivedstatus", receivedStatus);
        mSocket.off("readstatus", readStatus);
        mSocket.off("onlinestatus", onlineStatus);
        mSocket.off("listentyping", listenTyping);
        mSocket.off("blockstatus", blockStatus);
        mSocket.off("offlinereceivedstatus", offlineReceivedStatus);
        mSocket.off("offlinereadstatus", offlinereadstatus);
        mSocket.off(GroupEvent.GROUP_INVITATION, groupInvitation);
        mSocket.off(GroupEvent.CHANGE_USER_IMAGE, userImageChange);
        mSocket.off(GroupEvent.MESSAGE_FROM_GROUP, messageFromGroup);
        mSocket.off(GroupEvent.LISTEN_GROUP_TYPING, listenGroupTyping);
        mSocket.off(GroupEvent.MEMBER_EXITED, memberExited);
        mSocket.off(GroupEvent.GROUP_MODIFIED, groupModified);
        mSocket.off(ChannelEvent.MAKE_PRIVATE, makeprivate);
        mSocket.off(ChannelEvent.CHANNEL_CREATED, channelCreated);
        mSocket.off(ChannelEvent.MESSAGE_FROM_CHANNEL, messageFromChannel);
        mSocket.off(ChannelEvent.MESSAGE_FROM_ADMIN_CHANNEL, msgfromadminchannels);
        mSocket.off(ChannelEvent.RECEIVE_CHANNEL_INVITATION, receiveChannelInvitation);
        mSocket.off(ChannelEvent.BLOCK_CHANNEL, channelblocked);
        mSocket.off(StoryEvent.RECEIVE_STORY, receiveStory);
        mSocket.off(StoryEvent.STORY_DELETED, storyDeleted);
        mSocket.off(StoryEvent.STORY_VIEWED, storyViewed);
        mSocket.on(CallEvent.CALL_CREATED, callCreated);
        mSocket.on(CallEvent.RECENT_CALLS, recentcalls);
//        mSocket.off("pong", pong);
        mSocket.off(Socket.EVENT_CONNECT);
        mSocket.off(Socket.EVENT_DISCONNECT);
        mInstance = null;
        Log.v(TAG, "disconnect");
    }

    private void joinChatBox() {
        try {
            JSONObject join = new JSONObject();
            join.put("user_id", GetSet.getUserId());
            if (mSocket.connected()) {
                Log.d(TAG, "joinChatBox: " + join);
                mSocket.emit("chatbox", join);
            } else {
                showToast("joinChatBox");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void goLive() {
        if (mSocket.connected()) {
            try {
                JSONObject goLive = new JSONObject();
                goLive.put("user_id", GetSet.getUserId());
                goLive.put("groups", "" + new JSONArray(ApplicationClass.groupList));
                goLive.put("channels", "" + new JSONArray(ApplicationClass.channelList));
                Log.d(TAG, "goLive: " + goLive);
                mSocket.emit("golive", goLive);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            showToast("goLive");
        }
    }

    public void goAway(List<String> groupList) {
        try {
            JSONObject goAway = new JSONObject();
            goAway.put("user_id", GetSet.getUserId());
            goAway.put("groups", groupList);
            if (mSocket.connected()) {
                Log.d(TAG, "goAway: " + goAway);
                mSocket.emit("goaway", goAway);
            } else {
                showToast("goAway");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getReadReceipts() {
        if (GetSet.isLogged()) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(TAG_SENDER_ID, GetSet.getUserId());
                if (mSocket.connected()) {
                    Log.d(TAG, "getReadReceipts: " + jsonObject);
                    mSocket.emit("readreceipts", jsonObject);
                } else {
                    showToast("getReadReceipts");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void joinGroups() {
        if (GetSet.isLogged()) {
            List<String> groupList = dbhelper.getGroupIdList();
            for (String groupId : groupList) {
                try {
                    JSONObject jobj = new JSONObject();
                    jobj.put(Constants.TAG_GROUP_ID, groupId);
                    jobj.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                    joinGroup(jobj);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void startChat(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "startChat: " + jsonObject);
            mSocket.emit("startchat", jsonObject);
        } else {
            showToast("startChat");
        }
    }

    public void chatReceived(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.v(TAG, "chatReceived: " + jsonObject);
            mSocket.emit("chatreceived", jsonObject);
        } else {
            showToast("chatReceived");
        }
    }

    public void chatViewed(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "chatViewed: " + jsonObject);
            mSocket.emit("chatviewed", jsonObject);
        } else {
            showToast("chatViewed");
        }
    }

    public void online(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            mSocket.emit("online", jsonObject);
        } else {
            showToast("online");
        }
    }

    public void typing(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            mSocket.emit("typing", jsonObject);
        } else {
            showToast("typing");
        }
    }

    public void block(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "block: " + jsonObject);
            mSocket.emit("block", jsonObject);
        } else {
            showToast("block");
        }
    }

    public void createCall(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "createCall: " + jsonObject);
            mSocket.emit(CallEvent.CREATE_CALL, jsonObject);
        } else {
            showToast("createCall");
        }
    }

    public MessagesData getMessagesByType(JSONObject data) {
        MessagesData mdata = new MessagesData();
        try {
            JSONObject jobj = data.getJSONObject("message_data");
            mdata = Utils.getMessageFromJson(jobj);

            if (mdata.message_type != null && mdata.message_type.equals(Constants.TAG_ISDELETE)) {
                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                if (ApplicationClass.isStringNotNull(mdata.attachment)) {
                    storageManager.checkDeleteFile(mdata.attachment, mdata.message_type, "receive");
                    dbhelper.updateMessageData(mdata.message_id, Constants.TAG_ATTACHMENT, "");
                    dbhelper.updateMessageData(mdata.message_id, Constants.TAG_THUMBNAIL, "");
                }

            } else {
                if (!dbhelper.isMessageIdExist(mdata.message_id)) {
                    MessagesData tempMessageData = Utils.getMessageData(GetSet.getUserId() + mdata.user_id, mdata.message_id, mdata.user_id, "", mdata.message_type, mdata.message, mdata.attachment, mdata.lat, mdata.lon, mdata.contact_name, mdata.contact_phone_no, mdata.contact_country_code, mdata.chat_time, GetSet.getUserId(), mdata.user_id, "sent", mdata.thumbnail, mdata.statusData, "");

                    dbhelper.addMessageData(tempMessageData, false);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return mdata;
    }

    private void setMessagesListener(MessagesData messagesData) {
        try {
            int unseenCount = dbhelper.getUnseenMessagesCount(messagesData.user_id);
            if (ApplicationClass.isStringNotNull(messagesData.message_type) && messagesData.message_type.equals(Constants.TAG_ISDELETE)) {
                if (dbhelper.isRecentMessageIdExist(messagesData.message_id)) {
                    dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.user_id, messagesData.user_id, messagesData.message_id, messagesData.chat_time, String.valueOf(unseenCount));
                }
            } else {
                MessagesData lastMessage = dbhelper.getRecentMessage(messagesData.user_id);
                if (lastMessage != null && !TextUtils.isEmpty(lastMessage.message_id)) {
                    dbhelper.addRecentMessages(GetSet.getUserId() + lastMessage.user_id, lastMessage.user_id, lastMessage.message_id, lastMessage.chat_time, "" + unseenCount);
                } else {
                    dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.user_id, messagesData.user_id, messagesData.message_id, messagesData.chat_time, "" + unseenCount);
                }
            }

            // To acknowledge the message has been delivered
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_SENDER_ID, messagesData.user_id);
            jsonObject.put(Constants.TAG_RECEIVER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_MESSAGE_ID, messagesData.message_id);
            chatReceived(jsonObject);

            if (chatCallbackListener != null) {
                chatCallbackListener.onReceiveChat(messagesData);
            }
            if (recentChatReceivedListener != null) {
                recentChatReceivedListener.onRecentChatReceived();
            }
            if (onUpdateTabIndication != null) {
                onUpdateTabIndication.updateIndication();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setRecentListener(boolean isRefresh) {
        if (recentChatReceivedListener != null) {
            recentChatReceivedListener.onRecentChatReceived();
        }
        if (chatCallbackListener != null) {
            chatCallbackListener.onGetUpdateFromDB(isRefresh);
        }
        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    public void setRecentListener() {
        if (recentChatReceivedListener != null) {
            recentChatReceivedListener.onRecentChatReceived();
        }
        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    public void setUploadingListen(String chatType, String message_id, String attachment, String progress, String localFileName) {
        switch (chatType) {
            case "chat":
                if (chatCallbackListener != null) {
                    Log.d(TAG, "setUploadingListen: " + progress);
                    chatCallbackListener.onUploadListen(message_id, attachment, progress);
                }
                break;
            case "group":
                if (groupChatCallbackListener != null) {
                    groupChatCallbackListener.onUploadListen(message_id, attachment, progress);
                }
                break;
            case Constants.TAG_CHANNEL:
                if (channelChatCallbackListener != null) {
                    channelChatCallbackListener.onUploadListen(message_id, attachment, progress);
                }
                break;
            case "status":
                if (statusUploadListener != null) {
                    statusUploadListener.onUploadListen(attachment, progress, localFileName);
                }
                break;
        }

    }

    public void setExternalUploadListener(String progress) {
        if (externalUploadListener != null) {
            externalUploadListener.onExternalUploaded(progress);
        }
    }

    private void getUserData(boolean isNewGroup, JSONObject data, String memberKey, GroupData groupData, String memberId, String memberRole, boolean refreshChatActivity) {
        String groupId = groupData.groupId;
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));
                        dbhelper.createGroupMembers(memberKey, groupId, memberId, memberRole);
                        if (refreshChatActivity) {
                            updateGroup(isNewGroup, groupData, groupId);
                            setGroupMsgListener(data);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserData: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getUserData(String memberKey, String groupId, String memberId, String memberRole) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                try {
                    Log.v(TAG, "getUserData: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));
                        dbhelper.createGroupMembers(memberKey, groupId, memberId, memberRole);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "getUserData: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.v(TAG, "getUserData Failed" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getGroupInfo(JSONObject data, String groupId, boolean isNewGroup) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(groupId);
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GroupResult> call = apiInterface.getGroupInfo(GetSet.getToken(), jsonArray.toString());
        call.enqueue(new Callback<GroupResult>() {
            @Override
            public void onResponse(Call<GroupResult> call, Response<GroupResult> response) {
                if (response.isSuccessful()) {
                    GroupResult userdata = response.body();
                    if (userdata.status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        for (GroupData groupData : userdata.result) {
                            dbhelper.createGroup(groupData.groupId, groupData.groupAdminId, groupData.groupName, groupData.createdAt, groupData.groupImage);
                            addGroupId(groupData.groupId);
                            if (!isNewGroup) {
                                dbhelper.deleteMembersFromGroup(groupData.groupId);
                            }
                            int membersCount = 0;
                            for (GroupData.GroupMembers groupMember : groupData.groupMembers) {
                                membersCount++;
                                if (!dbhelper.isUserExist(groupMember.memberId)) {
                                    String memberKey = groupData.groupId + groupMember.memberId;
                                    getUserData(isNewGroup, data, memberKey, groupData, groupMember.memberId, groupMember.memberRole, (membersCount == groupData.groupMembers.size()));
                                } else {
                                    String memberKey = groupData.groupId + groupMember.memberId;
                                    dbhelper.createGroupMembers(memberKey, groupData.groupId, groupMember.memberId, groupMember.memberRole);
//                                    Refresh the chatActivity
                                    if (membersCount == groupData.groupMembers.size()) {
                                        updateGroup(isNewGroup, groupData, groupId);
                                        setGroupMsgListener(data);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<GroupResult> call, Throwable t) {
                Log.v("getGroupInfo Failed", "TEST" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void updateGroup(boolean isNewGroup, GroupData groupData, String groupId) {
        String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = groupData.groupId + randomString.nextString();

        if (isNewGroup) {
            dbhelper.addGroupMessages(messageId, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "create_group", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), groupData.createdAt, ApplicationClass.encryptMessage(""), "");
        }

        int unseenCount = dbhelper.getUnseenGroupMessagesCount(groupData.groupId);
        dbhelper.addGroupRecentMsg(groupData.groupId, messageId, GetSet.getUserId(), currentUTCTime, "" + unseenCount);

        if (!groupData.groupAdminId.equals(GetSet.getUserId())) {
            String messageId2 = groupId + randomString.nextString();
            dbhelper.addGroupMessages(messageId2, groupId, GetSet.getUserId(), groupData.groupAdminId, "add_member", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), groupData.createdAt, ApplicationClass.encryptMessage(""), "");
            unseenCount = dbhelper.getUnseenGroupMessagesCount(groupData.groupId);
            dbhelper.addGroupRecentMsg(groupData.groupId, messageId, GetSet.getUserId(), currentUTCTime, "" + unseenCount);
        }

        if (groupRecentReceivedListener != null) {
            groupRecentReceivedListener.onGroupCreated();
        }
    }

    private void addGroupId(String groupId) {
        if (!ApplicationClass.groupList.contains(groupId)) {
            ApplicationClass.groupList.add(groupId);
            goLive();
        }
    }

    public void removeGroupId(String groupId) {
        ApplicationClass.groupList.remove(groupId);
        goLive();
    }

    private void setGroupMsgListener(JSONObject jsonObject) {

        GroupMessage mData = getGroupMessagesByType(jsonObject);

        if (mData.memberId.equalsIgnoreCase(GetSet.getUserId()) && (mData.messageType.equals("text") || mData.messageType.equals("link") || mData.messageType.equals("image") || mData.messageType.equals(Constants.TAG_GIF) || mData.messageType.equals("audio") || mData.messageType.equals("video") || mData.messageType.equals("document") || mData.messageType.equals("location") || mData.messageType.equals("contact"))) {

        } else if (mData.messageType.equals("admin") && !mData.memberId.equalsIgnoreCase(GetSet.getUserId())) {

        } else if (mData.messageType.equalsIgnoreCase("remove_member") || mData.messageType.equalsIgnoreCase(Constants.TAG_GROUP_JOINED)) {
            int unseenCount = dbhelper.getUnseenGroupMessagesCount(mData.groupId);
            dbhelper.addGroupMessages(mData.messageId, mData.groupId, mData.memberId, mData.groupAdminId, mData.messageType, mData.message, mData.attachment, mData.lat, mData.lon, mData.contactName, mData.contactPhoneNo, mData.contactCountryCode, mData.chatTime, mData.thumbnail, "read");
            dbhelper.addGroupRecentMsg(mData.groupId, mData.messageId, mData.memberId, mData.chatTime, String.valueOf(unseenCount));
            if (groupRecentReceivedListener != null) {
                groupRecentReceivedListener.onGroupRecentReceived();
            }
            if (groupChatCallbackListener != null) {
                groupChatCallbackListener.onGroupChatReceive(mData);
            }
            if (onUpdateTabIndication != null) {
                onUpdateTabIndication.updateIndication();
            }
        } else {
            if (ApplicationClass.isStringNotNull(mData.messageType) && mData.messageType.equals(Constants.TAG_ISDELETE)) {
                int unseenCount = dbhelper.getUnseenGroupMessagesCount(mData.groupId);
                if (dbhelper.isRecentGroupIdExist(mData.messageId)) {
                    dbhelper.addGroupRecentMsg(mData.groupId, mData.messageId, mData.memberId, mData.chatTime, String.valueOf(unseenCount));
                }
                if (ApplicationClass.isStringNotNull(mData.attachment)) {
                    storageManager.checkDeleteFile(mData.attachment, mData.messageType, "receive");
                    dbhelper.updateMessageData(mData.messageId, Constants.TAG_ATTACHMENT, "");
                    dbhelper.updateMessageData(mData.messageId, Constants.TAG_THUMBNAIL, "");
                }
            } else {
                dbhelper.addGroupMessages(mData.messageId, mData.groupId, mData.memberId, mData.groupAdminId, mData.messageType, mData.message, mData.attachment, mData.lat, mData.lon, mData.contactName, mData.contactPhoneNo, mData.contactCountryCode, mData.chatTime, mData.thumbnail, mData.memberId.equals(GetSet.getUserId()) ? "read" : "");
                int unseenCount = dbhelper.getUnseenGroupMessagesCount(mData.groupId);
                dbhelper.addGroupRecentMsg(mData.groupId, mData.messageId, mData.memberId, mData.chatTime, "" + unseenCount);
            }

            if (groupChatCallbackListener != null) {
                groupChatCallbackListener.onGroupChatReceive(mData);
            }
            if (groupRecentReceivedListener != null) {
                groupRecentReceivedListener.onGroupRecentReceived();
            }
            if (onUpdateTabIndication != null) {
                onUpdateTabIndication.updateIndication();
            }
        }

        try {
            JSONObject json = new JSONObject();
            json.put(Constants.TAG_USER_ID, GetSet.getUserId());
            json.put(Constants.TAG_MESSAGE_ID, mData.messageId);
            groupChatReceived(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private GroupMessage getGroupMessagesByType(JSONObject data) {
        GroupMessage groupMessage = new GroupMessage();
        groupMessage = new Gson().fromJson(data.toString(), GroupMessage.class);
            /*groupMessage.groupId = data.optString(TAG_GROUP_ID, "");
            groupMessage.groupName = data.optString(Constants.TAG_GROUP_NAME, "");
            groupMessage.memberId = data.optString(Constants.TAG_MEMBER_ID, "");
            groupMessage.memberName = data.optString(Constants.TAG_MEMBER_NAME, "");
            groupMessage.memberNo = data.optString(Constants.TAG_MEMBER_NO, "");
            groupMessage.messageType = data.optString(Constants.TAG_MESSAGE_TYPE, "");
            groupMessage.message = data.optString(Constants.TAG_MESSAGE, "");
            groupMessage.messageId = data.optString(Constants.TAG_MESSAGE_ID, "");
            groupMessage.chatTime = data.optString(Constants.TAG_CHAT_TIME, "");
            try {
                groupMessage.attachment = "" + data.getJSONArray(Constants.TAG_ATTACHMENT);
            } catch (JSONException e) {
                groupMessage.attachment = data.optString(Constants.TAG_ATTACHMENT, "");
            }
            groupMessage.thumbnail = data.optString(Constants.TAG_THUMBNAIL, "");
            groupMessage.lat = data.optString(Constants.TAG_LAT, "");
            groupMessage.lon = data.optString(Constants.TAG_LON, "");
            groupMessage.contactName = data.optString(Constants.TAG_CONTACT_NAME, "");
            groupMessage.contactPhoneNo = data.optString(Constants.TAG_CONTACT_PHONE_NO, "");
            groupMessage.contactCountryCode = data.optString(Constants.TAG_CONTACT_COUNTRY_CODE, "");
            groupMessage.groupAdminId = data.optString(Constants.TAG_GROUP_ADMIN_ID, "");*/

        switch (groupMessage.messageType) {
            case "subject":
                dbhelper.updateGroupData(groupMessage.groupId, Constants.TAG_GROUP_NAME, groupMessage.groupName);
                break;
            case "group_image":
                dbhelper.updateGroupData(groupMessage.groupId, Constants.TAG_GROUP_IMAGE, groupMessage.attachment);
                break;
            case Constants.TAG_GROUP_JOINED: {
                int groupData = dbhelper.getGroupMemberSize(groupMessage.groupId);
                String memberId = groupMessage.memberId;
                String memberRole;
                if (groupData == 0) {
                    memberRole = ADMIN;
                } else {
                    memberRole = MEMBER;
                }
                String memberKey = groupMessage.groupId + memberId;
                dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, groupMessage.memberId, memberRole);
            }
            break;
            case "add_member": {
                if (!TextUtils.isEmpty(groupMessage.attachment)) {
                    try {
                        JSONArray jsonArray = new JSONArray(groupMessage.attachment);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String memberId = jsonObject.getString(Constants.TAG_MEMBER_ID);
                            String memberRole = jsonObject.getString(Constants.TAG_MEMBER_ROLE);
                            if (!dbhelper.isUserExist(memberId)) {
                                String memberKey = groupMessage.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                getUserData(memberKey, groupMessage.groupId, memberId, memberRole);
                            } else {
                                String memberKey = groupMessage.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, memberId, memberRole);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            break;
            case "left":
            case "remove_member":
                dbhelper.deleteFromGroup(groupMessage.groupId, groupMessage.memberId);
                if (groupMessage.memberId.equals(GetSet.getUserId())) {
                    removeGroupId(groupMessage.groupId);
                }
                break;
            case "admin":
                if (!dbhelper.isUserExist(groupMessage.memberId)) {
                    String memberKey = groupMessage.groupId + groupMessage.memberId;
                    getUserData(memberKey, groupMessage.groupId, groupMessage.memberId, groupMessage.attachment);
                } else {
                    String memberKey = groupMessage.groupId + groupMessage.memberId;
                    dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, groupMessage.memberId, groupMessage.attachment);
                }
                break;
            case "change_number":
                dbhelper.updateContactInfo(groupMessage.memberId, Constants.TAG_COUNTRY_CODE, groupMessage.contactCountryCode);
                dbhelper.updateContactInfo(groupMessage.memberId, Constants.TAG_PHONE_NUMBER, groupMessage.contactPhoneNo);
                break;
            case Constants.TAG_ISDELETE:
                dbhelper.updateGroupMessageData(groupMessage.messageId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                break;
        }
        return groupMessage;
    }

    private void addStatus(JSONObject jsonObject) {
        Log.d(TAG, "addStatus: " + jsonObject);
        try {
            StatusDatas datas = new StatusDatas();
            datas.mType = jsonObject.getString("story_type");
            datas.mStatusId = jsonObject.getString(Constants.TAG_STORY_ID);
            datas.mStatusTime = jsonObject.getString(Constants.TAG_STORY_TIME);
            datas.mAttachment = jsonObject.getString(Constants.TAG_ATTACHMENT);
            datas.mThumbnail = jsonObject.getString(Constants.TAG_THUMBNAIL);
            datas.mMessage = jsonObject.getString(Constants.TAG_MESSAGE);
            datas.mSenderId = jsonObject.getString(Constants.TAG_SENDER_ID);
            datas.mExpiryTime = jsonObject.getString(Constants.TAG_EXPIRY_TIME);
            datas.mMember = jsonObject.getString(Constants.TAG_STORY_MEMBERS);

            //if(dbhelper.isUserExist(datas.mSenderId) && dbhelper.isContactSaved(datas.mSenderId)){
            Log.e("checkupstatus","-"+!dbhelper.isStoryExists(datas.mStatusId));
            if (dbhelper.isUserExist(datas.mSenderId) && !dbhelper.isStoryExists(datas.mStatusId)) {
                dbhelper.createStatus(datas.mStatusId, datas.mStatusTime, datas.mType, datas.mSenderId, datas.mAttachment, datas.mMessage, "0", datas.mThumbnail, datas.mExpiryTime, datas.mMember);
            }

            clearStoryReceived(datas.mStatusId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void deleteStatus(JSONObject jsonObject) {
        try {
            JSONArray array = jsonObject.getJSONArray("story_id");
            for (int i = 0; i < array.length(); i++) {
                String id = array.getString(i);
                id = id.replaceAll("^\"|\"$", "");
                dbhelper.deleteStatus(id);
                clearOfflineStoryReceived(id);
                if (recentChatReceivedListener != null) {
                    recentChatReceivedListener.onDeleteStatus(id);
                }
                if (storyListener != null) {
                    storyListener.onStoryDeleted(id);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void clearOfflineStoryReceived(String storyId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_STORY_ID, storyId);
            if (mSocket != null && mSocket.connected()) {
                mSocket.emit(StoryEvent.CLEAR_OFFLINE_STORY_RECEIVED, jsonObject);
            } else {
                showToast("clearOfflineStoryReceived");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void refreshStoryListener(String storyId) {
        if (recentChatReceivedListener != null) {
            recentChatReceivedListener.onDeleteStatus(storyId);
        }
        if (storyListener != null) {
            storyListener.onStoryDeleted(storyId);
        }
    }

    private void clearStoryViewed(String statusId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_STORY_ID, statusId);
            if (mSocket != null && mSocket.connected()) {
                Log.d(TAG, "clearStoryViewed: " + jsonObject);
                mSocket.emit(StoryEvent.CLEAR_STORY_VIEWED, jsonObject);
            } else {
                showToast("clearStoryReceived");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void clearStoryReceived(String statusId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_STORY_ID, statusId);
            if (mSocket != null && mSocket.connected()) {
                Log.d(TAG, "clearStoryReceived: " + jsonObject);
                mSocket.emit(StoryEvent.STORY_RECEIVED, jsonObject);
            } else {
                showToast("clearStoryReceived");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setAdminChannelMessages(JSONObject jObj) {
        AdminChannelMsg.Result adminMessage = getAdminMessagesByType(jObj);

        if (dbhelper.isChannelExist(adminMessage.channelId)) {
            dbhelper.addChannelMessages(adminMessage.channelId, adminMessage.chatType, adminMessage.messageId, adminMessage.messageType, ApplicationClass.encryptMessage(adminMessage.message), adminMessage.attachment, "", "", "", "", "", adminMessage.messageDate, adminMessage.thumbnail, "");

            int unseenCount = dbhelper.getUnseenChannelMessagesCount(adminMessage.channelId);
            dbhelper.addChannelRecentMsgs(adminMessage.channelId, adminMessage.messageId, adminMessage.messageDate, "" + unseenCount);
        }

        if (channelChatCallbackListener != null) {
            channelChatCallbackListener.onAdminChatReceive(adminMessage);
        }

        if (channelRecentReceivedListener != null) {
            channelRecentReceivedListener.onAdminChatReceive();
        }

        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    private void getAdminChannels(JSONObject jObj) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<AdminChannel> call3 = apiInterface.getAdminChannels(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<AdminChannel>() {
            @Override
            public void onResponse(Call<AdminChannel> call, Response<AdminChannel> response) {
                Log.v(TAG, "getAdminChannels: " + new Gson().toJson(response.body()));
                if (response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                    /*Get Channels from Admin*/
                    for (AdminChannel.Result result : response.body().result) {
                        if (!dbhelper.isChannelExist(result.channelId)) {
                            dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, "", Constants.TAG_PUBLIC, "", "", "", result.createdAt, Constants.TAG_ADMIN_CHANNEL, "", "", "0");
                            if (!dbhelper.isChannelIdExistInMessages(result.channelId)) {
                                String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                                RandomString randomString = new RandomString(10);
                                String messageId = result.channelId + randomString.nextString();
                                dbhelper.addChannelMessages(result.channelId, Constants.TAG_ADMIN_CHANNEL, messageId, "create_channel", ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), "", "", "", result.createdAt, ApplicationClass.encryptMessage(""), "");

                                int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                                dbhelper.addChannelRecentMsgs(result.channelId, messageId, currentUTCTime, "" + unseenCount);
                            }
                        }
                    }
                    setAdminChannelMessages(jObj);
                }
            }

            @Override
            public void onFailure(Call<AdminChannel> call, Throwable t) {
                Log.e(TAG, "getAdminChannels: " + t.getMessage());
                call.cancel();
            }
        });
    }

    public void setRecentGroupListener() {
        if (groupRecentReceivedListener != null) {
            groupRecentReceivedListener.onGroupRecentReceived();
        }
        if (groupChatCallbackListener != null) {
            groupChatCallbackListener.onGetUpdateFromDB();
        }
        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    public void updateGroupInfo(GroupMessage groupMessage) {
        if (groupChatCallbackListener != null) {
            groupChatCallbackListener.onUpdateGroupInfo(groupMessage);
        }
    }

    public void setRecentChannelChatListener() {
        if (channelChatCallbackListener != null) {
            channelChatCallbackListener.onGetUpdateFromDB();
        }

        if (channelRecentReceivedListener != null) {
            channelRecentReceivedListener.onChannelRecentReceived();
        }

        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    public void onStoryReceived() {
        if (recentChatReceivedListener != null) recentChatReceivedListener.onStatusReceived();
    }

    public void onStoryViewed(String storyId) {
        if (storyListener != null) {
            storyListener.onStoryViewed(storyId);
        }
    }

    public void onStoryDeleted(String storyId) {
        if (storyListener != null) {
            storyListener.onStoryDeleted(storyId);
        }
    }

    void getUserProfile(final MessagesData mdata) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), mdata.user_id);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                            name = map.get(Constants.TAG_USER_NAME);

                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));

                        setMessagesListener(mdata);
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserProfile: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void setChannelMsgListener(JSONObject jsonObject) {
        ChannelMessage mdata = getChannelMessagesByType(jsonObject);
        if (mdata.chatType.equalsIgnoreCase(Constants.TAG_CHANNEL)) {
            if (mdata.messageType.equals(Constants.TAG_ISDELETE)) {
                if (mdata.channelAdminId != null && !mdata.channelAdminId.equalsIgnoreCase(GetSet.getUserId())) {
                    setChannelListener(mdata);
                }
            } else {
                if (mdata.channelAdminId != null && !mdata.channelAdminId.equalsIgnoreCase(GetSet.getUserId())) {
                    insertChannelMessages(mdata);
                }
            }
        }
        channelChatReceived(mdata);
    }

    private void channelChatReceived(ChannelMessage channelMessage) {
        OneTimeWorkRequest chatReceivedRequest = new OneTimeWorkRequest.Builder(ChannelChatWorker.class).setInputData(createChannelChatData(channelMessage)).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();
        WorkManager.getInstance(mContext).enqueue(chatReceivedRequest);
    }

    private Data createChannelChatData(ChannelMessage channelMessage) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_CHANNEL_ID, channelMessage.channelId);
        builder.putString(Constants.TAG_MESSAGE_ID, channelMessage.messageId);
        return builder.build();
    }

    private void insertChannelMessages(ChannelMessage result) {

        dbhelper.addChannelMessages(result.channelId, result.chatType, result.messageId, result.messageType, result.message, result.attachment, result.lat, result.lon, result.contactName, result.contactPhoneNo, result.contactCountryCode, result.chatTime, result.thumbnail, "");

        int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
        if (ApplicationClass.isStringNotNull(result.messageType) && result.messageType.equals(Constants.TAG_ISDELETE)) {
            if (dbhelper.isRecentGroupIdExist(result.messageId)) {
                dbhelper.addChannelRecentMsgs(result.channelId, result.messageId, result.chatTime, String.valueOf(unseenCount));
            }
        } else {
            dbhelper.addChannelRecentMsgs(result.channelId, result.messageId, result.chatTime, String.valueOf(unseenCount));
        }
        setChannelListener(result);
    }

    private void setChannelListener(ChannelMessage result) {
        if (channelChatCallbackListener != null) {
            channelChatCallbackListener.onChannelChatReceive(result);
        }
        if (channelRecentReceivedListener != null) {
            channelRecentReceivedListener.onChannelRecentReceived();
        }

        if (onUpdateTabIndication != null) {
            onUpdateTabIndication.updateIndication();
        }
    }

    private ChannelMessage getChannelMessagesByType(JSONObject data) {
        ChannelMessage mdata = new ChannelMessage();
        try {
            mdata.channelId = data.optString(TAG_CHANNEL_ID, "");
            mdata.channelAdminId = data.optString(TAG_ADMIN_ID, "");
            mdata.channelName = data.optString(TAG_CHANNEL_NAME, "");
            mdata.messageType = data.optString(Constants.TAG_MESSAGE_TYPE, "");
            mdata.chatType = data.optString(Constants.TAG_CHAT_TYPE, "");
            mdata.message = data.optString(Constants.TAG_MESSAGE, "");
            mdata.messageId = data.optString(Constants.TAG_MESSAGE_ID, "");
            mdata.chatTime = data.optString(Constants.TAG_CHAT_TIME, "");
            mdata.attachment = data.optString(Constants.TAG_ATTACHMENT, "");
            mdata.thumbnail = data.optString(Constants.TAG_THUMBNAIL, "");
            mdata.lat = data.optString(Constants.TAG_LAT, "");
            mdata.lon = data.optString(Constants.TAG_LON, "");
            mdata.contactName = data.optString(Constants.TAG_CONTACT_NAME, "");
            mdata.contactPhoneNo = data.optString(Constants.TAG_CONTACT_PHONE_NO, "");
            mdata.contactCountryCode = data.optString(Constants.TAG_CONTACT_COUNTRY_CODE, "");
            mdata.progress = data.optString(Constants.TAG_PROGRESS, "");

            if (!dbhelper.isChannelExist(mdata.channelId)) {
                getChannelInfo(mdata.channelId, mdata);
            } else {
                updateChannelData(mdata);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mdata;
    }

    private void updateChannelData(ChannelMessage mdata) {
        switch (mdata.messageType) {
            case "subject":
                dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_NAME, mdata.channelName);
                break;
            case "channel_image":
                dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_IMAGE, mdata.attachment);
                break;
            case "channel_des":
                dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_DES, mdata.message);
                break;
            case Constants.TAG_ISDELETE:
                dbhelper.updateChannelMessageData(mdata.messageId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                if (ApplicationClass.isStringNotNull(mdata.attachment)) {
                    storageManager.checkDeleteFile(mdata.attachment, mdata.messageType, "receive");
                    dbhelper.updateMessageData(mdata.messageId, Constants.TAG_ATTACHMENT, "");
                    dbhelper.updateMessageData(mdata.messageId, Constants.TAG_THUMBNAIL, "");
                }
                break;
        }
    }

    private AdminChannelMsg.Result getAdminMessagesByType(JSONObject data) {
        AdminChannelMsg.Result mdata = new AdminChannelMsg().new Result();
        try {
            mdata.channelId = data.optString(TAG_CHANNEL_ID, "");
            mdata.messageType = data.optString(Constants.TAG_MESSAGE_TYPE, "");
            mdata.message = data.optString(Constants.TAG_MESSAGE, "");
            mdata.messageId = data.optString(Constants.TAG_ID, "");
            mdata.messageDate = data.optString("message_date", "");
            mdata.messageAt = data.optString("message_at", "");
            mdata.channelId = data.optString(Constants.TAG_CHANNEL_ID, "");
            mdata.attachment = data.optString(Constants.TAG_ATTACHMENT, "");
            mdata.thumbnail = data.optString(Constants.TAG_THUMBNAIL, "");
            mdata.chatType = data.optString(Constants.TAG_CHAT_TYPE, "");
            mdata.progress = data.optString(Constants.TAG_PROGRESS, "");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return mdata;
    }

    private void getChannelInfo(String channelId, ChannelMessage mdata) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(channelId);
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
//        Log.i(TAG, "initChannel: " + jsonArray);
        Call<ChannelInfoResponse> call = apiInterface.getChannelInfo(GetSet.getToken(), jsonArray);
        call.enqueue(new Callback<ChannelInfoResponse>() {
            @Override
            public void onResponse(Call<ChannelInfoResponse> call, Response<ChannelInfoResponse> response) {
                if (response.isSuccessful() && response.body().status != null && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                    for (ChannelResult.Result result : response.body().result) {
                        dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, result.channelImage, result.channelType, result.channelAdminId, result.channelAdminName, result.totalSubscribers, result.createdAt, Constants.TAG_USER_CHANNEL, "", result.blockStatus, result.report);
                    }
                    updateChannelData(mdata);
                }
            }

            @Override
            public void onFailure(Call<ChannelInfoResponse> call, Throwable t) {
                Log.e(TAG, "getChannelInfo: " + t.getMessage());
                call.cancel();
            }
        });
    }

    public void setForegroundListener(ForegroundListener listener) {
        foregroundListener = listener;
    }

    public void setApplicationClassListener(ApplicationClassListener listener) {
        applicationClassListener = listener;
    }

    public void setRecentChatReceivedListener(RecentChatReceivedListener listener) {
        recentChatReceivedListener = listener;
    }

    public void setChatCallbackListener(ChatCallbackListener listener) {
        chatCallbackListener = listener;
    }

    public void setGroupChatCallbackListener(GroupChatCallbackListener listener) {
        groupChatCallbackListener = listener;
    }

    public void setForwardActivityListener(ExternalUploadListener listener) {
        externalUploadListener = listener;
    }

    public void setGroupRecentCallbackListener(GroupRecentReceivedListener listener) {
        groupRecentReceivedListener = listener;
    }

    public void setOnGroupCreatedListener(OnGroupCreatedListener listener) {
        onGroupCreatedListener = listener;
    }

    public void setGroupInfoSocketListener(GroupInfoSocketListener listener) {
        groupInfoSocketListener = listener;
    }

    public void setSelectContactListener(SelectContactListener listener) {
        selectContactListener = listener;
    }

    public void setUserProfileListener(UserProfileListener listener) {
        userProfileListener = listener;
    }

    public void setNewAdminCreatedListener(NewAdminCreatedListener listener) {
        newAdminCreatedListener = listener;
    }

    public void createGroup(JSONObject jobj) {
        Log.i(TAG, "createGroup: " + jobj);
        if (mSocket != null && mSocket.connected()) {
            mSocket.emit(GroupEvent.CREATE_GROUP, jobj);
        } else {
            showToast("createGroup");
        }
    }

    public void joinGroup(JSONObject jobj) {
        if (mSocket != null && mSocket.connected()) {
//            Log.i(TAG, "joinGroup: " + jobj.toString());
            mSocket.emit(GroupEvent.JOIN_GROUP, jobj);
        } else {
            showToast("joinGroup");
        }
    }

    public void modifyGroupInfo(JSONObject jsonObject) {
        Log.i(TAG, "modifyGroupInfo: " + jsonObject);
        mSocket.emit("modifyGroupinfo", jsonObject);
    }

    public void deleteGroup(JSONObject jsonObject) {
        Log.i(TAG, "deleteGroup: " + jsonObject);
        mSocket.emit("trashGroup", jsonObject);
    }

    public void messageToGroup(JSONObject jobj) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "messageToGroup: " + jobj);
            mSocket.emit(GroupEvent.MESSAGE_TO_GROUP, jobj);
        } else {
            showToast("messageToGroup");
        }
    }

    public void groupChatReceived(JSONObject jobj) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "groupChatReceived: " + jobj);
            mSocket.emit(GroupEvent.GROUP_CHAT_RECEIVED, jobj);
        } else {
            showToast("groupChatReceived");
        }
    }

    public void groupTyping(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "groupTyping: " + jsonObject.toString());
            mSocket.emit(GroupEvent.GROUP_TYPING, jsonObject);
        } else {
            showToast("groupTyping");
        }
    }

    public void clearGroupInvitations(String groupId) {
        JSONObject jobj = new JSONObject();
        try {
            jobj.put(TAG_USER_ID, GetSet.getUserId());
            jobj.put(TAG_GROUP_ID, groupId);
            Log.i(TAG, "clearGroupInvitations: " + jobj.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (mSocket != null && mSocket.connected()) {
            mSocket.emit(GroupEvent.CLEAR_GROUP_INVITATION, jobj);
        } else {
            showToast("clearGroupInvitations");
        }
    }

    public void exitFromGroup(JSONObject jsonObject) {
        Log.i(TAG, "exitFromGroup: " + jsonObject);
        if (mSocket != null && mSocket.connected()) {
            mSocket.emit(GroupEvent.EXIT_FROM_GROUP, jsonObject);
        } else {
            showToast("exitFromGroup");
        }
    }

    private void getUserInfo(String memberId, JSONObject data) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));

                        onCallReceive(data);
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserInfo Failed" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void onCallReceive(JSONObject data) {
        String type = data.optString(Constants.TAG_TYPE, "");
        String callerId = data.optString("caller_id", "");
        String callId = data.optString("call_id", "");
        String unixStamp = data.optString("created_at", "");
        String call_type = data.optString("call_type", "");
        String roomId = data.optString("room_id", "");
        String platform = data.optString(Constants.TAG_PLATFORM, "");
        Log.d(TAG, "onCallReceive: " + data);
        if (call_type.equalsIgnoreCase("created")) {
            TelephonyManager telephony = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
            int isPhoneCallOn = -1;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    isPhoneCallOn = telephony.getCallStateForSubscription();
                } else {
                    /*if (ApplicationClass.getCurrentActivity() != null && ApplicationClass.getCurrentActivity() instanceof CallActivity) {
                        CallActivity activity = (CallActivity) ApplicationClass.getCurrentActivity();
                        activity.finish();
                        CallActivity.isInCall = false;
                    } else*/
                    if (ApplicationClass.getCurrentActivity() == null) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(mContext, mContext.getString(R.string.enable_read_phone_state), Toast.LENGTH_SHORT).show();
                                mContext.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + mContext.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                            }
                        });
                    }
                }
            } else {
                isPhoneCallOn = telephony.getCallState();
            }

            dbhelper.addRecentCall(callId, callerId, type, "incoming", unixStamp, "1");
            if (onUpdateTabIndication != null) {
                onUpdateTabIndication.updateIndication();
            }
            if (!CallActivity.isInCall && isPhoneCallOn == 0) {
                CallActivity.isInCall = true;
                AppRTCUtils appRTCUtils = new AppRTCUtils(mContext);
                Intent intent = appRTCUtils.connectToRoom(callerId, Constants.TAG_RECEIVE, type);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("call_id", callId);
                intent.putExtra("room_id", roomId);
                intent.putExtra(Constants.TAG_PLATFORM, platform);
                mContext.startActivity(intent);
            } else if (CallActivity.isInCall && isPhoneCallOn == 0) {
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("call_id", callId);
                    jsonObject.put("user_id", callerId);
                    jsonObject.put("caller_id", GetSet.getUserId());
                    jsonObject.put("sender_id", GetSet.getUserId());
                    jsonObject.put("type", type);
                    jsonObject.put("call_status", "outgoing");
                    jsonObject.put("created_at", unixStamp);
                    jsonObject.put("call_type", "waiting");
                    jsonObject.put("room_id", roomId);
                    jsonObject.put(Constants.TAG_CHAT_TYPE, Constants.TAG_CALL);
                    jsonObject.put(Constants.TAG_PLATFORM, "android");
                    createCall(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } else if (call_type.equalsIgnoreCase("ended")) {
            if (CallActivity.callActivity != null && CallActivity.userid.equals(callerId))
                CallActivity.callActivity.finish();
        } else if (call_type.equalsIgnoreCase("waiting")) {
            if (CallActivity.callActivity != null) {
                CallActivity.callActivity.setWaiting();
            }
        } else if (call_type.equals(Constants.TAG_MISSED)) {
            dbhelper.addRecentCall(callId, callerId, type, Constants.TAG_MISSED, unixStamp, "1");
            EventBus.getDefault().post(new CallReceiveEvent(Constants.TAG_MISSED));
            if (onUpdateTabIndication != null) {
                onUpdateTabIndication.updateIndication();
            }
            if (CallFragment.callFragment != null) { // For refresh the call history
                CallFragment.callFragment.refreshAdapter();
            }
        }
    }

    public void setChannelCallbackListener(ChannelCallbackListener listener) {
        channelCallbackListener = listener;
    }

    public void setChannelChatCallbackListener(ChannelChatCallbackListener listener) {
        channelChatCallbackListener = listener;
    }

    public void setChannelRecentReceivedListener(ChannelRecentReceivedListener listener) {
        channelRecentReceivedListener = listener;
    }

    public void setOnUpdateTabIndication(OnUpdateTabIndication listener) {
        onUpdateTabIndication = listener;
    }

    public void createChannel(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "createChannel: " + jsonObject);
            mSocket.emit(ChannelEvent.CREATE_CHANNEL, jsonObject);
        } else {
            showToast("createChannel");
        }
    }

    public void sendInvitesToSubscribers(JSONObject jObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "sendInvitesToSubscribers: " + jObject);
            mSocket.emit(ChannelEvent.SEND_CHANNEL_INVITATION, jObject);
        } else {
            showToast("sendInvitesToSubscribers");
        }
    }

    public void subscribeChannel(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "subscribeChannel: " + jsonObject);
            mSocket.emit(ChannelEvent.SUBSCRIBE_CHANNEL, jsonObject);
        } else {
            showToast("subscribeChannel");
        }
    }

    public void unsubscribeChannel(JSONObject jsonObject, String channelId, String totalSubscribers) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "unsubscribeChannel: " + jsonObject);
            mSocket.emit(ChannelEvent.UNSUBSCRIBE_CHANNEL, jsonObject);
        } else {
            showToast("unsubscribeChannel");
        }
        dbhelper.deleteChannelRecentMessages(channelId);
        dbhelper.deleteChannelMessages(channelId);
        dbhelper.deleteChannel(channelId);
    }

    public void messageToChannel(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "messageToChannel: " + jsonObject);
            mSocket.emit(ChannelEvent.MESSAGE_TO_CHANNEL, jsonObject);
        } else {
            showToast("messageToChannel");
        }
    }

    public void leaveChannel(JSONObject jsonObject, String channelId) {
        if (mSocket != null && mSocket.connected()) {
            Log.e(TAG, "leaveChannel: " + jsonObject);
            mSocket.emit(ChannelEvent.LEAVE_CHANNEL, jsonObject);
        } else {
            showToast("leaveChannel");
        }
        dbhelper.deleteChannel(channelId);

        if (channelChatCallbackListener != null) {
            channelChatCallbackListener.onChannelDeleted();
        }

        if (channelRecentReceivedListener != null) {
            channelRecentReceivedListener.onChannelDeleted();
        }
    }

    public void setStoryListener(StoryListener listener) {
        storyListener = listener;
    }

    public void setStatusUploadListener(StatusUploadListener listener) {
        statusUploadListener = listener;
    }

    public void setOnlineCallBackListener(OnlineCallbackListener listener) {
        onlineCallbackListener = listener;
    }

    public void postStory(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.d(TAG, "postStory: " + jsonObject);
            mSocket.emit(StoryEvent.POST_STORY, jsonObject);
        } else {
            showToast("postStory");
        }
    }

    public void viewStory(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.v(TAG, "viewStory: " + jsonObject);
            mSocket.emit(StoryEvent.VIEW_STORY, jsonObject);
        } else {
            showToast("viewStory");
        }
    }

    public void deleteStory(String statusId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_STORY_ID, statusId);
            JSONArray array = new JSONArray(dbhelper.getStatusMember(statusId));
            jsonObject.put(Constants.TAG_STORY_MEMBERS, array);
            if (mSocket != null && mSocket.connected()) {
                Log.d(TAG, "deleteStory: " + jsonObject);
                mSocket.emit(StoryEvent.DELETE_STORY, jsonObject);
            } else {
                showToast("deleteStory");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void registerCalls(JSONObject jsonObject) {
        if (mSocket != null && mSocket.connected()) {
            Log.i(TAG, "registerCalls: " + jsonObject);
            mSocket.emit("registercalls", jsonObject);
        } else {
            showToast("registerCalls");
        }
    }

    public void muteChat(String chatType, String muteId, boolean isMute) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_CHAT_ID, muteId);
            jsonObject.put(Constants.TAG_CHAT_TYPE, chatType);
            jsonObject.put(Constants.TAG_TYPE, isMute ? "mute" : "unmute");
            Log.d(TAG, "muteChat: " + jsonObject);
            if (mSocket != null && mSocket.connected()) {
                mSocket.emit("mutechat", jsonObject);
            } else {
                showToast("muteChat");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void clearReceivedMessages(String messageId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(TAG_SENDER_ID, GetSet.getUserId());
            jsonObject.put(TAG_MESSAGE_ID, messageId);
            Log.d(TAG, "clearReceivedMessages: " + jsonObject);
            if (mSocket != null && mSocket.connected()) {
                mSocket.emit("clearreceivedmessages", jsonObject);
            } else {
                showToast("clearReceivedMessages");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void clearReadMessages(String senderId, String chatId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(TAG_SENDER_ID, senderId);
            jsonObject.put(TAG_CHAT_ID, chatId);
            Log.d(TAG, "clearReadMessages: " + jsonObject);
            if (mSocket != null && mSocket.connected()) {
                mSocket.emit("clearreadmessages", jsonObject);
            } else {
                showToast("clearReadMessages");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void clearChannelInvites(String channelId) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(TAG_CHANNEL_ID, channelId);
            if (mSocket != null && mSocket.connected()) {
                Log.d(TAG, "clearChannelInvites: " + jsonObject);
                mSocket.emit(ChannelEvent.CLEAR_CHANNEL_INVITES, jsonObject);
            } else {
                showToast("clearChannelInvites");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public interface OnlineCallbackListener {
        void onChatBoxJoined();
    }

    public interface ForegroundListener {
        void onChatBoxJoined();
    }

    public interface ApplicationClassListener {
        void onChatBoxJoined();
    }

    public interface RecentChatReceivedListener {
        void onRecentChatReceived();

        void onUserImageChange(String user_id, String user_image);

        void onBlockStatus(JSONObject data);

        void onUpdateChatStatus(String user_id);

        void onListenTyping(JSONObject data);

        void onPrivacyChanged(JSONObject jsonObject);

        void onStatusReceived();

        void onDeleteStatus(String statusId);

        void onPrivateChatUpdate(String receiverId);
    }

    public interface ChatCallbackListener {

        void onChatBoxJoined();

        void onReceiveChat(MessagesData mdata);

        void receivedStatus(String message_id, String sender_id, String receiverId);

        void onViewChat(String chat_id, String sender_id, String receiverId);

        void onlineStatus(JSONObject data);

        void onListenTyping(JSONObject data);

        void onBlockStatus(JSONObject data);

        void onUserImageChange(String user_id, String user_image);

        void onGetUpdateFromDB(boolean isRefresh);

        void onUploadListen(String message_id, String attachment, String progress);

        void onPrivacyChanged(JSONObject jsonObject);

        void onPrivateChatReceived(String userId, String senderId);
    }

    public interface ExternalUploadListener {
        void onExternalUploaded(String progress);
    }

    public interface GroupChatCallbackListener {

        void onGroupChatReceive(GroupMessage mdata);

        void onListenGroupTyping(JSONObject data);

        void onMemberExited(JSONObject data);

        void onUploadListen(String message_id, String attachment, String progress);

        void onGetUpdateFromDB();

        void onUpdateGroupInfo(GroupMessage groupMessage);
    }

    public interface GroupRecentReceivedListener {

        void onGroupCreated();

        void onGroupRecentReceived();

        void onGroupModified(JSONObject data);

        void onUserImageChange(String user_id, String user_image);

        void onMemberExited(JSONObject data);

        void onUpdateChatStatus(String user_id);

        void onListenGroupTyping(JSONObject data);

        void onGroupDeleted(JSONObject jsonObject);

    }

    public interface GroupInfoSocketListener {
        void onMemberExited(JSONObject jsonObject);
    }

    public interface NewAdminCreatedListener {
        void onNewAdminCreated();
    }

    public interface OnGroupCreatedListener {
        void onGroupCreated(JSONObject data);
    }

    public interface SelectContactListener {
        void onUserImageChange(String user_id, String user_image);

        void onBlockStatus(JSONObject data);

        void onPrivacyChanged(JSONObject jsonObject);
    }

    public interface UserProfileListener {
        void onPrivacyChanged(JSONObject jsonObject);
    }

    public interface ChannelCallbackListener {
        void onChannelCreated(JSONObject jsonObject);
    }

    public interface ChannelChatCallbackListener {

        void onChatBoxJoined();

        void onChannelChatReceive(ChannelMessage mdata);

        void onAdminChatReceive(AdminChannelMsg.Result adminMessage);

        void onUploadListen(String message_id, String attachment, String progress);

        void onChannelDeleted();

        void onGetUpdateFromDB();

        void onChannelBlocked(String channelId);
    }

    public interface ChannelRecentReceivedListener {

        void onChannelCreated(JSONObject jsonObject);

        void onChannelRecentReceived();

        void onChannelDeleted();

        void onAdminChatReceive();

        void onChannelInviteReceived(JSONObject jsonObject);

        void onChannelBlocked(String channelId);

    }

    public interface OnUpdateTabIndication {
        void updateIndication();
    }

    public interface StatusUploadListener {
        void onUploadListen(String attachment, String progress, String localFileName);
    }

    public interface CallReceivedFromSocket {
        void onCallReceived(Object args);
    }

    public interface StoryListener {
        void onStoryViewed(String storyId);

        void onStoryDeleted(String statusId);
    }

    private void showToast(String message) {
        Log.e(TAG, "showToast: " + message + " Not connected");
        /*new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mCtx, message, Toast.LENGTH_SHORT).show();
            }
        });*/
    }
}
