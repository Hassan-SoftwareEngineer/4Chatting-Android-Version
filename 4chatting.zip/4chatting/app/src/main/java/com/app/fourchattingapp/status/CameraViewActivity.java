package com.app.fourchattingapp.status;

import static com.app.helper.StorageManager.TAG_IMAGE_SENT;
import static com.app.helper.StorageManager.TAG_VIDEO;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowMetrics;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.app.helper.FileUriUtils;
import com.app.helper.PermissionsUtils;
import com.app.helper.StorageManager;
import com.app.helper.callback.OkayCancelCallback;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.fourchattingapp.BuildConfig;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;
import com.otaliastudios.cameraview.CameraException;
import com.otaliastudios.cameraview.CameraListener;
import com.otaliastudios.cameraview.CameraOptions;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.FileCallback;
import com.otaliastudios.cameraview.PictureResult;
import com.otaliastudios.cameraview.VideoResult;
import com.otaliastudios.cameraview.controls.Facing;
import com.otaliastudios.cameraview.controls.Flash;
import com.otaliastudios.cameraview.controls.Mode;
import com.otaliastudios.cameraview.size.SizeSelectors;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.utils.ContentUriUtils;

public class CameraViewActivity extends BaseActivity {

    private static final String TAG = CameraViewActivity.class.getSimpleName();
    StorageManager storageManager;
    private FrameLayout mainLay;
    private ConstraintLayout bottomLay;
    private LinearLayout timerLay;
    private CameraView cameraView;
    private AppCompatCheckBox btnFlash, btnSwitchCamera;
    private ImageView btnGallery, btnImage, btnVideo, btnCapture, btnStatus;
    private Button permissionsButton;
    private TextView txtRecordTimer, txtTapHold;
    int bottomNavHeight = 0, bottomMargin = 0;
    private String statusType = Constants.TAG_IMAGE;
    public static final double RATIO_4_3_VALUE = 4.0 / 3.0;
    public static final double RATIO_16_9_VALUE = 16.0 / 9.0;
    private static final String FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS";
    private static final String PHOTO_EXTENSION = ".jpg";
    private static final String VIDEO_EXTENSION = ".mp4";
    private CountDownTimer longClickTimer;
    private CountDownTimer videoTimer;
    private long clickTime;
    private boolean isVideoStarted = false, isCompleted = false, isVideo = true;
    private View.OnTouchListener cameraTouchListener;
    private Facing lensFacing = Facing.BACK;
    public int displayHeight;
    public int displayWidth;
    private final long STATUS_DURATION = 30 * 1000;
    private SharedPreferences pref;
    private Context mContext;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<Intent> galleryResultLauncher;
    private ActivityResultLauncher<Intent> statusResultLauncher;
    ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler mainHandler = new Handler(Looper.myLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cameraview);
        Window w = getWindow(); // in Activity's onCreate() for instance
        pref = getSharedPreferences("SavedPref", MODE_PRIVATE);
        mContext = this;
        getDisplayWidthHeight(mContext);
        mainLay = findViewById(R.id.main_lay);
        cameraView = findViewById(R.id.cameraView);
        btnFlash = findViewById(R.id.btn_flash);
        btnSwitchCamera = findViewById(R.id.btn_switch_camera);
        bottomLay = findViewById(R.id.bottom_lay);
        btnGallery = findViewById(R.id.btn_gallery);
        btnImage = findViewById(R.id.btn_image);
        btnVideo = findViewById(R.id.btn_video);
        btnCapture = findViewById(R.id.btn_capture);
        btnStatus = findViewById(R.id.btn_status);
        permissionsButton = findViewById(R.id.permissionsButton);
        timerLay = findViewById(R.id.timerLay);
        txtRecordTimer = findViewById(R.id.txt_record_timer);
        txtTapHold = findViewById(R.id.txt_tap_hold);
        bottomMargin = ApplicationClass.dpToPx(this, 5);

        storageManager = StorageManager.getInstance(this);

        initPermissionResult();
        initActivityResultLauncher();
        mainLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + bottomMargin;
                if (bottomLay != null) {
                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                    params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
//                    params.bottomMargin = bottomNavHeight;
                    if (bottomLay != null) {
                        bottomLay.setPadding(0, 0, 0, bottomNavHeight + bottomMargin);
                        bottomLay.setLayoutParams(params);
                    }
                }
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        initListeners();
    }

    private void getDisplayWidthHeight(Context mContext) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = this.getWindowManager().getCurrentWindowMetrics();
            Insets insets = windowMetrics.getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            displayHeight = windowMetrics.getBounds().height() - insets.bottom - insets.top;
            displayWidth = windowMetrics.getBounds().width() - insets.left - insets.right;
        } else {
            this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            displayHeight = displayMetrics.heightPixels;
            displayWidth = displayMetrics.widthPixels;
        }
    }

    private void initPermissionResult() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    btnGallery.performClick();
                } else {
                    boolean neverAsked = false;
                    Log.d(TAG, "requestPermissions: ");
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CameraViewActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, mContext.getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void initActivityResultLauncher() {
        galleryResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        ArrayList<Uri> pathsAry = new ArrayList<>();
                        if (result.getData() != null) {
                            pathsAry.addAll(result.getData().getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));
                        }
                        if (pathsAry.size() > 0) {
                            boolean isVideo = false;
                            if (storageManager.getMimeTypeOfUri(mContext, pathsAry.get(0)).startsWith("video/")) {
                                isVideo = true;
                            }
                            String savedVideoPath = "";
                            String savedImagePath = "";

                            if (isVideo) {
                                String extension = storageManager.getExtension(pathsAry.get(0));
                                savedVideoPath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                            } else {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    String extension = storageManager.getExtension(pathsAry.get(0));
                                    String tempPath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                                    savedImagePath = storageManager.saveFileInStorage(new File(tempPath), TAG_IMAGE_SENT);
                                } else {
                                    try {
                                        String tempFilePath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                        savedImagePath = storageManager.saveFileInStorage(new File(tempFilePath), TAG_IMAGE_SENT);
                                    } catch (URISyntaxException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }

//                if (ApplicationClass.isVideoFile(filepath)) {
                            if (isVideo) {
                                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                                retriever.setDataSource(CameraViewActivity.this, Uri.fromFile(new File(savedVideoPath)));
                                String videoFormat = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE);
                                if (!videoFormat.contains("webm")) {
                                    statusType = Constants.TAG_VIDEO;
                                    previewMedia(savedVideoPath, statusType);
                                } else {
                                    ApplicationClass.showToast(CameraViewActivity.this, getString(R.string.video_format_not_supported), Toast.LENGTH_SHORT);
                                }
                            } else {
                                statusType = Constants.TAG_IMAGE;
                                previewMedia(savedImagePath, statusType);
                            }
                        }
                    }
                });
        statusResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            finish();
                        }
                    }
                });
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        ApplicationClass.showSnack(CameraViewActivity.this, findViewById(R.id.main_lay), isConnected);
    }

    @Override
    public void backPressed() {
        finish();
    }

    private void initListeners() {

        btnSwitchCamera.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                setCameraSizes();
                if (cameraView.isTakingPicture() || cameraView.isTakingVideo()) return;
                lensFacing = cameraView.toggleFacing();
                if (lensFacing == Facing.FRONT) {
                    btnFlash.setChecked(false);
                    btnFlash.setVisibility(View.INVISIBLE);
                } else {
                    btnFlash.setVisibility(View.VISIBLE);
                }

                Animation scaling = AnimationUtils.loadAnimation(CameraViewActivity.this, R.anim.anim_spin);
                btnSwitchCamera.startAnimation(scaling);
            }
        });

        btnFlash.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) cameraView.setFlash(Flash.ON);
                else cameraView.setFlash(Flash.OFF);
                Animation scaling = AnimationUtils.loadAnimation(CameraViewActivity.this, R.anim.anim_spin);
                btnFlash.startAnimation(scaling);
            }
        });

        /*permissionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraView.requestPermissions(true, true);
            }
        });*/

        cameraTouchListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        setClickCountDown();
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        longClickTimer.cancel();
                        if (isVideoStarted) {
                            stopRecorder();
                            resetCaptureButton();
                        } else {
                            btnCapture.setOnTouchListener(null);
                            captureImage();
                        }
                        clickTime = 0;
                        return true;
                }
                return false;
            }
        };

        btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (PermissionsUtils.checkStoragePermission(mContext)) {
                    FilePickerBuilder.getInstance()
                            .setMaxCount(1)
                            .setActivityTheme(R.style.MainTheme)
                            .setActivityTitle(getString(R.string.please_select_media))
                            .enableVideoPicker(true)
                            .enableImagePicker(true)
                            .enableCameraSupport(false)
                            .showGifs(false)
                            .showFolderView(false)
                            .enableSelectAll(false)
                            .enableDocSupport(false)
                            .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                            .pickPhoto(CameraViewActivity.this, galleryResultLauncher);
                } else {
                    requestStoragePermissions();
                }
            }
        });

        btnImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                statusType = Constants.TAG_IMAGE;
                btnCapture.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_normal));
                btnVideo.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.video));
                btnImage.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_selected));
            }
        });

        btnVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                statusType = Constants.TAG_VIDEO;
                btnCapture.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_recorder));
                btnVideo.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.video_selected));
                btnImage.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_unselected));
            }
        });

        btnStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CameraViewActivity.this, TextStatusActivity.class);
                statusResultLauncher.launch(intent);
            }
        });
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void captureImage() {
        resetCaptureButton();
        statusType = Constants.TAG_IMAGE;
        if (cameraView.getMode() == Mode.VIDEO) return;
        if (cameraView.isTakingPicture()) return;
        cameraView.takePicture();
    }

    private void saveFileInGallery(File srcFile, String from, String fileType) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String fileName = mContext.getString(R.string.app_name) + "_" + (System.currentTimeMillis() / 1000) + "." + FilenameUtils.getExtension(srcFile.getName());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    storageManager.saveFileInStorageV10(srcFile, fileName, from, fileType);
                } else {
                    storageManager.saveFileInGallery(srcFile, fileName, from);
                }
            }
        });
    }

    private void captureVideo() {
        if (cameraView.getMode() == Mode.PICTURE) return;
        if (cameraView.isTakingPicture() || cameraView.isTakingVideo()) return;
        File videoFile = getVideoOutputFile(storageManager.getExtCachesDir(), FILENAME, VIDEO_EXTENSION);
        cameraView.takeVideo(videoFile);
        if (btnFlash.isChecked()) {
            cameraView.setFlash(Flash.TORCH);
        }
    }

    private void setClickCountDown() {
        Animation anim = new ScaleAnimation(
                1f, 1.2f, // Start and end values for the X axis scaling
                1f, 1.2f, // Start and end values for the Y axis scaling
                Animation.RELATIVE_TO_SELF, 0.5f, // Pivot point of X scaling
                Animation.RELATIVE_TO_SELF, 0.5f); // Pivot point of Y scaling
        anim.setFillAfter(true); // Needed to keep the result of the animation
        anim.setDuration(400);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                btnCapture.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_recorder));
            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        btnCapture.startAnimation(anim);

        longClickTimer = new CountDownTimer(STATUS_DURATION, 500) {
            public void onTick(long millisUntilFinished) {
                clickTime = STATUS_DURATION - millisUntilFinished;
                if (clickTime > 100 && !isVideoStarted) {
                    isVideoStarted = true;
                    cameraView.setMode(Mode.VIDEO);
                    statusType = Constants.TAG_VIDEO;
                    captureVideo();
                }
            }

            public void onFinish() {
                if (isVideoStarted) {
                    stopRecorder();
                }
            }
        };
        longClickTimer.start();
    }

    private void resetCaptureButton() {
        cameraView.setFlash(btnFlash.isChecked() ? Flash.ON : Flash.OFF);
        cameraView.setMode(Mode.PICTURE);
        btnCapture.animate().cancel();
        Animation anim = new ScaleAnimation(
                1.2f, 1f, // Start and end values for the X axis scaling
                1.2f, 1f, // Start and end values for the Y axis scaling
                Animation.RELATIVE_TO_SELF, 0.5f, // Pivot point of X scaling
                Animation.RELATIVE_TO_SELF, 0.5f); // Pivot point of Y scaling
        anim.setFillAfter(true); // Needed to keep the result of the animation
        anim.setDuration(400);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                btnCapture.setImageDrawable(ContextCompat.getDrawable(CameraViewActivity.this, R.drawable.camera_normal));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        btnCapture.startAnimation(anim);
    }

    // function setup countdown timerHandler for video recording
    private void startVideoCountDown() {
        timerLay.setVisibility(View.VISIBLE);
        videoTimer = new CountDownTimer(FileUriUtils.MAX_STORY_DURATION, 1000) {
            public void onTick(long millisUntilFinished) {
                // check that video recording time coming previous activity or not
                long timeElapsed = FileUriUtils.MAX_STORY_DURATION - millisUntilFinished;
                txtRecordTimer.setText(getTime(timeElapsed));
            }

            public void onFinish() {
                isCompleted = true;
                stopRecorder();
                cameraView.setMode(Mode.PICTURE);
                resetCaptureButton();
            }
        };
        videoTimer.start();
    }

    public void resetVideoRecording() {
        if (longClickTimer != null) longClickTimer.cancel();
        if (videoTimer != null) {
            videoTimer.cancel();
//            videoTimer = null;
        }
    }

    private void stopRecorder() {
        isVideoStarted = false;
        txtTapHold.setVisibility(View.VISIBLE);
        cameraView.stopVideo();
    }

    private void setViewVisibility(View view, int visible) {
        view.setVisibility(visible);
    }

    private void setActivity(String filePath, String sourceFrom) {
        if (statusType == null || statusType.equals(Constants.TAG_IMAGE)) {
            Intent intent = new Intent(CameraViewActivity.this, StatusPreviewActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.putExtra(Constants.TAG_FROM, sourceFrom);
            intent.putExtra(Constants.TAG_ATTACHMENT, filePath);
            statusResultLauncher.launch(intent);
        } else {
            Intent intent = new Intent(this, TrimmerActivity.class);
            intent.putExtra(Constants.TAG_ATTACHMENT, filePath);
            intent.putExtra(Constants.TAG_FROM, sourceFrom);
            intent.putExtra(Constants.TAG_STORY_TIME, getMediaDuration(storageManager.getUriFromFile(new File(filePath))));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            statusResultLauncher.launch(intent);
            if (sourceFrom.equals(Constants.TAG_CAMERA)) {
                saveFileInGallery(new File(filePath), StorageManager.TAG_VIDEO, TAG_VIDEO);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        btnCapture.setOnTouchListener(cameraTouchListener);
        statusType = Constants.TAG_IMAGE;
        startCamera();
    }

    @Override
    public void onPause() {
        super.onPause();
        btnCapture.setOnTouchListener(null);
        cameraView.clearCameraListeners();
    }

    @Override
    protected void onDestroy() {
        mContext = null;
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    private void startCamera() {
        setCameraView();
    }

    private void setCameraView() {
        setCameraSizes();
        cameraView.setLifecycleOwner(this);
        cameraView.addCameraListener(new CameraViewListener());
        cameraView.setUseDeviceOrientation(true);
    }

    private void setCameraSizes() {
        cameraView.setPreviewStreamSize(SizeSelectors.aspectRatio(com.otaliastudios.cameraview.size.AspectRatio.of(1, 1), 0f));
        cameraView.setVideoSize(SizeSelectors.aspectRatio(com.otaliastudios.cameraview.size.AspectRatio.of(1, 1), 0f));
        cameraView.setPictureSize(SizeSelectors.aspectRatio(com.otaliastudios.cameraview.size.AspectRatio.of(1, 1), 0f));

        /*cameraView.setPreviewStreamSize(SizeSelectors.aspectRatio(screenAspectRatio == AspectRatio.RATIO_4_3 ?
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(4, 3)) :
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(16, 9)), 0f));
        cameraView.setPictureSize(SizeSelectors.aspectRatio(screenAspectRatio == AspectRatio.RATIO_4_3 ?
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(4, 3)) :
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(16, 9)), 0f));
        cameraView.setVideoSize(SizeSelectors.aspectRatio(screenAspectRatio == AspectRatio.RATIO_4_3 ?
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(4, 3)) :
                com.otaliastudios.cameraview.size.AspectRatio.of(new Size(16, 9)), 0f));*/
    }

    private class CameraViewListener extends CameraListener {
        @Override
        public void onCameraOpened(@NonNull CameraOptions options) {
            super.onCameraOpened(options);
            resetVideoRecording();
            setViewVisibility(btnFlash, lensFacing == Facing.FRONT ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onCameraError(@NonNull CameraException exception) {
            super.onCameraError(exception);
            Log.e(TAG, "onCameraError: " + exception.getMessage());
        }

        @Override
        public void onCameraClosed() {
            super.onCameraClosed();
            Log.d(TAG, "onCameraClosed: ");
        }

        @Override
        public void onPictureTaken(@NonNull PictureResult result) {
            super.onPictureTaken(result);
            resetCaptureButton();
            timerLay.setVisibility(View.GONE);
            if (videoTimer != null) videoTimer.cancel();
            btnCapture.setOnTouchListener(cameraTouchListener);
            if (videoTimer != null) videoTimer.cancel();
            File photoFile = getImageOutputFile(storageManager.getExtCachesDir(), FILENAME, PHOTO_EXTENSION);
            result.toFile(photoFile, new FileCallback() {
                @Override
                public void onFileReady(@Nullable File file) {
                    Log.d(TAG, "onFileReady: " + file.getAbsolutePath());
                    setActivity(file.getAbsolutePath(), Constants.TAG_CAMERA);
                }
            });
        }

        @Override
        public void onVideoRecordingStart() {
            super.onVideoRecordingStart();
            setViewVisibility(txtTapHold, View.GONE);
            setViewVisibility(btnGallery, View.GONE);
            setViewVisibility(btnStatus, View.GONE);
            setViewVisibility(btnFlash, View.GONE);
            setViewVisibility(btnSwitchCamera, View.GONE);
            startVideoCountDown();
        }


        @Override
        public void onVideoTaken(@NonNull VideoResult result) {
            super.onVideoTaken(result);
            Log.d(TAG, "onVideoTaken: " + result.getFile().getAbsolutePath());
            isVideo = true;
            setFlashVisibility(lensFacing == Facing.FRONT ? View.GONE : View.VISIBLE);
            setViewVisibility(btnSwitchCamera, View.VISIBLE);
            setViewVisibility(btnGallery, View.VISIBLE);
            setViewVisibility(btnStatus, View.VISIBLE);
            setViewVisibility(timerLay, View.GONE);

            long duration = (long) storageManager.getMediaDuration(result.getFile());
            if (duration < (FileUriUtils.MIN_STORY_DURATION)) {
                btnCapture.setOnTouchListener(cameraTouchListener);
                makeToast(String.format(getString(R.string.minimum_video_seconds_description), Integer.parseInt("" + (FileUriUtils.MIN_STORY_DURATION / 1000))));
            } else {
                setActivity(result.getFile().getAbsolutePath(), Constants.TAG_CAMERA);
            }
        }

        @Override
        public void onVideoRecordingEnd() {
            super.onVideoRecordingEnd();
            isVideo = true;
            btnCapture.setOnTouchListener(null);
            resetVideoRecording();
            resetCaptureButton();
        }

        /*public void onVideoError(boolean successful, @NonNull PointF point) {
            btnCapture.setOnTouchListener(cameraTouchListener);
            btnSwitchCamera.setVisibility(View.VISIBLE);
            if (cameraView.isFacingBack()) {
                btnFlash.setVisibility(View.VISIBLE);
            } else {
                btnFlash.setChecked(false);
                btnFlash.setVisibility(View.INVISIBLE);
            }
            if (btnFlash.isChecked()) {
                flashMode = CameraKit.Constants.FLASH_ON;
                cameraView.setFlash(flashMode);
            } else {
                flashMode = CameraKit.Constants.FLASH_OFF;
                cameraView.setFlash(flashMode);
            }
            timerLay.setVisibility(View.GONE);

        }*/
    }

    /**
     * Inflate camera controls and update the UI manually upon config changes to avoid removing
     * and re-adding the view finder from the view hierarchy; this provides a seamless rotation
     * transition on devices that support it.
     * <p>
     * NOTE: The flag is supported starting in Android 8 but there still is a small flash on the
     * screen for devices that run Android 9 or below.
     */
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    /**
     * Use external media if it is available, our app's file directory otherwise
     */
    public File getImageOutputFile(File mDestDir, String FILENAME, String PHOTO_EXTENSION) {
        File mDestFile = new File(mDestDir.getPath() + File.separator + new SimpleDateFormat(FILENAME, Locale.US)
                .format(System.currentTimeMillis()) + PHOTO_EXTENSION);
        return mDestFile;
    }

    public File getVideoOutputFile(File mDestDir, String FILENAME, String VIDEO_EXTENSION) {
        File mDestFile = new File(mDestDir.getPath() + File.separator + new SimpleDateFormat(FILENAME, Locale.US)
                .format(System.currentTimeMillis()) + VIDEO_EXTENSION);
        return mDestFile;
    }


    private void setFlashVisibility(int visibility) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                btnFlash.setVisibility(visibility);
            }
        });
    }

    public String getMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = this.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        Log.d(TAG, "getMimeType: " + mimeType);
        return mimeType;
    }


    private void previewMedia(String filePath, String type) {
        if (type.equals(Constants.TAG_VIDEO)) {
            if (!TextUtils.isEmpty(filePath)) {
                setActivity(filePath, Constants.TAG_GALLERY);
            }
            /*
            Bitmap thumb = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    thumb = getContentResolver().loadThumbnail(storageManager.getUriFromFile(new File(filePath)), Utils.getBitmapSize(mContext), null);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                thumb = ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Video.Thumbnails.MINI_KIND);
            }
            if (thumb != null) {
                String fileName = (System.currentTimeMillis() / 1000L) + ".jpg";
                Uri savedThumbUri = null;
                String savedThumbPath = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    savedThumbUri = storageManager.saveImageInStorageV10(thumb, fileName, StorageManager.TAG_THUMB);
                } else {
                    savedThumbPath = storageManager.saveImageInStorage(thumb, fileName, StorageManager.TAG_THUMB).getAbsolutePath();
                }
                if (savedThumbUri != null || savedThumbPath != null) {
                    setActivity(filePath, Constants.TAG_GALLERY);
                }
            }
        */
        } else {
            setActivity(filePath, Constants.TAG_GALLERY);
        }
    }

    private int getMediaDuration(Uri uriOfFile) {
        MediaPlayer mp = MediaPlayer.create(this, uriOfFile);
        return mp.getDuration();
    }

    private String getTime(long time) {
        int sec = (int) (time / 1000);
        String seconds;
        if (sec >= 10) {
            seconds = "00:" + sec;
        } else {
            seconds = "00:0" + sec;
        }
        Log.i(TAG, "getTime: " + seconds);
        return seconds;
    }


}
