
package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;

public class OfflineStoryDeleteResponse {

    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public HashMap<String, Result> result;

    public class Result {

        @SerializedName("story_id")
        public String storyId;

        /*@SerializedName("story_members")
        public List<String> storyMembers;*/

    }

}
