package com.app.helper.workers;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.fourchattingapp.ApplicationClass;
import com.app.helper.DatabaseHandler;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetProfileWorker extends Worker {
    private static final String TAG = GetProfileWorker.class.getSimpleName();
    private Context mContext;
    private DatabaseHandler dbHelper;

    public GetProfileWorker(
            @NonNull Context appContext,
            @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);
        mContext = appContext;
        dbHelper = DatabaseHandler.getInstance(mContext);
    }

    @NonNull
    @NotNull
    @Override
    public Result doWork() {
        // To acknowledge the message has been delivered
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), getInputData().getString(Constants.TAG_USER_ID));
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbHelper.addContactDetails(name, userdata.get(Constants.TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE),
                                userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(Constants.TAG_CONTACT_STATUS));
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserProfile: " + t.getMessage());
                call.cancel();
            }
        });
        return Result.success();
    }
}
