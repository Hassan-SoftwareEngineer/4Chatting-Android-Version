package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Hitasoft on 5/7/18.
 */

public class RecentChatBackup {

    @SerializedName("status")
    public String status;

    @SerializedName("result")
    public List<Messages> result;

    public class Messages {

        @SerializedName("chat_id")
        public String chatId;

        @SerializedName("unread_count")
        public String unreadCount;

        @SerializedName("messsages")
        public List<ChatBackup> messages;
    }

    public class ChatBackup {
        @SerializedName("message_data")
        public MessagesData messagesData;
    }
}
