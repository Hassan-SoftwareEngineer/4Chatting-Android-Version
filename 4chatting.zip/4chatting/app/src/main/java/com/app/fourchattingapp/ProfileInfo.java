package com.app.fourchattingapp;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_CONTACTS;
import static com.app.utils.Constants.TAG_CONTACT_STATUS;
import static com.app.utils.Constants.TAG_ID;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.app.model.ChannelResult;
import com.app.model.GroupData;
import com.app.model.GroupResult;
import com.app.model.SaveMyContacts;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.app.external.RandomString;
import com.app.helper.BitmapCompression;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.ForegroundService;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.helper.Utils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.R;
import com.app.model.ChannelInfoResponse;
import com.app.model.ContactsData;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.onesignal.OSDeviceState;
import com.onesignal.OSSubscriptionObserver;
import com.onesignal.OSSubscriptionStateChanges;
import com.onesignal.OneSignal;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileInfo extends BaseActivity implements View.OnClickListener, OSSubscriptionObserver {
    private static final String TAG = ProfileInfo.class.getSimpleName();
    private ApiInterface apiInterface;
    ProgressDialog progressDialog;
    ProgressBar progressbar;
    EditText name, about;
    TextView detail;
    CoordinatorLayout mainLay;
    CircleImageView userImage, noimage;
    ImageView backbtn, fab;
    RelativeLayout btnNext;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String from = "", countryName = "";
    String oneSignalId = null;

    DatabaseHandler dbhelper;
    StorageManager storageManager;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private ActivityResultLauncher<Intent> cameraLauncherResult;
    private ActivityResultLauncher<Intent> galleryLauncherResult;
    private Uri mCurrentPhotoUri;
    boolean isCameraClicked = false, isGalleryClicked = false;
    private DateUtils dateUtils;
    private Utils utils;
    private Context mContext;
    SocketConnection socketConnection;
    private final ExecutorService mExecutorService = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_info);
        dateUtils = DateUtils.getInstance(this);
        utils = new Utils(this);
        mContext = this;
        socketConnection = SocketConnection.getInstance(this);
        OneSignal.addSubscriptionObserver(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        userImage = findViewById(R.id.userImage);
        noimage = findViewById(R.id.noimage);
        name = findViewById(R.id.name);
        about = findViewById(R.id.about);
        detail = findViewById(R.id.detail);
        btnNext = findViewById(R.id.btnNext);
        backbtn = findViewById(R.id.backbtn);
        fab = findViewById(R.id.fab);
        mainLay = findViewById(R.id.mainLay);
        progressbar = findViewById(R.id.progressbar);
        progressbar.setIndeterminate(true);
        progressbar.getIndeterminateDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
            btnNext.setRotation(180);
        } else {
            backbtn.setRotation(0);
            btnNext.setRotation(0);
        }

        from = getIntent().getExtras().getString("from");
        if (getIntent().hasExtra("country_name")) {
            countryName = getIntent().getStringExtra("country_name");
        }
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = ProfileInfo.this.getSharedPreferences(Constants.SHARED_PREFERENCE, MODE_PRIVATE);
        editor = pref.edit();
        dbhelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);

        progressDialog = new ProgressDialog(ProfileInfo.this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);
        initPermission();
        initActivityResult();

        if (GetSet.getUserName() != null) {
            name.setText(GetSet.getUserName());
        }

        if (GetSet.getImageUrl() != null) {
            Glide.with(ProfileInfo.this).load(Constants.USER_IMG_PATH + GetSet.getImageUrl())
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            noimage.setVisibility(View.VISIBLE);
                            userImage.setVisibility(View.INVISIBLE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            noimage.setVisibility(View.GONE);
                            userImage.setVisibility(View.VISIBLE);
                            return false;
                        }
                    }).into(userImage);
        }

        if (from.equals("edit")) {
            hideLoading();
            detail.setText(R.string.editprofileinfo);
            about.setVisibility(View.VISIBLE);
            if (GetSet.getAbout() != null) {
                about.setText(GetSet.getAbout());
            }
        } else {
            if (from.equals("welcome") && NetworkStatus.isConnected()) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getMyGroups();
                    }
                }, 1000);
            } else {
                hideLoading();
            }
            detail.setText(R.string.profileinfodetail);
            about.setVisibility(View.GONE);
        }

        userImage.setOnClickListener(this);
        noimage.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(ProfileInfo.this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(ProfileInfo.this, new String[]{READ_CONTACTS}, Constants.CONTACT_REQUEST_CODE);
                } else {
                    if (NetworkStatus.isConnected()) {
                        updateProfile();
                    } else {
                        Snackbar.make(mainLay, getString(R.string.no_internet_connection), Snackbar.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void initPermission() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }
                if (granted) {
                    if (isCameraClicked) {
                        takeCameraPictures();
                    } else {
                        pickGalleryPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ProfileInfo.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(ProfileInfo.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }
            }
        });

        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                            takeCameraPictures();
                        } else {
                            requestStoragePermissions();
                        }
                    }
                   else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        if (PermissionsUtils.checkStoragePermission(mContext)) {
                            takeCameraPictures();
                        } else {
                            requestStoragePermissions();
                        }
                    } else {
                        takeCameraPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ProfileInfo.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(ProfileInfo.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.camera_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void initActivityResult() {
        galleryLauncherResult = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            mCurrentPhotoUri = result.getData().getData();
                            compressImage(mCurrentPhotoUri);
                        }
                    }
                });

        cameraLauncherResult = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        Log.d(TAG, "onActivityResult: " + mCurrentPhotoUri.getPath());
                        if (result.getResultCode() == RESULT_OK) {
                            compressImage(mCurrentPhotoUri);
                        }
                    }
                });
    }

    private void openPickerDialog() {

        View contentView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_pick_options, findViewById(R.id.parentLay), false);
        BottomSheetDialog pickerOptionsSheet = new BottomSheetDialog(this, R.style.SimpleBottomDialog);
        pickerOptionsSheet.setCanceledOnTouchOutside(true);
        pickerOptionsSheet.setContentView(contentView);
        //    pickerOptionsSheet.setDismissWithAnimation(true);

        View layoutCamera = contentView.findViewById(R.id.container_camera_option);
        View layoutGallery = contentView.findViewById(R.id.container_gallery_option);

        layoutCamera.setOnClickListener(v -> {
            pickerOptionsSheet.dismiss();
            isCameraClicked = true;
            isGalleryClicked = false;
            if (ContextCompat.checkSelfPermission(this, CAMERA) == PackageManager.PERMISSION_GRANTED) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                    if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                        takeCameraPictures();
                    } else {
                        requestStoragePermissions();
                    }
                }
                else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        takeCameraPictures();
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    takeCameraPictures();
                }
            } else {
                requestCameraPermission();
            }
        });
        layoutGallery.setOnClickListener(v -> {
            isCameraClicked = false;
            isGalleryClicked = true;
            pickerOptionsSheet.dismiss();
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                    pickGalleryPictures();
                } else {
                    requestStoragePermissions();
                }
            }
            else{
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                pickGalleryPictures();
            } else {
                requestStoragePermissions();
            }
            }
        });

        pickerOptionsSheet.show();
    }

    private void requestCameraPermission() {
        cameraPermissionResult.launch(new String[]{CAMERA});
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_IMAGE_PERMISSION);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void takeCameraPictures() {
        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        if (captureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                //     Timber.e(ex);
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                mCurrentPhotoUri = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri);
                cameraLauncherResult.launch(captureIntent);
            }
        }
    }

    private void pickGalleryPictures() {
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Intent pickIntent = new Intent(Intent.ACTION_PICK, collection);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(pickIntent, "Select a picture");
        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            galleryLauncherResult.launch(chooserIntent);
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = storageManager.getExtCachesDir();
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        // Save a file: path for use with ACTION_VIEW intents
        return image;
    }

    private void getMyChannels() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<ChannelInfoResponse> call3 = apiInterface.getMyChannels(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<ChannelInfoResponse>() {
            @Override
            public void onResponse(Call<ChannelInfoResponse> call, Response<ChannelInfoResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        new InsertMyChannelTask(response.body().result).execute();
                    } else {
                        getSubscribedChannels();
                    }
                } else {
                    getSubscribedChannels();
                }
            }

            @Override
            public void onFailure(Call<ChannelInfoResponse> call, Throwable t) {
                Log.e(TAG, "getMyChannels: " + t.getMessage());
                call.cancel();
                getSubscribedChannels();
            }
        });
    }

    public void getSubscribedChannels() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<ChannelInfoResponse> call = apiInterface.getMySubscribedChannels(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<ChannelInfoResponse>() {
            @Override
            public void onResponse(Call<ChannelInfoResponse> call, Response<ChannelInfoResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        new InsertSubscribedChannelTask(response.body().result).execute();
                    } else {
                        hideLoading();
                    }
                } else {
                    hideLoading();
                }
            }

            @Override
            public void onFailure(Call<ChannelInfoResponse> call, Throwable t) {
                Log.e(TAG, "getMySubscribedChannels: " + t.getMessage());
                call.cancel();
                hideLoading();
            }
        });
    }

    private void getMyGroups() {
        showLoading();
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GroupResult> call3 = apiInterface.getMyGroups(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<GroupResult>() {
            @Override
            public void onResponse(Call<GroupResult> call, Response<GroupResult> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        new InsertMyGroupTask(response.body().result).execute();
                    } else {
                        getMyChannels();
                    }
                } else {
                    getMyChannels();
                }
            }

            @Override
            public void onFailure(Call<GroupResult> call, Throwable t) {
                Log.e(TAG, "getMyGroups: " + t.getMessage());
                call.cancel();
                getMyChannels();
            }
        });
    }

    private void getUserInfo(GroupData groupData, GroupData.GroupMembers groupMember) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), groupMember.memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                try {
                    Log.i(TAG, "getUserInfo: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        new InsertGroupMemberTask(groupData, groupMember, userdata).execute();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserInfo Failed: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void updateProfile() {
        if (TextUtils.isEmpty(name.getText())) {
            Snackbar.make(mainLay, getString(R.string.profileinfodetail), Snackbar.LENGTH_LONG).show();
        } else {
            if (from.equals("welcome") || from.equals("backup")) {
                SignIn(name.getText().toString());
            } else {
                if (about.getText().toString().trim().length() == 0) {
                    Snackbar.make(mainLay, getString(R.string.about_blank), Snackbar.LENGTH_LONG).show();
                } else {
                    updateMyProfile();
                }
            }
        }
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    void SignIn(String name) {
        showLoading();
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_PHONE_NUMBER, GetSet.getphonenumber());
        map.put(Constants.TAG_COUNTRY_CODE, GetSet.getcountrycode());
        map.put(Constants.TAG_COUNTRY, countryName);
        map.put(Constants.TAG_USER_NAME, name);

        Call<HashMap<String, String>> call3 = apiInterface.signin(map);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                try {
                    HashMap<String, String> userdata = response.body();
                    if (userdata.get("status").equals("true")) {
                        editor.putBoolean("isLogged", true);
                        editor.putString("userId", userdata.get("_id"));
                        editor.putString("userName", userdata.get("user_name"));
                        editor.putString("userImage", userdata.get("user_image"));
                        editor.putString("phoneNumber", userdata.get("phone_no"));
                        editor.putString("countryCode", userdata.get("country_code"));
                        editor.putString("countryName", userdata.get("country"));
                        editor.putString("token", userdata.get("token"));
                        editor.putString("about", userdata.get("about"));
                        editor.putString("privacyprofileimage", userdata.get("privacy_profile_image"));
                        editor.putString("privacylastseen", userdata.get("privacy_last_seen"));
                        editor.putString("privacyabout", userdata.get("privacy_about"));
                        editor.commit();
                        editor.apply();

                        GetSet.setLogged(true);
                        GetSet.setUserId(pref.getString("userId", null));
                        GetSet.setUserName(pref.getString("userName", null));
                        GetSet.setphonenumber(pref.getString("phoneNumber", null));
                        GetSet.setcountrycode(pref.getString("countryCode", null));
                        GetSet.setCountryName(pref.getString("countryName", null));
                        GetSet.setImageUrl(pref.getString("userImage", null));
                        GetSet.setToken(pref.getString("token", null));
                        GetSet.setAbout(pref.getString("about", null));
                        GetSet.setPrivacyprofileimage(pref.getString("privacyprofileimage", Constants.TAG_EVERYONE));
                        GetSet.setPrivacylastseen(pref.getString("privacylastseen", Constants.TAG_EVERYONE));
                        GetSet.setPrivacyabout(pref.getString("privacyabout", Constants.TAG_EVERYONE));

                        dbhelper.addContactDetails("", GetSet.getUserId(), GetSet.getUserName(),
                                GetSet.getphonenumber(), GetSet.getcountrycode(), GetSet.getImageUrl(),
                                GetSet.getPrivacyabout(), GetSet.getPrivacylastseen(), GetSet.getPrivacyprofileimage(),
                                GetSet.getAbout(), "true");
                        addDeviceId(ProfileInfo.this);
                    } else if (userdata.get("status").equals("false")) {
                        hideLoading();
                        Toast.makeText(getApplicationContext(), userdata.get("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    hideLoading();
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                t.printStackTrace();
                call.cancel();
                hideLoading();
            }
        });

    }

    private void compressImage(Uri mCurrentPhotoUri) {
        BitmapCompression imageCompression = new BitmapCompression(mContext, mCurrentPhotoUri, null) {
            @Override
            protected void onPostExecute(Bitmap compressedBitmap) {
                String fileName = "TEMP_" + System.currentTimeMillis() + ".jpg";
                File tempFile = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_PROFILE);
                if (tempFile != null) {
                    try {
                        byte[] bytes = FileUtils.readFileToByteArray(tempFile);
                        uploadImage(bytes, tempFile);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        imageCompression.execute();
    }

    private void addDeviceId(final Context context) {
        OSDeviceState deviceState = OneSignal.getDeviceState();
        Log.d(TAG, "addDeviceId: " + deviceState.getPushToken());
        if (deviceState != null) {
            oneSignalId = deviceState.getUserId();
            Log.i(TAG, "addDeviceId: " + oneSignalId);
            sendTokenToServer(oneSignalId);
        }
    }

    public void onOSSubscriptionChanged(OSSubscriptionStateChanges stateChanges) {
        if (!stateChanges.getFrom().isSubscribed() &&
                stateChanges.getTo().isSubscribed()) {
            // get player ID
            if (stateChanges.getTo().getUserId() != null) {
                oneSignalId = stateChanges.getTo().getUserId();
                Log.i(TAG, "onOSSubscriptionChanged: " + oneSignalId);
            }
        }

    }

    private void sendTokenToServer(String oneSignalId) {
        final String deviceId = android.provider.Settings.Secure.getString(getContentResolver(),
                android.provider.Settings.Secure.ANDROID_ID);

        Map<String, String> map = new HashMap<>();
        map.put("user_id", GetSet.getUserId());
        map.put("device_type", "1");
        map.put("device_id", deviceId);
        if (!TextUtils.isEmpty(oneSignalId)) {
            map.put("device_token", oneSignalId);
            map.put("onesignal_id", oneSignalId);
        }

        Log.d(TAG, "sendTokenToServer: " + new Gson().toJson(map));
        Call<Map<String, String>> call = apiInterface.pushsignin(GetSet.getToken(), map);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                Map<String, String> data = response.body();
                if (response.isSuccessful()) {
                    if (data.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                        if (from.equals("backup")) {
                            goToHome();
                        } else {
                            new GetContactTask().execute();
                        }
                    } else {
                        hideLoading();
                        makeToast(data.get(Constants.TAG_MESSAGE));
                        logout();
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
                hideLoading();
                Log.e(TAG, "addDeviceId: " + t.getMessage());
            }
        });
    }

    private void logout() {
        GetSet.logout();
        SharedPreferences settings = getSharedPreferences("SavedPref", MODE_PRIVATE);
        settings.edit().clear().apply();
        Intent logout = new Intent(getApplicationContext(), WelcomeActivity.class);
        logout.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(logout);
        finish();
    }

    void updateMyProfile() {
        showLoading();
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_USER_NAME, name.getText().toString().trim());
        if (about.getText().toString().trim().length() != 0) {
            map.put(Constants.TAG_ABOUT, about.getText().toString().trim());
        }

        Log.v(TAG, "updateMyProfileParams: " + map);
        Call<HashMap<String, String>> call3 = apiInterface.updatemyprofile(GetSet.getToken(), map);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                try {
                    HashMap<String, String> userdata = response.body();
                    Log.v(TAG, "updateMyProfileResponse: " + userdata.toString());

                    if (userdata.get("status").equals("true")) {
                        editor.putBoolean("isLogged", true);
                        editor.putString("userId", userdata.get("_id"));
                        editor.putString("userName", userdata.get("user_name"));
                        editor.putString("userImage", userdata.get("user_image"));
                        editor.putString("phoneNumber", userdata.get("phone_no"));
                        editor.putString("countryCode", userdata.get("country_code"));
                        editor.putString("token", "" + GetSet.getToken());
                        editor.putString("about", userdata.get("about"));
                        editor.putString("privacyprofileimage", userdata.get("privacy_profile_image"));
                        editor.putString("privacylastseen", userdata.get("privacy_last_seen"));
                        editor.putString("privacyabout", userdata.get("privacy_about"));
                        editor.commit();
                        editor.apply();

                        GetSet.setLogged(true);
                        GetSet.setUserId(pref.getString("userId", null));
                        GetSet.setUserName(pref.getString("userName", null));
                        GetSet.setphonenumber(pref.getString("phoneNumber", null));
                        GetSet.setcountrycode(pref.getString("countryCode", null));
                        GetSet.setImageUrl(pref.getString("userImage", null));
                        GetSet.setToken(pref.getString("token", null));
                        GetSet.setAbout(pref.getString("about", null));
                        GetSet.setPrivacyprofileimage(pref.getString("privacyprofileimage", Constants.TAG_EVERYONE));
                        GetSet.setPrivacylastseen(pref.getString("privacylastseen", Constants.TAG_EVERYONE));
                        GetSet.setPrivacyabout(pref.getString("privacyabout", Constants.TAG_EVERYONE));

                        Toast.makeText(getApplicationContext(), getString(R.string.updated_successfully), Toast.LENGTH_SHORT).show();
                        hideLoading();
                        finish();

                    } else if (userdata.get("status").equals("false")) {
                        hideLoading();
                        Toast.makeText(getApplicationContext(), userdata.get("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    hideLoading();
                }

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "updateMyProfile: " + t.getMessage());
                call.cancel();
                hideLoading();
            }
        });

    }

    public void saveMyContacts(List<String> contacts, ArrayList<HashMap<String, String>> contactsName) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, "" + contacts);
        Call<SaveMyContacts> call = apiInterface.saveMyContacts(GetSet.getToken(), map);
        call.enqueue(new Callback<SaveMyContacts>() {
            @Override
            public void onResponse(Call<SaveMyContacts> call, Response<SaveMyContacts> response) {
                updateMyContacts(contacts, contactsName);
            }

            @Override
            public void onFailure(Call<SaveMyContacts> call, Throwable t) {
                Log.e(TAG, "saveMyContacts: " + t.getMessage());
                call.cancel();
                hideLoading();
            }
        });
    }

    void updateMyContacts(List<String> contactsNum, ArrayList<HashMap<String, String>> contactsName) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, "" + contactsNum);
        map.put(Constants.TAG_PHONE_NUMBER, GetSet.getphonenumber());

        Log.v(TAG, "updateMyContacts: " + map);
        Call<ContactsData> call3 = apiInterface.updateMyContacts(GetSet.getToken(), map);
        call3.enqueue(new Callback<ContactsData>() {
            @Override
            public void onResponse(Call<ContactsData> call, Response<ContactsData> response) {
                try {
                    if (response.isSuccessful()) {
                        ContactsData data = response.body();
//                        Log.i(TAG, "updateMyContactsResponse: " + new Gson().toJson(data));
                        Log.i(TAG, "updateMyContactsResponse: " + data.status);
                        if (data.status.equals("true")) {
                            new UpdateContactTask(data, contactsName).execute();
                        } else if (data.status.equals("false")) {
                            goToHome();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    hideLoading();
                }
            }

            @Override
            public void onFailure(Call<ContactsData> call, Throwable t) {
                Log.e(TAG, "updateMyContacts: " + t.getMessage());
                call.cancel();
                hideLoading();
            }
        });

    }

    private void startForegroundService() {
        Intent service = new Intent(ProfileInfo.this, ForegroundService.class);
        service.putExtra(Constants.TAG_FROM, "login");
        service.setAction("start");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service);
        } else {
            startService(service);
        }
    }

    private void uploadImage(byte[] imageBytes, File srcFile) {
        progressDialog.show();
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("user_image", "openImage.jpg", requestFile);

        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call3 = apiInterface.upmyprofile(GetSet.getToken(), body, userid);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                if (response.isSuccessful()) {
                    String apiFileName = response.body().get(Constants.TAG_USER_IMAGE);
                    if (!TextUtils.isEmpty(apiFileName)) {
                        storageManager.renameFile(null, srcFile.getAbsolutePath(), apiFileName, StorageManager.TAG_IMAGE);
                        File tempFile = storageManager.getSrcFile(StorageManager.TAG_PROFILE, apiFileName, StorageManager.TAG_IMAGE);
                        GetSet.setImageUrl(apiFileName);
                        editor.putString("userImage", apiFileName);
                        editor.commit();
                        editor.apply();

                        Glide.with(ProfileInfo.this).load(tempFile)
                                .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                                .listener(new RequestListener<Drawable>() {
                                    @Override
                                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                        noimage.setVisibility(View.VISIBLE);
                                        userImage.setVisibility(View.GONE);
                                        return false;
                                    }

                                    @Override
                                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                        noimage.setVisibility(View.GONE);
                                        userImage.setVisibility(View.VISIBLE);
                                        return false;
                                    }
                                }).into(userImage);
                        Toast.makeText(getApplicationContext(), getString(R.string.updated_successfully), Toast.LENGTH_SHORT).show();
                    }
                    if (progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.v(TAG, "uploadImage=" + t.getMessage());
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                call.cancel();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.v(TAG, "requestCode=" + requestCode);
        switch (requestCode) {
            case Constants.CONTACT_REQUEST_CODE:
                int permissionContacts = ContextCompat.checkSelfPermission(ProfileInfo.this,
                        READ_CONTACTS);
                if (permissionContacts == PackageManager.PERMISSION_GRANTED) {
                    if (NetworkStatus.isConnected()) {
                        updateProfile();
                    } else {
                        Snackbar.make(mainLay, getString(R.string.no_internet_connection), Snackbar.LENGTH_LONG).show();
                    }
                }
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.userImage:
            case R.id.noimage:
                openPickerDialog();
                break;

            case R.id.backbtn:
                backPressed();
                break;
        }
    }

    public void showLoading() {
        progressbar.setVisibility(View.VISIBLE);
        fab.setVisibility(View.GONE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        btnNext.setEnabled(false);
//        if (progressDialog != null && !progressDialog.isShowing()){
//            progressDialog.show();
//        }

    }

    public void hideLoading() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        progressbar.setVisibility(View.GONE);
        fab.setVisibility(View.VISIBLE);
        btnNext.setEnabled(true);
//        if(progressDialog != null && progressDialog.isShowing()){
//            progressDialog.dismiss();
//        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @SuppressLint("StaticFieldLeak")
    private class GetContactTask extends AsyncTask<Void, Integer, Void> {
        List<String> contactsNum = new ArrayList<>();
        ArrayList<HashMap<String, String>> contactsName = new ArrayList<>();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Uri uri = null;
            uri = ContactsContract.CommonDataKinds.Contactables.CONTENT_URI;
            ContentResolver cr = getContentResolver();
            Cursor cur = cr.query(uri, Constants.PROJECTION, Constants.SELECTION, Constants.SELECTION_ARGS, null);

            if (cur != null) {
                try {
                    final int nameIndex = cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                    final int numberIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    while (cur.moveToNext()) {
                        HashMap<String, String> map = new HashMap<>();
                        String phoneNo = cur.getString(numberIndex).replace(" ", "");
                        String name = cur.getString(nameIndex);
                        map.put(Constants.TAG_SAVED_NAME, name);
                        String formattedPhoneNumber = utils.getFormattedPhoneNumber(phoneNo);
                        if (!TextUtils.isEmpty(formattedPhoneNumber)) {
                            contactsNum.add(formattedPhoneNumber);
                            map.put(Constants.TAG_PHONE_NUMBER, formattedPhoneNumber);
                            contactsName.add(map);
                        }
                    }
                } finally {
                    cur.close();
                }
            }
//            Log.e(TAG, "getContactList: " + contactsNum.size());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            saveMyContacts(contactsNum, contactsName);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class InsertMyChannelTask extends AsyncTask<Void, Integer, Void> {
        List<ChannelResult.Result> channelList = new ArrayList<>();

        public InsertMyChannelTask(List<ChannelResult.Result> result) {
            this.channelList = result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            for (ChannelResult.Result result : channelList) {
                dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, result.channelImage, result.channelType,
                        result.adminId, GetSet.getUserName(), result.totalSubscribers, result.createdTime,
                        Constants.TAG_USER_CHANNEL, "", result.blockStatus, result.report);

                if (!dbhelper.isChannelIdExistInMessages(result.channelId)) {
                    String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                    RandomString randomString = new RandomString(10);
                    String messageId = result.channelId + randomString.nextString();
                    dbhelper.addChannelMessages(result.channelId, Constants.TAG_CHANNEL, messageId, "create_channel",
                            "", "", "", "", "", "", "",
                            currentUTCTime, "", "read");

                    int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                    dbhelper.addChannelRecentMsgs(result.channelId, messageId, currentUTCTime, "" + unseenCount);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            getSubscribedChannels();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class InsertSubscribedChannelTask extends AsyncTask<Void, Integer, Void> {
        List<ChannelResult.Result> channelList = new ArrayList<>();

        public InsertSubscribedChannelTask(List<ChannelResult.Result> result) {
            this.channelList = result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            for (ChannelResult.Result result : channelList) {
                if (dbhelper.isChannelExist(result.channelId)) {
                    dbhelper.updateChannelWithoutAdminName(result.channelId, result.channelName, result.channelDes, result.channelImage,
                            result.channelType != null ? result.channelType : Constants.TAG_PUBLIC, result.adminId != null ? result.adminId : "", result.totalSubscribers);
                } else {
                    dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, result.channelImage, result.channelType,
                            result.adminId, "", result.totalSubscribers, result.createdTime,
                            Constants.TAG_USER_CHANNEL, Constants.TAG_TRUE, result.blockStatus, result.report);
                }
                addChannelId(result.channelId);
                if (!dbhelper.isChannelIdExistInMessages(result.channelId)) {
                    String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                    RandomString randomString = new RandomString(10);
                    String messageId = result.channelId + randomString.nextString();
                    dbhelper.addChannelMessages(result.channelId, Constants.TAG_CHANNEL, messageId, "create_channel",
                            "", "", "", "", "", "", "",
                            currentUTCTime, "", "");

                    int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                    dbhelper.addChannelRecentMsgs(result.channelId, messageId, currentUTCTime, "" + unseenCount);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            hideLoading();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class InsertMyGroupTask extends AsyncTask<Void, Integer, Void> {
        List<GroupData> result = new ArrayList<>();

        public InsertMyGroupTask(List<GroupData> result) {
            this.result = result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            ApplicationClass.groupList.clear();
            ApplicationClass.groupList.add(GetSet.getUserId());
            for (GroupData groupData : result) {
                dbhelper.createGroup(groupData.groupId, groupData.groupAdminId, groupData.groupName, groupData.createdAt, groupData.groupImage);
                addGroupId(groupData.groupId);
                for (GroupData.GroupMembers groupMember : groupData.groupMembers) {
                    getUserInfo(groupData, groupMember);
                }

                String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                RandomString randomString = new RandomString(10);
                String messageId = groupData.groupId + randomString.nextString();

                if (groupData.groupAdminId.equals(GetSet.getUserId())) {
                    // update delivery status to read if the user is admin for that group
                    dbhelper.addGroupMessages(messageId, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "create_group",
                            "", "", "", "",
                            "", "", "", groupData.createdAt, "", "read");
                } else {
                    String unixStamp2 = DateUtils.getInstance(mContext).getCurrentUTCTime();
                    String messageId2 = groupData.groupId + randomString.nextString();
                    dbhelper.addGroupMessages(messageId2, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "add_member",
                            "", "", "", "",
                            "", "", "", unixStamp2, "", "");
                    dbhelper.addGroupMessages(messageId, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "create_group",
                            "", "", "", "",
                            "", "", "", groupData.createdAt, "", "");
                }


                int unseenCount = dbhelper.getUnseenGroupMessagesCount(groupData.groupId);
                dbhelper.addGroupRecentMsg(groupData.groupId, messageId, GetSet.getUserId(), currentUTCTime, "" + unseenCount);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            getMyChannels();
        }
    }

    private void addGroupId(String groupId) {
        if (!ApplicationClass.groupList.contains(groupId)) {
            ApplicationClass.groupList.add(groupId);
        }
    }

    private void addChannelId(String channelId) {
        if (!ApplicationClass.channelList.contains(channelId)) {
            ApplicationClass.channelList.add(channelId);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class InsertGroupMemberTask extends AsyncTask<Void, Integer, Void> {
        Map<String, String> userdata = new HashMap<>();
        GroupData groupData = new GroupData();
        GroupData.GroupMembers groupMember = new GroupData().new GroupMembers();

        public InsertGroupMemberTask(GroupData groupData, GroupData.GroupMembers groupMember, Map<String, String> userdata) {
            this.groupData = groupData;
            this.userdata = userdata;
            this.groupMember = groupMember;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            String name = "";
            HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), userdata.get(Constants.TAG_PHONE_NUMBER));
                name = map.get(Constants.TAG_USER_NAME);

            dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE),
                    userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));

            String memberKey = groupData.groupId + groupMember.memberId;
            dbhelper.createGroupMembers(memberKey, groupData.groupId, groupMember.memberId, groupMember.memberRole);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class UpdateContactTask extends AsyncTask<Void, Integer, Void> {
        ContactsData data = new ContactsData();
        ArrayList<HashMap<String, String>> contactName = new ArrayList<>();
        List<String> tempContacts = new ArrayList<>();

        public UpdateContactTask(ContactsData data, ArrayList<HashMap<String, String>> contactData) {
            this.data = data;
            this.contactName = contactData;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            tempContacts.add(GetSet.getUserId());
            for (ContactsData.Result result : data.result) {
                String savedName = "";
                String name = "";
                HashMap<String, String> map;
                map = ApplicationClass.getContactOrNot(getApplicationContext(), result.phone_no);
                if (map.get("isAlready").equals("true")) {
                    name = map.get(Constants.TAG_USER_NAME);
                }

                result.isDeletedAccount = "0";
                dbhelper.addContactDetails(name, result);
            }
            updateDeletedContacts(tempContacts);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            goToHome();
        }
    }

    private void updateDeletedContacts(List<String> tempContacts) {
        mExecutorService.execute(new Runnable() {
            public void run() {
                String array = null;
                array = String.join(",", tempContacts).replaceAll("([^,]+)", "\"$1\"");
                Log.d(TAG, "updateDeletedContacts: " + array);
                dbhelper.updateDeletedContacts(ProfileInfo.this, array);
            }
        });
    }

    private void goToHome() {
        startForegroundService();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideLoading();
                if (!TextUtils.isEmpty(GetSet.getInviteLink()) && GetSet.getInviteLink().contains("/groups")) {
                    Intent intent = new Intent();
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    intent.setData(Uri.parse(GetSet.getInviteLink()));
                    intent.setAction(Intent.ACTION_VIEW);
                    startActivity(intent);
                    finish();
                    GetSet.setInviteLink(null);
                } else if (!TextUtils.isEmpty(GetSet.getInviteLink()) && GetSet.getInviteLink().contains("/channel")) {
                    Intent intent = new Intent();
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    intent.setData(Uri.parse(GetSet.getInviteLink()));
                    intent.setAction(Intent.ACTION_VIEW);
                    startActivity(intent);
                    finish();
                    GetSet.setInviteLink(null);
                } else {
                    Intent in = new Intent(ProfileInfo.this, MainActivity.class);
                    startActivity(in);
                    finish();
                }
            }
        }, 500);
    }
}