package com.app.model;

import com.google.gson.annotations.SerializedName;

public class SaveMyContacts {
    @SerializedName("status")
    public String status;
    @SerializedName("message")
    public String message;
}
