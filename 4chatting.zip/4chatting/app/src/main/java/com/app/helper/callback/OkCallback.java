package com.app.helper.callback;

public interface OkCallback {
    void onOkClicked(Object object);
}
