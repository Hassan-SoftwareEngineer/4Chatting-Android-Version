package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;

public class ChannelChatResult {
    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public HashMap<String, ChannelMessage> result;
}
