package com.app.fourchattingapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.app.model.ChannelResult;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.app.external.RandomString;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.NetworkUtil;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.CAMERA;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.utils.Constants.TAG_TRUE;

public class CreateChannelActivity extends BaseActivity implements View.OnClickListener, SocketConnection.ChannelCallbackListener {

    private String TAG = this.getClass().getSimpleName();
    ImageView backbtn, searchbtn, optionbtn, cancelbtn, fab;
    LinearLayout buttonLayout, channelTypeLayout;
    CircleImageView userImage, noimage;
    TextView title;
    EditText edtChannelName, edtChannelDes;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    DatabaseHandler dbhelper;
    StorageManager storageManager;
    RadioButton btnPublic, btnPrivate;
    RelativeLayout publicLay, privateLay, mainLay;
    String channelImage = "";
    SocketConnection socketConnection;
    ChannelResult.Result channelData;
    String channelId;
    boolean isImageChanged = false, isEdit = false;
    private ApiInterface apiInterface;
    ProgressDialog progressDialog;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private ActivityResultLauncher<Intent> cameraResultLauncher;
    private Uri mCurrentPhotoUri;
    boolean isCameraClicked = false, isGalleryClicked = false;
    private Context mContext;
    private static final int CAMERA_REQ_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_channel);

        mContext = this;
        socketConnection = SocketConnection.getInstance(this);
        SocketConnection.getInstance(this).setChannelCallbackListener(this);
        pref = CreateChannelActivity.this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        dbhelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        userImage = findViewById(R.id.userImage);
        noimage = findViewById(R.id.noimage);

        title = findViewById(R.id.title);
        edtChannelName = findViewById(R.id.edtChannelName);
        edtChannelDes = findViewById(R.id.edtChannelDes);
        backbtn = findViewById(R.id.backbtn);
        searchbtn = findViewById(R.id.searchbtn);
        optionbtn = findViewById(R.id.optionbtn);
        buttonLayout = findViewById(R.id.buttonLayout);
        channelTypeLayout = findViewById(R.id.channelTypeLayout);
        btnPublic = findViewById(R.id.btnPublic);
        btnPrivate = findViewById(R.id.btnPrivate);
        publicLay = findViewById(R.id.publicLay);
        privateLay = findViewById(R.id.privateLay);
        fab = findViewById(R.id.fab);
        mainLay = findViewById(R.id.mainLay);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
            fab.setRotation(180);
        } else {
            backbtn.setRotation(0);
            fab.setRotation(0);
        }
        initPermission();
        initActivityResultLauncher();
        title.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        searchbtn.setVisibility(View.GONE);
        optionbtn.setVisibility(View.GONE);

        edtChannelName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(30)});
        edtChannelDes.setFilters(new InputFilter[]{new InputFilter.LengthFilter(250)});

        if (getIntent().getStringExtra(Constants.TAG_CHANNEL_ID) != null) {
            channelId = getIntent().getStringExtra(Constants.TAG_CHANNEL_ID);
            channelData = dbhelper.getChannelInfo(channelId);
            isEdit = true;
        }

        title.setText(channelId == null ? getString(R.string.create_channel) : getString(R.string.edit_channel));

        if (isEdit) {
            edtChannelName.setText("" + channelData.channelName);
            edtChannelDes.setText("" + channelData.channelDes);
            channelImage = channelData.channelImage;
            Glide.with(getApplicationContext()).load(Constants.CHAT_IMG_PATH + channelImage)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            noimage.setVisibility(View.VISIBLE);
                            userImage.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            noimage.setVisibility(View.GONE);
                            userImage.setVisibility(View.VISIBLE);
                            return false;
                        }
                    }).into(userImage);

            channelTypeLayout.setVisibility(View.GONE);

            btnPublic.setChecked(channelData.channelType.equalsIgnoreCase(Constants.TAG_PUBLIC));
            btnPrivate.setChecked(channelData.channelType.equalsIgnoreCase(Constants.TAG_PRIVATE));
        }
        fab.setOnClickListener(this);
        userImage.setOnClickListener(this);
        noimage.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        btnPublic.setOnClickListener(this);
        btnPrivate.setOnClickListener(this);
        privateLay.setOnClickListener(this);
        publicLay.setOnClickListener(this);

    }

    private void initPermission() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "storagePermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isCameraClicked) {
                        takeCameraPictures();
                    } else {
                        pickGalleryPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CreateChannelActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(CreateChannelActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });

        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        if (PermissionsUtils.checkStoragePermission(mContext)) {
                            takeCameraPictures();
                        } else {
                            requestStoragePermissions();
                        }
                    } else {
                        takeCameraPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CreateChannelActivity.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(CreateChannelActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.camera_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void initActivityResultLauncher() {
        cameraResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    boolean isCamera = (result == null
                            || result.getData() == null || result.getData().getData() == null);
                    if (isCamera) {     /** CAMERA **/
                        Log.d(TAG, "onActivityResult: " + mCurrentPhotoUri.getPath());
                    } else {            /** ALBUM **/
                        mCurrentPhotoUri = result.getData().getData();
                    }
                    isImageChanged = true;
                    Glide.with(getApplicationContext()).load(mCurrentPhotoUri)
                            .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                            .listener(new RequestListener<Drawable>() {
                                @Override
                                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                    noimage.setVisibility(View.VISIBLE);
                                    userImage.setVisibility(View.GONE);
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                    noimage.setVisibility(View.GONE);
                                    userImage.setVisibility(View.VISIBLE);
                                    return false;
                                }
                            }).into(userImage);
                }

            }
        });
    }

    private void openPickerDialog() {

        View contentView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_pick_options, findViewById(R.id.parentLay), false);
        BottomSheetDialog pickerOptionsSheet = new BottomSheetDialog(this, R.style.SimpleBottomDialog);
        pickerOptionsSheet.setCanceledOnTouchOutside(true);
        pickerOptionsSheet.setContentView(contentView);
        //    pickerOptionsSheet.setDismissWithAnimation(true);

        View layoutCamera = contentView.findViewById(R.id.container_camera_option);
        View layoutGallery = contentView.findViewById(R.id.container_gallery_option);

        layoutCamera.setOnClickListener(v -> {
            pickerOptionsSheet.dismiss();
            isCameraClicked = true;
            isGalleryClicked = false;
            if (ContextCompat.checkSelfPermission(this, CAMERA) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        takeCameraPictures();
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    takeCameraPictures();
                }
            } else {
                requestCameraPermission();
            }
        });
        layoutGallery.setOnClickListener(v -> {
            isCameraClicked = false;
            isGalleryClicked = true;
            pickerOptionsSheet.dismiss();
            if (PermissionsUtils.checkStoragePermission(CreateChannelActivity.this)) {
                pickGalleryPictures();
            } else {
                requestStoragePermissions();
            }
        });

        pickerOptionsSheet.show();
    }

    private void requestCameraPermission() {
        cameraPermissionResult.launch(new String[]{CAMERA});
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void takeCameraPictures() {
        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        if (captureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                //     Timber.e(ex);
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                mCurrentPhotoUri = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri);
                cameraResultLauncher.launch(captureIntent);
            }
        }
    }

    private void pickGalleryPictures() {
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Intent pickIntent = new Intent(Intent.ACTION_PICK, collection);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(pickIntent, "Select a picture");
        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            cameraResultLauncher.launch(chooserIntent);
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        // Save a file: path for use with ACTION_VIEW intents
        return image;
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.userImage:
            case R.id.noimage:
                openPickerDialog();
                break;
            case R.id.btnPublic:
                btnPrivate.setChecked(false);
                btnPublic.setChecked(true);
                break;
            case R.id.btnPrivate:
                btnPrivate.setChecked(true);
                btnPublic.setChecked(false);
                break;
            case R.id.publicLay:
                btnPrivate.setChecked(false);
                btnPublic.setChecked(true);
                break;
            case R.id.privateLay:
                btnPublic.setChecked(false);
                btnPrivate.setChecked(true);
                break;
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.fab:
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (TextUtils.isEmpty(edtChannelName.getText().toString().trim())) {
                        makeToast(getString(R.string.enter_channel_name));
                    } else if (TextUtils.isEmpty(edtChannelDes.getText().toString().trim())) {
                        makeToast(getString(R.string.enter_channel_description));
                    } else {
                        if (!isEdit) {
                            if (progressDialog != null && !progressDialog.isShowing())
                                progressDialog.show();
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
                                jsonObject.put(Constants.TAG_CHANNEL_NAME, "" + edtChannelName.getText());
                                jsonObject.put(Constants.TAG_CHANNEL_DES, "" + edtChannelDes.getText());
                                jsonObject.put(Constants.TAG_CHANNEL_TYPE, btnPublic.isChecked() ? Constants.TAG_PUBLIC : Constants.TAG_PRIVATE);
                                socketConnection.createChannel(jsonObject);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            if (!channelData.channelName.equals(edtChannelName.getText().toString()) ||
                                    !channelData.channelDes.equals(edtChannelDes.getText().toString()) ||
                                    isImageChanged) {
                                updateChannel();
                            }
                        }
                    }
                }
                break;
        }
    }

    private void updateChannel() {
        if (progressDialog != null && !progressDialog.isShowing()) progressDialog.show();
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_CHANNEL_ID, channelId);
        map.put(Constants.TAG_CHANNEL_NAME, "" + edtChannelName.getText());
        map.put(Constants.TAG_CHANNEL_DES, "" + edtChannelDes.getText());
        map.put(Constants.TAG_CHANNEL_TYPE, btnPublic.isChecked() ? Constants.TAG_PUBLIC : Constants.TAG_PRIVATE);
        Call<HashMap<String, String>> call = apiInterface.updateChannel(GetSet.getToken(), map);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> hashMap = response.body();
//                Log.i(TAG, "updateChannel: " + hashMap);
                dbhelper.addChannel(hashMap.get(Constants.TAG_ID), "" + hashMap.get(Constants.TAG_CHANNEL_NAME), "" + hashMap.get(Constants.TAG_CHANNEL_DES),
                        hashMap.get(Constants.TAG_CHANNEL_IMAGE), hashMap.get(Constants.TAG_CHANNEL_TYPE),
                        hashMap.get(Constants.TAG_CHANNEL_ADMIN_ID), GetSet.getUserName(), hashMap.get(Constants.TAG_TOTAL_SUBSCRIBERS),
                        hashMap.get(Constants.TAG_CREATED_TIME), Constants.TAG_USER_CHANNEL, "", channelData.blockStatus, channelData.report);
                if (isImageChanged) {
                    try {
                        uploadImage(StorageManager.getBytes(getContentResolver().openInputStream(mCurrentPhotoUri)), channelId);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (progressDialog != null && progressDialog.isShowing())
                        progressDialog.dismiss();
                    if (!channelData.channelName.equals(edtChannelName.getText().toString())) {
                        sendChannelModified("subject");
                    }
                    if (!channelData.channelDes.equals(edtChannelDes.getText().toString())) {
                        sendChannelModified("channel_des");
                    }
                    finish();
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                call.cancel();
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
//                Log.e(TAG, "updateChannel: " + t.getMessage());
            }
        });
    }

    private void uploadImage(byte[] imageBytes, final String channelId) {
        if (progressDialog != null && !progressDialog.isShowing()) {
            progressDialog.show();
        }
        RequestBody requestFile = RequestBody.create(MediaType.parse("openImage/*"), imageBytes);
        MultipartBody.Part body = MultipartBody.Part.createFormData("channel_attachment", "openImage.jpg", requestFile);

        RequestBody channelID = RequestBody.create(MediaType.parse("multipart/form-data"), channelId);
        Call<HashMap<String, String>> call3 = apiInterface.uploadChannelImage(GetSet.getToken(), body, channelID);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
                HashMap<String, String> data = response.body();
//                Log.i(TAG, "uploadChannelImage: " + data);
                if (data.get(Constants.TAG_STATUS).equals(TAG_TRUE)) {
                    channelImage = data.get(Constants.TAG_CHANNEL_IMAGE);
                    dbhelper.updateChannelData(channelId, Constants.TAG_CHANNEL_IMAGE, channelImage);

                    if (isEdit) {
                        sendChannelModified("channel_image");
                        if (!channelData.channelName.equals(edtChannelName.getText().toString())) {
                            sendChannelModified("subject");
                        }
                        if (!channelData.channelDes.equals(edtChannelDes.getText().toString())) {
                            sendChannelModified("channel_des");
                        }
                        finish();
                    } else {
                        sendChannelModified("channel_image");
                        finish();
                        Intent intent = new Intent(getApplicationContext(), ChannelCreatedActivity.class);
                        intent.putExtra(Constants.TAG_CHANNEL_ID, channelId);
                        startActivity(intent);
                    }
                }

                finish();
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
//                Log.e(TAG, "uploadChannelImage: " + t.getMessage());
                call.cancel();
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    private void sendChannelModified(String type) {
        try {
            ChannelResult.Result channelData = dbhelper.getChannelInfo(channelId);
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            RandomString randomString = new RandomString(10);
            String messageId = channelId + randomString.nextString();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_CHANNEL_ID, channelId);
            jsonObject.put(Constants.TAG_CHANNEL_NAME, channelData.channelName);
            jsonObject.put(Constants.TAG_CHAT_TYPE, Constants.TAG_CHANNEL);
            jsonObject.put(Constants.TAG_MESSAGE_ID, messageId);
            jsonObject.put(Constants.TAG_MESSAGE_TYPE, type);
            jsonObject.put(Constants.TAG_MESSAGE, channelData.channelDes);
            jsonObject.put(Constants.TAG_ATTACHMENT, channelData.channelImage);
            jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);
            socketConnection.messageToChannel(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onChannelCreated(JSONObject jsonObject) {
        try {
            channelId = jsonObject.getString(Constants.TAG_ID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isImageChanged) {
                    try {
                        uploadImage(StorageManager.getBytes(getContentResolver().openInputStream(mCurrentPhotoUri)), channelId);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (progressDialog != null && !progressDialog.isShowing())
                        progressDialog.dismiss();
                    Intent intent = new Intent(getApplicationContext(), ChannelCreatedActivity.class);
                    intent.putExtra(Constants.TAG_CHANNEL_ID, channelId);
                    startActivity(intent);
                    finish();
                }

            }
        });
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy: ");
        SocketConnection.getInstance(this).setChannelCallbackListener(null);
        super.onDestroy();
    }
}
