package com.app.helper.connectivity;

import static android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;

public class ConnectionLiveData extends LiveData<Boolean> {
    private static final String TAG = ConnectionLiveData.class.getSimpleName();
    private ConnectivityManager.NetworkCallback networkCallback;
    private ConnectivityManager cm;
    private Context mContext;

    public ConnectionLiveData(Context context) {
        mContext = context;
        cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Override
    protected void onActive() {
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network network) {
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                    boolean isConnected = capabilities.hasCapability(NET_CAPABILITY_INTERNET);
                    NetworkStatus.isConnected = isConnected;
                    postValue(isConnected);
                } else {
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    boolean isConnected = networkInfo.isConnectedOrConnecting();
                    NetworkStatus.isConnected = isConnected;
                    postValue(isConnected);
                }
            }

            @Override
            public void onLost(@NonNull Network network) {
                super.onLost(network);
                NetworkStatus.isConnected = false;
                postValue(false);
            }
        };

        NetworkRequest networkRequest = new NetworkRequest.Builder()
                .addCapability(NET_CAPABILITY_INTERNET)
                .build();
        cm.registerNetworkCallback(networkRequest, networkCallback);
    }

    @Override
    protected void onInactive() {
        super.onInactive();
        try {
            cm.unregisterNetworkCallback(networkCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
