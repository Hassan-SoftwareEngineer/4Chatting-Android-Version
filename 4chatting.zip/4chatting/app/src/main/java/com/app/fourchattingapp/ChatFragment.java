package com.app.fourchattingapp;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.fourchattingapp.status.CameraViewActivity;
import com.app.fourchattingapp.status.StoryActivity;
import com.app.model.MessagesData;
import com.app.model.StatusDatas;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;
import com.app.helper.StorageManager;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.event.NewMessageEvent;
import com.app.model.ContactsData;
import com.app.model.RecentMessages;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_MEDIA_IMAGES;
import static android.content.Context.MODE_PRIVATE;
import static androidx.recyclerview.widget.RecyclerView.VERTICAL;
import static androidx.recyclerview.widget.RecyclerView.ViewHolder;
import static com.app.utils.Constants.TAG_MY_CONTACTS;
import static com.app.utils.Constants.TAG_NOBODY;
import static com.app.utils.Constants.TAG_TRUE;

public class ChatFragment extends Fragment implements SocketConnection.RecentChatReceivedListener {

    private static final int CAPTURE_MEDIA = 369;
    private final String TAG = ChatFragment.this.getClass().getSimpleName();
    RecyclerViewAdapter recyclerViewAdapter;
    LinearLayout nullLay;
    TextView nullText, recenttitle;
    ArrayList<RecentMessages> chatList = new ArrayList<>();
    List<ContactsData.Result> statusList = new ArrayList<>();
    LinearLayoutManager linearLayoutManager;
    DatabaseHandler dbhelper;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    List<StatusDatas> datas = new ArrayList<>();
    HorizontalScrollView horizontalScrollLay;
    private StatusRecyclerAdapter statusRecyclerAdapter;
    private RecyclerView recyclerView, statusRecyclerView;
    private ActivityResultLauncher<String[]> statusPermissionResult;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String> storagePermissionResult2;

    private DateUtils dateUtils;
    private Context mContext;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler mainHandler = new Handler(Looper.myLooper());
    private int selectedPosition = -1;
    private boolean isStatusClicked = false, isChatClicked = false;

    public ChatFragment() {

    }

    public static String getURLForResource(int resourceId) {
        return Uri.parse("android.resource://com.app.fourchattingapp/" + resourceId).toString();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        Log.v(TAG, "onCreateView");
        pref = getActivity().getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        nullLay = view.findViewById(R.id.nullLay);
        nullText = view.findViewById(R.id.nullText);
        recyclerView = view.findViewById(R.id.recyclerView);
        statusRecyclerView = view.findViewById(R.id.statusRecyclerView);
        recenttitle = view.findViewById(R.id.recenttitle);
        horizontalScrollLay = view.findViewById(R.id.horizontalScrollLay);
        if (mContext == null) mContext = getActivity();
        dateUtils = DateUtils.getInstance(mContext);


        dbhelper = DatabaseHandler.getInstance(getActivity());
        SocketConnection.getInstance(getActivity()).setRecentChatReceivedListener(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        statusRecyclerView.setLayoutManager(layoutManager);

        updateStatusAry();
        statusRecyclerAdapter = new StatusRecyclerAdapter(getContext(), statusList);
        statusRecyclerView.setAdapter(statusRecyclerAdapter);
        statusRecyclerView.setNestedScrollingEnabled(false);

        linearLayoutManager = new LinearLayoutManager(getActivity(), VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        initPermission();
//        updateChatAry();
        getRecentChats();
        recyclerViewAdapter = new RecyclerViewAdapter(getActivity(), chatList);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();

        nullText.setText(R.string.no_chat_yet_buddy);

        return view;
    }

    private void initPermission() {
        statusPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    openCamera();
                } else {
                    boolean neverAsked = false;
                    Log.d(TAG, "requestPermissions: ");
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), x.getKey())) {
                                statusPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                String alertMsg ="";
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    alertMsg = getActivity().getString(R.string.status_permission_error_T);
                                }else{
                                    alertMsg = getActivity().getString(R.string.status_permission_error);
                                }
                                PermissionsUtils.openPermissionDialog(getActivity(), new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, alertMsg);
                            }
                            break;
                        }
                    }
                }

            }
        });

        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isChatClicked && selectedPosition != -1 && ((chatList.size() - 1) >= selectedPosition)) {
                        Intent i = new Intent(mContext, ChatActivity.class);
                        i.putExtra("user_id", chatList.get(selectedPosition).getUserId());
                        startActivity(i);
                    } else {

                    }
                } else {
                    boolean neverAsked = false;
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                String alertMsg ="";
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    alertMsg =mContext.getString(R.string.storage_error_T);
                                }else{
                                    alertMsg =mContext.getString(R.string.storage_error);
                                }
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, alertMsg);
                            }
                            break;
                        }
                    }
                }

            }

        });






    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    private void moveToStart() {
        if (statusList.size() > 0) {
            horizontalScrollLay.post(new Runnable() {
                @Override
                public void run() {
                    horizontalScrollLay.fullScroll(View.FOCUS_BACKWARD);
                }
            });
        }
    }

    public void refreshAdapter() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null) {
                    updateChatAry();
                    recyclerViewAdapter.notifyDataSetChanged();
                }
                if (statusRecyclerAdapter != null) {
                    updateStatusAry();
                    statusRecyclerAdapter.notifyDataSetChanged();
                    statusRecyclerView.smoothScrollToPosition(0);
                }
            }
        });
    }

    void openCamera() {
//        Intent intent = new Intent(mContext, CameraKitActivity.class);
        Intent intent = new Intent(mContext, CameraViewActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

    private void getRecentChats() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                chatList.clear();
                chatList.addAll(dbhelper.getAllRecentMessages(getActivity()));
                Log.d(TAG, "getRecentChats: " + chatList.size());
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (chatList.size() == 0) {
                            nullLay.setVisibility(View.VISIBLE);
                            recenttitle.setVisibility(View.GONE);
                        } else {
                            nullLay.setVisibility(View.GONE);
                            recenttitle.setVisibility(View.VISIBLE);
                        }
                        if (recyclerViewAdapter != null) {
                            recyclerView.post(new Runnable() {
                                @Override
                                public void run() {
                                    recyclerViewAdapter.notifyDataSetChanged();
                                }
                            });
                        }
                    }
                });
            }
        });
    }

    private void updateChatAry() {
        chatList.clear();
        chatList.addAll(dbhelper.getAllRecentMessages(getActivity()));
        if (chatList.size() == 0) {
            nullLay.setVisibility(View.VISIBLE);
            recenttitle.setVisibility(View.GONE);
        } else {
            nullLay.setVisibility(View.GONE);
            recenttitle.setVisibility(View.VISIBLE);
        }
    }

    private void deleteChatConfirmDialog(Context context, String chatId, String userId, int position, boolean clearChat) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        if (clearChat) {
            title.setText(R.string.really_delete_chat_history);
        } else {
            title.setText(R.string.really_delete_chat);
        }
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (clearChat) {
                    callDeleteChatApi(userId);
                    dbhelper.deleteAllMessages(chatId);
                    dbhelper.updateRecentChat(chatId, Constants.TAG_UNREAD_COUNT, "0");
                } else {
                    callDeleteChatApi(userId);
                    dbhelper.deleteAllMessages(chatId);
                    dbhelper.deleteRecentChat(chatId);
                }
                /*chatAry.get(position).put(Constants.TAG_MESSAGE, "");
                chatAry.get(position).put(Constants.TAG_DELIVERY_STATUS, "");
                chatAry.get(position).put(Constants.TAG_DELIVERY_STATUS, "");*/
                updateChatAry();
                recyclerViewAdapter.notifyDataSetChanged();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void callDeleteChatApi(String userId) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
        requestMap.put(Constants.TAG_RECEIVER_ID, userId);
        requestMap.put(Constants.TAG_TYPE, Constants.TAG_DELETE);

        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<HashMap<String, String>> call = apiInterface.callDeleteChatApi(GetSet.getToken(), requestMap);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                call.cancel();
            }
        });
    }

    private void openUserDialog(View view, RecentMessages hashMap, Context context) {
        Intent i = new Intent(context, DialogActivity.class);
        i.putExtra(Constants.TAG_USER_ID, hashMap.getUserId());
        i.putExtra(Constants.TAG_USER_NAME, hashMap.getUserName());
        if (hashMap.getPrivacyProfileImage().equalsIgnoreCase(TAG_MY_CONTACTS)) {
            if (hashMap.getContactStatus() != null && hashMap.getContactStatus() != null && hashMap.getContactStatus().equalsIgnoreCase(TAG_TRUE)) {
                i.putExtra(Constants.TAG_USER_IMAGE, hashMap.getUserImage());
            } else {
                i.putExtra(Constants.TAG_USER_IMAGE, "");
            }
        } else if (hashMap.getPrivacyProfileImage().equalsIgnoreCase(TAG_NOBODY)) {
            i.putExtra(Constants.TAG_USER_IMAGE, "");
        } else {
            i.putExtra(Constants.TAG_USER_IMAGE, hashMap.getUserImage());
        }
        i.putExtra(Constants.TAG_BLOCKED_ME, hashMap.getBlockedMe());

        ActivityOptionsCompat options = ActivityOptionsCompat.makeScaleUpAnimation(view, view.getWidth(), view.getHeight(), view.getWidth(), view.getHeight());
        startActivity(i, options.toBundle());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                boolean isContactEnabled = false;

                for (String permission : permissions) {
                    if (permission.equals(READ_CONTACTS)) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                            isContactEnabled = true;
                        }
                    }
                }

                if (!isContactEnabled) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
                            requestPermission(new String[]{READ_CONTACTS}, 100);
                        } else {
                            Toast.makeText(getContext(), R.string.contact_permission_error, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getActivity().getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                }

                break;
            case 1010:
                int permissionCamera = ContextCompat.checkSelfPermission(getContext(),
                        CAMERA);
                int permissionAudio = ContextCompat.checkSelfPermission(getContext(),
                        RECORD_AUDIO);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    if (permissionAudio == PackageManager.PERMISSION_GRANTED &&
                            permissionCamera == PackageManager.PERMISSION_GRANTED) {
                        openCamera();
                    } else {
                        if (shouldShowRequestPermissionRationale(CAMERA) ||
                                shouldShowRequestPermissionRationale(RECORD_AUDIO)) {
                            requestPermission(new String[]{CAMERA, RECORD_AUDIO}, 1010);
                        } else {
                            Toast.makeText(getContext(), R.string.storage_permission_camera_error, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getActivity().getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                } else {
                    int permissionStorage = ContextCompat.checkSelfPermission(getContext(),
                            WRITE_EXTERNAL_STORAGE);
                    if (permissionAudio == PackageManager.PERMISSION_GRANTED &&
                            permissionStorage == PackageManager.PERMISSION_GRANTED &&
                            permissionCamera == PackageManager.PERMISSION_GRANTED) {
                        openCamera();
                    } else {
                        if (shouldShowRequestPermissionRationale(CAMERA) ||
                                shouldShowRequestPermissionRationale(WRITE_EXTERNAL_STORAGE) ||
                                shouldShowRequestPermissionRationale(RECORD_AUDIO)) {
                            requestPermission(new String[]{CAMERA, RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, 1010);
                        } else {
                            Toast.makeText(getContext(), R.string.contact_permission_error, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getActivity().getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                }
                break;
        }
    }

    private void requestPermission(String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(getActivity(), permissions, requestCode);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v(TAG, "onResume");
        SocketConnection.getInstance(getActivity()).setRecentChatReceivedListener(this);
        refreshAdapter();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(NewMessageEvent event) {
        refreshAdapter();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.v(TAG, "onPause");
        SocketConnection.getInstance(getActivity()).setRecentChatReceivedListener(null);
    }

    @Override
    public void onRecentChatReceived() {
        Log.d(TAG, "onRecentChatReceived: ");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null) {
                    updateChatAry();
                    recyclerViewAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public void onUserImageChange(final String user_id, final String user_image) {
        Log.v(TAG, "onUserImageChange");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null && chatList.size() > 0) {
                    for (int i = 0; i < chatList.size(); i++) {
                        if (chatList.get(i) != null && user_id.equals(chatList.get(i).getUserId())) {
                            chatList.get(i).setUserImage(user_image);
                            recyclerViewAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    @Override
    public void onBlockStatus(final JSONObject data) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null && chatList.size() > 0) {
                    try {
                        String sender_id = data.getString(Constants.TAG_SENDER_ID);
                        String type = data.getString(Constants.TAG_TYPE);
                        for (int i = 0; i < chatList.size(); i++) {
                            if (chatList.get(i) != null && sender_id.equals(chatList.get(i).getUserId())) {
                                chatList.get(i).setBlockedMe(type);
                                recyclerViewAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override
    public void onUpdateChatStatus(final String user_id) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null && chatList.size() > 0) {
                    for (int i = 0; i < chatList.size(); i++) {
                        if (chatList.get(i) != null && user_id.equals(chatList.get(i).getUserId()) && linearLayoutManager.findViewByPosition(i) != null) {
                            String msgId = chatList.get(i).getMessageId();
                            if (msgId != null) {
                                MessagesData mdata = dbhelper.getSingleMessage(msgId);
                                if (mdata != null) {
                                    chatList.get(i).setDeliveryStatus(mdata.delivery_status);
                                    View itemView = linearLayoutManager.findViewByPosition(i);
                                    ImageView tickimage = itemView.findViewById(R.id.tickimage);
                                    if (mdata.sender_id != null && mdata.sender_id.equals(GetSet.getUserId())) {
                                        tickimage.setVisibility(View.VISIBLE);
                                        if (mdata.delivery_status.equals("read")) {
                                            tickimage.setImageResource(R.drawable.double_tick);
                                        } else if (mdata.delivery_status.equals("sent")) {
                                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                                        } else if (("" + mdata.progress).equals("completed") && (mdata.message_type.equals("image") ||
                                                mdata.message_type.equals("video") || mdata.message_type.equals(StorageManager.TAG_DOCUMENT) || mdata.message_type.equals("audio"))) {
                                            tickimage.setImageResource(R.drawable.single_tick);
                                        } else if (mdata.message_type.equals("text") || mdata.message_type.equals("contact") || mdata.message_type.equals("location")) {
                                            tickimage.setImageResource(R.drawable.single_tick);
                                        } else {
                                            tickimage.setVisibility(View.GONE);
                                        }
                                    } else {
                                        tickimage.setVisibility(View.GONE);
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
        });
    }

    @Override
    public void onListenTyping(final JSONObject data) {
        Log.v(TAG, "onListenTyping");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null && linearLayoutManager != null && chatList.size() > 0) {
                    try {
                        for (int i = 0; i < chatList.size(); i++) {
                            if (chatList.get(i) != null && data.get(Constants.TAG_SENDER_ID).equals(chatList.get(i).getUserId())
                                    && linearLayoutManager.findViewByPosition(i) != null) {
                                View itemView = linearLayoutManager.findViewByPosition(i);
                                LinearLayout messageLay;
                                messageLay = itemView.findViewById(R.id.messageLay);
                                TextView typing = itemView.findViewById(R.id.typing);
                                if (data.get(Constants.TAG_SENDER_ID).equals(chatList.get(i).getUserId()) && data.get("type").equals("typing")) {
                                    typing.setText(getString(R.string.typing));
                                    typing.setVisibility(View.VISIBLE);
                                    messageLay.setVisibility(View.INVISIBLE);
                                } else if (data.get(Constants.TAG_SENDER_ID).equals(chatList.get(i).getUserId()) && data.get("type").equals(Constants.TAG_RECORDING)) {
                                    typing.setText(getString(R.string.recording));
                                    typing.setVisibility(View.VISIBLE);
                                    messageLay.setVisibility(View.INVISIBLE);
                                } else {
                                    typing.setVisibility(View.GONE);
                                    messageLay.setVisibility(View.VISIBLE);
                                }
                                break;
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override
    public void onPrivacyChanged(final JSONObject jsonObject) {
//        Log.i(TAG, "onPrivacyChanged: " + jsonObject);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null) {
                    updateChatAry();
                    recyclerViewAdapter.notifyDataSetChanged();
                }
                if (statusRecyclerAdapter != null) {
                    updateStatusAry();
                    statusRecyclerAdapter.notifyDataSetChanged();
                    statusRecyclerView.smoothScrollToPosition(0);
                }
            }
        });
    }

    @Override
    public void onStatusReceived() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusRecyclerAdapter != null) {
                    updateStatusAry();
                    statusRecyclerAdapter.notifyDataSetChanged();
                    statusRecyclerView.smoothScrollToPosition(0);
                }
            }
        });
    }

    private void updateStatusAry() {
        statusList.clear();
        /*Log.e("checkupstatus","single"+new Gson().toJson(dbhelper.getSingleUserStatus("639c3a71876a7747d45ba117")));
        Log.e("checkupstatus","-seencount"+dbhelper.getUserstatusUnSeenCount("639c3a71876a7747d45ba117"));
        */Log.e("checkupstatus","-"+new Gson().toJson(dbhelper.getStatusContactData(getContext())));
        statusList.addAll(dbhelper.getStatusContactData(getContext()));
    }

    @Override
    public void onDeleteStatus(String statusId) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusRecyclerAdapter != null) {
                    updateStatusAry();
                    statusRecyclerAdapter.notifyDataSetChanged();
                    statusRecyclerView.smoothScrollToPosition(0);
                }
            }
        });
    }

    @Override
    public void onPrivateChatUpdate(String receiverId) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (recyclerViewAdapter != null) {
                    updateChatAry();
                    recyclerViewAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter<ViewHolder> {

        private static final int TYPE_HEADER = 0;
        private static final int TYPE_ITEM = 1;
        ArrayList<RecentMessages> messageList = new ArrayList<>();
        Context context;

        public RecyclerViewAdapter(Context context, ArrayList<RecentMessages> Items) {
            this.messageList = Items;
            this.context = context;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.chat_item, parent, false);
            return new MyViewHolder(itemView);
            /*if (viewType == TYPE_ITEM) {
            } else if (viewType == TYPE_HEADER) {
                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.favorites_header, parent, false);
                return new HeaderViewHolder(itemView);
            }
            return null;*/
        }

        @Override
        public void onBindViewHolder(final ViewHolder viewHolder, int position) {

            if (viewHolder instanceof MyViewHolder) {
                MyViewHolder holder = (MyViewHolder) viewHolder;
                holder.typing.setVisibility(View.GONE);
                holder.messageLay.setVisibility(View.VISIBLE);
                RecentMessages recentMessage = this.messageList.get(position);
//                Log.d(TAG, "onBindViewHolder: " + new Gson().toJson(map));
                if (!TextUtils.isEmpty(recentMessage.getDeletedAccount())) {
                    if (recentMessage.getDeletedAccount().equals("1")) {
                        if (!TextUtils.isEmpty(recentMessage.getUserName())) {
                            holder.name.setText(recentMessage.getUserName() + " - " + context.getString(R.string.deleted_account));
                        } else {
                            holder.name.setText(context.getString(R.string.deleted_account));
                        }
                    } else {
                        holder.name.setText(recentMessage.getUserName());
                    }
                } else {
                    holder.name.setText(recentMessage.getUserName());
                }
                if (recentMessage != null && recentMessage.messageType != null &&
                        recentMessage.messageType.equals(Constants.TAG_LINK)) {
                    try {
                        JSONObject messageObject = new JSONObject(recentMessage.message);
                        String msg = messageObject.optString(Constants.TAG_NAME) + "\n" +
                                messageObject.optString(Constants.TAG_DESCRIPTION) + "\n\n" +
                                messageObject.optString(Constants.TAG_LINK);
                        holder.message.setText(msg);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    holder.message.setText(recentMessage.getMessage());
                }
                if (!TextUtils.isEmpty(recentMessage.getChatTime())) {
                    holder.time.setText(dateUtils.getRecentChatDateFromUTC(recentMessage.getChatTime()));
                }

                if (recentMessage.getBlockedMe().equals("block")) {
                    Glide.with(context).load(R.drawable.temp).thumbnail(0.5f)
                            .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.add).override(ApplicationClass.dpToPx(context, 70)))
                            .into(holder.profileimage);
                } else {
                    DialogActivity.setProfileImage(dbhelper.getContactDetail(recentMessage.getUserId()), holder.profileimage, context);
                }

                if (recentMessage.getSenderId() != null && recentMessage.getSenderId().equals(GetSet.getUserId())) {
                    holder.tickimage.setVisibility(View.VISIBLE);
                    if (recentMessage.getMessageType() != null) {
                        if (recentMessage.getDeliveryStatus().equals("read")) {
                            holder.tickimage.setImageResource(R.drawable.double_tick);
                        } else if (recentMessage.getDeliveryStatus().equals("sent")) {
                            holder.tickimage.setImageResource(R.drawable.double_tick_unseen);
                        } else if (recentMessage.getProgress() != null && recentMessage.getProgress().equals("completed") && (recentMessage.getMessageType().equals("image") ||
                                recentMessage.getMessageType().equals("video") || recentMessage.getMessageType().equals(StorageManager.TAG_DOCUMENT) || recentMessage.getMessageType().equals("audio"))) {
                            holder.tickimage.setImageResource(R.drawable.single_tick);
                        } else if (recentMessage.getMessageType().equals("text") ||
                                recentMessage.getMessageType().equals("contact") ||
                                recentMessage.getMessageType().equals("story") ||
                                recentMessage.getMessageType().equals("location")) {
                            holder.tickimage.setImageResource(R.drawable.single_tick);
                        } else {
                            holder.tickimage.setVisibility(View.GONE);
                        }
                    }
                } else {
                    holder.tickimage.setVisibility(View.GONE);
                }

                if (recentMessage.getMessageType() != null) {
                    switch (recentMessage.getMessageType()) {
                        case "image":
                        case "video":
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.upload_gallery);
                            break;
                        case "location":
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.upload_location);
                            break;
                        case StorageManager.TAG_AUDIO:
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.upload_audio);
                            break;
                        case "contact":
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.upload_contact);
                            break;
                        case StorageManager.TAG_DOCUMENT:
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.upload_file);
                            break;
                        case Constants.TAG_ISDELETE:
                            holder.typeicon.setVisibility(View.VISIBLE);
                            holder.typeicon.setImageResource(R.drawable.block_primary);
                            holder.tickimage.setVisibility(View.GONE);
                            break;
                        default:
                            holder.typeicon.setVisibility(View.GONE);
                            break;
                    }
                } else {
                    holder.typeicon.setVisibility(View.GONE);
                }

                if (recentMessage.getFavouriteId().equals("true")) {
                    holder.favorite.setVisibility(View.VISIBLE);
                } else {
                    holder.favorite.setVisibility(View.GONE);
                }

                if (recentMessage.getMuteNotification().equals("true")) {
                    holder.mute.setVisibility(View.VISIBLE);
                } else {
                    holder.mute.setVisibility(View.GONE);
                }

                if (recentMessage.getUnreadCount().equals("") || recentMessage.getUnreadCount().equals("0")) {
                    holder.unseenLay.setVisibility(View.GONE);
                } else {
                    holder.unseenLay.setVisibility(View.VISIBLE);
                    holder.unseenCount.setText(recentMessage.getUnreadCount());
                }
            } else if (viewHolder instanceof HeaderView) {
                HeaderView holder = (HeaderView) viewHolder;
                Log.v("header", "header");
                if (messageList.size() == 1) {
                    holder.recenttitle.setVisibility(View.GONE);
                }
                holder.horizontalScrollLay.post(new Runnable() {
                    @Override
                    public void run() {
                        holder.horizontalScrollLay.fullScroll(View.FOCUS_BACKWARD);
                    }
                });
                Glide.with(context).load(R.drawable.temp).thumbnail(0.5f)
                        .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                        .into(holder.userImage);
                List<ContactsData.Result> statusList = dbhelper.getStatusContactData(getContext());
                LinearLayoutManager layoutManager = new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false);
                holder.favrecyclerView.setLayoutManager(layoutManager);
                holder.favrecyclerView.setAdapter(new StatusRecyclerAdapter(context, statusList));
                holder.favrecyclerView.setNestedScrollingEnabled(false);
                holder.favrecyclerView.setHasFixedSize(true);
            }
        }

        @Override
        public int getItemCount() {
            return messageList.size();
        }

        /*@Override
        public int getItemViewType(int position) {
            return Items.get(position) == null ? TYPE_HEADER : TYPE_ITEM;
        }*/

        public class MyViewHolder extends ViewHolder implements View.OnClickListener, View.OnLongClickListener {

            LinearLayout parentlay, messageLay;
            RelativeLayout unseenLay;
            TextView name, message, time, unseenCount, typing;
            ImageView tickimage, typeicon, mute, favorite, deleteMsg;
            CircleImageView profileimage;
            View profileview;

            public MyViewHolder(View view) {
                super(view);

                parentlay = view.findViewById(R.id.parentlay);
                message = view.findViewById(R.id.message);
                time = view.findViewById(R.id.time);
                name = view.findViewById(R.id.name);
                profileimage = view.findViewById(R.id.profileimage);
                tickimage = view.findViewById(R.id.tickimage);
                typeicon = view.findViewById(R.id.typeicon);
                unseenLay = view.findViewById(R.id.unseenLay);
                unseenCount = view.findViewById(R.id.unseenCount);
                profileview = view.findViewById(R.id.profileview);
                typing = view.findViewById(R.id.typing);
                messageLay = view.findViewById(R.id.messageLay);
                mute = view.findViewById(R.id.mute);
                favorite = view.findViewById(R.id.favorite);

                parentlay.setOnClickListener(this);
                profileimage.setOnClickListener(this);
                parentlay.setOnLongClickListener(this);
            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.parentlay:
                        ApplicationClass.preventMultiClick(parentlay);
                        if (messageList.size() > 0 && getAbsoluteAdapterPosition() != -1) {
                            isChatClicked = true;
                            isStatusClicked = false;
                            if (PermissionsUtils.checkStoragePermission(mContext)) {
                                Intent i = new Intent(context, ChatActivity.class);
                                i.putExtra("user_id", messageList.get(getAbsoluteAdapterPosition()).getUserId());
                                startActivity(i);
                                selectedPosition = -1;
                            } else {
                                selectedPosition = getAbsoluteAdapterPosition();
                                requestStoragePermissions();
                            }
                        }
                        break;
                    case R.id.profileimage:
                        openUserDialog(profileview, messageList.get(getAbsoluteAdapterPosition()), context);
                        break;

                }
            }

            @Override
            public boolean onLongClick(View view) {
                switch (view.getId()) {
                    case R.id.parentlay:
                        View bottomView = getLayoutInflater().inflate(R.layout.chat_longpress_dialog, null);
                        BottomSheetDialog dialog = new BottomSheetDialog(context, R.style.BottomSheetDialogTheme);
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        dialog.setContentView(bottomView);
                        String userId = messageList.get(getAbsoluteAdapterPosition()).getUserId();
                        String chatId = GetSet.getUserId() + userId;
                        ContactsData.Result results = dbhelper.getContactDetail(userId);
                        TextView txtFavourite = bottomView.findViewById(R.id.txtFavourite);
                        TextView txtView = bottomView.findViewById(R.id.txtView);
                        TextView txtClear = bottomView.findViewById(R.id.txtClear);
                        TextView txtDelete = bottomView.findViewById(R.id.txtDelete);

                        if (results.favourited.equals("true")) {
                            txtFavourite.setText(getString(R.string.remove_favourite));
                        } else {
                            txtFavourite.setText(getString(R.string.mark_favourite));
                        }

                        txtFavourite.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                                if (results.favourited.equals("true")) {
                                    dbhelper.updateFavUser(userId, "false");
                                    Toast.makeText(context, getString(R.string.removed_favourites), Toast.LENGTH_SHORT).show();
                                } else {
                                    dbhelper.updateFavUser(userId, "true");
                                    Toast.makeText(context, getString(R.string.marked_favourite), Toast.LENGTH_SHORT).show();
                                }
                                updateChatAry();
                                recyclerViewAdapter.notifyDataSetChanged();
                            }
                        });

                        txtView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                                Intent profile = new Intent(context, ProfileActivity.class);
                                profile.putExtra(Constants.TAG_USER_ID, userId);
                                startActivity(profile);
                            }
                        });

                        txtClear.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                                deleteChatConfirmDialog(context, chatId, userId, getAbsoluteAdapterPosition(), true);
                            }
                        });

                        txtDelete.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                                deleteChatConfirmDialog(context, chatId, userId, getAbsoluteAdapterPosition(), false);
                            }
                        });

                        dialog.show();
                        break;
                }
                return false;
            }
        }

        public class HeaderView extends ViewHolder implements View.OnClickListener {

            RecyclerView favrecyclerView;
            RelativeLayout parentLay;
            LinearLayout addStoryLay;
            CircleImageView userImage;
            TextView recenttitle;
            HorizontalScrollView horizontalScrollLay;

            public HeaderView(View view) {
                super(view);
                favrecyclerView = view.findViewById(R.id.favrecyclerView);
                parentLay = view.findViewById(R.id.parentLay);
                addStoryLay = view.findViewById(R.id.addStoryLay);
                userImage = view.findViewById(R.id.userImage);
                recenttitle = view.findViewById(R.id.recenttitle);
                horizontalScrollLay = view.findViewById(R.id.horizontalScrollLay);

                addStoryLay.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.addStoryLay) {
                    ApplicationClass.preventMultiClick(addStoryLay);
                    onAddStoryClicked(context);
                }
            }
        }
    }

    public class StatusRecyclerAdapter extends RecyclerView.Adapter<ViewHolder> {

        private static final int TYPE_HEADER = 0;
        private static final int TYPE_ITEM = 1;
        List<ContactsData.Result> favList;
        Context context;

        public StatusRecyclerAdapter(Context context, List<ContactsData.Result> favList) {
            this.context = context;
            this.favList = favList;
        }

        @Override
        public int getItemViewType(int position) {
            return position == 0 ? TYPE_HEADER : TYPE_ITEM;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            if (viewType == TYPE_ITEM) {
                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.fav_item, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == TYPE_HEADER) {
                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.add_story_lay, parent, false);
                return new HeaderViewHolder(itemView);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
            if (viewHolder instanceof MyViewHolder) {
                MyViewHolder holder = (MyViewHolder) viewHolder;
                ContactsData.Result result = favList.get(position - 1);

                if (ApplicationClass.isStringNotNull(result.blockedme) && result.blockedme.equals("block")) {
                    Glide.with(context).load(R.drawable.temp)
                            .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                            .into(holder.profileimage);
                } else {
                    if (ApplicationClass.isStringNotNull(result.privacy_profile_image) && result.privacy_profile_image.equalsIgnoreCase(TAG_MY_CONTACTS)) {
                        if (result.contactstatus != null && result.contactstatus.equalsIgnoreCase(TAG_TRUE)) {
                            Glide.with(context).load(Constants.USER_IMG_PATH + result.user_image).thumbnail(0.5f)
                                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                                    .into(holder.profileimage);
                        } else {
                            Glide.with(context).load(R.drawable.temp).thumbnail(0.5f)
                                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                                    .into(holder.profileimage);
                        }
                    } else if (ApplicationClass.isStringNotNull(result.privacy_profile_image) && result.privacy_profile_image.equalsIgnoreCase(TAG_NOBODY)) {
                        Glide.with(context).load(R.drawable.temp).thumbnail(0.5f)
                                .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                                .into(holder.profileimage);
                    } else {
                        Glide.with(context).load(Constants.USER_IMG_PATH + result.user_image).thumbnail(0.5f)
                                .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                                .into(holder.profileimage);
                    }
                }

                holder.profileimage.setBorderWidth(10);
                if (result.is_View.equals("0")) {
                    holder.profileimage.setBorderColor(ContextCompat.getColor(context, R.color.colorAccent));
                } else {
                    holder.profileimage.setBorderColor(ContextCompat.getColor(context, R.color.chat_selected));
                }

            //    holder.txtName.setText(result.user_name);
            } else if (viewHolder instanceof HeaderViewHolder) {
                HeaderViewHolder holder = (HeaderViewHolder) viewHolder;
                if(!(position==0)){
                    Glide.with(mContext).load(Constants.USER_IMG_PATH + GetSet.getImageUrl()).thumbnail(0.5f)
                            .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(getContext(), 70)))
                            .into(holder.userImage);

                }
                           }
        }

        @Override
        public int getItemCount() {
            return favList.size() + 1;
        }

        public class MyViewHolder extends ViewHolder implements View.OnClickListener {

            LinearLayout parentlay;
            CircleImageView profileimage;
            TextView txtName;

            public MyViewHolder(View view) {
                super(view);

                parentlay = view.findViewById(R.id.parentlay);
                profileimage = view.findViewById(R.id.userImage);
                txtName = view.findViewById(R.id.txtName);

                parentlay.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.parentlay:
                        ApplicationClass.preventMultiClick(parentlay);
                        if (favList.size() > 0 && getAbsoluteAdapterPosition() != -1) {
                            if (PermissionsUtils.checkStoragePermission(mContext)) {
                                openStatusActivity();
                            } else {
                                isChatClicked = false;
                                isStatusClicked = true;
                                requestStoragePermissions();
                            }
                        }
                        break;
                }
            }

            private void openStatusActivity() {
                Intent i = new Intent(context, StoryActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                i.putExtra(Constants.TAG_DATA, (Serializable) favList);
                i.putExtra(Constants.TAG_POSITION, getAbsoluteAdapterPosition() - 1);
                startActivity(i);
            }
        }

        public class HeaderViewHolder extends ViewHolder implements View.OnClickListener {
            LinearLayout addStoryLay;
            CircleImageView userImage;
            TextView txtName;

            public HeaderViewHolder(@NonNull View itemView) {
                super(itemView);
                addStoryLay = itemView.findViewById(R.id.addStoryLay);
                userImage = itemView.findViewById(R.id.userImage);

                addStoryLay.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.addStoryLay) {
                    ApplicationClass.preventMultiClick(addStoryLay);
                    onAddStoryClicked(context);
                }
            }
        }

    }

    private void onAddStoryClicked(Context context) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
            if(ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
                    ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED){
                statusPermissionResult.launch(new String[]{CAMERA,READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO});
            }else openCamera();
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ) {
            if (ContextCompat.checkSelfPermission(context, CAMERA) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                statusPermissionResult.launch(new String[]{CAMERA, RECORD_AUDIO});
            } else {
                openCamera();
            }
        } else {
            if (ContextCompat.checkSelfPermission(context, CAMERA) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                statusPermissionResult.launch(new String[]{CAMERA, RECORD_AUDIO, WRITE_EXTERNAL_STORAGE});
            } else {
                openCamera();
            }
        }
    }
}
