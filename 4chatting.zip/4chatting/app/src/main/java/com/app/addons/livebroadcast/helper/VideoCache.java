package com.app.addons.livebroadcast.helper;

import android.content.Context;

import com.app.helper.StorageManager;
import com.google.android.exoplayer2.database.DatabaseProvider;
import com.google.android.exoplayer2.database.ExoDatabaseProvider;
import com.google.android.exoplayer2.upstream.cache.LeastRecentlyUsedCacheEvictor;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;

import java.io.File;

public class VideoCache {
    private static SimpleCache sDownloadCache;

    public static SimpleCache getInstance(Context context) {
        if (sDownloadCache == null) {
            DatabaseProvider databaseProvider = new ExoDatabaseProvider(context);
            LeastRecentlyUsedCacheEvictor evictor = new LeastRecentlyUsedCacheEvictor((100 * 1024 * 1024));
            sDownloadCache = new SimpleCache(new File(StorageManager.getInstance(context).getExtCachesDir(), "exoCache"),
                    evictor, databaseProvider);
        }
        return sDownloadCache;
    }
}