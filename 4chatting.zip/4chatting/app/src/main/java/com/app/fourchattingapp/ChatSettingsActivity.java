package com.app.fourchattingapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowMetrics;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.app.helper.DatabaseHandler;
import com.app.helper.Utils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.PermissionsUtils;
import com.app.helper.StorageManager;
import com.app.helper.ThemeHelper;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

import java.io.File;
import java.util.Map;

public class ChatSettingsActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = ChatSettingsActivity.class.getSimpleName();
    private Context mContext;
    private LinearLayout themeLay, wallpaperLay;
    private Toolbar toolbar;
    private ImageView btnBack;
    private TextView txtTitle;
    private ActivityResultLauncher<Intent> galleryResultLauncher;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Utils utils;
    private int displayHeight, displayWidth;
    private StorageManager storageManager;
    private DatabaseHandler dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_settings);
        mContext = this;
        dbHelper = DatabaseHandler.getInstance(mContext);
        pref = mContext.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        utils = new Utils(this);
        getDisplayWidthHeight(this);
        storageManager = StorageManager.getInstance(mContext);

        initView();
        initClickListeners();
        initActivityResultLauncher();
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    private void initView() {
        toolbar = findViewById(R.id.actionbar);
        btnBack = toolbar.findViewById(R.id.backbtn);
        txtTitle = toolbar.findViewById(R.id.title);
        themeLay = findViewById(R.id.themeLay);
        wallpaperLay = findViewById(R.id.wallpaperLay);
        initToolBar();
    }

    private void initToolBar() {
        if (ApplicationClass.isRTL()) {
            btnBack.setRotation(180);
        } else {
            btnBack.setRotation(0);
        }
        txtTitle.setVisibility(View.VISIBLE);
        btnBack.setVisibility(View.VISIBLE);
        txtTitle.setText(R.string.chats);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void initClickListeners() {
        themeLay.setOnClickListener(this);
        wallpaperLay.setOnClickListener(this);
    }

    private void initActivityResultLauncher() {
        galleryResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == RESULT_OK) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        TypedValue tv = new TypedValue();
                        int actionBarHeight = 0;
                        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
                            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
                            Log.d(TAG, "getScaledBitmap: " + actionBarHeight);
                        }
                        Glide.with(mContext)
                                .asBitmap()
                                .load(uri)
                                .centerCrop()
                                .override(displayWidth - ApplicationClass.dpToPx(mContext, (int) Math.round((actionBarHeight + (actionBarHeight * 0.2)))), displayHeight - ApplicationClass.dpToPx(mContext, actionBarHeight) - ApplicationClass.dpToPx(mContext, actionBarHeight))
                                .into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap scaledBitmap, @Nullable Transition<? super Bitmap> transition) {
                                        String fileName = mContext.getString(R.string.app_name) + "_" + mContext.getString(R.string.wallpaper) + ".jpg";
                                        File wallpaper = storageManager.saveBitmapInExternal(scaledBitmap, fileName, StorageManager.TAG_WALLPAPER);
                                        editor.putString(Constants.TAG_COMMON_WALLPAPER, wallpaper.getAbsolutePath());
                                        editor.apply();
                                        dbHelper.resetWallpaper();
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            storageManager.saveFileInStorageV10(wallpaper, fileName, StorageManager.TAG_WALLPAPER, StorageManager.TAG_IMAGE);
                                        } else {
                                            storageManager.saveFileInGallery(wallpaper, fileName, StorageManager.TAG_WALLPAPER);
                                        }
                                        makeToast(mContext.getString(R.string.wallpaper_set));
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {

                                    }
                                });
                    }
                }
            }
        });

        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    openGalleryPictures();
                } else {
                    boolean neverAsked = false;
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ChatSettingsActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, mContext.getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.themeLay) {
            showThemeDialog();
        } else if (v.getId() == R.id.wallpaperLay) {
            openPickerDialog();
        }
    }

    private void showThemeDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(ChatSettingsActivity.this);
        alertDialog.setTitle(getString(R.string.choose_theme));
        String[] items;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            items = new String[]{getString(R.string.light), getString(R.string.dark), getString(R.string.system_default)};
        } else {
            items = new String[]{getString(R.string.light), getString(R.string.dark)};
        }
        SharedPreferences themePref = PreferenceManager.getDefaultSharedPreferences(this);
        String theme = themePref.getString("themePref", ThemeHelper.DEFAULT_MODE);
        int checkedItem = 0;
        if (theme.equals(ThemeHelper.LIGHT_MODE)) {
            checkedItem = 0;
        } else if (theme.equals(ThemeHelper.DARK_MODE)) {
            checkedItem = 1;
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                checkedItem = 2;
            } else {
                checkedItem = 0;
            }
        }
        SharedPreferences.Editor prefEditor = themePref.edit();
        alertDialog.setSingleChoiceItems(items, checkedItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        prefEditor.putString("themePref", ThemeHelper.LIGHT_MODE);
                        prefEditor.apply();
                        ThemeHelper.applyTheme(ThemeHelper.LIGHT_MODE);
                        break;
                    case 1:
                        prefEditor.putString("themePref", ThemeHelper.DARK_MODE);
                        prefEditor.apply();
                        ThemeHelper.applyTheme(ThemeHelper.DARK_MODE);
                        break;
                    case 2:
                        prefEditor.putString("themePref", ThemeHelper.DEFAULT_MODE);
                        prefEditor.apply();
                        ThemeHelper.applyTheme(ThemeHelper.DEFAULT_MODE);
                        break;
                }
            }
        });
        AlertDialog alert = alertDialog.create();
        alert.setCanceledOnTouchOutside(false);
        alert.show();
    }

    private void openPickerDialog() {

        View contentView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_pick_options, findViewById(R.id.parentLay), false);
        BottomSheetDialog pickerOptionsSheet = new BottomSheetDialog(this, R.style.SimpleBottomDialog);
        pickerOptionsSheet.setCanceledOnTouchOutside(true);
        pickerOptionsSheet.setContentView(contentView);
        //    pickerOptionsSheet.setDismissWithAnimation(true);

        View cameraLay = contentView.findViewById(R.id.container_camera_option);
        View galleryLay = contentView.findViewById(R.id.container_gallery_option);
        LinearLayout defaultLay = contentView.findViewById(R.id.defaultLay);
        TextView labelUpload = contentView.findViewById(R.id.labelUpload);
        ImageView iconCamera = contentView.findViewById(R.id.iconCamera);
        TextView txtCamera = contentView.findViewById(R.id.txtCamera);
        ImageView iconGallery = contentView.findViewById(R.id.iconGallery);
        TextView txtGallery = contentView.findViewById(R.id.txtGallery);

        labelUpload.setText(mContext.getString(R.string.wallpaper));
        cameraLay.setVisibility(View.GONE);
        defaultLay.setVisibility(View.VISIBLE);

        galleryLay.setOnClickListener(v -> {
            pickerOptionsSheet.dismiss();
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                openGalleryPictures();
            } else {
                requestStoragePermissions();
            }
        });
        defaultLay.setOnClickListener(v -> {
            editor.putString(Constants.TAG_COMMON_WALLPAPER, null);
            editor.apply();
            String defaultWallpaper = utils.getDefaultChatWallpaper(mContext);
            dbHelper.setDefaultWallpaper(defaultWallpaper != null ? defaultWallpaper : "");
            makeToast(mContext.getString(R.string.wallpaper_set));
            pickerOptionsSheet.dismiss();
        });

        pickerOptionsSheet.show();
    }

    private void openGalleryPictures() {
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Intent pickIntent = new Intent(Intent.ACTION_PICK, collection);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(pickIntent, "Select a picture");
        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            galleryResultLauncher.launch(chooserIntent);
        }
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void getDisplayWidthHeight(Context mContext) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = this.getWindowManager().getCurrentWindowMetrics();
            Insets insets = windowMetrics.getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            displayHeight = windowMetrics.getBounds().height() - insets.bottom - insets.top;
            displayWidth = windowMetrics.getBounds().width() - insets.left - insets.right;
        } else {
            this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            displayHeight = displayMetrics.heightPixels;
            displayWidth = displayMetrics.widthPixels;
        }
    }
}