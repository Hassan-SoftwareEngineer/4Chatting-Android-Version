package com.app.addons.livebroadcast.ui;

import static android.telephony.TelephonyManager.NETWORK_TYPE_1xRTT;
import static android.telephony.TelephonyManager.NETWORK_TYPE_CDMA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EDGE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EHRPD;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_0;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_A;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_B;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GPRS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSDPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPAP;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSUPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_IDEN;
import static android.telephony.TelephonyManager.NETWORK_TYPE_LTE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UMTS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UNKNOWN;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.addons.livebroadcast.external.CustomLayoutManager;
import com.app.addons.livebroadcast.external.avloading.AVLoadingIndicatorView;
import com.app.addons.livebroadcast.external.avloading.BallBeatIndicator;
import com.app.addons.livebroadcast.external.heartlayout.HeartLayout;
import com.app.addons.livebroadcast.helper.SocketIO;
import com.app.addons.livebroadcast.model.StartStreamResponse;
import com.app.addons.livebroadcast.model.StreamDetails;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.helper.DatabaseHandler;
import com.app.helper.LocaleManager;
import com.app.helper.Utils;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.BaseActivity;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.DataChannel;
import org.webrtc.EglRenderer;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.tavendo.autobahn.WebSocket;
import io.antmedia.webrtcandroidframework.IDataChannelObserver;
import io.antmedia.webrtcandroidframework.IWebRTCClient;
import io.antmedia.webrtcandroidframework.IWebRTCListener;
import io.antmedia.webrtcandroidframework.StreamInfo;
import io.antmedia.webrtcandroidframework.WebRTCClient;
import io.antmedia.webrtcandroidframework.apprtc.AppRTCAudioManager;
import io.antmedia.webrtcandroidframework.apprtc.CallActivity;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class PublishActivity extends BaseActivity implements SocketIO.SocketEvents,
        GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, View.OnClickListener, IWebRTCListener, IDataChannelObserver {

    private static final String TAG = PublishActivity.class.getSimpleName();

    private CoordinatorLayout parentLay;
    private RelativeLayout bottomLay;
    private RelativeLayout commentsLay;
    private RecyclerView rvComments;
    private HeartLayout heartLay;
    private LinearLayout viewersLay;
    private RelativeLayout viewLay;
    private ImageView iconView;
    private AppCompatTextView txtViewCount;
    private RecyclerView rvViewers;
    private LinearLayout stopLay;
    private Button btnStopBroadCast;
    private RoundedImageView btnDetail;
    private RelativeLayout loadingLay;
    private ImageView loadingImage;
    private LinearLayout initializeLay;
    private AVLoadingIndicatorView avBallIndicator;
    private AppCompatTextView txtLiveCount;
    private RelativeLayout liveCountLay;
    private FrameLayout liveTxtLay;
    private View transparentCover;
    RelativeLayout bottomDurationLay;
    AppCompatTextView bottomStreamTitle;
    RoundedImageView publisherImage;
    RoundedImageView publisherColorImage;
    AppCompatTextView txtPublisherName;
    LinearLayout bottomFirstLay, bottomDeleteLay, bottomReportLay, chatHideLay, bottomDetailsLay,
            bottomUserLay, bottomTopLay, bottomViewersLay;
    AppCompatTextView bottomViewerCount, txtBottomDuration;
    RecyclerView bottomRecyclerView, bottomGiftView;
    private BottomSheetDialog bottomDialog, bottomCommentsDialog, bottomGiftsDialog, bottomHashTagsDialog;
    private View bottomSheet;

    private static final long FADE_DURATION = 1000;
    // Gestures are used to toggle the focus modes
    protected GestureDetectorCompat mAutoFocusDetector = null;
    private boolean mIsRecording = false, isPublished = false;
    private ApiInterface apiInterface;
    private String title, streamName, streamToken = null;
    private Handler handler = new Handler();
    private int resultCode = RESULT_CANCELED;

    ArrayList<StreamDetails.LiveViewers> viewersList = new ArrayList<>();
    ArrayList<HashMap<String, String>> commentList = new ArrayList<HashMap<String, String>>();
    private ViewerListViewAdapter viewerListAdapter;
    private BottomListAdapter bottomListAdapter;
    private CommentsAdapter commentsAdapter;
    private SocketIO socketIO;
    private Socket mSocket;
    private int displayHeight, displayWidth;
    private boolean isStreamStarted = false, isBroadCastStopped = false;
    private GestureDetector gestureScanner;
    Utils appUtils;
    private DatabaseHandler dbHelper;
    Timer netWorktimer = new Timer();
    private static final long SECONDS_INTERVAL = 1000;
    private static final long SCREEN_UPLOAD_INTERVAL = 10000;
    private boolean isCameraOpened = false;
    private int lensFacing = Camera.CameraInfo.CAMERA_FACING_BACK;
    private SharedPreferences pref;
    private Context context;

    private Runnable imageUpload = new Runnable() {
        @Override
        public void run() {
            try {
                if (cameraViewRenderer != null && captureFrameListener != null) {
                    cameraViewRenderer.addFrameListener(captureFrameListener, 1);
                }
                handler.postDelayed(imageUpload, SCREEN_UPLOAD_INTERVAL);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    /**
     * Mode can Publish, Play or P2P
     */

    ExecutorService executor = Executors.newSingleThreadExecutor();
    private String webRTCMode = IWebRTCClient.MODE_PUBLISH;
    private WebRTCClient webRTCClient;
    @Nullable
    private AppRTCAudioManager audioManager;
    private boolean enableDataChannel = true;
    private SurfaceViewRenderer cameraViewRenderer;
    private SurfaceViewRenderer pipViewRenderer;
    final int RECONNECTION_PERIOD_MLS = 100;
    private boolean stoppedStream = false;
    Handler reconnectionHandler = new Handler();
    Runnable reconnectionRunnable = new Runnable() {
        @Override
        public void run() {
            if (!webRTCClient.isStreaming()) {
                attempt2Reconnect();
                // call the handler again in case startStreaming is not successful
                reconnectionHandler.postDelayed(this, RECONNECTION_PERIOD_MLS);
            }
        }
    };

    private EglRenderer.FrameListener captureFrameListener = new EglRenderer.FrameListener() {
        @Override
        public void onFrame(Bitmap bitmap) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    cameraViewRenderer.removeFrameListener(captureFrameListener);
                }
            });
            if (bitmap != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, bos);
                byte[] imageBytes = bos.toByteArray();
                uploadImage(imageBytes);
            }
        }
    };

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.i(TAG, "onConnect: " + "EVENT_CONNECTED");
        }
    };

    private Emitter.Listener _msgReceived = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    Log.e(TAG, "_msgReceived: " + data);
                    String type = data.optString(Constants.TAG_TYPE);
                    switch (type) {
                        case StreamConstants.TAG_STREAM_JOINED:
                            if (data.optString(StreamConstants.TAG_STREAM_NAME).equals(streamName)) {
                                HashMap<String, String> map = new HashMap<>();
                                map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                                map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                                map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                                map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                                map.put(Constants.TAG_TYPE, data.optString(Constants.TAG_TYPE));
                                addComment(map);
                                getStreamInfo(streamName);
                            }
                            break;
                        case Constants.TAG_TEXT: {
                            HashMap<String, String> map = new HashMap<>();
                            map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                            map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                            map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                            map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                            map.put(Constants.TAG_TYPE, Constants.TAG_TEXT);
                            addComment(map);
                            break;
                        }
                        case StreamConstants.TAG_LIKED: {
                            HashMap<String, String> map = new HashMap<>();
                            map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                            map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                            map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                            map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                            map.put(Constants.TAG_TYPE, Constants.TAG_MESSAGE);
                            try {
                                String userId = data.optString(Constants.TAG_USER_ID);
                                String likeColor = data.optString(StreamConstants.TAG_LIKE_COLOR);
                                heartLay.addHeart(Color.parseColor(likeColor));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;
                        }
                    }
                }
            });
        }
    };

    private Emitter.Listener _subscriberLeft = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    Log.i(TAG, "_subscriberLeft: " + data);
                    getStreamInfo(data.optString(StreamConstants.TAG_STREAM_NAME));
                }
            });
        }
    };

    private Emitter.Listener _streamInfo = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "_streamInfo: " + data);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Gson gson = new Gson();
                    StreamDetails tempDetails = gson.fromJson("" + data, StreamDetails.class);
                    txtViewCount.setText(tempDetails.getWatchCount() != null ? tempDetails.getWatchCount() : "");
                    viewersList.clear();
                    viewersList.addAll(tempDetails.getLiveViewers());
                    viewerListAdapter.notifyDataSetChanged();
                    setBottomDialogUI(tempDetails);
                }
            });
        }
    };

    private Emitter.Listener _streamBlocked = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "_streamBlocked: " + data);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    makeToast(getString(R.string.your_broadcast_deactivated_by_admin));
                    triggerStopRecording();
                }
            });
        }
    };

    private void setBottomDialogUI(StreamDetails details) {
        bottomListAdapter.notifyDataSetChanged();
        bottomStreamTitle.setText(details.getTitle());
        bottomViewerCount.setText(details.getWatchCount());
        txtLiveCount.setText(details.getWatchCount());
    }

    private void addComment(HashMap<String, String> map) {
        commentList.add(map);
        commentsAdapter.notifyItemInserted(commentList.size() - 1);
        rvComments.scrollToPosition(commentList.size() - 1);
    }

    private void publishStream() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket.connected()) {
                Log.i(TAG, "publishStream: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_PUBLISH_STREAM, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "publishStream: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void getStreamInfo(String streamName) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket.connected()) {
                Log.i(TAG, "getStreamInfo: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_GET_STREAM_INFO, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "getStreamInfo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        overridePendingTransition(0, 0);
        setContentView(R.layout.activity_publish);

        context = this;
        Intent intent = getIntent();
        title = intent.getStringExtra(StreamConstants.TAG_TITLE);
        streamName = intent.getStringExtra(StreamConstants.TAG_STREAM_NAME);
        streamToken = intent.getStringExtra(StreamConstants.TAG_STREAM_TOKEN);
        lensFacing = intent.getIntExtra(StreamConstants.TAG_LENS_FACING, lensFacing);

        pref = getSharedPreferences(Constants.SHARED_PREFERENCE, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Constants.isInStream = true;
        appUtils = new Utils(this);
        dbHelper = DatabaseHandler.getInstance(this);
        gestureScanner = new GestureDetector(this, this);

        findViews();

        intent.putExtra(CallActivity.EXTRA_CAPTURETOTEXTURE_ENABLED, true);
        intent.putExtra(CallActivity.EXTRA_VIDEO_FPS, 30);
        intent.putExtra(CallActivity.EXTRA_VIDEO_BITRATE, 1500);
        intent.putExtra(CallActivity.EXTRA_CAPTURETOTEXTURE_ENABLED, true);
        intent.putExtra(CallActivity.EXTRA_DATA_CHANNEL_ENABLED, enableDataChannel);
        initSocket();

        initView();
        // Check for mandatory permissions.
        for (String permission : CallActivity.MANDATORY_PERMISSIONS) {
            if (this.checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission " + permission + " is not granted", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        audioManager = AppRTCAudioManager.create(PublishActivity.this);
        if (lensFacing == Camera.CameraInfo.CAMERA_FACING_FRONT)
            cameraViewRenderer.setMirror(lensFacing == Camera.CameraInfo.CAMERA_FACING_FRONT);  //this line to mirror for frontcamera
        else cameraViewRenderer.setMirror(false);

        webRTCClient = new WebRTCClient(this, this);
        webRTCClient.setOpenFrontCamera(lensFacing == Camera.CameraInfo.CAMERA_FACING_FRONT);
        webRTCClient.setVideoRenderers(pipViewRenderer, cameraViewRenderer);

        String STREAM_URL = pref.getString(StreamConstants.TAG_STREAM_BASE_URL, StreamConstants.STREAM_BASE_URL);
        // intent.putExtra(CallActivity.EXTRA_VIDEO_FPS, 24);

        Log.d(TAG, "onCreate: " + STREAM_URL);
        webRTCClient.init(STREAM_URL, streamName, webRTCMode, "tokenId", intent);
        webRTCClient.setDataChannelObserver(this);

        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                attempt2Reconnect();
            }
        }, 500);
    }

    public void findViews() {
        parentLay = findViewById(R.id.parentLay);
        cameraViewRenderer = findViewById(R.id.camera_view_renderer);
        pipViewRenderer = findViewById(R.id.pip_view_renderer);
        bottomLay = findViewById(R.id.bottomLay);
        commentsLay = findViewById(R.id.commentsLay);
        rvComments = findViewById(R.id.rv_comments);
        heartLay = findViewById(R.id.heartLay);
        viewersLay = findViewById(R.id.viewersLay);
        viewLay = findViewById(R.id.viewLay);
        iconView = findViewById(R.id.iconView);
        txtViewCount = findViewById(R.id.txtViewCount);
        rvViewers = findViewById(R.id.rv_viewers);
        stopLay = findViewById(R.id.stopLay);
        btnStopBroadCast = findViewById(R.id.btnStopBroadCast);
        btnDetail = findViewById(R.id.btnDetail);
        loadingLay = findViewById(R.id.loadingLay);
        loadingImage = findViewById(R.id.loadingImage);
        initializeLay = findViewById(R.id.initializeLay);
        avBallIndicator = findViewById(R.id.avBallIndicator);
        transparentCover = findViewById(R.id.transparent_cover);

        avBallIndicator.setIndicator(new BallBeatIndicator());
        btnStopBroadCast.setOnClickListener(this);
        btnDetail.setOnClickListener(this);
        viewLay.setOnClickListener(this);
    }

    public void initView() {
        // Initialize the UI controls
        if (LocaleManager.isRTL()) {
            viewLay.setBackground(getResources().getDrawable(R.drawable.rounded_curve_rtl_bg));
        } else {
            viewLay.setBackground(getResources().getDrawable(R.drawable.rounded_curve_bg));
        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        displayHeight = displayMetrics.heightPixels;
        displayWidth = displayMetrics.widthPixels;

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ABOVE, R.id.viewersLay);
        params.height = (int) (displayHeight * 0.4);
        commentsLay.setLayoutParams(params);

        setLoadingLay(VISIBLE);
        Glide.with(this)
                .load(Constants.USER_IMG_PATH + GetSet.getImageUrl())
                .placeholder(R.drawable.profile_square)
                .error(R.drawable.profile_square)
                .thumbnail(0.1f)
                .into(loadingImage);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rvViewers.setLayoutManager(linearLayoutManager);
        viewerListAdapter = new ViewerListViewAdapter(this, viewersList);
        rvViewers.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        rvViewers.setAdapter(viewerListAdapter);
        rvViewers.setHasFixedSize(true);
        viewerListAdapter.notifyDataSetChanged();

        commentsAdapter = new CommentsAdapter(this, commentList);
        CustomLayoutManager commentLayoutManager = new CustomLayoutManager(this);
        commentLayoutManager.setScrollEnabled(false);
        rvComments.setLayoutManager(commentLayoutManager);
        rvComments.setAdapter(commentsAdapter);
        commentsAdapter.notifyDataSetChanged();

        transparentCover.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureScanner.onTouchEvent(event);
            }
        });
        initBottomDetailsDialog();
        initBottomViewersDialog();
        backgroundInNetWorkSpeed();
    }

    private void initBottomDetailsDialog() {
        bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_details, null);
        bottomDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomDialog.setContentView(bottomSheet);
        bottomDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {

            }
        });

        bottomFirstLay = bottomSheet.findViewById(R.id.bottomFirstLay);
        bottomDeleteLay = bottomSheet.findViewById(R.id.bottomDeleteLay);
        liveCountLay = bottomSheet.findViewById(R.id.liveCountLay);
        liveTxtLay = bottomSheet.findViewById(R.id.liveTxtLay);
        txtLiveCount = bottomSheet.findViewById(R.id.txtLiveCount);
        bottomStreamTitle = bottomSheet.findViewById(R.id.bottomStreamTitle);
        bottomUserLay = bottomSheet.findViewById(R.id.bottomUserLay);
        publisherImage = bottomSheet.findViewById(R.id.publisherImage);
        publisherColorImage = bottomSheet.findViewById(R.id.publisherColorImage);
        txtPublisherName = bottomSheet.findViewById(R.id.txtPublisherName);
        bottomDetailsLay = bottomSheet.findViewById(R.id.bottomDetailsLay);
        chatHideLay = bottomSheet.findViewById(R.id.chatHideLay);
        bottomReportLay = bottomSheet.findViewById(R.id.bottomReportLay);

        if (LocaleManager.isRTL()) {
            liveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg_rtl));
            liveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg_rtl));
        } else {
            liveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg));
            liveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg));
        }

        bottomStreamTitle.setText(title);
        bottomDeleteLay.setVisibility(GONE);
        bottomReportLay.setVisibility(GONE);
        chatHideLay.setVisibility(VISIBLE);
        bottomUserLay.setVisibility(GONE);

        bottomDetailsLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (bottomCommentsDialog != null && !bottomCommentsDialog.isShowing()) {
                    bottomCommentsDialog.show();
                }
            }
        });

        chatHideLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (bottomLay.getVisibility() == VISIBLE)
                    slideDownAnim();
            }
        });

        bottomDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initBottomViewersDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_viewers, null);
        bottomCommentsDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomCommentsDialog.setContentView(bottomSheet);

        bottomViewersLay = bottomSheet.findViewById(R.id.bottomViewersLay);
        bottomViewerCount = bottomSheet.findViewById(R.id.bottomViewerCount);
        bottomRecyclerView = bottomSheet.findViewById(R.id.bottomRecyclerView);
        bottomTopLay = bottomSheet.findViewById(R.id.bottomTopLay);
        txtBottomDuration = bottomSheet.findViewById(R.id.txtBottomDuration);
        bottomDurationLay = bottomSheet.findViewById(R.id.bottomDurationLay);

        bottomDurationLay.setVisibility(GONE);

        bottomListAdapter = new BottomListAdapter(this, viewersList);
        bottomRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        bottomRecyclerView.setAdapter(bottomListAdapter);
        bottomRecyclerView.setHasFixedSize(true);
        bottomListAdapter.notifyDataSetChanged();

        bottomCommentsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomCommentsDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initSocket() {
        socketIO = new SocketIO(PublishActivity.this);
        mSocket = socketIO.getInstance();
        socketIO.setSocketEvents(PublishActivity.this);

        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(StreamConstants.TAG_STREAM_BLOCKED, _streamBlocked);
        mSocket.on(StreamConstants.TAG_MESSAGE_RECEIVED, _msgReceived);
        mSocket.on(StreamConstants.TAG_SUBSCRIBER_LEFT, _subscriberLeft);
        mSocket.on(StreamConstants.TAG_STREAM_INFO, _streamInfo);
        mSocket.on(StreamConstants.TAG_STREAM_BLOCKED, _streamBlocked);
        mSocket.connect();
    }

    public void backgroundInNetWorkSpeed() {
        netWorktimer.schedule(new TimerTask() {
            @Override
            public void run() {
                // this code will be executed after 2 seconds
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        backgroundInNetWorkSpeed();
                        checkNetworkType();
                    }
                });

            }
        }, 10000);

    }

    private void checkNetworkType() {
        boolean connectionStatus = isConnectedFast(getApplicationContext());
        if (!connectionStatus) {
            // connection is slow
            //Toast.makeText(getApplicationContext(),"Network is poor",Toast.LENGTH_LONG).show();
        } else {
            // connection is fast
            //Toast.makeText(getApplicationContext(),"goodabnd",Toast.LENGTH_LONG).show();

        }
    }

    private boolean isConnectedFast(Context context) {
        NetworkInfo info = getNetworkInfo(context);
        return (info != null && info.isConnected() && isConnectionFast(info.getType(), info.getSubtype(), context));
    }

    private NetworkInfo getNetworkInfo(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo();
    }

    private boolean isConnectionFast(int type, int subType, Context context) {
        if (type == ConnectivityManager.TYPE_WIFI) {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            int speedMbps = wifiInfo.getLinkSpeed();

            Log.e(TAG, "isConnectionFast: " + speedMbps);
            switch (speedMbps) {
                case NETWORK_TYPE_1xRTT:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_CDMA:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 14-64 kbps
                case NETWORK_TYPE_EDGE:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_EVDO_0:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return true; // ~ 400-1000 kbps
                case NETWORK_TYPE_EVDO_A:
                    //Toast.makeText(getApplicationContext(),"High Network connection",Toast.LENGTH_SHORT).show();
                    return true; // ~ 600-1400 kbps
                case NETWORK_TYPE_GPRS:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 100 kbps
                case NETWORK_TYPE_HSDPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 2-14 Mbps
                case NETWORK_TYPE_HSPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 700-1700 kbps
                case NETWORK_TYPE_HSUPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 1-23 Mbps
                case NETWORK_TYPE_UMTS:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 400-7000 kbps

                // Above API level 7, make sure to set android:targetSdkVersion to appropriate level to use these

                case NETWORK_TYPE_EHRPD: // API level 11
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 1-2 Mbps
                case NETWORK_TYPE_EVDO_B: // API level 9
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 5 Mbps
                case NETWORK_TYPE_HSPAP: // API level 13
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 10-20 Mbps
                case NETWORK_TYPE_IDEN: // API level 8
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return false; // ~25 kbps
                case NETWORK_TYPE_LTE: // API level 11
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 10+ Mbps
                // Unknown
                case NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
            //return true;
        } else if (type == ConnectivityManager.TYPE_MOBILE) {

            switch (subType) {
                case NETWORK_TYPE_1xRTT:
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_CDMA:
                    return false; // ~ 14-64 kbps
                case NETWORK_TYPE_EDGE:
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_EVDO_0:
                    return true; // ~ 400-1000 kbps
                case NETWORK_TYPE_EVDO_A:
                    return true; // ~ 600-1400 kbps
                case NETWORK_TYPE_GPRS:
                    return false; // ~ 100 kbps
                case NETWORK_TYPE_HSDPA:
                    return true; // ~ 2-14 Mbps
                case NETWORK_TYPE_HSPA:
                    return true; // ~ 700-1700 kbps
                case NETWORK_TYPE_HSUPA:
                    return true; // ~ 1-23 Mbps
                case NETWORK_TYPE_UMTS:
                    return true; // ~ 400-7000 kbps

                // Above API level 7, make sure to set android:targetSdkVersion to appropriate level to use these

                case NETWORK_TYPE_EHRPD: // API level 11
                    return true; // ~ 1-2 Mbps
                case NETWORK_TYPE_EVDO_B: // API level 9
                    return true; // ~ 5 Mbps
                case NETWORK_TYPE_HSPAP: // API level 13
                    return true; // ~ 10-20 Mbps
                case NETWORK_TYPE_IDEN: // API level 8
                    return false; // ~25 kbps
                case NETWORK_TYPE_LTE: // API level 11
                    return true; // ~ 10+ Mbps
                // Unknown
                case NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
        } else {
            return false;
        }

    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        if (!isConnected) {
            finish();
        }
    }

    @Override
    public void backPressed() {
        if (isPublished) {
            closeConfirmDialog(getString(R.string.stop_publish_description));
        } else {
            finish();
        }
    }

    @Override
    public void onPlayStarted(String streamId) {
        Log.w(getClass().getSimpleName(), "onPlayStarted");
        webRTCClient.switchVideoScaling(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        webRTCClient.getStreamInfoList();
    }

    @Override
    public void onPublishStarted(String streamId) {
        Log.v(TAG, "onPublishStarted: " + streamId);
        if (audioManager != null) {
            if (audioManager.hasWiredHeadset()) {
                audioManager.setDefaultAudioDevice(AppRTCAudioManager.AudioDevice.WIRED_HEADSET);
            } else {
                audioManager.setDefaultAudioDevice(AppRTCAudioManager.AudioDevice.SPEAKER_PHONE);
            }
            startAudioManager();
        }
        if (bottomLay.getVisibility() != VISIBLE)
            slideUpAnim();
        setLoadingLay(GONE);
        resultCode = RESULT_OK;
        initStream();
    }

    @Override
    public void onDisconnected(String streamId) {
        Log.e(TAG, "onDisconnected: " + streamId);
    }

    @Override
    public void onPublishFinished(String streamId) {
        triggerStopRecording();
    }

    @Override
    public void onPlayFinished(String streamId) {
        Log.w(getClass().getSimpleName(), "onPlayFinished");
    }

    @Override
    public void noStreamExistsToPlay(String streamId) {
        Log.w(getClass().getSimpleName(), "noStreamExistsToPlay");
        finish();
    }

    @Override
    public void streamIdInUse(String streamId) {
        Log.w(getClass().getSimpleName(), "streamIdInUse");
    }

    @Override
    public void onIceConnected(String streamId) {
        // remove scheduled reconnection attempts
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (reconnectionHandler.hasCallbacks(reconnectionRunnable)) {
                reconnectionHandler.removeCallbacks(reconnectionRunnable, null);
            }
        } else {
            reconnectionHandler.removeCallbacks(reconnectionRunnable, null);
        }
    }

    @Override
    public void onIceDisconnected(String streamId) {

    }

    @Override
    public void onPeerConnectionClosed(String streamId) {

    }

    @Override
    public void onTrackList(String[] tracks) {

    }

    @Override
    public void onBitrateMeasurement(String streamId, int targetBitrate, int videoBitrate, int audioBitrate) {
        Log.d(TAG, "onBitrateMeasurement: " + streamId + ", " + targetBitrate + ", " + videoBitrate + ", " + audioBitrate);
    }

    @Override
    public void onStreamInfoList(String streamId, ArrayList<StreamInfo> streamInfoList) {

    }

    @Override
    public void onError(String description, String streamId) {
        Log.e(TAG, "onError: " + description);
    }

    @Override
    public void onSignalChannelClosed(WebSocket.WebSocketConnectionObserver.WebSocketCloseNotification code, String streamId) {

    }

    @Override
    public void onBufferedAmountChange(long previousAmount, String dataChannelLabel) {

    }

    @Override
    public void onStateChange(DataChannel.State state, String dataChannelLabel) {
        Log.d(TAG, "onStateChange: " + state + ", " + dataChannelLabel);
    }

    @Override
    public void onMessage(DataChannel.Buffer buffer, String dataChannelLabel) {

    }

    @Override
    public void onMessageSent(DataChannel.Buffer buffer, boolean successful) {

    }

    private void attempt2Reconnect() {
        Log.w(getClass().getSimpleName(), "Attempt2Reconnect called");
        if (!webRTCClient.isStreaming()) {
            webRTCClient.startStream();
            if (webRTCMode.equals(IWebRTCClient.MODE_JOIN)) {
                pipViewRenderer.setZOrderOnTop(true);
            }
        }
    }

    // This method is called when the audio manager reports audio device change,
    // e.g. from wired headset to speakerphone.
    private void onAudioManagerDevicesChanged(
            final AppRTCAudioManager.AudioDevice device, final Set<AppRTCAudioManager.AudioDevice> availableDevices) {
        Log.d(TAG, "onAudioManagerDevicesChanged: " + availableDevices + ", "
                + "selected: " + device);
        // TODO(henrika): add callback handler.
    }

    private void startAudioManager() {
        // Store existing audio settings and change audio mode to
        // MODE_IN_COMMUNICATION for best possible VoIP performance.
        Log.d(TAG, "Starting the audio manager...");
        // This method will be called each time the number of available audio
        // devices has changed.

        audioManager.start(new AppRTCAudioManager.AudioManagerEvents() {
            @Override
            public void onAudioDeviceChanged(AppRTCAudioManager.AudioDevice selectedAudioDevice, Set<AppRTCAudioManager.AudioDevice> availableAudioDevices) {
                onAudioManagerDevicesChanged(selectedAudioDevice, availableAudioDevices);
            }
        });
    }

    public void stopAudioManager() {
        if (audioManager != null) {
            /*Reset audio manager to previous state*/

            audioManager.stop();
            audioManager = null;
        }
    }

    public void triggerStopRecording() {
        stopAudioManager();
        if (webRTCClient != null) {
            webRTCClient.stopStream();
        }
        stopStream();
    }

    private void setLoadingLay(int visiblity) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (visiblity == VISIBLE) {
                    avBallIndicator.show();
                } else {
                    avBallIndicator.hide();
                }
                loadingLay.setVisibility(visiblity);
                initializeLay.setVisibility(visiblity);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void initStream() {
        startStream();
        publishStream();
    }

    /**
     * Android Activity lifecycle methods
     */

    @Override
    protected void onResume() {
        super.onResume();
        if (socketIO != null) {
            socketIO.setSocketEvents(PublishActivity.this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (socketIO != null) {
            socketIO.setSocketEvents(null);
        }
        triggerStopRecording();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(imageUpload);
        if (mSocket != null) {
            mSocket.disconnect();
            mSocket.off(Socket.EVENT_CONNECT, onConnect);
            mSocket.off(StreamConstants.TAG_MESSAGE_RECEIVED, _msgReceived);
            mSocket.off(StreamConstants.TAG_MESSAGE_RECEIVED, _subscriberLeft);
            mSocket.off(StreamConstants.TAG_STREAM_INFO, _streamInfo);
            mSocket.off(StreamConstants.TAG_STREAM_BLOCKED, _streamBlocked);
        }
        Constants.isInStream = false;
        makeToast(getString(R.string.your_stream_end_description));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mAutoFocusDetector != null)
            mAutoFocusDetector.onTouchEvent(event);

        return super.onTouchEvent(event);
    }

    public void startStream() {
        if (NetworkStatus.isConnected()) {
            Map<String, String> map = new HashMap<>();
            map.put(StreamConstants.TAG_PUBLISHER_ID, GetSet.getUserId());
            map.put(StreamConstants.TAG_TITLE, title);
            map.put(StreamConstants.TAG_NAME, streamName);
            map.put(StreamConstants.TAG_RECORDING, "" + true);

            Log.i(TAG, "startStream: " + new Gson().toJson(map));
            Call<StartStreamResponse> call3 = apiInterface.startStream(GetSet.getToken(), map);
            call3.enqueue(new Callback<StartStreamResponse>() {
                @Override
                public void onResponse(Call<StartStreamResponse> call, Response<StartStreamResponse> response) {
                    if (response.isSuccessful()) {
                        StartStreamResponse streamResponse = response.body();
                        if (streamResponse.getStatus().equals(Constants.TAG_TRUE)) {
                            hideProgress();
                            handler.post(imageUpload);
                        } else {
                            makeToast(getString(R.string.something_wrong));
                            triggerStopRecording();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StartStreamResponse> call, Throwable t) {
                    Log.e(TAG, "onFailure: " + t.getMessage());
                    makeToast(getString(R.string.something_wrong));
                    call.cancel();
                    triggerStopRecording();
                }
            });
        }
    }

    public void stopStream() {
        if (NetworkStatus.isConnected() && streamName != null) {
            if (!isBroadCastStopped) {
                isBroadCastStopped = true;
                btnStopBroadCast.setOnClickListener(null);
                showProgress();
                Map<String, String> map = new HashMap<>();
                map.put(StreamConstants.TAG_PUBLISHER_ID, GetSet.getUserId());
                map.put(Constants.TAG_NAME, streamName);

                Call<Map<String, String>> call3 = apiInterface.stopStream(GetSet.getToken(), map);
                call3.enqueue(new Callback<Map<String, String>>() {
                    @Override
                    public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                        hideProgress();
                        makeToast(getString(R.string.your_stream_end_description));
                        closeActivity();
                    }

                    @Override
                    public void onFailure(Call<Map<String, String>> call, Throwable t) {
                        hideProgress();
                        closeActivity();
                    }
                });
            }
        } else {
            closeActivity();
        }
    }

    private void closeActivity() {
        setResult(resultCode);
        finish();
    }

    public void uploadImage(byte[] imageBytes) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("image/*"));
                MultipartBody.Part body = MultipartBody.Part.createFormData(StreamConstants.TAG_STREAM_IMAGE, streamName + ".jpeg", requestFile);
                RequestBody publisherId = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
                RequestBody streamNameBody = RequestBody.create(streamName, MediaType.parse("multipart/form-data"));

                Call<Map<String, String>> call3 = apiInterface.uploadStreamImage(GetSet.getToken(), body, publisherId, streamNameBody);
                call3.enqueue(new Callback<Map<String, String>>() {
                    @Override
                    public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                        Log.i(TAG, "uploadImageRes: " + response.isSuccessful());
                    }

                    @Override
                    public void onFailure(Call<Map<String, String>> call, Throwable t) {
                        call.cancel();
                        Log.e(TAG, "uploadImage: " + t.getMessage());
                    }
                });
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnStopBroadCast:
                closeConfirmDialog(getString(R.string.stop_publish_description));
                break;
            case R.id.btnDetail:
                if (bottomDialog != null && !bottomDialog.isShowing())
                    bottomDialog.show();
                break;
            case R.id.viewLay:
                if (bottomCommentsDialog != null && !bottomCommentsDialog.isShowing())
                    bottomCommentsDialog.show();
                break;
        }
    }

    public void showProgress() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }


    public void hideProgress() {
        /*Enable touch options*/

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float v, float v1) {
        // TODO Auto-generated method stub
        float sensitivity = 50;
        // Get swipe delta value in x axis.
        float deltaX = e1.getX() - e2.getX();

        // Get swipe delta value in y axis.
        float deltaY = e1.getY() - e2.getY();
        // Get absolute value.
        float deltaXAbs = Math.abs(deltaX);
        float deltaYAbs = Math.abs(deltaY);
        // Minimal x and y axis swipe distance.
        int MIN_SWIPE_DISTANCE_X = 100;
        int MIN_SWIPE_DISTANCE_Y = 100;

        // Maximal x and y axis swipe distance.
        int MAX_SWIPE_DISTANCE_X = 1000;
        int MAX_SWIPE_DISTANCE_Y = 1000;

        Log.i(TAG, "onFling: ");
        if ((deltaYAbs >= MIN_SWIPE_DISTANCE_Y) && (deltaYAbs <= MAX_SWIPE_DISTANCE_Y)) {
            if (deltaY > 0) {
                if (bottomLay.getVisibility() != VISIBLE)
                    slideUpAnim();
            } else {
                if (bottomLay.getVisibility() == VISIBLE)
                    slideDownAnim();
            }
        }

        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        Log.i(TAG, "onDoubleTapEvent: " + motionEvent.getAction());
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
            webRTCClient.onCameraSwitch();

            if (lensFacing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                cameraViewRenderer.setMirror(false);  //this line to mirror for frontcamera
                lensFacing = Camera.CameraInfo.CAMERA_FACING_BACK;
            } else {
                lensFacing = Camera.CameraInfo.CAMERA_FACING_FRONT;
                cameraViewRenderer.setMirror(lensFacing == Camera.CameraInfo.CAMERA_FACING_FRONT);
            }
        }
        return false;
    }

    private void slideUpAnim() {
        bottomLay.setVisibility(VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0,
                0,
                bottomLay.getHeight(),
                0);
        animate.setDuration(500);
        animate.setFillAfter(true);
        bottomLay.startAnimation(animate);
    }

    private void slideDownAnim() {
        TranslateAnimation animate = new TranslateAnimation(
                0,
                0,
                0,
                bottomLay.getHeight());
        animate.setDuration(500);
        animate.setFillAfter(true);
        animate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                bottomLay.setVisibility(GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        bottomLay.startAnimation(animate);
    }

    public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        public final int VIEW_TYPE_JOIN = 0;
        public final int VIEW_TYPE_TEXT = 1;
        public final int VIEW_TYPE_GIFT = 2;
        ArrayList<HashMap<String, String>> commentList;
        Context context;

        public CommentsAdapter(Context context, ArrayList<HashMap<String, String>> commentList) {
            this.commentList = commentList;
            this.context = context;
        }

        @Override
        public int getItemCount() {
            return commentList.size();
        }

        @Override
        public int getItemViewType(int position) {
            if (commentList.get(position) != null) {
                String type = "" + commentList.get(position).get(Constants.TAG_TYPE);
                switch (type) {
                    case Constants.TAG_TEXT:
                        return VIEW_TYPE_TEXT;
                    case StreamConstants.TAG_STREAM_JOINED:
                        return VIEW_TYPE_JOIN;
                }
            }
            return VIEW_TYPE_TEXT;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == VIEW_TYPE_JOIN) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_join, parent, false);
                return new JoiningViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_TEXT) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
                return new MyViewHolder(view);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, int position) {

            if (viewHolder instanceof MyViewHolder) {
                final MyViewHolder holder = (MyViewHolder) viewHolder;
                final HashMap<String, String> map = commentList.get(position);
                holder.txtMessage.setText(map.get(Constants.TAG_MESSAGE));
                holder.txtUserName.setText("@" + map.get(Constants.TAG_USER_NAME));
                new CountDownTimer(5000, 1000) { //(timer_duration, timer_interval)
                    @Override
                    public void onTick(long millisUntilFinished) {
                        holder.itemLay.setVisibility(VISIBLE);
                        //runs every second (1000 ms)
                    }

                    @Override
                    public void onFinish() {
                        //Do your operations when timer is finised
                        setFadeAnimation(holder.itemLay, holder.getAdapterPosition());
                        holder.itemLay.setVisibility(GONE);

                    }
                }.start();

            } else if (viewHolder instanceof JoiningViewHolder) {
                final JoiningViewHolder joinViewHolder = (JoiningViewHolder) viewHolder;
                final HashMap<String, String> map = commentList.get(position);

                joinViewHolder.txtJoined.setText("@" + map.get(Constants.TAG_USER_NAME) + " Joined");
                new CountDownTimer(5000, 1000) { //(timer_duration, timer_interval)
                    @Override
                    public void onTick(long millisUntilFinished) {
                        joinViewHolder.itemLay.setVisibility(VISIBLE);
                        //runs every second (1000 ms)
                    }

                    @Override
                    public void onFinish() {
                        //Do your operations when timer is finised
                        setFadeAnimation(joinViewHolder.itemLay, joinViewHolder.getAdapterPosition());
                        joinViewHolder.itemLay.setVisibility(GONE);

                    }
                }.start();
            }
        }

        public class JoiningViewHolder extends RecyclerView.ViewHolder {
            TextView txtJoined;
            RelativeLayout itemLay;

            public JoiningViewHolder(View view) {
                super(view);
                txtJoined = view.findViewById(R.id.txtJoined);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView txtUserName;
            TextView txtMessage;
            RelativeLayout itemLay;

            public MyViewHolder(View view) {
                super(view);
                txtUserName = view.findViewById(R.id.txtUserName);
                txtMessage = view.findViewById(R.id.txtMessage);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }
    }

    private void setFadeAnimation(final View view, final int position) {
        /*sets animation from complete opaque state(1.0f) to complete transparent state(0.0f)*/

        AlphaAnimation anim = new AlphaAnimation(1.0f, 0.0f);
        anim.setDuration(FADE_DURATION);
        view.startAnimation(anim);
    }

    public class ViewerListViewAdapter extends RecyclerView.Adapter<ViewerListViewAdapter.MyViewHolder> {

        ArrayList<StreamDetails.LiveViewers> viewersList;
        Context context;
        Random rnd;

        public ViewerListViewAdapter(Context context, ArrayList<StreamDetails.LiveViewers> viewersList) {
            this.viewersList = viewersList;
            this.context = context;
            rnd = new Random();
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_viewers, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            final StreamDetails.LiveViewers viewer = viewersList.get(position);
            int color = Color.argb(60, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));
            Glide.with(context).load(Constants.USER_IMG_PATH + viewer.getUserImage())
                    .apply(RequestOptions.circleCropTransform())
                    .thumbnail(0.5f)
                    .error(R.drawable.profile_square)
                    .transition(new DrawableTransitionOptions().crossFade())
                    .into(holder.userImage);
            holder.colorImage.setBackgroundColor(color);
            holder.itemLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return viewersList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView userImage;
            ImageView colorImage;
            RelativeLayout itemLay;

            public MyViewHolder(View view) {
                super(view);
                userImage = view.findViewById(R.id.userImage);
                colorImage = view.findViewById(R.id.colorImage);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }
    }

    public class BottomListAdapter extends RecyclerView.Adapter<BottomListAdapter.MyViewHolder> {

        ArrayList<StreamDetails.LiveViewers> viewerList;
        Context context;
        Random rnd;

        public BottomListAdapter(Context context, ArrayList<StreamDetails.LiveViewers> viewerList) {
            this.viewerList = viewerList;
            this.context = context;
            rnd = new Random();
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_viewer, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            final StreamDetails.LiveViewers viewer = viewerList.get(position);
            int color = Color.argb(60, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));
            Glide.with(context).load("" + viewer.getUserImage())
                    .apply(RequestOptions.circleCropTransform())
                    .thumbnail(0.5f)
                    .error(R.drawable.profile_square)
                    .transition(new DrawableTransitionOptions().crossFade())
                    .into(holder.userImage);
            holder.colorImage.setBackgroundColor(color);

            holder.txtUserName.setText(viewer.getUserName());
            holder.mainLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return viewerList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            RoundedImageView userImage;
            RoundedImageView colorImage;
            TextView txtUserName;
            RelativeLayout mainLay;

            public MyViewHolder(View view) {
                super(view);
                mainLay = view.findViewById(R.id.mainLay);
                userImage = view.findViewById(R.id.userImage);
                txtUserName = view.findViewById(R.id.txtUserName);
                colorImage = view.findViewById(R.id.colorImage);
            }
        }
    }

    private void closeConfirmDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(PublishActivity.this);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.okay), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                handler.removeCallbacks(imageUpload);
                isPublished = false;
                triggerStopRecording();
                dialog.cancel();
            }
        });
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        Typeface typeface = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            typeface = getResources().getFont(R.font.font_regular);
        } else {
            typeface = ResourcesCompat.getFont(this, R.font.font_regular);
        }
        TextView textView = dialog.findViewById(android.R.id.message);
        textView.setTypeface(typeface);

        Button btn1 = dialog.findViewById(android.R.id.button1);
        btn1.setTypeface(typeface);

        Button btn2 = dialog.findViewById(android.R.id.button2);
        btn2.setTypeface(typeface);

    }
}
