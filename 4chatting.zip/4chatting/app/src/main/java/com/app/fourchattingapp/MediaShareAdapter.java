package com.app.fourchattingapp;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.app.helper.StorageManager;
import com.app.fourchattingapp.R;
import com.app.model.MediaModelData;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.List;

public class MediaShareAdapter extends RecyclerView.Adapter<MediaShareAdapter.ImageViewHolder> {
    Context context;
    StorageManager storageManager;
    String TAG = "MediaShareAdapter";
    int totalMedia;
    private List<MediaModelData> mediaList;

    MediaShareAdapter(List<MediaModelData> mediaList, Context context, int totalMedia) {
        this.mediaList = mediaList;
        this.context = context;
        this.totalMedia = totalMedia;
        storageManager = StorageManager.getInstance(context);
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.media_item, parent, false);
        return new ImageViewHolder(view);
    }

    public String firstThree(String str) {
        return str.length() < 3 ? str : str.substring(0, 3);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        MediaModelData message = mediaList.get(position);
        holder.playLay.setVisibility(View.GONE);
        if (position < 12) {
            if (message.message_type.equals("document")) {
                holder.mediaItem.setImageResource(R.drawable.icon_file_unknown);
                holder.file_type_tv.setVisibility(View.VISIBLE);
                holder.file_type_tv.setText(firstThree(FilenameUtils.getExtension(message.attachment)));
            } else {
                if (message.message_type.equalsIgnoreCase("video")) {
                    holder.playLay.setVisibility(View.VISIBLE);
                    File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, message.attachment, StorageManager.TAG_VIDEO);
                    if (file != null) {
                        setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Uri fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                            if (fileUri != null) {
                                setImage(holder.mediaItem, fileUri);
                            }
                        } else {
                            file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                            if (file != null) {
                                setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                            }
                        }
                    }
                } else {
                    File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, message.attachment, StorageManager.TAG_IMAGE);
                    if (file != null) {
                        setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Uri fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                            if (fileUri != null) {
                                setImage(holder.mediaItem, fileUri);
                            }
                        } else {
                            file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                            if (file != null) {
                                setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                            }
                        }
                    }
                }
            }
        } else if (position == 12) {
            holder.mediaItem.setBackgroundColor(ContextCompat.getColor(context, R.color.white));
            holder.mediaItem.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.next_arrow));
        }
    }

    @Override
    public int getItemCount() {
        return mediaList.size();
    }

    private void setImage(ImageView view, Uri fileUri) {

        RequestOptions options = new RequestOptions().frame(1000).centerCrop();
        Glide.with(context).asBitmap()
                .load(fileUri)
                .apply(options)
                .into(view);
    }

    private void openMedia(MediaModelData message, ImageView view) {
        String type = message.message_type;
        String name = message.attachment;
        if (type.equalsIgnoreCase("video")) {
            File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, message.attachment, StorageManager.TAG_VIDEO);
            if (file != null) {
                openMediaIntent(storageManager.getUriFromFile(file));
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Uri fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                    if (fileUri != null) {
                        openMediaIntent(fileUri);
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                } else {
                    file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                    if (file != null) {
                        openMediaIntent(storageManager.getUriFromFile(file));
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                }
            }
        } else if (type.equalsIgnoreCase("image")) {
            File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, message.attachment, StorageManager.TAG_IMAGE);
            if (file != null) {
                openMediaIntent(storageManager.getUriFromFile(file));
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Uri fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                    if (fileUri != null) {
                        openMediaIntent(fileUri);
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                } else {
                    file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                    if (file != null) {
                        openMediaIntent(storageManager.getUriFromFile(file));
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                }
            }

        } else if (type.equalsIgnoreCase("document")) {

            File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT_SENT, message.attachment, StorageManager.TAG_DOCUMENT);
            if (file != null) {
                openMediaIntent(storageManager.getUriFromFile(file));
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Uri fileUri = storageManager.getFileUri(StorageManager.TAG_DOCUMENT, message.attachment, StorageManager.TAG_DOCUMENT);
                    if (fileUri != null) {
                        openMediaIntent(fileUri);
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                } else {
                    file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, message.attachment, StorageManager.TAG_DOCUMENT);
                    if (file != null) {
                        openMediaIntent(storageManager.getUriFromFile(file));
                    } else {
                        showToast(context, context.getString(R.string.no_media));
                    }
                }
            }
        }
    }

    private void openMediaIntent(Uri fileUri) {
        try {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            MimeTypeMap mime = MimeTypeMap.getSingleton();
            String ext = storageManager.getExtension(fileUri);
            String mimeType = mime.getMimeTypeFromExtension(ext);
            intent.setDataAndType(fileUri, mimeType);

            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            showToast(context, context.getString(R.string.no_application));
            e.printStackTrace();
        }
    }

    void showToast(Context context, String text) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
    }

    class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView mediaItem;
        RelativeLayout playLay;
        TextView file_type_tv;

        ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            mediaItem = itemView.findViewById(R.id.mediaItem);
            playLay = itemView.findViewById(R.id.playLay);
            file_type_tv = itemView.findViewById(R.id.file_type_tv);

            mediaItem.getLayoutParams().width = (int) ((ApplicationClass.getWidth(itemView.getContext())) * (0.23));
            mediaItem.getLayoutParams().height = (int) ((ApplicationClass.getWidth(itemView.getContext())) * (0.23));

            mediaItem.setOnClickListener(this);
            playLay.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.mediaItem || v.getId() == R.id.playLay) {
                MediaModelData message = mediaList.get(getAbsoluteAdapterPosition());
                openMedia(message, mediaItem);
            }
        }
    }
}
