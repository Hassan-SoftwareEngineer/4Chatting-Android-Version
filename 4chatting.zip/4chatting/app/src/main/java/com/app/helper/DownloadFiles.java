package com.app.helper;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by hitasoft on 30/6/18.
 */

public abstract class DownloadFiles extends AsyncTask<String, Integer, String> {
    private static final String TAG = DownloadFiles.class.getSimpleName();
    private final Context mContext;
    private final StorageManager storageManager;

    public DownloadFiles(Context context) {
        this.mContext = context;
        storageManager = StorageManager.getInstance(context);
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        Log.d(TAG, "onProgressUpdate: " + values[0]);
    }

    @Override
    protected String doInBackground(String... strings) {
        String downloadType = null;
        downloadType = strings[1];

        String fileName = getFileName(strings[0]);
        String urlString = strings[0];
        try {
            URL url = new URL(urlString);//Create Download URl
            Log.i(TAG, "doInBackground: " + url);
            HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();//Open Url Connection
            httpConn.setRequestMethod("GET");//Set Request Method to "GET" since we are grtting data
            httpConn.connect();//connect the URL Connection
            long mTotal = httpConn.getContentLength();
            int responseCode = httpConn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = httpConn.getInputStream();
                FileOutputStream outputStream = null;
                File downloadedFile = new File(mContext.getExternalCacheDir(), fileName);
                outputStream = new FileOutputStream(downloadedFile);
                int bytesRead = -1;
                byte[] buffer = new byte[1024];
                while ((bytesRead = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, bytesRead);
//                    publishProgress((int) (100 * bytesRead / mTotal));

                }
                outputStream.flush();
                inputStream.close();
                outputStream.close();

                if (downloadType.equals(StorageManager.TAG_STATUS)) {
                    File outputFile = storageManager.saveStatusFile(null, downloadedFile, fileName, "");
                    return outputFile.getAbsolutePath();
                } else {
                    File outputFile = new File(storageManager.saveFileInStorage(downloadedFile, downloadType));
                    return outputFile.getAbsolutePath();
                }
            }
        } catch (
                IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void doProgress(int progress) {
        publishProgress(progress);
    }

    private String getFileName(String url) {
        String imgSplit = url;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1);
        }
        return imgSplit;
    }

    protected abstract void onPostExecute(String downPath);
}
