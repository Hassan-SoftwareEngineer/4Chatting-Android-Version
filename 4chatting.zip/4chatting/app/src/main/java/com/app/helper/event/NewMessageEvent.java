package com.app.helper.event;

import com.app.model.MessagesData;

public class NewMessageEvent {
    private MessagesData messagesData;

    public NewMessageEvent(MessagesData messagesData) {
        this.messagesData = messagesData;
    }

    public MessagesData getMessageData() {
        return messagesData;
    }

    public void setMessageData(MessagesData messagesData) {
        this.messagesData = messagesData;
    }
}
