package com.app.fourchattingapp.status;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;

import com.app.external.keyboard.HeightProvider;
import com.app.helper.StorageManager;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.fourchattingapp.NewGroupActivity;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Random;

public class TextStatusActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "TextStatus";
    private RelativeLayout parentLay;
    private RelativeLayout bottomLay;
    private LinearLayout statusLay;
    ImageView ivEmoji, changeColor, sendStatus;
    EditText editText;

    int textSize = 50, height = 0;
    StorageManager storageManager;
    InputFilter[] filters = new InputFilter[1];
    private String beforeText = "";
    private int keyBoardHeight = 0, bottomNavHeight = 0, bottomMargin = 0;
    private boolean isKeyBoardOpen = false;
    private final RectF _availableSpaceRect = new RectF();
    int _widthLimit;
    private final SparseIntArray _textCachedSizes = new SparseIntArray();
    private SizeTester _sizeTester;
    private float _maxTextSize;
    private float _spacingMult = 1.0f;
    private float _spacingAdd = 0.0f;
    private Float _minTextSize;
    private int _maxLines;
    private float finalTextSize = 0;
    private static final int NO_LINE_LIMIT = -1;
    private static final int MIN_TEXT_SIZE = 120;
    private static final int MAX_TEXT_SIZE = 180;
    private static final int NORMAL_TEXT_SIZE = 150;
    private TextPaint paint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_status);
        parentLay = findViewById(R.id.parentLay);
        bottomLay = findViewById(R.id.bottomLay);
        statusLay = findViewById(R.id.statusLay);
        ivEmoji = findViewById(R.id.iv_emoji);
        changeColor = findViewById(R.id.changeColor);
        sendStatus = findViewById(R.id.sendStatus);
        editText = findViewById(R.id.editText);
        storageManager = StorageManager.getInstance(this);
        height = editText.getLayoutParams().height;
        bottomMargin = ApplicationClass.dpToPx(this, 2);
        HeightProvider heightProvider = new HeightProvider(this);
        paint = new TextPaint(editText.getPaint());

        parentLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + bottomMargin;
                if (parentLay != null) {
                    /*editText.setPadding(ApplicationClass.dpToPx(TextStatus.this, 15),
                            0, ApplicationClass.dpToPx(TextStatus.this, 15), bottomNavHeight + bottomMargin);*/
                    setBottomMargin(bottomNavHeight + bottomMargin);
                }
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        /*ViewTreeObserver vto = editText.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                ViewTreeObserver obs = editText.getViewTreeObserver();
                obs.removeOnGlobalLayoutListener(this);
                Log.d(TAG, "lineCount %d" + editText.getLineCount());
                int l = editText.getLineCount();
                float tempSize = textSize - (l * 3);
                if (editText.getText().length() == 0) {
                    editText.setTextSize(textSize);
                } else {
                    if (l != 0) {
                        editText.setTextSize(tempSize);
                    }

                }

            }
        });*/

        /* filters[0] = new InputFilter.LengthFilter(500);
        editText.setFilters(filters);*/

        changeBg();
        initAutoFitEditText(this);

        changeColor.setOnClickListener(this);
        sendStatus.setOnClickListener(this);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                beforeText = "" + s;
                Log.d(TAG, "beforeTextChanged: " + "");
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d(TAG, "onTextChanged: ");
                if (s.length() > 0) {
                    sendStatus.setVisibility(View.VISIBLE);
                    int l = editText.getLineCount();
                    float tempSize = MIN_TEXT_SIZE - (l * 3);
                    if (s.length() > 500 || l > 14) {
                        editText.setText("" + beforeText);
                        //         editText.setSelection(editText.length() - 1);
                        makeToast(getString(R.string.maximum_characters_limit_reached));
                    } else if (s.length() == 0) {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_PX, MIN_TEXT_SIZE);
                    } else {
                        if (l != 0) {
                            Log.i(TAG, "afterTextChanged: " + l);
                            Log.i(TAG, "afterTextChanged: " + tempSize);
                            finalTextSize = tempSize;
                            editText.setTextSize(TypedValue.COMPLEX_UNIT_PX, tempSize);
                        }

                    }
                } else {
                    sendStatus.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.d(TAG, "afterTextChanged: ");
                int l = editText.getLineCount();
                float tempSize = MIN_TEXT_SIZE - (l * 3);
                if (s.length() > 500 || l > 14) {
                    editText.setText("" + beforeText);
                    //   editText.setSelection(editText.length() - 1);
                    makeToast(getString(R.string.maximum_characters_limit_reached));
                } else if (s.length() == 0) {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_PX, MIN_TEXT_SIZE);
                } else {
                    if (l != 0) {
                        Log.i(TAG, "afterTextChanged: " + l);
                        Log.i(TAG, "afterTextChanged: " + tempSize);
                        finalTextSize = tempSize;
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_PX, tempSize);
                    }

                }
            }
        });
    }

    public void initAutoFitEditText(final Context context) {
        // using the minimal recommended font size
        _minTextSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
                MIN_TEXT_SIZE, getResources().getDisplayMetrics());
        _maxTextSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
                MAX_TEXT_SIZE, getResources().getDisplayMetrics());
        if (_maxLines == 0)
            // no value was assigned during construction
            _maxLines = NO_LINE_LIMIT;
        // prepare size tester:
        _sizeTester = new SizeTester() {
            final RectF textRect = new RectF();

            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public int onTestSize(final int suggestedSize,
                                  final RectF availableSPace) {
                paint.setTextSize(suggestedSize);
                final String text = editText.getText().toString();
                final boolean singleline = editText.getMaxLines() == 1;
                if (singleline) {
                    textRect.bottom = paint.getFontSpacing();
                    textRect.right = paint.measureText(text);
                } else {
                    final StaticLayout layout = new StaticLayout(text, paint,
                            _widthLimit, Layout.Alignment.ALIGN_NORMAL, _spacingMult,
                            _spacingAdd, true);
                    if (editText.getMaxLines() != NO_LINE_LIMIT
                            && layout.getLineCount() > editText.getMaxLines())
                        return 1;
                    textRect.bottom = layout.getHeight();
                    int maxWidth = -1;
                    for (int i = 0; i < layout.getLineCount(); i++)
                        if (maxWidth < layout.getLineWidth(i))
                            maxWidth = (int) layout.getLineWidth(i);
                    textRect.right = maxWidth;
                }
                textRect.offsetTo(0, 0);
                if (availableSPace.contains(textRect))
                    // may be too small, don't worry we will find the best match
                    return -1;
                // else, too big
                return 1;
            }
        };
    }

    private int efficientTextSizeSearch(final int start, final int end,
                                        final SizeTester sizeTester, final RectF availableSpace) {
        final String text = editText.getText().toString();
        final int key = text == null ? 0 : text.length();
        int size = _textCachedSizes.get(key);
        if (size != 0)
            return size;
        size = binarySearch(start, end, sizeTester, availableSpace);
        _textCachedSizes.put(key, size);
        return size;
    }

    private int binarySearch(final int start, final int end,
                             final SizeTester sizeTester, final RectF availableSpace) {
        int lastBest = start;
        int lo = start;
        int hi = end - 1;
        int mid = 0;
        while (lo <= hi) {
            mid = lo + hi >>> 1;
            final int midValCmp = sizeTester.onTestSize(mid, availableSpace);
            if (midValCmp < 0) {
                lastBest = lo;
                lo = mid + 1;
            } else if (midValCmp > 0) {
                hi = mid - 1;
                lastBest = hi;
            } else
                return mid;
        }
        // make sure to return last best
        // this is what should always be returned
        return lastBest;
    }

    private interface SizeTester {
        /**
         * AutoFitEditText
         *
         * @param suggestedSize  Size of text to be tested
         * @param availableSpace available space in which text must fit
         * @return an integer < 0 if after applying {@code suggestedSize} to
         * text, it takes less space than {@code availableSpace}, > 0
         * otherwise
         */
        public int onTestSize(int suggestedSize, RectF availableSpace);
    }

    private void initBottomPadding(int bottomPadding) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        if (bottomLay != null) {
            bottomLay.setPadding(0, 0, 0, bottomPadding);
            bottomLay.setLayoutParams(params);
        }
    }

    private void setBottomMargin(int height) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        params.gravity = Gravity.BOTTOM;
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.setMargins(ApplicationClass.dpToPx(this, 15),
                0, ApplicationClass.dpToPx(this, 15), height);
        if (bottomLay != null) {
            bottomLay.setLayoutParams(params);
        }
    }

    private void changeBg() {
        Random rnd = new Random();
        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
        if (color == -1) {
            changeBg();
        } else {
            statusLay.setBackgroundColor(color);
        }
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        ApplicationClass.showSnack(TextStatusActivity.this, findViewById(R.id.parentLay), isConnected);
    }

    @Override
    public void backPressed() {
        finish();
    }

    private void createImage() {
        editText.clearFocus();
        Bitmap thumb = viewToBitmap(statusLay);
        String fileName = getString(R.string.app_name) + "_" + System.currentTimeMillis() + ".JPG";
        File mDestDir = storageManager.getExtFilesDir();
        File mDestFile = new File(mDestDir.getPath() + File.separator + fileName);
        if (mDestDir != null) {
            try {
                FileOutputStream out = new FileOutputStream(mDestFile);
                thumb.compress(Bitmap.CompressFormat.JPEG, 100, out);
                out.flush();
                out.close();
                String imagePath = mDestFile.getAbsolutePath();
                HashMap<String, String> map = new HashMap<>();
                map.put(Constants.TAG_MESSAGE, "");
                map.put(Constants.TAG_ATTACHMENT, imagePath);
                map.put(Constants.TAG_TYPE, "image");
                Intent intent = new Intent(this, NewGroupActivity.class);
                intent.putExtra(Constants.TAG_FROM, "status");
                intent.putExtra(Constants.TAG_MESSAGE_DATA, map);
                startActivityForResult(intent, Constants.STATUS_TEXT_CODE);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public Bitmap viewToBitmap(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        editText.setCursorVisible(true);
        return bitmap;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == Constants.STATUS_TEXT_CODE) {
            setResult(Activity.RESULT_OK);
            finish();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.changeColor:
                changeBg();
                break;
            case R.id.sendStatus:
                ApplicationClass.preventMultiClick(sendStatus);
                editText.setCursorVisible(false);
                if (NetworkStatus.isConnected()) {
                    ApplicationClass.hideSoftKeyboard(TextStatusActivity.this);
                    editText.setPadding(ApplicationClass.dpToPx(TextStatusActivity.this, 15), 0, ApplicationClass.dpToPx(TextStatusActivity.this, 15), bottomNavHeight + bottomMargin);
                    createImage();
                } else {
                    ApplicationClass.showSnack(TextStatusActivity.this, findViewById(R.id.parentLay), false);
                }
                break;
        }
    }
}
