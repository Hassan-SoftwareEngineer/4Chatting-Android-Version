package com.app.fourchattingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.app.addons.chattranslate.GetLanguageWorker;
import com.app.helper.LocaleManager;
import com.app.fourchattingapp.R;
import com.app.model.LanguageData;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LanguageActivity extends BaseActivity {

    private final String TAG = this.getClass().getSimpleName();
    Toolbar toolbar;
    ImageView btnBack;
    TextView txtTitle;
    RecyclerView recyclerView;
    private String[] resourceArray;
    List<LanguageData> languageList = new ArrayList<>();
    LanguageAdapter adapter;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    static ApiInterface apiInterface;
    ProgressDialog dialog;
    private String from = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();



        if (getIntent().hasExtra(Constants.TAG_FROM)) {
            from = getIntent().getStringExtra(Constants.TAG_FROM);
        }

        toolbar = findViewById(R.id.actionbar);
        btnBack = toolbar.findViewById(R.id.backbtn);
        txtTitle = toolbar.findViewById(R.id.title);
        recyclerView = findViewById(R.id.recyclerView);

        if (ApplicationClass.isRTL()) {
            btnBack.setRotation(180);
        } else {
            btnBack.setRotation(0);
        }

        initToolBar();
        setAdapter();

        if (from != null && from.equals(Constants.TAG_CHAT)) {

            startTranslateLanguageWork();
        } else {
            resourceArray = getResources().getStringArray(R.array.language_array);
            List<String> tempList = Arrays.asList(resourceArray);
            for (String list : tempList) {
                String lang[] = list.split("-");
                String langTitle = lang[0];
                String langCode = lang[1];
                LanguageData data = new LanguageData();
                data.language = langTitle;
                data.languageCode = langCode;
                languageList.add(data);
            }
            adapter.notifyDataSetChanged();
        }

        dialog = new ProgressDialog(LanguageActivity.this);
        dialog.setMessage(getString(R.string.pleasewait));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    private void initToolBar() {
        txtTitle.setVisibility(View.VISIBLE);
        btnBack.setVisibility(View.VISIBLE);
        txtTitle.setText(R.string.app_language);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void setAdapter() {
        adapter = new LanguageAdapter(this, languageList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
    }

    //Addon Chat Translate
    private void startTranslateLanguageWork() {
        OneTimeWorkRequest locationWorkRequest = new OneTimeWorkRequest.Builder(GetLanguageWorker.class)
                .setConstraints(new Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build())
                .build();
        WorkManager workManager = WorkManager.getInstance(this);
        workManager.enqueue(locationWorkRequest);
            workManager.getWorkInfoByIdLiveData(locationWorkRequest.getId()).observe(this, workInfo -> {
            if (workInfo.getState().isFinished()) {
                LanguageData data = new LanguageData();
                data.language = getString(R.string.none);
                data.languageCode = "";
                data.languageId = "";
                languageList.add(data);
                if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                    String languageJson = workInfo.getOutputData().getString(Constants.TAG_DATA);
                    Log.d(TAG, "startTranslateLanguageWork: " + languageJson);
                    Type userListType = new TypeToken<ArrayList<LanguageData>>() {
                    }.getType();
                    languageList.addAll(new Gson().fromJson(languageJson, userListType));
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    private class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.LanguageViewHolder> {

        List<LanguageData> languageList = new ArrayList<>();
        Context context;

        LanguageAdapter(Context context, List<LanguageData> languageList) {
            this.languageList = languageList;
            this.context = context;
        }

        @NonNull
        @Override
        public LanguageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.language_item, parent, false);
            return new LanguageViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final LanguageViewHolder holder, final int position) {
            LanguageData language = languageList.get(position);
            if (from != null && from.equals(Constants.TAG_CHAT)) {
                holder.txtLanguage.setText(language.language);

                if (language.languageCode.equalsIgnoreCase(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, context.getResources().getString(R.string.none)))) {
                    holder.btnLanguage.setChecked(true);
                }else if (language.languageCode.equalsIgnoreCase("")  && pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, context.getResources().getString(R.string.none)).equalsIgnoreCase(context.getString(R.string.none))) {
                    holder.btnLanguage.setChecked(true);
                }
                else {
                    holder.btnLanguage.setChecked(false);
                }
            } else {
                holder.txtLanguage.setText(language.language);
                if (language.languageCode.equals(LocaleManager.getLanguageCode(context))) {
                    holder.btnLanguage.setChecked(true);
                } else {
                    holder.btnLanguage.setChecked(false);
                }
            }

            holder.mainLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!holder.btnLanguage.isChecked()) {
                        if (from != null && from.equals(Constants.TAG_CHAT)) {
                            setTranslateLanguage(language.languageCode);
                        } else {
                            setNewLocale(context, language.languageCode);
                        }
                    }
                }
            });

            holder.btnLanguage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (from != null && from.equals(Constants.TAG_CHAT)) {
                        setTranslateLanguage(language.languageCode);
                    } else {
                        setNewLocale(context, language.languageCode);
                    }
                }
            });
        }

        private void setNewLocale(Context context, String languageCode) {
            adapter.notifyDataSetChanged();
            editor.putString(Constants.TAG_LANGUAGE_CODE, languageCode).commit();
            LocaleManager.setNewLocale(context, languageCode);
            Intent intent = new Intent(LanguageActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        }

        private void setTranslateLanguage(String languageCode) {
            adapter.notifyDataSetChanged();
            editor.putString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, languageCode).commit();
            finish();
        }

        @Override
        public int getItemCount() {
            return languageList.size();
        }

        public class LanguageViewHolder extends RecyclerView.ViewHolder {
            private RelativeLayout mainLayout;
            private TextView txtLanguage;
            private RadioButton btnLanguage;

            public LanguageViewHolder(View itemView) {
                super(itemView);
                mainLayout = itemView.findViewById(R.id.mainLayout);
                txtLanguage = itemView.findViewById(R.id.txtLanguage);
                btnLanguage = itemView.findViewById(R.id.btnLanguage);
            }
        }
    }

}
