package com.app.fourchattingapp.legals;

import android.app.Activity;
import android.content.Context;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.app.fourchattingapp.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PermissionsDialog extends DialogFragment {

    public static final String TAG = "permissions-dialog";

    private DialogActionListener mListener;

    private Context mContext;

    public PermissionsDialog() {
    }

    public PermissionsDialog(@NonNull Context context) {
        setStyle(STYLE_NO_TITLE, R.style.Dialog);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_permissions, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvAllow = view.findViewById(R.id.allow);
        TextView tvCancel = view.findViewById(R.id.cancel);
        TextView txtTitle = view.findViewById(R.id.title);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);

        txtTitle.setText(String.format(getString(R.string.app_would_access_to), getString(R.string.app_name)));
        tvCancel.setOnClickListener(v -> dismiss(false));
        tvAllow.setOnClickListener(v -> dismiss(true));

        final PermissionsAdapter adapter = new PermissionsAdapter(new DiffUtil.ItemCallback<Permission>() {
            @Override
            public boolean areItemsTheSame(@NonNull Permission oldItem, @NonNull Permission newItem) {
                return oldItem.title.equals(newItem.title);
            }

            @Override
            public boolean areContentsTheSame(@NonNull Permission oldItem, @NonNull Permission newItem) {
                return Objects.equals(oldItem, newItem);
            }
        });
        recyclerView.setAdapter(adapter);

        List<Permission> permissions = new ArrayList<Permission>() {{
            add(new Permission(getString(R.string.read_contacts), String.format(getString(R.string.read_contact_description),
                    getString(R.string.app_name), getString(R.string.app_name), getString(R.string.app_name))));
            add(new Permission(getString(R.string.write_external_storage), getString(R.string.write_storage_description)));
            add(new Permission(getString(R.string.location_permission), getString(R.string.location_description)));
        }};
        adapter.submitList(permissions);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null && getDialog() != null && getDialog().getWindow() != null) {
            int displayWidth = getScreenWidth(getActivity());
            Window window = getDialog().getWindow();
            int maxWidth = displayWidth / 100 * 90;
            Drawable d = mContext.getResources().getDrawable(R.drawable.rounded_corners);
            window.setBackgroundDrawable(d);
            window.setLayout(maxWidth, WindowManager.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.CENTER);
        }
    }

    public static int getScreenWidth(@NonNull Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = activity.getWindowManager().getCurrentWindowMetrics();
            Insets insets = windowMetrics.getWindowInsets()
                    .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars());
            return windowMetrics.getBounds().width() - insets.left - insets.right;
        } else {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            return displayMetrics.widthPixels;
        }
    }

    public void dismiss(boolean b) {
        if (mListener != null) {
            if (b) mListener.affirmative();
            else mListener.onCanceled();
        }
        super.dismiss();
    }

    private static class Permission {
        private String title;
        private String description;

        //        @Contract(pure = true)
        public Permission(String title, String description) {
            this.title = title;
            this.description = description;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }
    }

    public DialogActionListener getListener() {
        return mListener;
    }

    public void setListener(DialogActionListener mListener) {
        this.mListener = mListener;
    }

    public static class Builder {
        private PermissionsDialog d;

        public Builder(@NonNull Context context) {
            d = new PermissionsDialog(context);
        }

        public Builder setOnDialogActionsListener(@NonNull DialogActionListener listener) {
            d.setListener(listener);
            return this;
        }

        public PermissionsDialog build() {
            return d;
        }
    }

    private static class PermissionsAdapter extends ListAdapter<Permission, PermissionsAdapter.ViewHolder> {

        protected PermissionsAdapter(@NonNull DiffUtil.ItemCallback<Permission> diffCallback) {
            super(diffCallback);
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_permission, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            @NonNull final Permission p = getItem(position);
            holder.bind(p);
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView title, description;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                title = itemView.findViewById(R.id.title);
                description = itemView.findViewById(R.id.description);
            }

            private void bind(@NonNull Permission data) {
                title.setText(data.getTitle());
                description.setText(data.getDescription());
            }
        }
    }

    public interface DialogActionListener {
        void affirmative();

        void onCanceled();
    }
}