package com.app.helper.workers;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GroupChatReceivedWorker extends Worker {
    private static final String TAG = GroupChatReceivedWorker.class.getSimpleName();
    private Context mContext;

    public GroupChatReceivedWorker(
            @NonNull Context appContext,
            @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);
        mContext = appContext;
    }

    @NonNull
    @NotNull
    @Override
    public Result doWork() {
        // To acknowledge the message has been delivered
        Map<String, String> params = new HashMap<>();
        params.put(Constants.TAG_USER_ID, getInputData().getString(Constants.TAG_USER_ID));
        params.put(Constants.TAG_MESSAGE_ID, getInputData().getString(Constants.TAG_MESSAGE_ID));
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call = apiInterface.groupChatReceived(GetSet.getToken(), params);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
//                Log.d(TAG, "groupChatReceivedResponse: "+ response.isSuccessful());
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {

            }
        });
        return Result.success();
    }
}
