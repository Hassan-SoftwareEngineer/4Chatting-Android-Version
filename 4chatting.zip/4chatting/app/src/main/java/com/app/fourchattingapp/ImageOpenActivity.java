package com.app.fourchattingapp;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.app.external.TouchImageView;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

public class ImageOpenActivity extends BaseActivity {

    TouchImageView imageView;
    ImageView closeBtn;
    String url = "", from;
    Uri fileUri = null;
    int placeHolderId = R.drawable.profile_banner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_open);
        imageView = findViewById(R.id.imageView);
        closeBtn = findViewById(R.id.closeBtn);

        // overridePendingTransition(R.anim.slide_up,R.anim.slide_up);
        if (getIntent().hasExtra(Constants.TAG_FROM)) {
            from = getIntent().getExtras().getString(Constants.TAG_FROM);
        }

        if (getIntent().hasExtra(Constants.TAG_USER_IMAGE)) {
            url = getIntent().getExtras().getString(Constants.TAG_USER_IMAGE);
        } else {
            fileUri = getIntent().getData();
        }

        if (from.equals(Constants.TAG_SINGLE)) {
            placeHolderId = R.drawable.profile_banner;
        } else if (from.equals(Constants.TAG_GROUP)) {
            placeHolderId = R.drawable.ic_group_banner;
        } else if (from.equals(Constants.TAG_CHANNEL)) {
            placeHolderId = R.drawable.ic_channel_banner;
        }

        Glide.with(getApplicationContext()).load(!TextUtils.isEmpty(url.trim()) ? url : fileUri)
                .placeholder(placeHolderId)
                .error(placeHolderId)
                .into(imageView);

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // overridePendingTransition(R.anim.slide_up,R.anim.slide_down);
                finish();
            }
        });
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void finish() {
        super.finish();
        // overridePendingTransition(R.anim.slide_up,R.anim.slide_down);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
