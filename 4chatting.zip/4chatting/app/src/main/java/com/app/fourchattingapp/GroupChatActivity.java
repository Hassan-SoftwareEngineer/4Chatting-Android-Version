package com.app.fourchattingapp;

import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.helper.StorageManager.TAG_AUDIO;
import static com.app.helper.StorageManager.TAG_DOCUMENT;
import static com.app.helper.StorageManager.TAG_DOCUMENT_SENT;
import static com.app.helper.StorageManager.TAG_THUMB;
import static com.app.helper.StorageManager.TAG_VIDEO;
import static com.app.helper.StorageManager.TAG_VIDEO_SENT;
import static com.app.fourchattingapp.GroupChatActivity.MessageListAdapter.VIEW_TYPE_DATE;
import static com.app.utils.Constants.ADMIN;
import static com.app.utils.Constants.TAG_GROUP;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_IMAGE;
import static com.app.utils.Constants.TAG_MEMBER_ID;
import static com.app.utils.Constants.TAG_MEMBER_ROLE;
import static com.app.utils.Constants.TAG_TRUE;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.transition.TransitionManager;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.app.model.GroupData;
import com.app.model.GroupResult;
import com.app.model.GroupUpdateResult;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.GranularRoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.devlomi.record_view.OnRecordListener;
import com.devlomi.record_view.RecordButton;
import com.devlomi.record_view.RecordView;
import com.giphy.sdk.core.models.Media;
import com.giphy.sdk.ui.GPHContentType;
import com.giphy.sdk.ui.GPHSettings;
import com.giphy.sdk.ui.Giphy;
import com.giphy.sdk.ui.themes.GPHTheme;
import com.giphy.sdk.ui.themes.GridType;
import com.giphy.sdk.ui.views.GiphyDialogFragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.mlkit.nl.smartreply.SmartReplySuggestion;
import com.app.addons.chattranslate.ChatTranslateWorker;
import com.app.addons.smartreply.GenerateSmartReplyWorker;
import com.app.addons.smartreply.ReplyChipAdapter;
import com.app.external.EndlessRecyclerOnScrollListener;
import com.app.external.ImagePicker;
import com.app.external.MediaPlayerUtils;
import com.app.external.ProgressWheel;
import com.app.external.RandomString;
import com.app.external.RecyclerItemClickListener;
import com.app.external.keyboard.HeightProvider;
import com.app.helper.BitmapCompression;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.DownloadFilesTask;
import com.app.helper.FileUploadService;
import com.app.helper.ImageDownloader;
import com.app.helper.NetworkUtil;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.helper.Utils;
import com.app.helper.WrapContentLinearLayoutManager;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.event.NewGroupMessageEvent;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.models.sort.SortingTypes;
import droidninja.filepicker.utils.ContentUriUtils;
import jp.wasabeef.glide.transformations.BlurTransformation;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GroupChatActivity extends BaseActivity implements View.OnClickListener, SocketConnection.GroupChatCallbackListener,
        TextWatcher, DeleteAdapter.deleteListener, MediaPlayerUtils.Listener, SocketConnection.OnGroupCreatedListener, GiphyDialogFragment.GifSelectionListener, RecognitionListener {
    public static String tempGroupId = "";
    EditText editText;
    String groupId, groupName;
    List<GroupMessage> messagesList = new ArrayList<>();
    String TAG = this.getClass().getSimpleName();
    RecyclerView recyclerView;
    TextView username, online, txtMembers, audioTime;
    private CoordinatorLayout parentLay;
    RelativeLayout chatUserLay, mainLay, attachmentsLay, imageViewLay, bottomLay, forwordLay;
    ImageView attachbtn, optionbtn, backbtn, send, audioCallBtn, videoCallBtn, cameraBtn,
            galleryBtn, fileBtn, audioBtn, locationBtn, contactBtn, imageView, forwordBtn,
            copyBtn, closeBtn, deleteBtn, btnGif, btnLanguage;
    CircleImageView userimage;
    FrameLayout newMessageLay;
    ImageView iconNewMessage;
    Display display;
    boolean visible, stopLoading = false, meTyping, chatLongPressed = false;
    int totalMsg;
    SocketConnection socketConnection;
    LinearLayoutManager linearLayoutManager;
    MessageListAdapter messageListAdapter;
    DatabaseHandler dbHelper;
    StorageManager storageManager;
    ApiInterface apiInterface;
    ArrayList<Uri> pathsAry = new ArrayList<>();
    Handler handler = new Handler();
    Runnable runnable;
    EndlessRecyclerOnScrollListener endlessRecyclerOnScrollListener;
    GroupData groupData;
    ArrayList<GroupMessage> selectedChatPos = new ArrayList<>();
    String recordVoicePath = null;
    Uri recordVoiceUri = null;
    MediaRecorder mediaRecorder;
    RecordView recordView;
    RecordButton recordButton;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    LinearLayout editLay, excryptText;
    boolean isRecording = false;
    private Utils utils;
    private boolean isFromNotification;
    private String currentMessageId = null;
    private Parcelable state;
    private Context mContext;
    private int keyBoardHeight = 0, bottomNavHeight = 0, bottomMargin = 0;
    private boolean isKeyBoardOpen = false;
    private boolean isMoveToStart = true;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private ActivityResultLauncher<Intent> contactResultLauncher;
    private ActivityResultLauncher<Intent> galleryResultLauncher;
    private ActivityResultLauncher<Intent> audioResultLauncher;
    private ActivityResultLauncher<Intent> documentResultLauncher;
    private ActivityResultLauncher<Intent> forwardResultLauncher;
    private ActivityResultLauncher<Intent> locationResultLauncher;

    private Uri photoURI;
    private boolean isGalleryClicked = false, isCameraClicked = false, isDownloadClicked = false,
            isFileClicked = false, isAudioClicked = false;
    private DateUtils dateUtils;
    private List<String> tempMessageIdList = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    //Addon Gif
    GiphyDialogFragment giphyDialogFragment;
    //Addon Smart Reply
    ReplyChipAdapter mChipAdapter;
    private RecyclerView mSmartRepliesRecycler;
    TextToSpeech t1;
    Intent intent;
    SpeechRecognizer recognizer;
    TextView txt_recording;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initValues();
        initBackground();
        setContentView(R.layout.activity_main_chat);
        if (getIntent().getStringExtra("notification") != null) {
            Constants.isGroupChatOpened = true;
            isFromNotification = true;
        }
        isRecording = false;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        parentLay = findViewById(R.id.parentLay);
        txt_recording = findViewById(R.id.txt_recording);
        recyclerView = findViewById(R.id.recyclerView);
        send = findViewById(R.id.send);
        editText = findViewById(R.id.editText);
        chatUserLay = findViewById(R.id.chatUserLay);
        userimage = findViewById(R.id.userImg);
        username = findViewById(R.id.userName);
        txtMembers = findViewById(R.id.txtMembers);
        online = findViewById(R.id.online);
        attachbtn = findViewById(R.id.attachbtn);
        audioCallBtn = findViewById(R.id.audioCallBtn);
        videoCallBtn = findViewById(R.id.videoCallBtn);
        optionbtn = findViewById(R.id.optionbtn);
        backbtn = findViewById(R.id.backbtn);
        bottomLay = findViewById(R.id.bottom);
        mainLay = findViewById(R.id.mainLay);
        attachmentsLay = findViewById(R.id.attachmentsLay);
        cameraBtn = findViewById(R.id.cameraBtn);
        galleryBtn = findViewById(R.id.galleryBtn);
        fileBtn = findViewById(R.id.fileBtn);
        audioBtn = findViewById(R.id.audioBtn);
        locationBtn = findViewById(R.id.locationBtn);
        contactBtn = findViewById(R.id.contactBtn);
        newMessageLay = findViewById(R.id.newMessageLay);
        iconNewMessage = findViewById(R.id.iconNewMessage);
        imageViewLay = findViewById(R.id.imageViewLay);
        closeBtn = imageViewLay.findViewById(R.id.closeBtn);
        imageView = findViewById(R.id.imageView);
        forwordLay = findViewById(R.id.forwordLay);
        forwordBtn = findViewById(R.id.forwordBtn);
        copyBtn = findViewById(R.id.copyBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        editLay = findViewById(R.id.editLay);
        recordView = findViewById(R.id.record_view);
        recordButton = findViewById(R.id.record_button);
        excryptText = findViewById(R.id.excryptText);
        btnGif = findViewById(R.id.btnGif);
        btnLanguage = findViewById(R.id.btnLanguage);
        // Set up recycler view for smart replies
        mSmartRepliesRecycler = findViewById(R.id.smartRepliesRecycler);
        if (recyclerView.getItemAnimator() != null) {
            ((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
        }


        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        // set visibility status
        chatUserLay.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        audioCallBtn.setVisibility(View.GONE);
        videoCallBtn.setVisibility(View.GONE);
        optionbtn.setVisibility(View.VISIBLE);
        txtMembers.setVisibility(View.VISIBLE);

        initPermission();
        initActivityResult();

        username.setText(!TextUtils.isEmpty(groupName) ? groupName : groupData.groupName);
        setGroupMembers(groupId);
        Glide.with(GroupChatActivity.this).load(Constants.CHAT_IMG_PATH + groupData.groupImage)
                .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.create_group).error(R.drawable.create_group))
                .into(userimage);

        totalMsg = dbHelper.getGroupMessagesCount(groupId);

        messagesList.addAll(getMessagesAry(dbHelper.getGroupMessages(groupId, "0", "20", this), null));
//        Log.e(TAG, "onCreate: " + new Gson().toJson(messagesList));
        showEncryptionText();
        linearLayoutManager = new WrapContentLinearLayoutManager(this, RecyclerView.VERTICAL, false);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(linearLayoutManager);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setItemViewCacheSize(100);
//        recyclerView.setDrawingCacheEnabled(true);
//        recyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);

        messageListAdapter = new MessageListAdapter(this, messagesList);
        recyclerView.setAdapter(messageListAdapter);

        recyclerView.post(new Runnable() {
            @Override
            public void run() {
                recyclerView.scrollToPosition(0);
            }
        });

        DividerItemDecoration divider = new DividerItemDecoration(recyclerView.getContext(),
                linearLayoutManager.getOrientation());
        divider.setDrawable(getResources().getDrawable(R.drawable.emptychat_divider));
        recyclerView.addItemDecoration(divider);

        initAdOns();

        send.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        attachbtn.setOnClickListener(this);
        optionbtn.setOnClickListener(this);
        userimage.setOnClickListener(this);
        audioCallBtn.setOnClickListener(this);
        videoCallBtn.setOnClickListener(this);
        cameraBtn.setOnClickListener(this);
        galleryBtn.setOnClickListener(this);
        fileBtn.setOnClickListener(this);
        audioBtn.setOnClickListener(this);
        locationBtn.setOnClickListener(this);
        contactBtn.setOnClickListener(this);
        editText.addTextChangedListener(this);
        chatUserLay.setOnClickListener(this);
        copyBtn.setOnClickListener(this);
        forwordBtn.setOnClickListener(this);
        closeBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);
        newMessageLay.setOnClickListener(this);

        setVoiceRecorder();
        whileViewChat();
        setKeyBoardListener();

        if (!dbHelper.isMemberExist(GetSet.getUserId(), groupId)) {
            bottomLay.setVisibility(View.GONE);
            setNewMessageParams(View.GONE);
        }

        endlessRecyclerOnScrollListener = new EndlessRecyclerOnScrollListener(linearLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                Log.v(TAG, "onLoadMore=" + page + "&totalItems=" + totalItemsCount);
                final List<GroupMessage> tmpList = new ArrayList<>(dbHelper.getGroupMessages(groupId, String.valueOf(page * 20), "20", GroupChatActivity.this));
                if (tmpList.size() == 0 && !stopLoading) {
                    stopLoading = true;
                    messagesList.addAll(getMessagesAry(tmpList, messagesList.get(messagesList.size() - 1)));
                } else {
                    messagesList.addAll(getMessagesAry(tmpList, null));
                }
                showEncryptionText();
                recyclerView.post(new Runnable() {
                    public void run() {
                        messageListAdapter.notifyDataSetChanged();
                    }
                });
            }
        };
        recyclerView.addOnScrollListener(endlessRecyclerOnScrollListener);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (linearLayoutManager.findFirstCompletelyVisibleItemPosition() == 0) {
                    isMoveToStart = true;
                } else {
                    isMoveToStart = false;
                }
                new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setNewMessageLay();
                    }
                }, 100);
            }
        });

        if (SocketConnection.onUpdateTabIndication != null) {
            SocketConnection.onUpdateTabIndication.updateIndication();
        }

        recyclerView.addOnItemTouchListener(chatItemClick(this, recyclerView));

        txt_recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkAudioPermission()) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(GroupChatActivity.this);
                    if (txt_recording.getText().toString().equals("Stop Recording")){
                        recognizer.stopListening();
                        txt_recording.setText("Start Recording");

                    }else{
                        txt_recording.setText("Stop Recording");
                        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").isEmpty()){
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                        }else{
                            if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")!=null){
                                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""));

                            }else{
                                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                            }

                        }

                        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true);

                        recognizer = SpeechRecognizer.createSpeechRecognizer(GroupChatActivity.this);
                        recognizer.setRecognitionListener(GroupChatActivity.this);
                        recognizer.startListening(intent);
                    }


                } else {

                    requestAudioPermission();
                }
            }
        });
    }

    private void initValues() {
        mContext = this;
        utils = new Utils(mContext);
        pref = GroupChatActivity.this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        if (getIntent().getStringExtra("notification") != null) {
            Constants.isGroupChatOpened = true;
            isFromNotification = true;
        }
        if (Constants.groupContext != null && Constants.isGroupChatOpened) {
            ((Activity) Constants.groupContext).finish();
        }
        dateUtils = DateUtils.getInstance(mContext);
        socketConnection = SocketConnection.getInstance(this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        dbHelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        display = getWindowManager().getDefaultDisplay();
        groupId = getIntent().getStringExtra(TAG_GROUP_ID);
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
        Constants.groupContext = this;
        if (dbHelper.getGroupData(this, groupId) != null) {
            groupData = dbHelper.getGroupData(this, groupId);
            groupName = groupData.groupName;
            tempGroupId = groupId;
        } else {
            finish();
        }
    }

    private void setNewMessageLay() {
        if (isFirstItemVisible() || messagesList.size() == 0) {
            iconNewMessage.setVisibility(View.GONE);
            newMessageLay.setVisibility(View.GONE);
        } else {
            newMessageLay.setVisibility(View.VISIBLE);
        }
    }

    private void setNewMessageParams(int visibility) {
        if (visibility == View.VISIBLE) {
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.addRule(RelativeLayout.ABOVE, R.id.bottom);
            params.addRule(RelativeLayout.ALIGN_PARENT_END);
            params.bottomMargin = ApplicationClass.dpToPx(this, 15);
            params.rightMargin = ApplicationClass.dpToPx(this, 15);
            newMessageLay.setLayoutParams(params);
        } else {
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            params.addRule(RelativeLayout.ALIGN_PARENT_END);
            params.bottomMargin = ApplicationClass.dpToPx(this, 15);
            params.rightMargin = ApplicationClass.dpToPx(this, 15);
            newMessageLay.setLayoutParams(params);
        }
    }

    private void initBackground() {
        getWindow().setBackgroundDrawableResource(R.drawable.chat_bg);
    }

    private void getDefaultChatWallpaper() {
        Bitmap icon = BitmapFactory.decodeResource(getResources(),
                R.drawable.chat_bg);
        int dimension = Math.min(icon.getWidth(), icon.getHeight());
        Bitmap backgroundBitmap = ThumbnailUtils.extractThumbnail(icon, dimension, dimension);
        Drawable d = new BitmapDrawable(getResources(), backgroundBitmap);
        getWindow().setBackgroundDrawable(d);
    }

    private void initPermission() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "storagePermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isGalleryClicked) galleryBtn.performClick();
                    else if (isFileClicked) fileBtn.performClick();
                    else if (isAudioClicked) audioBtn.performClick();
                } else {
                    boolean neverAsked = false;
                    Log.d(TAG, "requestPermissions: ");
                    String alertMsg="";

                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if(x.getKey()==Manifest.permission.READ_MEDIA_AUDIO)
                                alertMsg = "Please enable audio permission";
                            else alertMsg = mContext.getString(R.string.storage_error);

                            if (ActivityCompat.shouldShowRequestPermissionRationale(GroupChatActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, alertMsg);
                            }
                            break;
                        }
                    }
                }

            }
        });

        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }
                if (granted) {
                    cameraBtn.performClick();
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(GroupChatActivity.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                String errorString;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    errorString = mContext.getString(R.string.camera_error);
                                } else {
                                    errorString = mContext.getString(R.string.camera_storage_error);
                                }
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, errorString);
                            }
                            break;
                        }
                    }
                }
            }
        });
    }

    private void initActivityResult() {
        contactResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            // There are no request codes
                            Intent data = result.getData();

                            try {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    Uri uri = data.getData();
                                    Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                                    if (cursor.moveToFirst()) {
                                        int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                                        int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                                        String phoneNo = cursor.getString(phoneIndex);
                                        String name = cursor.getString(nameIndex);

                                        Log.v(TAG, "Name & Contact: " + name + "," + phoneNo);

                                        emitContact("contact", name, phoneNo, "");
                                    }
                                    cursor.close();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }
                });

        documentResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                sendDocument(result.getData());
                            }
                        }
                    }
                });

        audioResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                pathsAry = new ArrayList<>();
                                pathsAry.addAll(result.getData().getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                                if (pathsAry.size() > 0) {
                                    String savedPath = null;
                                    try {
                                        String filepath = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            String extension = storageManager.getExtension(pathsAry.get(0));
                                            File tempFile = new File(storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension));
                                            savedPath = storageManager.saveFileInStorage(tempFile, StorageManager.TAG_AUDIO_SENT);
                                        } else {
                                            filepath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                            savedPath = storageManager.saveFileInStorage(new File(filepath), StorageManager.TAG_AUDIO_SENT);
                                        }
                                        GroupMessage mdata = updateDBList(Constants.TAG_AUDIO, null, null, savedPath, "");
                                        Intent service = new Intent(GroupChatActivity.this, FileUploadService.class);
                                        Bundle b = new Bundle();
                                        b.putSerializable("mdata", mdata);
                                        b.putString("filepath", savedPath);
                                        b.putString("chatType", "group");
                                        service.putExtras(b);
                                        startService(service);
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                } else {
                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });
        galleryResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                pathsAry = new ArrayList<>();
                                pathsAry.addAll(result.getData().getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));
                                if (pathsAry.size() > 0) {
                                    boolean isVideo = false;
                                    if (storageManager.getMimeTypeOfUri(mContext, pathsAry.get(0)).startsWith("video/")) {
                                        isVideo = true;
                                    }

                                    String filePath = "";
                                    if (isVideo) {
                                        String savedVideoPath = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            String extension = storageManager.getExtension(pathsAry.get(0));
                                            String tempPath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                                            savedVideoPath = storageManager.saveFileInStorage(new File(tempPath), TAG_VIDEO_SENT);
                                        } else {
                                            try {
                                                filePath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                                savedVideoPath = storageManager.saveFileInStorage(new File(filePath), TAG_VIDEO_SENT);
                                            } catch (URISyntaxException | NullPointerException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        Bitmap thumb = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            try {
                                                thumb = getContentResolver().loadThumbnail(pathsAry.get(0),
                                                        Utils.getBitmapSize(mContext), null);
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        } else {
                                            thumb = ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Video.Thumbnails.MINI_KIND);
                                        }

                                        try {
                                            if (thumb != null) {
                                                String fileName = System.currentTimeMillis() + ".jpg";
                                                String savedThumbPath = null;
                                                savedThumbPath = storageManager.saveImageInStorage(thumb, fileName, StorageManager.TAG_THUMB).getAbsolutePath();

                                                GroupMessage mdata = updateDBList(Constants.TAG_VIDEO, null, null, savedVideoPath, savedThumbPath);
                                                byte[] bytes = null;
                                                bytes = FileUtils.readFileToByteArray(new File(savedThumbPath));
                                                uploadVideoThumbnail(bytes, null, savedThumbPath, mdata, null, savedVideoPath);
                                            }
                                        } catch (IOException ex) {
                                            ex.printStackTrace();
                                            Toast.makeText(GroupChatActivity.this, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        String savedImagePath = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            String extension = storageManager.getExtension(pathsAry.get(0));
                                            savedImagePath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                                        } else {
                                            try {
                                                savedImagePath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                            } catch (URISyntaxException | NullPointerException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        String finalSavedImagePath = savedImagePath;
                                        BitmapCompression imageCompression = new BitmapCompression(mContext, null, finalSavedImagePath) {
                                            @Override
                                            protected void onPostExecute(Bitmap compressedBitmap) {
                                                String fileName = (System.currentTimeMillis()) + ".jpg";
                                                String savedPath = null;
                                                savedPath = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();
                                                GroupMessage mdata = updateDBList(Constants.TAG_IMAGE, null, null, savedPath, "");
                                                byte[] bytes = StorageManager.bitmapToByteArray(compressedBitmap);
                                                uploadImage(bytes, null, savedPath, mdata);
                                            }
                                        };
                                        imageCompression.execute();
                                    }
                                } else {
                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });
        locationResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            String lat = result.getData().getStringExtra("lat");
                            String lon = result.getData().getStringExtra("lon");
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                emitLocation(Constants.TAG_LOCATION, lat, lon);
                            }

                        }
                    }
                });
        forwardResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            selectedChatPos.clear();
                            messageListAdapter.notifyDataSetChanged();
                            chatUserLay.setVisibility(View.VISIBLE);
                            forwordLay.setVisibility(View.GONE);
                            chatLongPressed = false;
                        }
                    }
                });
    }


    private void getGroupInfo(String groupId) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(groupId);
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GroupResult> call3 = apiInterface.getGroupInfo(GetSet.getToken(), jsonArray.toString());
        call3.enqueue(new Callback<GroupResult>() {
            @Override
            public void onResponse(Call<GroupResult> call, Response<GroupResult> response) {
                try {
                    Log.i(TAG, "getGroupInfo: " + new Gson().toJson(response.body()));
                    GroupResult userdata = response.body();
                    if (userdata.status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        for (GroupData groupData : userdata.result) {

                            for (GroupData.GroupMembers groupMember : groupData.groupMembers) {
                                Log.i(TAG, "getGroupInfo: " + new Gson().toJson(groupMember));
                            }

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<GroupResult> call, Throwable t) {
                Log.v("getGroupInfo Failed", "TEST" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void sendDocument(Intent data) {
        if (isNetworkConnected().equals(NOT_CONNECT)) {
            networkSnack();
        } else {
            pathsAry = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Uri contentUri = data.getData();
                pathsAry.add(contentUri);
            } else {
                pathsAry.addAll(data.getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
            }
            String filePath = "";
            String savedFilePath = null;
            if (pathsAry.size() > 0) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String extension = storageManager.getExtension(pathsAry.get(0));
                    String tempFile = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                    savedFilePath = storageManager.saveFileInStorage(new File(tempFile), TAG_DOCUMENT_SENT);
                } else {
                    try {
                        filePath = ContentUriUtils.INSTANCE.getFilePath(mContext, pathsAry.get(0));
                        savedFilePath = storageManager.saveFileInStorage(new File(filePath), TAG_DOCUMENT_SENT);
                    } catch (URISyntaxException | NullPointerException e) {
                        e.printStackTrace();
                    }
                }

                GroupMessage mdata = updateDBList(Constants.TAG_DOCUMENT, null, null, savedFilePath, "");
                Intent service = new Intent(GroupChatActivity.this, FileUploadService.class);
                Bundle b = new Bundle();
                b.putSerializable("mdata", mdata);
                b.putString("filepath", savedFilePath);
                b.putString("chatType", "group");
                service.putExtras(b);
                startService(service);
            } else {
                Toast.makeText(this, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestPermission(String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(GroupChatActivity.this, permissions, requestCode);
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void requestCameraPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cameraPermissionResult.launch(PermissionsUtils.CAMERA_PERMISSION);
        } else {
            cameraPermissionResult.launch(PermissionsUtils.CAMERA_STORAGE_PERMISSION);
        }
    }

    private boolean isFirstItemVisible() {
        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        int position = linearLayoutManager.findFirstVisibleItemPosition();
        return position == 0;
    }

    private void setKeyBoardListener() {
        HeightProvider heightProvider = new HeightProvider(this);

        parentLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + bottomMargin;
                if (parentLay != null) {
//                    setBottomMargin(bottomNavHeight + bottomMargin);
                }
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        heightProvider.init().setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                if (height > 0) {
                    params.bottomMargin = height;
                    bottomLay.setLayoutParams(params);
                    if (isMoveToStart) {
                        recyclerView.scrollToPosition(0);
                    }
                    keyBoardHeight = height;
                    isKeyBoardOpen = true;
                } else {
                    params.bottomMargin = 0;
                    bottomLay.setLayoutParams(params);
                    isKeyBoardOpen = false;
                }
            }
        });
    }

    private void initAdOns() {
        if (Constants.ADDON_EMOJI_GIF) {
            initGif();
        }
        if (Constants.ADDON_SMART_REPLY) {
            setSmartReplyRecyclerView();
        }

        if (Constants.ADDON_CHAT_TRANSLATE) {
            btnLanguage.setVisibility(View.VISIBLE);
            btnLanguage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isRecording)return;
                    Intent language = new Intent(getApplicationContext(), LanguageActivity.class);
                    language.putExtra(Constants.TAG_FROM, Constants.TAG_CHAT);
                    language.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(language);
                }
            });
        } else {
            btnLanguage.setVisibility(View.GONE);
        }
    }

    //Addon Gif
    private void initGif() {
        btnGif.setVisibility(View.VISIBLE);
        Giphy.INSTANCE.configure(this, Constants.GIPHY_KEY, false);
        GPHSettings settings = new GPHSettings();
        settings.setGridType(GridType.waterfall);
        settings.setTheme(GPHTheme.Light);
        settings.setMediaTypeConfig(new GPHContentType[]{GPHContentType.sticker, GPHContentType.emoji, GPHContentType.gif, GPHContentType.text});
        giphyDialogFragment = GiphyDialogFragment.Companion.newInstance(settings);
        giphyDialogFragment.setGifSelectionListener(this);
        btnGif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                giphyDialogFragment.show(getSupportFragmentManager(), "giphy_dialog");
            }
        });
    }

    //Addon SmartReply
    private void setSmartReplyRecyclerView() {
        mSmartRepliesRecycler.setVisibility(View.VISIBLE);
        LinearLayoutManager chipManager = new LinearLayoutManager(this);
        chipManager.setOrientation(RecyclerView.HORIZONTAL);
        mChipAdapter = new ReplyChipAdapter(new ReplyChipAdapter.ClickListener() {
            @Override
            public void onChipClick(@NonNull String chipText) {
                sendTextMessage(chipText);
            }
        });
        mSmartRepliesRecycler.setLayoutManager(chipManager);
        mSmartRepliesRecycler.setAdapter(mChipAdapter);

        if (messagesList.size() > 0) {
            for (GroupMessage messagesData : messagesList) {
                if (!messagesData.messageType.equals(Constants.TAG_DATE)) {
                    if (messagesData.messageType.equals(Constants.TAG_TEXT) || messagesData.messageType.equals(Constants.TAG_STORY)) {
                        if (messagesData.memberId != null && !messagesData.memberId.equals(GetSet.getUserId())) {
                            generateReplies(messagesData.message);
                        }
                    } else {
                        mSmartRepliesRecycler.setVisibility(View.GONE);
                    }
                    break;
                }
            }
        }
    }

    private void showEncryptionText() {
        if (messagesList.isEmpty()) {
            excryptText.setVisibility(View.VISIBLE);
        } else {
            excryptText.setVisibility(View.GONE);
        }
    }

    private void setGroupMembers(String groupId) {
        List<GroupData.GroupMembers> memberList = dbHelper.getThreeMembers(this, groupId);
        StringBuilder members = new StringBuilder();
        String prefix = "";
        for (GroupData.GroupMembers groupMembers : memberList) {
            members.append(prefix);
            prefix = ", ";
            if (groupMembers.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                members.append(getString(R.string.you));
            } else {
                ContactsData.Result user = dbHelper.getContactDetail(groupMembers.memberId);
                members.append(user.user_name);
            }
        }
        txtMembers.setText("" + members);

    }

    private void setVoiceRecorder() {

//        recordView.setCounterTimeColor(Color.parseColor("#a3a3a3"));
        recordView.setCounterTimeColor(getResources().getColor(R.color.recieveLastSeen));
        recordView.setSmallMicColor(ContextCompat.getColor(GroupChatActivity.this, R.color.colorAccent));
//        recordView.setSlideToCancelTextColor(Color.parseColor("#a3a3a3"));
        recordView.setSlideToCancelTextColor(getResources().getColor(R.color.recieveLastSeen));
        recordView.setLessThanSecondAllowed(false);
        recordView.setSlideToCancelText(getString(R.string.slide_to_cancel));
        //set Custom sounds onRecord
        //you can pass 0 if you don't want to play sound in certain state
        recordView.setCustomSounds(R.raw.record_start, R.raw.record_finished, R.raw.record_error);

        recordButton.setRecordView(recordView);
        setClickEvent(false, false, false, false, true, false);

        if (isNetworkConnected().equals(NOT_CONNECT)) {
            networkSnack();
        } else {
            recordView.setOnRecordListener(new OnRecordListener() {
                @Override
                public void onStart() {
                    if (checkAudioPermission()) {
                        isRecording = true;
                        startVoice();
                    } else {
                        recordVoicePath = null;
                        recordVoiceUri = null;
                        recordView.setOnRecordListener(null);
                        requestAudioPermission();
                    }
                }

                @Override
                public void onCancel() {
                    isRecording = false;
                    editText.requestFocus();
                    playSound(R.raw.record_error);
//                Toast.makeText(ChatActivity.this, "onCancel"+time, Toast.LENGTH_SHORT).show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            sendTypingStatus("untyping");
                            ApplicationClass.hideSoftKeyboard(GroupChatActivity.this, recordView);
                            editLay.setVisibility(View.VISIBLE);
                            recordView.setVisibility(View.GONE);
                        }
                    }, 1000);

                }

                @Override
                public void onFinish(long recordTime, boolean limitReached) {
                    if (recordTime > 1000 && (recordVoicePath != null || recordVoiceUri != null)) {
                        editText.requestFocus();
                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                            networkSnack();
                        } else {
                            if (null != mediaRecorder) {
                                try {
                                    mediaRecorder.stop();
                                } catch (RuntimeException ex) {
                                    ex.printStackTrace();
                                }
                            }
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    editLay.setVisibility(View.VISIBLE);
                                    recordView.setVisibility(View.GONE);
                                    sendTypingStatus("untyping");

                                    GroupMessage mdata = updateDBList(Constants.TAG_AUDIO, null, null, recordVoicePath, "");
                                    Intent service = new Intent(GroupChatActivity.this, FileUploadService.class);
                                    Bundle b = new Bundle();
                                    b.putSerializable("mdata", mdata);
                                    b.putString("filepath", recordVoicePath);
                                    b.putString("chatType", "group");
                                    service.putExtras(b);
                                    startService(service);
                                }
                            }, 200);
                        }
                    } else if (!checkAudioPermission()) {
                        stopAudioViewHolder();
                        makeToast(getString(R.string.audio_record_permission_error));
                    } else {
                        sendTypingStatus("untyping");
                        stopAudioViewHolder();
                        editLay.setVisibility(View.VISIBLE);
                        recordView.setVisibility(View.GONE);
                        ApplicationClass.hideSoftKeyboard(GroupChatActivity.this, recordView);
                        Toast.makeText(GroupChatActivity.this, getString(R.string.less_than_second), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onLessThanSecond() {
                    sendTypingStatus("untyping");
                    stopAudioViewHolder();
                    editLay.setVisibility(View.VISIBLE);
                    recordView.setVisibility(View.GONE);
                    ApplicationClass.hideSoftKeyboard(GroupChatActivity.this, recordView);
                    if (!checkAudioPermission()) {
                        makeToast(getString(R.string.audio_record_permission_error));
                    } else {
                        Toast.makeText(GroupChatActivity.this, getString(R.string.less_than_second), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    public boolean checkAudioPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return ContextCompat.checkSelfPermission(this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;

        } else
            return ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    public void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(this, PermissionsUtils.AUDIO_RECORD_V11_PERMISSION, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(this, PermissionsUtils.AUDIO_RECORD_PERMISSION, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
        }
    }

    private void startVoice() {
        if (visible) {
            TransitionManager.beginDelayedTransition(bottomLay);
            visible = !visible;
            attachmentsLay.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
        stopAudioViewHolder();
        editLay.setVisibility(View.GONE);
        recordView.setVisibility(View.VISIBLE);
        boolean permissionGranted = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissionGranted = ContextCompat.checkSelfPermission(this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        } else {
            permissionGranted = ContextCompat.checkSelfPermission(this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        if (permissionGranted) {
            if (isNetworkConnected().equals(NOT_CONNECT)) {
                networkSnack();
            } else {
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                    jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                    jsonObject.put("type", Constants.TAG_RECORDING);
                    socketConnection.groupTyping(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            MediaRecorderReady();
                            mediaRecorder.prepare();
                            mediaRecorder.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }, 350);
            }
        } else {
            requestAudioPermission();
        }
    }

    private void sendTypingStatus(String typingStatus) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_GROUP_ID, groupId);
            jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
            jsonObject.put("type", typingStatus);
            socketConnection.groupTyping(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void MediaRecorderReady() {
        if (mediaRecorder != null) {
            mediaRecorder.release();
            mediaRecorder = null;
        }
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        String fileName = (getString(R.string.app_name) + "_" + System.currentTimeMillis() + ".mp3").replaceAll(" ", "");
        File destDir = storageManager.createDirectory(StorageManager.TAG_AUDIO_SENT);
        recordVoicePath = new File(destDir, fileName).getAbsolutePath();
        mediaRecorder.setOutputFile(recordVoicePath);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        Log.v("onNetwork", "GroupChat=" + isConnected);
//        if (isConnected) {
//            online.setVisibility(View.VISIBLE);
//        } else {
//            online.setVisibility(View.GONE);
//        }
    }

    @Override
    public void backPressed() {
        if (selectedChatPos.size() > 0) {
            selectedChatPos.clear();
            messageListAdapter.notifyDataSetChanged();
            chatUserLay.setVisibility(View.VISIBLE);
            forwordLay.setVisibility(View.GONE);
            chatLongPressed = false;
        } else {
            if (isFromNotification) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            } else {
                finish();
            }
        }
    }

    private void playSound(int soundRes) {
        try {
            MediaPlayer player = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(soundRes);
            if (afd == null) return;
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.prepare();
            player.start();
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                }

            });
            player.setLooping(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<GroupMessage> getMessagesAry(List<GroupMessage> tmpList, GroupMessage lastData) {
        List<GroupMessage> msgList = new ArrayList<>();
        if (tmpList.size() == 0 && lastData != null) {
            GroupMessage groupMessage = new GroupMessage();
            groupMessage.messageType = "date";
            groupMessage.message = dateUtils.getChatDateFromUTC(lastData.chatTime);
            msgList.add(groupMessage);
        } else {
            for (int i = 0; i < tmpList.size(); i++) {
                Calendar cal1 = Calendar.getInstance();
                cal1.setTimeInMillis(dateUtils.getTimeInMillisFromUTC(tmpList.get(i).chatTime));
                Log.d(TAG, "getMessagesAry: " + (i + 1) + ", " + tmpList.size());
                if (i + 1 < tmpList.size()) {
                    Calendar cal2 = Calendar.getInstance();
                    cal2.setTimeInMillis(dateUtils.getTimeInMillisFromUTC(tmpList.get(i + 1).chatTime));

                    /*boolean sameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                            cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);*/

                    boolean sameDay = cal1.get(Calendar.DATE) == cal2.get(Calendar.DATE) &&
                            cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) &&
                            cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

                    msgList.add(tmpList.get(i));
                    if (!sameDay) {
                        GroupMessage groupMessage = new GroupMessage();
                        groupMessage.messageType = "date";
                        groupMessage.message = dateUtils.getChatDateFromUTC(tmpList.get(i).chatTime);
                        msgList.add(groupMessage);
                    }
                } else {
                    msgList.add(tmpList.get(i));
                }
            }
        }
        return msgList;
    }

    @Override
    public void onGroupChatReceive(final GroupMessage mdata) {
       Log.i(TAG, "onGroupChatReceive: " + new Gson().toJson(mdata));
//        Log.i(TAG, "onGroupChatReceive: " + new Gson().toJson(ApplicationClass.decryptMessage(mdata.message)));

        mdata.message = ApplicationClass.decryptMessage(mdata.message);
        mdata.attachment = ApplicationClass.decryptMessage(mdata.attachment);
        mdata.thumbnail = ApplicationClass.decryptMessage(mdata.thumbnail);
        mdata.lat = ApplicationClass.decryptMessage(mdata.lat);
        mdata.lon = ApplicationClass.decryptMessage(mdata.lon);
        mdata.contactName = ApplicationClass.decryptMessage(mdata.contactName);
        mdata.contactPhoneNo = ApplicationClass.decryptMessage(mdata.contactPhoneNo);
        mdata.contactCountryCode = ApplicationClass.decryptMessage(mdata.contactCountryCode);
        runOnUiThread(new Runnable() {
            public void run() {
                mSmartRepliesRecycler.setVisibility(View.GONE);
                if (mdata.groupId.equalsIgnoreCase(groupId)) {
                    GroupMessage groupMessage = mdata;
                    groupMessage = dbHelper.getGroupMessagesByType(dbHelper, GroupChatActivity.this, mdata);
                    switch (mdata.messageType) {
                        case Constants.TAG_TEXT: {
                            if (Constants.ADDON_CHAT_TRANSLATE && !TextUtils.isEmpty(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")) &&
                                    !pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equalsIgnoreCase(mContext.getString(R.string.none))) {
                                //Addon Chat Translate
                                Data.Builder builder = new Data.Builder();
                                builder.putString(Constants.TAG_MESSAGE, mdata.message);
                                final OneTimeWorkRequest translateWorkRequest = new OneTimeWorkRequest.Builder(ChatTranslateWorker.class)
                                        .setConstraints(new Constraints.Builder()
                                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                                .build())
                                        .setInputData(builder.build())
                                        .build();
                                final WorkManager workManager = WorkManager.getInstance(GroupChatActivity.this);
                                workManager.enqueue(translateWorkRequest);
                                new Handler(Looper.getMainLooper()).post(new Runnable() {
                                    public void run() {
                                        workManager.getWorkInfoByIdLiveData(translateWorkRequest.getId()).observe(GroupChatActivity.this, workInfo -> {
                                            if (workInfo.getState().isFinished()) {
                                                if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                                                    String translatedMsg = workInfo.getOutputData().getString(Constants.TAG_DATA);
                                                    mdata.message = translatedMsg;
                                                    String checkswitch=pref.getString("listencheck", "userPhone");
                                                    if (checkswitch.equals("yes")){
                                                        if (translatedMsg!=null){
                                                            t1.speak(translatedMsg, TextToSpeech.QUEUE_FLUSH, null);
                                                        }

                                                    }
                                                    if (mdata.messageId != null && !tempMessageIdList.contains(mdata.messageId)) {
                                                        insertNewMessage(mdata);
                                                    }
                                                }
                                            }
                                        });
                                    }
                                });
                            } else {
                                insertNewMessage(groupMessage);
                            }
                            if (Constants.ADDON_SMART_REPLY) {
                                setSmartReply(mdata, mdata.message);
                            }
                        }
                        break;
                        case Constants.TAG_IMAGE:
                        case Constants.TAG_GIF:
                        case Constants.TAG_VIDEO:
                        case StorageManager.TAG_DOCUMENT:
                        case Constants.TAG_LOCATION:
                        case "contact":
                        case "audio":
                        case "group_image":
                        case "subject":
                            insertNewMessage(groupMessage);
                            break;
                        case "admin":
                            if (groupMessage.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                                insertNewMessage(groupMessage);
                            }
                            break;
                        case "remove_member":
                        case "left":
                            messagesList.add(0, groupMessage);
                            showEncryptionText();
                            updatePosition();
                            notifyItemInserted(0);
                            if (mdata.memberId.equals(GetSet.getUserId())) {
                                bottomLay.setVisibility(View.GONE);
                                setNewMessageParams(View.GONE);
                            } else {
                                bottomLay.setVisibility(View.VISIBLE);
                                setNewMessageParams(View.VISIBLE);
                            }
                            setGroupMembers(groupId);
                            break;
                        case "add_member":
                        case Constants.TAG_GROUP_JOINED:
                            messagesList.add(0, groupMessage);
                            updatePosition();
                            showEncryptionText();
                            notifyItemInserted(0);
                            try {
                                JSONArray jsonArray = new JSONArray(mdata.attachment);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    if (jsonObject.getString(TAG_MEMBER_ID).equals(GetSet.getUserId())) {
                                        bottomLay.setVisibility(View.VISIBLE);
                                        setNewMessageParams(View.VISIBLE);
                                        setGroupMembers(groupId);
                                        recyclerView.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                recyclerView.scrollToPosition(0);
                                            }
                                        });
                                        break;
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            break;
                        case Constants.TAG_ISDELETE: {
                            int index = 0;
                            for (GroupMessage data : messagesList) {
                                if (mdata.messageId != null && data.messageId != null) {
                                    if (data.messageId.equals(mdata.messageId)) {
                                        Log.d(TAG, "onGroupChatReceive: " + index);
                                        data.messageType = mdata.messageType;
                                        messageListAdapter.notifyItemChanged(index);
                                        break;
                                    }
                                }
                                index++;
                            }
                        }
                        break;
                    }
                    setGroupMembers(groupId);
                    whileViewChat();
                }
            }
        });
    }

    private void setSmartReply(GroupMessage mdata, String message) {
        if (mdata.messageType.equals(Constants.TAG_TEXT)) {
//            Log.d(TAG, "setSmartReply: " + mdata.memberId);
            if (mdata.groupId.equals(groupId)) {
                generateReplies(message);
            }
        } else {
            mSmartRepliesRecycler.setVisibility(View.GONE);
        }
    }

    private void notifyItemInserted(int position) {
        messageListAdapter.notifyItemInserted(position);
        recyclerView.post(new Runnable() {
            @Override
            public void run() {
                recyclerView.smoothScrollToPosition(position);
            }
        });
    }

    @Override
    public void onGroupCreated(JSONObject data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                bottomLay.setVisibility(View.VISIBLE);
                setNewMessageParams(View.VISIBLE);
                int currentCount = dbHelper.getGroupMessagesCount(groupId);
                if (currentCount > totalMsg) {
                    setGroupMembers(groupId);
                    messagesList.clear();
                    if (endlessRecyclerOnScrollListener != null) {
                        endlessRecyclerOnScrollListener.resetState();
                    }
                    messagesList.addAll(getMessagesAry(dbHelper.getGroupMessages(groupId, "0", "20", GroupChatActivity.this), null));
                    showEncryptionText();
                    messageListAdapter.notifyDataSetChanged();
                    whileViewChat();
                }
            }
        });
    }

    private void insertNewMessage(GroupMessage groupMessage) {
        if (groupMessage.messageId != null && !tempMessageIdList.contains(groupMessage.messageId)) {
            tempMessageIdList.add(groupMessage.messageId);
            if (isFirstItemVisible()) {
                messagesList.add(0, groupMessage);
                notifyItemInserted(0);
                iconNewMessage.setVisibility(View.GONE);
            } else {
                messagesList.add(0, groupMessage);
                messageListAdapter.notifyItemInserted(0);
                iconNewMessage.setVisibility(View.VISIBLE);
            }
            updatePosition();
            showEncryptionText();
            groupData = dbHelper.getGroupData(GroupChatActivity.this, groupId);
            username.setText(groupData.groupName);
            Glide.with(getApplicationContext()).load(Constants.CHAT_IMG_PATH + groupData.groupImage)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .into(userimage);
        }
    }

    private void makeAdmin(String groupId) {
        GroupData groupData = dbHelper.getGroupData(getApplicationContext(), groupId);
        if (dbHelper.isGroupHaveAdmin(groupData.groupId) == 1 && groupData.groupAdminId.equalsIgnoreCase(GetSet.getUserId())) {
            List<GroupData.GroupMembers> membersData = dbHelper.getNotGroupMembers(getApplicationContext(), groupData.groupId);
            for (GroupData.GroupMembers groupMember : membersData) {
                if (!groupMember.memberId.equals(GetSet.getUserId())) {
                    JSONArray jsonArray = new JSONArray();
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put(TAG_MEMBER_ID, groupMember.memberId);
                        jsonObject.put(TAG_MEMBER_ROLE, ADMIN);
                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
                    RandomString randomString = new RandomString(10);
                    String messageId = groupId + randomString.nextString();

                    JSONObject message = new JSONObject();
                    try {
                        message.put(Constants.TAG_GROUP_ADMIN_ID, groupMember.memberId);
                        message.put(Constants.TAG_GROUP_ID, groupId);
                        message.put(Constants.TAG_GROUP_NAME, groupData.groupName);
                        message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                        message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                        message.put(Constants.TAG_MESSAGE_ID, messageId);
                        message.put(Constants.TAG_ATTACHMENT, Constants.ADMIN);
                        message.put(Constants.TAG_MEMBER_ID, groupMember.memberId);
                        message.put(Constants.TAG_MEMBER_NAME, groupMember.memberName);
                        message.put(Constants.TAG_MEMBER_NO, groupMember.memberNo);
                        message.put(Constants.TAG_MESSAGE_TYPE, "admin");
                        message.put(Constants.TAG_MESSAGE, "Admin");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    socketConnection.messageToGroup(message);
                    updateGroupData(jsonArray);
                    break;
                }
            }
        }
    }

    private void updateGroupData(JSONArray jsonArray) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GroupUpdateResult> call3 = apiInterface.updateGroup(GetSet.getToken(), groupId, jsonArray);
        call3.enqueue(new Callback<GroupUpdateResult>() {
            @Override
            public void onResponse(Call<GroupUpdateResult> call, Response<GroupUpdateResult> response) {
                try {
                    Log.i(TAG, "updateGroup: " + new Gson().toJson(response.body()));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<GroupUpdateResult> call, Throwable t) {
                Log.e(TAG, "updateGroup: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void whileViewChat() {
        dbHelper.resetUnseenGroupMessagesCount(groupId);
        dbHelper.updateGroupMessageReadStatus(groupId);
    }

    @Override
    public void onListenGroupTyping(final JSONObject data) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (dbHelper.isMemberExist(GetSet.getUserId(), groupId)) {
                    try {
                        Log.e(TAG, "onListenGroupTyping: " + data.toString());
                        String memberId = data.getString(Constants.TAG_MEMBER_ID);
                        String group_id = data.getString(Constants.TAG_GROUP_ID);
                        if (!memberId.equalsIgnoreCase(GetSet.getUserId()) &&
                                group_id.equalsIgnoreCase(groupId)) {
                            ContactsData.Result result = dbHelper.getContactDetail(memberId);
                            if (data.get("type").equals("typing")) {
                                txtMembers.setText(ApplicationClass.getContactName(GroupChatActivity.this, result.phone_no, result.country_code) + " is " + getString(R.string.typing));
                            } else if (data.get("type").equals(Constants.TAG_RECORDING)) {
                                txtMembers.setText(ApplicationClass.getContactName(GroupChatActivity.this, result.phone_no, result.country_code) + " is " + getString(R.string.recording));
                            }

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            setGroupMembers(groupId);
                        }
                    }, 1000);
                }
            }
        });
    }

    @Override
    public void onMemberExited(final JSONObject data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    setGroupMembers(data.getString(Constants.TAG_GROUP_ID));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public void onUploadListen(final String message_id, final String attachment, final String progress) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < messagesList.size(); i++) {
                    if (message_id.equals(messagesList.get(i).messageId)) {
                        Log.v("checkChat", "onPostExecute");
                        messagesList.get(i).attachment = attachment;
                        messagesList.get(i).progress = progress;
                        messageListAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
    }

    @Override
    public void onGetUpdateFromDB() {
        int currentCount = dbHelper.getGroupMessagesCount(groupId);
        if (totalMsg != currentCount) {
            updateMessagesFromDB(currentCount);
        }
    }

    private void updateMessagesFromDB(int currentCount) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messagesList.clear();
                if (endlessRecyclerOnScrollListener != null) {
                    endlessRecyclerOnScrollListener.resetState();
                }
                messagesList.addAll(getMessagesAry(dbHelper.getGroupMessages(groupId, "0", "20", GroupChatActivity.this), null));
                totalMsg = currentCount;
                showEncryptionText();
                messageListAdapter.notifyDataSetChanged();
                whileViewChat();
            }
        });
    }

    @Override
    public void onUpdateGroupInfo(GroupMessage groupMessage) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (GroupChatActivity.this.groupId.equals(groupMessage.groupId)) {
                    switch (groupMessage.messageType) {
                        case "group_image":
                        case "subject":
                            groupData = dbHelper.getGroupData(GroupChatActivity.this, groupMessage.groupId);
                            username.setText(groupData.groupName);
                            Glide.with(GroupChatActivity.this).load(Constants.CHAT_IMG_PATH + groupData.groupImage)
                                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                                    .into(userimage);
                            break;
                        case "remove_member":
                        case "left":
                            if (groupMessage.memberId.equals(GetSet.getUserId())) {
                                bottomLay.setVisibility(View.GONE);
                                setNewMessageParams(View.GONE);
                            } else {
                                bottomLay.setVisibility(View.VISIBLE);
                                setNewMessageParams(View.VISIBLE);
                            }
                            setGroupMembers(groupMessage.groupId);
                            break;
                        case "add_member":
                        case Constants.TAG_GROUP_JOINED:
                            try {
                                JSONArray jsonArray = new JSONArray(groupMessage.attachment);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    if (jsonObject.getString(TAG_MEMBER_ID).equals(GetSet.getUserId())) {
                                        bottomLay.setVisibility(View.VISIBLE);
                                        setNewMessageParams(View.VISIBLE);
                                        setGroupMembers(groupMessage.groupId);
                                        recyclerView.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                recyclerView.scrollToPosition(0);
                                            }
                                        });
                                        break;
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            break;
                    }
                }
            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length() > 0) {
            send.setVisibility(View.VISIBLE);
            recordButton.setVisibility(View.GONE);
        } else {
            send.setVisibility(View.GONE);
            recordButton.setVisibility(View.VISIBLE);
        }
        if (runnable != null)
            handler.removeCallbacks(runnable);
        if (!meTyping) {
            meTyping = true;
        }
        sendTypingStatus("typing");
    }

    @Override
    public void afterTextChanged(Editable editable) {
        runnable = new Runnable() {
            public void run() {
                meTyping = false;
                sendTypingStatus("untyping");
            }
        };
        handler.postDelayed(runnable, 500);
    }

    @Override
    public void deleteType(String type) {
        for (int i = 0; i < selectedChatPos.size(); i++) {
            GroupMessage mData = selectedChatPos.get(i);
            if (type.equals("me")) {
                if (currentMessageId != null && currentMessageId.equals(mData.messageId)) {
                    currentMessageId = null;
                }
                dbHelper.deleteGroupMessageFromId(mData.messageId);
                messagesList.remove(mData);
                messageListAdapter.notifyDataSetChanged();
            } else {
                String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                    jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                    jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                    jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                    jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                    jsonObject.put(Constants.TAG_MESSAGE_ID, mData.messageId);
                    jsonObject.put(Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                    jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(getString(R.string.this_message_was_deleted)));
                    jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);

                    socketConnection.messageToGroup(jsonObject);

                    mData.messageType = Constants.TAG_ISDELETE;
                    mData.isDelete = "1";
                    messageListAdapter.notifyItemChanged(messagesList.indexOf(mData));
                    dbHelper.updateGroupMessageData(mData.messageId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);

                    whileViewChat();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            // Toast.makeText(GroupChatActivity.this, getString(R.string.message_deleted), Toast.LENGTH_SHORT).show();
        }
        if (type.equals("me")) {
            if (messagesList.isEmpty()) {
                dbHelper.deleteRecentChat(groupId);
            } else {
                GroupMessage data = messagesList.get(0);
                dbHelper.addGroupRecentMsg(groupId, data.messageId, GetSet.getUserId(), data.chatTime, "0");
            }
        }
        showEncryptionText();
        selectedChatPos.clear();
        chatUserLay.setVisibility(View.VISIBLE);
        forwordLay.setVisibility(View.GONE);
        chatLongPressed = false;
    }

    private String milliSecondsToTimer(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        // Add hours if there
        if (hours > 0) {
            finalTimerString = hours + ":";
        }

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }

        finalTimerString = finalTimerString + minutes + ":" + secondsString;

        // return timer string
        return finalTimerString;
    }

    private void stopMediaPlayer() {
        MediaPlayerUtils.releaseMediaPlayer();
    }

    void stopAudioViewHolder() {
        MediaPlayerUtils.pauseMediaPlayer();
        if (currentMessageId != null) {
            GroupMessage tempMsgData = dbHelper.getSingleGroupMessage(groupId, currentMessageId);
            int tempPosition = -1;
            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                messageListAdapter.notifyItemChanged(tempPosition);
                /*RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, ApplicationClass.decryptMessage(tempMsgData.attachment), TAG_AUDIO);
                    if (file != null) {
                        holder.duration.setVisibility(View.VISIBLE);
                        holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                    } else {
                        holder.duration.setVisibility(View.INVISIBLE);
                    }
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        Uri fileUri = storageManager.getUriFromFile(file);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    }
                }*/
            }
        }
    }

    private void setSectionMessage(Context mContext, GroupMessage message, TextView timeText) {
//        Log.i(TAG, "setSectionMessage: " + message.message);
        timeText.setText(message.message);
        if (message.messageType.equalsIgnoreCase("change_number")) {

            timeText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), message.contactPhoneNo);
                    if (map.get("isAlready").equals("false")) {
                        showAlertDialog(message);
                    } else {
                        makeToast(getString(R.string.contact_already_exists));
                    }
                }
            });
        } else {
            timeText.setOnClickListener(null);
        }
    }

    public RecyclerItemClickListener chatItemClick(Context mContext, final RecyclerView recyclerView) {
        return new RecyclerItemClickListener(mContext, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if (chatLongPressed) {
                    int chatType = recyclerView.getAdapter().getItemViewType(position);
                    if (chatType != VIEW_TYPE_DATE /*&& !messagesList.get(position).messageType.equals(Constants.TAG_ISDELETE)*/) {
                        if (selectedChatPos.contains(messagesList.get(position))) {
                            selectedChatPos.remove(messagesList.get(position));
                        } else {
                            selectedChatPos.add(messagesList.get(position));
                        }

                        messageListAdapter.notifyItemChanged(position);
                    }

                    for (GroupMessage messagesData : selectedChatPos) {
                        if (!isForwardable(messagesData)) {
                            forwordBtn.setVisibility(View.GONE);
                            break;
                        } else {
                            forwordBtn.setVisibility(View.VISIBLE);
                        }
                    }

                    if (selectedChatPos.isEmpty()) {
                        chatLongPressed = false;
                        chatUserLay.setVisibility(View.VISIBLE);
                        forwordLay.setVisibility(View.GONE);
                        copyBtn.setVisibility(View.GONE);
                    } else {
                        setCopyBtnVisibility();
                    }
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {
                if (!chatLongPressed && !isRecording) {
                    if (currentMessageId != null && currentMessageId.equals(messagesList.get(position))) {
                        if (MediaPlayerUtils.isPlaying()) MediaPlayerUtils.pauseMediaPlayer();
                    }
                    if (recyclerView.getAdapter().getItemViewType(position) != VIEW_TYPE_DATE
                        /*&& !messagesList.get(position).messageType.equals(Constants.TAG_ISDELETE)*/) {
                        chatLongPressed = true;
                        selectedChatPos.add(messagesList.get(position));
                        chatUserLay.setVisibility(View.GONE);
                        forwordLay.setVisibility(View.VISIBLE);
                        if (isForwardable(messagesList.get(position))) {
                            forwordBtn.setVisibility(View.VISIBLE);
                        } else {
                            forwordBtn.setVisibility(View.GONE);
                        }
                        messageListAdapter.notifyItemChanged(position);
                        setCopyBtnVisibility();
                    }
                }
            }
        });
    }

    private void setCopyBtnVisibility() {
        if (selectedChatPos.size() > 0) {
            for (GroupMessage message : selectedChatPos) {
                if (!message.messageType.equals("text") && !message.messageType.equals("link")) {
                    copyBtn.setVisibility(View.GONE);
                    break;
                } else {
                    copyBtn.setVisibility(View.VISIBLE);
                }
            }
        } else {
            copyBtn.setVisibility(View.GONE);
        }
    }

    public void showAlertDialog(GroupMessage message) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.do_you_want_to_add_contact);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                intent.putExtra(ContactsContract.Intents.Insert.PHONE, message.contactPhoneNo);
                intent.putExtra(ContactsContract.Intents.Insert.NAME, message.contactName);
                startActivity(intent);
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private boolean isForwardable(GroupMessage mData) {
        switch (mData.messageType) {
            case Constants.TAG_ISDELETE:
                return false;
            case Constants.TAG_VIDEO:
            case Constants.TAG_DOCUMENT:
            case Constants.TAG_AUDIO:
            case Constants.TAG_IMAGE:
                if (mData.memberId.equals(GetSet.getUserId()) && !mData.progress.equals("completed")) {
                    return false;
                } else {
                    if (mData.progress == null) {
                        return false;
                    } else {
                        return mData.memberId.equals(GetSet.getUserId()) || storageManager.checkFileExists(mData.attachment, mData.messageType);
                    }
                }
            default:
                return true;
        }
    }

    private void emitImage(GroupMessage mdata, String imageUrl) {
        if (socketConnection.getMSocket().connected()) {
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                jsonObject.put(Constants.TAG_MESSAGE_ID, mdata.messageId);
                jsonObject.put(Constants.TAG_MESSAGE_TYPE, mdata.messageType);
                jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
                jsonObject.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(imageUrl));
                jsonObject.put(Constants.TAG_CHAT_TIME, mdata.chatTime);
                Log.i(TAG, "emitImage: " + jsonObject);
                socketConnection.messageToGroup(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }

    }

    private void emitLocation(String type, String lat, String lon) {
        if (socketConnection.getMSocket().connected()) {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            RandomString randomString = new RandomString(10);
            String messageId = groupId + randomString.nextString();
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                jsonObject.put(Constants.TAG_MESSAGE_ID, messageId);
                jsonObject.put(Constants.TAG_MESSAGE_TYPE, type);
                jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(getString(R.string.location)));
                jsonObject.put(Constants.TAG_LAT, ApplicationClass.encryptMessage(lat));
                jsonObject.put(Constants.TAG_LON, ApplicationClass.encryptMessage(lon));
                jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                socketConnection.messageToGroup(jsonObject);

                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "", type,
                        getString(R.string.location), "", ApplicationClass.encryptMessage(lat), ApplicationClass.encryptMessage(lon),
                        "", "", "",
                        currentUTCTime, "", "read");

                dbHelper.addGroupRecentMsg(groupId, messageId, GetSet.getUserId(), currentUTCTime, "0");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            GroupMessage data = new GroupMessage();
            data.messageId = messageId;
            data.groupId = groupId;
            data.memberId = GetSet.getUserId();
            data.messageType = type;
            data.message = getString(R.string.location);
            data.lat = lat;
            data.lon = lon;
            data.chatTime = currentUTCTime;
            data.deliveryStatus = "";
            messagesList.add(0, data);
            updatePosition();
            showEncryptionText();
            notifyItemInserted(0);
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    public String firstThree(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        return str.length() < 3 ? str : str.substring(0, 3);
    }

    private void emitContact(String type, String name, String phone, String countrycode) {
        if (socketConnection.getMSocket().connected()) {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            RandomString randomString = new RandomString(10);
            String messageId = groupId + randomString.nextString();
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                jsonObject.put(Constants.TAG_MESSAGE_ID, messageId);
                jsonObject.put(Constants.TAG_MESSAGE_TYPE, type);
                jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(getString(R.string.contact)));
                jsonObject.put(Constants.TAG_CONTACT_NAME, ApplicationClass.encryptMessage(name));
                jsonObject.put(Constants.TAG_CONTACT_PHONE_NO, ApplicationClass.encryptMessage(phone));
                jsonObject.put(Constants.TAG_CONTACT_COUNTRY_CODE, ApplicationClass.encryptMessage(countrycode));
                jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);

                socketConnection.messageToGroup(jsonObject);

                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "", type,
                        ApplicationClass.encryptMessage(getString(R.string.contact)), "", "", "", ApplicationClass.encryptMessage(name),
                        ApplicationClass.encryptMessage(phone), ApplicationClass.encryptMessage(countrycode), currentUTCTime, "", "read");

                dbHelper.addGroupRecentMsg(groupId, messageId, GetSet.getUserId(), currentUTCTime, "0");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            GroupMessage data = new GroupMessage();
            data.memberId = GetSet.getUserId();
            data.messageType = type;
            data.message = getString(R.string.contact);
            data.contactName = name;
            data.contactPhoneNo = phone;
            data.contactCountryCode = countrycode;
            data.messageId = messageId;
            data.chatTime = currentUTCTime;
            data.deliveryStatus = "";
            messagesList.add(0, data);
            updatePosition();
            showEncryptionText();
            notifyItemInserted(0);
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    private void deleteChatConfirmDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_delete_chat_history);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                currentMessageId = null;
                totalMsg = 0;
                stopMediaPlayer();
                dbHelper.deleteGroupMessages(groupId);
                messagesList.clear();
                messageListAdapter.notifyDataSetChanged();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void openDeleteDialog() {
        boolean canEveryOneVisible = true;
        Dialog deleteDialog = new Dialog(GroupChatActivity.this);
        deleteDialog.setCancelable(true);
        if (deleteDialog.getWindow() != null) {
            deleteDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
            deleteDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        deleteDialog.setContentView(R.layout.dialog_report);

        RecyclerView deleteRecyclerView = deleteDialog.findViewById(R.id.reportRecyclerView);

        List<String> deleteTexts = new ArrayList<>();

        for (GroupMessage message : selectedChatPos) {
            if (dateUtils.isExceedsOneHour(message.chatTime) ||
                    !message.memberId.equalsIgnoreCase(GetSet.getUserId()) ||
                    message.messageType.equalsIgnoreCase(Constants.TAG_ISDELETE)) {
                canEveryOneVisible = false;
                break;
            }
        }

        deleteTexts.add(getString(R.string.delete_for_me));
        deleteTexts.add(getString(R.string.cancel));

        if (canEveryOneVisible) {
            deleteTexts.add(getString(R.string.delete_for_everyone));
            LinearLayoutManager layoutManager = new LinearLayoutManager(GroupChatActivity.this, RecyclerView.VERTICAL, false);
            deleteRecyclerView.setLayoutManager(layoutManager);
        } else {
            GridLayoutManager layoutManager = new GridLayoutManager(GroupChatActivity.this, 2);
            deleteRecyclerView.setLayoutManager(layoutManager);
        }
        DeleteAdapter adapter = new DeleteAdapter(deleteTexts, deleteDialog, GroupChatActivity.this);
        deleteRecyclerView.setAdapter(adapter);

        deleteDialog.show();
    }

    private void deleteMessageConfirmDialog(GroupMessage mData) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_delete_msg);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                dbHelper.deleteGroupMessageFromId(mData.messageId);
                messagesList.remove(mData);
                Toast.makeText(GroupChatActivity.this, getString(R.string.message_deleted), Toast.LENGTH_SHORT).show();
                selectedChatPos.clear();
                messageListAdapter.notifyDataSetChanged();
                chatUserLay.setVisibility(View.VISIBLE);
                forwordLay.setVisibility(View.GONE);
                chatLongPressed = false;
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void exitConfirmDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_exit_group);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                if (dbHelper.isGroupHaveAdmin(groupId) == 1) {
                    GroupData.GroupMembers memberData = dbHelper.getAdminFromMembers(groupId);
                    if (memberData.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                        for (GroupData.GroupMembers members : dbHelper.getNotGroupMembers(getApplicationContext(), groupId)) {
                            if (!members.memberId.equals(GetSet.getUserId())) {
                                JSONArray jsonArray = new JSONArray();
                                try {
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put(TAG_MEMBER_ID, members.memberId);
                                    jsonObject.put(TAG_MEMBER_ROLE, ADMIN);
                                    jsonArray.put(jsonObject);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                                    RandomString randomString = new RandomString(10);
                                    String messageId = groupId + randomString.nextString();

                                    JSONObject message = new JSONObject();
                                    message.put(Constants.TAG_GROUP_ID, groupId);
                                    message.put(Constants.TAG_GROUP_NAME, groupName);
                                    message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                                    message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                                    message.put(Constants.TAG_MESSAGE_ID, messageId);
                                    message.put(Constants.TAG_ATTACHMENT, "1");
                                    message.put(Constants.TAG_MEMBER_ID, members.memberId);
                                    message.put(Constants.TAG_MEMBER_NAME, "");
                                    message.put(Constants.TAG_MEMBER_NO, members.memberNo);
                                    message.put(Constants.TAG_MESSAGE_TYPE, "admin");
                                    message.put(Constants.TAG_MESSAGE, getString(R.string.admin));
                                    message.put(Constants.TAG_GROUP_ADMIN_ID, GetSet.getUserId());
                                    socketConnection.messageToGroup(message);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                updateGroupData(jsonArray);
                                break;
                            }
                        }
                    }
                }

                try {
                    String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                    RandomString randomString = new RandomString(10);
                    String messageId = groupId + randomString.nextString();

                    JSONObject message = new JSONObject();
                    message.put(Constants.TAG_GROUP_ID, groupId);
                    message.put(Constants.TAG_GROUP_NAME, groupName);
                    message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                    message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                    message.put(Constants.TAG_MESSAGE_ID, messageId);
                    message.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                    message.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                    message.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                    message.put(Constants.TAG_MESSAGE_TYPE, "left");
                    message.put(Constants.TAG_MESSAGE, getString(R.string.one_participant_left));
                    message.put(Constants.TAG_GROUP_ADMIN_ID, groupData.groupAdminId);
                    socketConnection.messageToGroup(message);

                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(TAG_GROUP_ID, groupId);
                    jsonObject.put(TAG_MEMBER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_MESSAGE, message);
                    socketConnection.exitFromGroup(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                bottomLay.setVisibility(View.GONE);
                setNewMessageParams(View.GONE);
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void uploadImage(byte[] imageBytes, final Uri imageUri, final String imagePath, final GroupMessage mdata) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("group_attachment", "openImage.jpg", requestFile);

        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call3 = apiInterface.upMyGroupChat(GetSet.getToken(), body, userid);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                if (data.get(Constants.TAG_STATUS).equals(TAG_TRUE)) {
                    if (mdata.messageType.equals(Constants.TAG_IMAGE)) {
                        String apiFileName = data.get(Constants.TAG_USER_IMAGE);
                        boolean isFileMoved = storageManager.renameFile(imageUri, imagePath, apiFileName, Constants.TAG_IMAGE);
                        if (isFileMoved) {
                            dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                            dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_PROGRESS, "completed");
                        }
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                                    messagesList.get(i).progress = "completed";
                                    messagesList.get(i).attachment = apiFileName;
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }
                        emitImage(mdata, apiFileName);
                    }
                } else {
                    dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_PROGRESS, "error");
                    if (messageListAdapter != null) {
                        for (int i = 0; i < messagesList.size(); i++) {
                            if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                                messagesList.get(i).progress = "error";
                                messageListAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.v(TAG, "onFailure=" + "onFailure");
                call.cancel();
            }
        });
    }

    private void uploadVideoThumbnail(byte[] imageBytes, final Uri imageUri, final String imagePath,
                                      final GroupMessage mdata, final Uri videoUri, final String videoPath) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("attachment", "openImage.jpg", requestFile);

        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call3 = apiInterface.upMyChat(GetSet.getToken(), body, userid);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                if (response.isSuccessful()) {
                    if (data.get(Constants.TAG_STATUS).equals("true")) {
                        String apiFileName = data.get(Constants.TAG_USER_IMAGE);
                        boolean isFileMoved = storageManager.renameFile(imageUri, imagePath, apiFileName, TAG_IMAGE);
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                                    messagesList.get(i).thumbnail = apiFileName;
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }

                        Intent service = new Intent(GroupChatActivity.this, FileUploadService.class);
                        Bundle b = new Bundle();
                        b.putSerializable("mdata", mdata);
                        b.putString(Constants.TAG_THUMBNAIL, apiFileName);
                        b.putString("filepath", videoPath);
                        b.putString("chatType", "group");
                        service.putExtras(b);
                        startService(service);
                    } else {
                        dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_PROGRESS, "error");
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                                    messagesList.get(i).progress = "error";
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_PROGRESS, "error");
                    if (messageListAdapter != null) {
                        for (int i = 0; i < messagesList.size(); i++) {
                            if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                                messagesList.get(i).progress = "error";
                                messageListAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "uploadImage: " + t.getMessage());
                call.cancel();
                dbHelper.updateGroupMessageData(mdata.messageId, Constants.TAG_PROGRESS, "error");
                if (messageListAdapter != null) {
                    for (int i = 0; i < messagesList.size(); i++) {
                        if (mdata.messageId.equals(messagesList.get(i).messageId)) {
                            messagesList.get(i).progress = "error";
                            messageListAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private GroupMessage updateDBList(String type, Uri fileUri, Uri thumbUri, String filePath, String thumbPath) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = groupId + randomString.nextString();

        String msg = "";
        switch (type) {
            case Constants.TAG_IMAGE:
                msg = getString(R.string.image);
                break;
            case "audio":
//                msg = getFileName(filePath);
                msg = getString(R.string.audio);
                break;
            case Constants.TAG_VIDEO:
                msg = getString(R.string.video);
                break;
            case Constants.TAG_GIF:
                msg = getString(R.string.gif);
                break;
            case Constants.TAG_DOCUMENT:
//                msg = getFileName(filePath);
                msg = getString(R.string.document);
                break;
        }

        GroupMessage groupMessage = new GroupMessage();
        groupMessage.groupId = groupId;
        groupMessage.groupName = groupName;
        groupMessage.memberId = GetSet.getUserId();
        groupMessage.memberName = GetSet.getUserName();
        groupMessage.memberNo = GetSet.getphonenumber();
        groupMessage.messageType = type;
        groupMessage.message = msg;
        groupMessage.messageId = messageId;
        groupMessage.chatTime = currentUTCTime;
        groupMessage.deliveryStatus = "";
        groupMessage.progress = "";

        switch (type) {
            case Constants.TAG_VIDEO:
                groupMessage.thumbnail = thumbUri != null ? "" + thumbUri.getLastPathSegment() : thumbPath;
                groupMessage.attachment = fileUri != null ? "" + fileUri.getLastPathSegment() : filePath;
                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "",
                        type, ApplicationClass.encryptMessage(msg), ApplicationClass.encryptMessage(groupMessage.attachment), "", "", "", "",
                        "", currentUTCTime, ApplicationClass.encryptMessage(groupMessage.thumbnail), "read");
                break;
            case Constants.TAG_IMAGE:
            case Constants.TAG_GIF:
                groupMessage.thumbnail = "";
                groupMessage.attachment = fileUri != null ? fileUri.getLastPathSegment() : filePath;
                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "",
                        type, ApplicationClass.encryptMessage(msg), ApplicationClass.encryptMessage(groupMessage.attachment), "", "", "", "",
                        "", currentUTCTime, "", "read");
                break;
            default:
                groupMessage.thumbnail = "";
                groupMessage.attachment = fileUri != null ? "" + fileUri.getLastPathSegment() : filePath;
                ;
                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "",
                        type, ApplicationClass.encryptMessage(msg), ApplicationClass.encryptMessage(groupMessage.attachment), "", "", "", "",
                        "", currentUTCTime, "", "read");
                break;
        }

        dbHelper.addGroupRecentMsg(groupId, messageId, GetSet.getUserId(), currentUTCTime, "0");

        messagesList.add(0, groupMessage);
        updatePosition();
        showEncryptionText();
        notifyItemInserted(0);

        return groupMessage;
    }

    private String getFileName(String url) {
        String imgSplit = url;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1);
        }
        return imgSplit;
    }

    /**
     * Function for Sent a message to Socket
     */

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE) {
            int permissionContacts = ContextCompat.checkSelfPermission(GroupChatActivity.this,
                    READ_CONTACTS);

            if (permissionContacts == PackageManager.PERMISSION_GRANTED) {
                contactBtn.performClick();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
                        requestPermission(new String[]{READ_CONTACTS}, PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.contact_permission_error));
                    }
                } else {
                    makeToast(getString(R.string.contact_permission_error));
                }
            }
        } else if (requestCode == PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE) {
            int permissionAudio = ContextCompat.checkSelfPermission(GroupChatActivity.this,
                    RECORD_AUDIO);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (permissionAudio != PackageManager.PERMISSION_GRANTED) {
                    if (shouldShowRequestPermissionRationale(RECORD_AUDIO)) {
                        requestPermission(new String[]{RECORD_AUDIO}, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.audio_record_permission_error));
                    }
                }
            } else {
                int permissionStorage = ContextCompat.checkSelfPermission(GroupChatActivity.this,
                        WRITE_EXTERNAL_STORAGE);
                if (permissionAudio != PackageManager.PERMISSION_GRANTED ||
                        permissionStorage != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(GroupChatActivity.this, RECORD_AUDIO) ||
                            ActivityCompat.shouldShowRequestPermissionRationale(GroupChatActivity.this, WRITE_EXTERNAL_STORAGE)) {
                        requestPermission(new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.audio_record_permission_error));
                    }
                }
            }
            setVoiceRecorder();
        }
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1 && requestCode == Constants.CAMERA_REQUEST_CODE) {
            if (isNetworkConnected().equals(NOT_CONNECT)) {
                networkSnack();
            } else {
                String filePath = null;
                Uri fileUri = null;
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        fileUri = photoURI;
                    } else {
                        filePath = ImagePicker.getImagePathFromResult(this, requestCode, resultCode, data);
                    }
                    BitmapCompression imageCompression = new BitmapCompression(mContext, fileUri, filePath) {
                        @Override
                        protected void onPostExecute(Bitmap compressedBitmap) {
                            String fileName = System.currentTimeMillis() + ".jpg";
                            String savedPath = null;
                            savedPath = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();
                            GroupMessage mdata = updateDBList(Constants.TAG_IMAGE, null, null, savedPath, "");
                            byte[] bytes = StorageManager.bitmapToByteArray(compressedBitmap);
                            uploadImage(bytes, null, savedPath, mdata);
                            saveFileInGallery(new File(savedPath), StorageManager.TAG_IMAGE, StorageManager.TAG_IMAGE);
                        }
                    };
                    imageCompression.execute();
                }
            }
        }
    }

    public String getMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = this.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        Log.d(TAG, "getMimeType: " + mimeType);
        return mimeType;
    }

    private void takeCameraPictures() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dispatchTakePictureIntent();
        } else {
            ImagePicker.pickImageCameraOnly(this, Constants.CAMERA_REQUEST_CODE);
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, Constants.CAMERA_REQUEST_CODE);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        // Save a file: path for use with ACTION_VIEW intents
        return image;
    }

    private void saveFileInGallery(File srcFile, String from, String fileType) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String fileName = mContext.getString(R.string.app_name) + "_" + (System.currentTimeMillis() / 1000) + "." + FilenameUtils.getExtension(srcFile.getName());
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    storageManager.saveFileInStorageV10(srcFile, fileName, from, fileType);
                } else {
                    storageManager.saveFileInGallery(srcFile, fileName, from);
                }
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(NewGroupMessageEvent event) {
        if (event != null && event.getGroupMessage() != null) {
            Log.d(TAG, "onMessageEvent: ");
            onGroupChatReceive(event.getGroupMessage());
        }
        totalMsg = dbHelper.getGroupMessagesCount(groupId);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getDisplayWidthHeight();
        SocketConnection.getInstance(this).setOnGroupCreatedListener(this);
        SocketConnection.getInstance(this).setGroupChatCallbackListener(this);
        if (getIntent().getStringExtra(TAG_GROUP_ID) != null) {
            groupId = getIntent().getStringExtra(TAG_GROUP_ID);
            getNewMessages();
        }
        tempGroupId = groupId;
        if (dbHelper.getGroupData(this, groupId) != null) {
            groupData = dbHelper.getGroupData(this, groupId);
            groupName = groupData.groupName;
            username.setText(groupData.groupName);
            Glide.with(GroupChatActivity.this).load(Constants.CHAT_IMG_PATH + groupData.groupImage)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.create_group).error(R.drawable.create_group))
                    .into(userimage);
            setGroupMembers(groupId);
        } else {
            finish();
        }
        ApplicationClass.onShareExternal = false;
        if(!pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none)) ||!pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("")){
            messageListAdapter.notifyDataSetChanged();
        }

        t1 = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result=0;
//                    Toast.makeText(mContext, pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""), Toast.LENGTH_SHORT).show();
                    if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").isEmpty()){
                        result = t1.setLanguage(Locale.getDefault());
                    }else{
                        if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")!=null){
                            result = t1.setLanguage(new Locale(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")));
                        }else{
                            result = t1.setLanguage(Locale.getDefault());
                        }

                    }
//
//                    if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("it")){
//                        result = t1.setLanguage(Locale.ITALIAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh") ||  pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh-CN")){
//                        result = t1.setLanguage(new Locale("zh-rCN"));
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh-TW")){
//                        result = t1.setLanguage(new Locale("zh-rTW"));
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("en")){
//                        result = t1.setLanguage(Locale.ENGLISH);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("fr")){
//                        result = t1.setLanguage(Locale.FRENCH);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("de")){
//                        result = t1.setLanguage(Locale.GERMAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("ja")){
//                        result = t1.setLanguage(Locale.JAPANESE);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("ko")){
//                        result = t1.setLanguage(Locale.KOREAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("uk")){
//                        result = t1.setLanguage(Locale.UK);
//                    }else{
//                        result = t1.setLanguage(new Locale("ja"));
//                    }
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
//                        Toast.makeText(ChatActivity.this, "language not supported", Toast.LENGTH_SHORT).show();
                    } else {
//                        Toast.makeText(ChatActivity.this, "language  supported", Toast.LENGTH_SHORT).show();
                    }
                } else {
//                    Toast.makeText(ChatActivity.this, "Initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getNewMessages() {
        onGetUpdateFromDB();
    }

    @Override
    public void onPause() {
        ApplicationClass.hideSoftKeyboard(this);
        editText.setError(null);
        SocketConnection.getInstance(this).setOnGroupCreatedListener(null);
        SocketConnection.getInstance(this).setGroupChatCallbackListener(null);
        super.onPause();
    }


    @Override
    public void onReadyForSpeech(Bundle params) {
        editText.setText("Listening...");
    }

    @Override
    public void onBeginningOfSpeech() {

    }

    @Override
    public void onRmsChanged(float rmsdB) {

    }

    @Override
    public void onBufferReceived(byte[] buffer) {

    }

    @Override
    public void onEndOfSpeech() {

    }

    @Override
    public void onError(int error) {
        String message;
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                Toast.makeText(GroupChatActivity.this, "Audio error", Toast.LENGTH_SHORT).show();
//                message = "Audio error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                Toast.makeText(GroupChatActivity.this, "Client error", Toast.LENGTH_SHORT).show();

//                message = "Client error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                Toast.makeText(GroupChatActivity.this, "Insufficient permissions", Toast.LENGTH_SHORT).show();

//                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                Toast.makeText(GroupChatActivity.this, "Network error", Toast.LENGTH_SHORT).show();

//                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                Toast.makeText(GroupChatActivity.this, "Network timeout", Toast.LENGTH_SHORT).show();

//                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                Toast.makeText(GroupChatActivity.this, "No match", Toast.LENGTH_SHORT).show();

//                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                Toast.makeText(GroupChatActivity.this, "Speech Recognizer is busy", Toast.LENGTH_SHORT).show();

//                message = "Speech Recognizer is busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                Toast.makeText(GroupChatActivity.this, "Server error", Toast.LENGTH_SHORT).show();

//                message = "Server error";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                Toast.makeText(GroupChatActivity.this, "No speech input", Toast.LENGTH_SHORT).show();

//                message = "No speech input";
                break;
            default:
                Toast.makeText(GroupChatActivity.this, "Speech Recognizer cannot understand you", Toast.LENGTH_SHORT).show();

//                message = "Speech Recognizer cannot understand you";
                break;
        }

        editText.setText("");
        txt_recording.setText("Start Recording");
        //recognizer.stopListening();
        //recognizer.startListening(intent);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> words = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

        String text = "";

        for (String word : words) {
            text += word + " ";
        }

        editText.setText(text);
        txt_recording.setText("Start Recording");

        //recognizer.stopListening();
        //recognizer.startListening(intent);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {

    }

    @Override
    public void onEvent(int eventType, Bundle params) {

    }

    @Override
    protected void onDestroy() {
        tempGroupId = "";
        stopMediaPlayer();
        EventBus.getDefault().unregister(this);
        super.onDestroy();
        if (Constants.isGroupChatOpened) {
            Constants.isGroupChatOpened = false;
        }

        if (t1 != null) {
            t1.stop();
            t1.shutdown();
        }

    }

    private void sendTextMessage(String textMsg) {
        if (socketConnection.getMSocket().connected()) {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            String encryptMessage = ApplicationClass.encryptMessage(textMsg);
            RandomString randomString = new RandomString(10);
            String messageId = groupId + randomString.nextString();
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                jsonObject.put(Constants.TAG_MESSAGE_ID, messageId);
                jsonObject.put(Constants.TAG_MESSAGE_TYPE, Constants.TAG_TEXT);
                jsonObject.put(Constants.TAG_MESSAGE, encryptMessage);
                jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                jsonObject.put(Constants.TAG_DELIVERY_STATUS, "read");

                socketConnection.messageToGroup(jsonObject);

                dbHelper.addGroupMessages(messageId, groupId, GetSet.getUserId(), "", Constants.TAG_TEXT,
                        encryptMessage, "", "", "", "", "",
                        "", currentUTCTime, "", "read");

                dbHelper.addGroupRecentMsg(groupId, messageId, GetSet.getUserId(), currentUTCTime, "0");
                mSmartRepliesRecycler.setVisibility(View.GONE);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            GroupMessage groupMessage = new GroupMessage();
            groupMessage.memberId = GetSet.getUserId();
            groupMessage.messageType = Constants.TAG_TEXT;
            groupMessage.message = textMsg;
            groupMessage.messageId = messageId;
            groupMessage.chatTime = currentUTCTime;
            groupMessage.deliveryStatus = "";
            messagesList.add(0, groupMessage);
            updatePosition();
            showEncryptionText();
            notifyItemInserted(0);
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.send:
                ApplicationClass.preventMultiClick(send);
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else if (dbHelper.isMemberExist(GetSet.getUserId(), groupId)) {
                    if (editText.getText().toString().trim().length() > 0) {
                        sendTextMessage(editText.getText().toString().trim());
                        editText.setText("");
                    } else {
                        editText.setError(getString(R.string.please_enter_your_message));
                    }
                } else {
                    makeToast(getString(R.string.you_are_no_longer_member_in_this_group));
                }
                break;
            case R.id.backbtn:
                if(isRecording)return;
                backPressed();
                break;
            case R.id.optionbtn:
                if(isRecording)return;
                ApplicationClass.preventMultiClick(optionbtn);
                stopAudioViewHolder();
                final ArrayList<String> values = new ArrayList<>();
                GroupData results = dbHelper.getGroupData(GroupChatActivity.this, groupId);

                if (dbHelper.isMemberExist(GetSet.getUserId(), groupId)) {
                    if (results.muteNotification.equals("true")) {
                        values.add(getString(R.string.unmute_notification));
                    } else {
                        values.add(getString(R.string.mute_notification));
                    }
                    values.add(getString(R.string.clear_chat));
                    values.add(getString(R.string.exit_group));
                } else {
                    values.add(getString(R.string.delete_group));
                }

                final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                        R.layout.option_item, android.R.id.text1, values);
                LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View layout = layoutInflater.inflate(R.layout.option_layout, null);
                final PopupWindow popup = new PopupWindow(GroupChatActivity.this);
                popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                popup.setContentView(layout);
                popup.setWidth(displayWidth * 60 / 100);
                popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
                popup.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
                popup.setFocusable(true);

                ImageView pinImage = layout.findViewById(R.id.pinImage);
                if (ApplicationClass.isRTL()) {
                    layout.setAnimation(AnimationUtils.loadAnimation(this, R.anim.grow_from_topleft_to_bottomright));
                    pinImage.setRotation(180);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.START, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                } else {
                    layout.setAnimation(AnimationUtils.loadAnimation(this, R.anim.grow_from_topright_to_bottomleft));
                    pinImage.setRotation(0);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.END, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                }

                final ListView lv = layout.findViewById(R.id.listView);
                lv.setAdapter(adapter);
                popup.showAsDropDown(v);

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        popup.dismiss();
                        if (values.get(position).equals(mContext.getString(R.string.mute_notification))) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                socketConnection.muteChat(Constants.TAG_GROUP, groupId, true);
                                dbHelper.updateMuteGroup(groupId, "true");
                                values.set(position, getString(R.string.unmute_notification));
                                adapter.notifyDataSetChanged();
                            }
                        } else if (values.get(position).equals(mContext.getString(R.string.unmute_notification))) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                socketConnection.muteChat(Constants.TAG_GROUP, groupId, false);
                                dbHelper.updateMuteGroup(groupId, "");
                                values.set(position, getString(R.string.mute_notification));
                                adapter.notifyDataSetChanged();
                            }
                        } else if (values.get(position).equals(mContext.getString(R.string.delete_group))) {
                            dbHelper.deleteMembers(groupId);
                            dbHelper.deleteGroupMessages(groupId);
                            dbHelper.deleteGroup(groupId);
                            socketConnection.removeGroupId(groupId);
                            finish();
                        } else if (values.get(position).equals(mContext.getString(R.string.clear_chat))) {
                            deleteChatConfirmDialog();
                        } else if (values.get(position).equals(mContext.getString(R.string.exit_group))) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                exitConfirmDialog();
                            }
                        } else if (values.get(position).equals(mContext.getString(R.string.wallpaper))) {

                        }
                    }
                });
                break;
            case R.id.attachbtn:
                ApplicationClass.preventMultiClick(attachbtn);
                TransitionManager.beginDelayedTransition(mainLay);
                visible = !visible;
                attachmentsLay.setVisibility(visible ? View.VISIBLE : View.GONE);
                break;
            case R.id.userImg:
                break;
            case R.id.cameraBtn:
                setClickEvent(false, true, false, false, false, false);
                ApplicationClass.preventMultiClick(cameraBtn);
                stopAudioViewHolder();
                if (PermissionsUtils.checkCameraPermission(mContext)) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                            networkSnack();
                        } else {
                            ApplicationClass.onShareExternal = true;
                            takeCameraPictures();
                        }
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    requestCameraPermissions();
                }
                break;
            case R.id.galleryBtn:
                setClickEvent(true, false, false, false, false, false);
                ApplicationClass.preventMultiClick(galleryBtn);
                stopAudioViewHolder();
                if (PermissionsUtils.checkStoragePermission(GroupChatActivity.this)) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else {
                        FilePickerBuilder.getInstance()
                                .setMaxCount(1)
                                .setActivityTheme(R.style.MainTheme)
                                .setActivityTitle(getString(R.string.please_select_media))
                                .enableVideoPicker(true)
                                .enableImagePicker(true)
                                .enableCameraSupport(false)
                                .showGifs(false)
                                .showFolderView(false)
                                .enableSelectAll(false)
                                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                                .pickPhoto(this, galleryResultLauncher);
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.fileBtn:
                setClickEvent(false, false, true, false, false, false);
                ApplicationClass.preventMultiClick(fileBtn);
                stopAudioViewHolder();
                if (PermissionsUtils.checkStoragePermission(this)) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Intent documentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                            documentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                            documentIntent.setType("application/*");
                            documentResultLauncher.launch(documentIntent);
                        } else {
                            FilePickerBuilder.getInstance()
                                    .setMaxCount(1)
                                    .enableDocSupport(true)
                                    .setActivityTitle(getString(R.string.please_select_document))
                                    .showTabLayout(true)
                                    .setActivityTheme(R.style.MainTheme)
                                    .pickFile(this, documentResultLauncher);
                        }
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.audioBtn:
                setClickEvent(false, false, false, true, false, false);
                ApplicationClass.preventMultiClick(audioBtn);
                stopAudioViewHolder();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    storagePermissionResult.launch(PermissionsUtils.AUDIO_STORAGE_PERMISSION13);
                }
               else if (PermissionsUtils.checkStoragePermission(this) || Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else {
                        FilePickerBuilder.getInstance()
                                .setMaxCount(1)
                                .setActivityTheme(R.style.MainTheme)
                                .setActivityTitle(getString(R.string.please_select_audio))
                                .addFileSupport("MP3", Utils.AUDIO_TYPES)
                                .enableDocSupport(false)
                                .enableSelectAll(true)
                                .showTabLayout(false)
                                .sortDocumentsBy(SortingTypes.NAME)
                                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                                .pickFile(this, audioResultLauncher);
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.locationBtn:
                ApplicationClass.preventMultiClick(locationBtn);
                stopAudioViewHolder();
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    Intent location = new Intent(this, LocationActivity.class);
                    location.putExtra("from", "share");
                    locationResultLauncher.launch(location);
                }
                break;
            case R.id.contactBtn:
                ApplicationClass.preventMultiClick(contactBtn);
                stopAudioViewHolder();
                if (ContextCompat.checkSelfPermission(this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{READ_CONTACTS}, PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE);
                } else {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else {
                        ApplicationClass.onShareExternal = true;
                        Intent contactIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                        contactResultLauncher.launch(contactIntent);
                    }
                }
                break;
            case R.id.chatUserLay:
                if(isRecording)return;
                ApplicationClass.preventMultiClick(chatUserLay);
                stopAudioViewHolder();
                Intent profile = new Intent(GroupChatActivity.this, GroupInfoActivity.class);
                profile.putExtra(Constants.TAG_GROUP_ID, groupId);
                startActivity(profile);
                break;
            case R.id.forwordBtn:
                ApplicationClass.preventMultiClick(forwordBtn);
                stopAudioViewHolder();
                Intent f = new Intent(GroupChatActivity.this, ForwardActivity.class);
                f.putExtra("from", "group");
                f.putExtra("id", groupId);
                f.putExtra("data", selectedChatPos);
                forwardResultLauncher.launch(f);
                break;
            case R.id.copyBtn:
                if (selectedChatPos.size() > 0) {
                    ArrayList<GroupMessage> sortList = new ArrayList<>(selectedChatPos);
                    Collections.reverse(sortList);
                    StringBuilder builder = new StringBuilder();
                    for (GroupMessage messageData : sortList) {
                        builder.append(messageData.message);
                        builder.append("\n");
                    }
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("Copied Message", builder.toString().trim());
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(this, getString(R.string.message_copied), Toast.LENGTH_SHORT).show();
                    selectedChatPos.clear();
                    messageListAdapter.notifyDataSetChanged();
                    chatUserLay.setVisibility(View.VISIBLE);
                    forwordLay.setVisibility(View.GONE);
                    chatLongPressed = false;
                }
                break;
            case R.id.closeBtn:
                backPressed();
                break;
            case R.id.deleteBtn:
                ApplicationClass.preventMultiClick(deleteBtn);
                openDeleteDialog();
                //deleteMessageConfirmDialog(selectedChatPos.get(0));
                break;
            case R.id.newMessageLay:
                recyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        recyclerView.smoothScrollToPosition(0);
                    }
                });
                iconNewMessage.setVisibility(View.GONE);
                newMessageLay.setVisibility(View.GONE);
                break;
        }
    }

    private void setClickEvent(boolean gallery, boolean camera, boolean file, boolean audio,
                               boolean download, boolean wallpaper) {
        isGalleryClicked = gallery;
        isCameraClicked = camera;
        isFileClicked = file;
        isAudioClicked = audio;
        isDownloadClicked = download;
    }

    private boolean isAdmin() {
        boolean isAdmin = false;
        for (GroupData.GroupMembers members : groupData.groupMembers) {
            if (members.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                isAdmin = members.memberRole.equalsIgnoreCase(ADMIN);
                break;
            }
        }
        return isAdmin;
    }

    private void updatePosition() {
        /*if(player != null){
            if(player.isPlaying()){
                playingPosition = playingPosition+1;
            }
        }*/
    }

    //Addon SmartReply
    private void generateReplies(String message) {
        // If the last message in the chat thread is not sent by the "other" user, don't generate
        // smart replies.
        if (!TextUtils.isEmpty(message)) {

            Data.Builder builder = new Data.Builder();
            builder.putString(Constants.TAG_MESSAGE, message);
            OneTimeWorkRequest locationWorkRequest = new OneTimeWorkRequest.Builder(GenerateSmartReplyWorker.class)
                    .setConstraints(new Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.CONNECTED)
                            .build())
                    .setInputData(builder.build())
                    .build();
            WorkManager workManager = WorkManager.getInstance(this);
            workManager.enqueue(locationWorkRequest);
            workManager.getWorkInfoByIdLiveData(locationWorkRequest.getId()).observe(this, workInfo -> {
                if (workInfo.getState().isFinished()) {
                    if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                        final List<SmartReplySuggestion> suggestion = new ArrayList<>();
                        String suggestionJson = workInfo.getOutputData().getString(Constants.TAG_DATA);
                        Log.d(TAG, "GenerateSmartReplyWorker: " + suggestionJson);
                        if (!TextUtils.isEmpty(suggestionJson)) {
                            Type userListType = new TypeToken<List<SmartReplySuggestion>>() {
                            }.getType();
                            suggestion.addAll(new Gson().fromJson(suggestionJson, userListType));
                            mChipAdapter.setSuggestions(suggestion);
                            mSmartRepliesRecycler.setVisibility(View.VISIBLE);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    recyclerView.scrollToPosition(0);
                                }
                            }, 100);
                        }
                    } else {
                        mSmartRepliesRecycler.setVisibility(View.GONE);
                    }
                }
            });
        } else {
            mSmartRepliesRecycler.setVisibility(View.GONE);
        }
    }

    @Override
    public void onAudioUpdate(int currentPosition) {
        if (currentMessageId != null) {
            GroupMessage tempMsgData = dbHelper.getSingleGroupMessage(groupId, currentMessageId);
            int tempPosition = -1;
            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(currentPosition);
                    holder.duration.setText(milliSecondsToTimer(currentPosition));
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.play_icon_white));
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(currentPosition);
                    holder.duration.setText(milliSecondsToTimer(currentPosition));
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.play_icon_white));
                }
            }
        }
    }

    @Override
    public void onAudioComplete() {
        state = recyclerView.getLayoutManager().onSaveInstanceState();
        // Main position of RecyclerView when loaded again
        if (state != null) {
            recyclerView.getLayoutManager().onRestoreInstanceState(state);
        }
        if (currentMessageId != null) {
            GroupMessage tempMsgData = dbHelper.getSingleGroupMessage(groupId, currentMessageId);
            int tempPosition = -1;
            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                    if (file != null) {
                        holder.duration.setVisibility(View.VISIBLE);
                        holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                    } else {
                        holder.duration.setVisibility(View.INVISIBLE);
                    }
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), TAG_AUDIO);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        if (file != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    }
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                }
            }
        }
    }

    @Override
    public void didSearchTerm(@NonNull String s) {

    }

    @Override
    public void onDismissed(@NonNull GPHContentType gphContentType) {

    }

    @Override
    public void onGifSelected(@NonNull Media media, @Nullable String s, @NonNull GPHContentType gphContentType) {
        if (socketConnection.getMSocket().connected()) {
            GroupMessage messagesData = updateDBList(Constants.TAG_GIF, null, null, media.getImages().getFixedHeightDownsampled().getGifUrl(), null);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(Constants.TAG_GROUP_ID, groupId);
                jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                jsonObject.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                jsonObject.put(Constants.TAG_MESSAGE_ID, messagesData.messageId);
                jsonObject.put(Constants.TAG_MESSAGE_TYPE, messagesData.messageType);
                jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(messagesData.message));
                jsonObject.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(messagesData.attachment));
                jsonObject.put(Constants.TAG_CHAT_TIME, messagesData.chatTime);

                socketConnection.messageToGroup(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    public class MessageListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        TextToSpeech t1;
        public static final int VIEW_TYPE_DATE = 9;
        private static final int VIEW_TYPE_MESSAGE_SENT = 1;
        private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
        private static final int VIEW_TYPE_IMAGE_SENT = 3;
        private static final int VIEW_TYPE_IMAGE_RECEIVED = 4;
        private static final int VIEW_TYPE_CONTACT_SENT = 5;
        private static final int VIEW_TYPE_CONTACT_RECEIVED = 6;
        private static final int VIEW_TYPE_FILE_SENT = 7;
        private static final int VIEW_TYPE_FILE_RECEIVED = 8;
        public static final int VIEW_TYPE_VOICE_SENT = 10;
        public static final int VIEW_TYPE_VOICE_RECEIVE = 11;
        public static final int VIEW_TYPE_DELETE_SENT = 12;
        public static final int VIEW_TYPE_DELETE_RECEIVE = 13;
        public static final int VIEW_TYPE_INVITE_LINK_SENT = 16;
        public static final int VIEW_TYPE_INVITE_LINK_RECEIVE = 17;
        private Context mContext;
        private List<GroupMessage> mMessageList = new ArrayList<>();

        public MessageListAdapter(Context context, List<GroupMessage> messageList) {
            mContext = context;
            mMessageList = messageList;
        }

        @Override
        public int getItemCount() {
            return mMessageList.size();
        }

        // Determines the appropriate ViewType according to the sender of the message.
        @Override
        public int getItemViewType(int position) {
            final GroupMessage message = mMessageList.get(position);

            if (message.memberId != null && message.memberId.equals(GetSet.getUserId())) {
                switch (message.messageType) {
                    case "text":
                        return VIEW_TYPE_MESSAGE_SENT;
                    case Constants.TAG_LINK:
                        return VIEW_TYPE_INVITE_LINK_SENT;
                    case Constants.TAG_IMAGE:
                    case Constants.TAG_VIDEO:
                    case Constants.TAG_LOCATION:
                    case Constants.TAG_GIF:
                        return VIEW_TYPE_IMAGE_SENT;
                    case "contact":
                        return VIEW_TYPE_CONTACT_SENT;
                    case "date":
                    case "create_group":
                    case "add_member":
                    case Constants.TAG_GROUP_JOINED:
                    case "group_image":
                    case "subject":
                    case "left":
                    case "remove_member":
                    case "admin":
                    case "change_number":
                        return VIEW_TYPE_DATE;
                    case "audio":
                        return VIEW_TYPE_VOICE_SENT;
                    case Constants.TAG_ISDELETE:
                        return VIEW_TYPE_DELETE_SENT;
                    default:
                        return VIEW_TYPE_FILE_SENT;
                }
            } else {
                switch (message.messageType) {
                    case "text":
                        return VIEW_TYPE_MESSAGE_RECEIVED;
                    case Constants.TAG_LINK:
                        return VIEW_TYPE_INVITE_LINK_RECEIVE;
                    case Constants.TAG_IMAGE:
                    case Constants.TAG_VIDEO:
                    case Constants.TAG_LOCATION:
                    case Constants.TAG_GIF:
                        return VIEW_TYPE_IMAGE_RECEIVED;
                    case "contact":
                        return VIEW_TYPE_CONTACT_RECEIVED;
                    case "date":
                    case "create_group":
                    case "add_member":
                    case Constants.TAG_GROUP_JOINED:
                    case "group_image":
                    case "subject":
                    case "left":
                    case "remove_member":
                    case "admin":
                    case "change_number":
                        return VIEW_TYPE_DATE;
                    case "audio":
                        return VIEW_TYPE_VOICE_RECEIVE;
                    case Constants.TAG_ISDELETE:
                        return VIEW_TYPE_DELETE_RECEIVE;
                    default:
                        return VIEW_TYPE_FILE_RECEIVED;
                }
            }
        }

        // Inflates the appropriate layout according to the ViewType.
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;

            switch (viewType) {
                case VIEW_TYPE_MESSAGE_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_text_bubble_sent, parent, false);
                    return new SentMessageHolder(view);
                case VIEW_TYPE_MESSAGE_RECEIVED:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_text_bubble_receive, parent, false);
                    return new ReceivedMessageHolder(view);
                case VIEW_TYPE_INVITE_LINK_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_link_bubble_sent, parent, false);
                    return new SentInviteLinkHolder(view);
                case VIEW_TYPE_INVITE_LINK_RECEIVE:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_link_bubble_receive, parent, false);
                    return new ReceivedInviteLinkHolder(view);
                case VIEW_TYPE_IMAGE_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_image_bubble_sent, parent, false);
                    return new SentImageHolder(view);
                case VIEW_TYPE_IMAGE_RECEIVED:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_image_bubble_receive, parent, false);
                    return new ReceivedImageHolder(view);
                case VIEW_TYPE_CONTACT_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_contact_bubble_sent, parent, false);
                    return new SentContactHolder(view);
                case VIEW_TYPE_CONTACT_RECEIVED:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_contact_bubble_receive, parent, false);
                    return new ReceivedContactHolder(view);
                case VIEW_TYPE_FILE_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_file_bubble_sent, parent, false);
                    return new SentFileHolder(view);
                case VIEW_TYPE_FILE_RECEIVED:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_file_bubble_received, parent, false);
                    return new ReceivedFileHolder(view);
                case VIEW_TYPE_DATE:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_date_layout, parent, false);
                    return new DateHolder(view);
                case VIEW_TYPE_VOICE_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_voice_sent, parent, false);
                    return new SentVoiceHolder(view);
                case VIEW_TYPE_VOICE_RECEIVE:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_voice_receive, parent, false);
                    return new ReceiveVoiceHolder(view);
                case VIEW_TYPE_DELETE_SENT:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_delete_bubble_sent, parent, false);
                    return new DeleteMsgSent(view);
                case VIEW_TYPE_DELETE_RECEIVE:
                    view = LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.chat_delete_bubble_receive, parent, false);
                    return new DeleteMsgReceived(view);
            }

            return null;
        }

        // Passes the message object to a ViewHolder so that the contents can be bound to UI.
        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            final GroupMessage message = mMessageList.get(position);
            switch (holder.getItemViewType()) {
                case VIEW_TYPE_MESSAGE_SENT:
                    ((SentMessageHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_MESSAGE_RECEIVED:
                    ((ReceivedMessageHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_INVITE_LINK_SENT:
                    ((SentInviteLinkHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_INVITE_LINK_RECEIVE:
                    ((ReceivedInviteLinkHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_IMAGE_SENT:
                    ((SentImageHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_IMAGE_RECEIVED:
                    ((ReceivedImageHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_FILE_SENT:
                    ((SentFileHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_FILE_RECEIVED:
                    ((ReceivedFileHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_CONTACT_SENT:
                    ((SentContactHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_CONTACT_RECEIVED:
                    ((ReceivedContactHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_DATE:
                    ((DateHolder) holder).bind(message);
                    break;
                case VIEW_TYPE_VOICE_SENT:
                    ((SentVoiceHolder) holder).bind(message, position);
                    break;
                case VIEW_TYPE_VOICE_RECEIVE:
                    ((ReceiveVoiceHolder) holder).bind(message, position);
                    break;
                case VIEW_TYPE_DELETE_SENT:
                    ((DeleteMsgSent) holder).bind(message);
                    break;
                case VIEW_TYPE_DELETE_RECEIVE:
                    ((DeleteMsgReceived) holder).bind(message);
                    break;
            }
        }

        private class SentMessageHolder extends RecyclerView.ViewHolder {
            TextView messageText, timeText;
            ImageView img_mike;

            SentMessageHolder(View itemView) {
                super(itemView);

                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                img_mike = itemView.findViewById(R.id.img_mike);

            }

            void bind(final GroupMessage message) {
//                Log.d(TAG, "SentMessageHolder: " + new Gson().toJson(message));
                messageText.setText(message.message
                        + Html.fromHtml(" &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;"));
                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));

                img_mike.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String toSpeak = messageText.getText().toString();
                        t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                    }
                });

                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
            }
        }

        private class ReceivedMessageHolder extends RecyclerView.ViewHolder {
            TextView messageText, timeText, nameText;
            TextView btnTranslate;

            ImageView img_mike;

            ReceivedMessageHolder(View itemView) {
                super(itemView);

                nameText = itemView.findViewById(R.id.text_message_sender);
                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                btnTranslate = itemView.findViewById(R.id.btnTranslate);
                img_mike = itemView.findViewById(R.id.img_mike);

            }

            void bind(GroupMessage message) {
//                Log.d(TAG, "ReceivedMessageHolder: " + new Gson().toJson(message));
                nameText.setVisibility(View.VISIBLE);
                nameText.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
                String msg = "";
                msg = message.message
                        + Html.fromHtml(" &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                if(containsIllegalCharacters(msg))
                 btnTranslate.setVisibility(View.GONE);
                else if(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none)) ||pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(""))
                    btnTranslate.setVisibility(View.GONE);
                else btnTranslate.setVisibility(View.VISIBLE);

                messageText.setText(msg);
                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));

                img_mike.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String toSpeak = messageText.getText().toString();
                        t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                    }
                });
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }

                //Addon Chat Translate
                btnTranslate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!TextUtils.isEmpty(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")) && !pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none))) {
                            Data.Builder builder = new Data.Builder();
                            builder.putString(Constants.TAG_MESSAGE, message.message);
                            OneTimeWorkRequest translateWorkRequest = new OneTimeWorkRequest.Builder(ChatTranslateWorker.class)
                                    .setConstraints(new Constraints.Builder()
                                            .setRequiredNetworkType(NetworkType.CONNECTED)
                                            .build())
                                    .setInputData(builder.build())
                                    .build();
                            WorkManager workManager = WorkManager.getInstance(mContext);
                            workManager.enqueue(translateWorkRequest);
                            workManager.getWorkInfoByIdLiveData(translateWorkRequest.getId()).observe(GroupChatActivity.this, workInfo -> {
                                if (workInfo.getState().isFinished()) {
                                    if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                                        String translatedMsg = workInfo.getOutputData().getString(Constants.TAG_DATA);

                                        String replace= translatedMsg.replace("&#39;","'");
                                        message.message = replace;
                                        notifyItemChanged(getAbsoluteAdapterPosition());
                                    }
                                }
                            });
                        } else {
                            ApplicationClass.showToast(mContext, mContext.getString(R.string.select_language), Toast.LENGTH_SHORT);
                        }
                    }
                });
            }
        }

        private class SentInviteLinkHolder extends RecyclerView.ViewHolder {
            private ConstraintLayout headerLay;
            private TextView messageText, timeText, txtName, txtDescription, btnView;
            private CircleImageView ivProfile;
            private ImageView tickimage;
            ImageView img_mike;

            SentInviteLinkHolder(View itemView) {
                super(itemView);

                headerLay = itemView.findViewById(R.id.headerLay);
                messageText = itemView.findViewById(R.id.text_message_body);
                img_mike = itemView.findViewById(R.id.img_mike);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                txtName = itemView.findViewById(R.id.txtName);
                txtDescription = itemView.findViewById(R.id.txtDescription);
                btnView = itemView.findViewById(R.id.btnView);
                ivProfile = itemView.findViewById(R.id.ivProfile);

            }

            void bind(GroupMessage message) {
//                Log.d(TAG, "SentInviteLinkHolder: " + new Gson().toJson(message));
                try {
                    JSONObject messageObject = new JSONObject(message.message);
                    txtName.setText(messageObject.optString(Constants.TAG_NAME));
                    txtDescription.setText(messageObject.optString(Constants.TAG_DESCRIPTION));
                    if (messageObject.optString(Constants.TAG_TYPE).equals(Constants.TAG_GROUP)) {
                        btnView.setText(mContext.getString(R.string.view_grouop));
                    } else {
                        btnView.setText(mContext.getString(R.string.view_channel));
                    }
                    String msg = messageObject.optString(Constants.TAG_LINK);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                    } else {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                    }
                    // set up spanned string with url
                    SpannableString spannableString = new SpannableString(msg);
                    String url = messageObject.optString(Constants.TAG_LINK);
                    int startIndex = msg.indexOf(url);
                    int lastIndex = startIndex + url.length();
                    spannableString.setSpan(new UnderlineSpan(), startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannableString.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(@NonNull View widget) {
                            btnView.performClick();
                        }
                    }, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    messageText.setText(spannableString);
                    messageText.setMovementMethod(LinkMovementMethod.getInstance()); // enable clicking on url span

                    img_mike.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String toSpeak = messageText.getText().toString();
                            t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    });

//                    messageText.setText(msg);
                    headerLay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btnView.performClick();
                        }
                    });
                    btnView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            intent.putExtra(Constants.TAG_FROM, Constants.TAG_CHAT);
                            intent.setData(Uri.parse(url));
                            startActivity(intent);
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                itemView.setSelected(selectedChatPos.contains(message));
            }
        }

        private class ReceivedInviteLinkHolder extends RecyclerView.ViewHolder {
            private ConstraintLayout headerLay;
            private TextView messageText, timeText, btnTranslate, txtName, txtDescription, btnView;
            private CircleImageView ivProfile;

            ImageView img_mike;

            ReceivedInviteLinkHolder(View itemView) {
                super(itemView);

                headerLay = itemView.findViewById(R.id.headerLay);
                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                btnTranslate = itemView.findViewById(R.id.btnTranslate);
                txtName = itemView.findViewById(R.id.txtName);
                txtDescription = itemView.findViewById(R.id.txtDescription);
                btnView = itemView.findViewById(R.id.btnView);
                ivProfile = itemView.findViewById(R.id.ivProfile);
                img_mike = itemView.findViewById(R.id.img_mike);

            }

            void bind(GroupMessage message) {
//                Log.d(TAG, "ReceivedInviteLinkHolder: " + new Gson().toJson(message));
                btnTranslate.setVisibility(View.GONE);
                try {
                    JSONObject messageObject = new JSONObject(message.message);
                    txtName.setText(messageObject.optString(Constants.TAG_NAME));
                    txtDescription.setText(messageObject.optString(Constants.TAG_DESCRIPTION));
                    if (messageObject.optString(Constants.TAG_TYPE).equals(Constants.TAG_GROUP)) {
                        btnView.setText(mContext.getString(R.string.view_grouop));
                    } else {
                        btnView.setText(mContext.getString(R.string.view_channel));
                    }
//                    Log.d(TAG, "ReceivedInviteLinkHolder: "+messageObject.optString(Constants.TAG_MESSAGE));
                    String msg = messageObject.optString(Constants.TAG_LINK);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                    } else {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                    }
                    // set up spanned string with url
                    SpannableString spannableString = new SpannableString(msg);
                    String url = messageObject.optString(Constants.TAG_LINK);
                    int startIndex = msg.indexOf(url);
                    int lastIndex = startIndex + url.length();
                    spannableString.setSpan(new UnderlineSpan(), startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannableString.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(@NonNull View widget) {
                            btnView.performClick();
                        }
                    }, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    // set to textview
                    messageText.setText(spannableString);
                    messageText.setMovementMethod(LinkMovementMethod.getInstance()); // enable clicking on url span

                    img_mike.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String toSpeak = messageText.getText().toString();
                            t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    });
//                    messageText.setText(msg);
                    headerLay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btnView.performClick();
                        }
                    });
                    btnView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            intent.setData(Uri.parse(url));
                            startActivity(intent);
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                itemView.setSelected(selectedChatPos.contains(message));
            }
        }

        private class SentImageHolder extends RecyclerView.ViewHolder {
            TextView timeText;
            ImageView uploadimage, downloadicon, gifImage;
            RelativeLayout progresslay;
            ProgressWheel progressbar;

            SentImageHolder(View itemView) {
                super(itemView);

                uploadimage = itemView.findViewById(R.id.uploadimage);
                timeText = itemView.findViewById(R.id.text_message_time);
                progresslay = itemView.findViewById(R.id.progresslay);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                gifImage = itemView.findViewById(R.id.gifImage);
            }

            void bind(final GroupMessage message) {
                Log.i(TAG, "SentImageHolder: " + new Gson().toJson(message));
                gifImage.setVisibility(View.GONE);
                uploadimage.setVisibility(View.VISIBLE);
                String attachmentPath = message.attachment;
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }

                switch (message.messageType) {
                    case Constants.TAG_IMAGE: {
                        downloadicon.setImageResource(R.drawable.upload);
                        switch (message.progress) {
                            case "": {
                                progresslay.setVisibility(View.VISIBLE);
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.spin();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                                break;
                            }
                            case "completed": {
                                progresslay.setVisibility(View.GONE);
                                progressbar.setVisibility(View.GONE);
                                progressbar.stopSpinning();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                                break;
                            }
                            case "error": {
                                progresslay.setVisibility(View.VISIBLE);
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.stopSpinning();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                                break;
                            }
                        }

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (!chatLongPressed && !isRecording) {
                                    if (message.progress.equals("error")) {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            try {
                                                progressbar.setVisibility(View.VISIBLE);
                                                progressbar.spin();
                                                dbHelper.updateGroupMessageData(message.messageId, Constants.TAG_PROGRESS, "");
                                                message.progress = "";
                                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                                if (file != null) {
                                                    setMediaImage(mContext, null, file, uploadimage);
                                                } else {
                                                    setErrorImage(mContext, "", uploadimage);
                                                }
                                                byte[] bytes = FileUtils.readFileToByteArray(new File(attachmentPath));
                                                uploadImage(bytes, null, attachmentPath, message);
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                            }
                                        }
                                    } else if (message.progress.equals("completed")) {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                        Uri fileuri;
                                        fileuri = storageManager.getUriFromFile(file);
                                        if (fileuri != null) {
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, fileuri, Constants.TAG_MESSAGE, imageView);
                                        } else {
                                            Toast.makeText(mContext, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_LOCATION: {
                        progresslay.setVisibility(View.GONE);
                        Glide.with(mContext).load(ApplicationClass.getMapUrl(message.lat, message.lon, mContext)).thumbnail(0.5f)
                                .into(uploadimage);

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (!chatLongPressed && !isRecording) {
                                    stopAudioViewHolder();
                                    Intent i = new Intent(GroupChatActivity.this, LocationActivity.class);
                                    i.putExtra("from", "view");
                                    i.putExtra("lat", message.lat);
                                    i.putExtra("lon", message.lon);
                                    startActivity(i);
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_VIDEO: {
                        progresslay.setVisibility(View.VISIBLE);
                        String thumbnail = message.thumbnail;
                        switch (message.progress) {
                            case "": {
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.spin();
                                downloadicon.setImageResource(R.drawable.upload);
                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                Uri thumbUri = storageManager.getUriFromFile(thumb);
                                if (fileUri != null) {
                                    if (thumbUri != null) {
                                        setMediaImage(mContext, thumbUri, null, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                            }
                            break;
                            case "completed": {
                                progressbar.setVisibility(View.GONE);
                                progressbar.stopSpinning();
                                downloadicon.setImageResource(R.drawable.play);
                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                Uri thumbUri = storageManager.getUriFromFile(thumb);
                                Log.d(TAG, "bind: " + thumbUri);
                                if (fileUri != null) {
                                    if (thumbUri != null) {
                                        setMediaImage(mContext, thumbUri, null, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    setErrorImage(mContext, Constants.CHAT_IMG_PATH + thumbnail, uploadimage);
                                }
                            }
                            break;
                            case "error": {
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.stopSpinning();
                                downloadicon.setImageResource(R.drawable.upload);
                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                Uri thumbUri = storageManager.getUriFromFile(thumb);
                                if (fileUri != null) {
                                    if (thumbUri != null) {
                                        setMediaImage(mContext, thumbUri, null, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                            }
                            break;
                            default:
                                break;
                        }

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (!chatLongPressed && !isRecording) {
                                    if (message.progress.equals("error")) {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            try {
                                                Bitmap thumb = null;
                                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                                String filePath = null;
                                                if (file != null) {
                                                    filePath = file.getAbsolutePath();
                                                    Uri fileUri = storageManager.getUriFromFile(file);
                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                        CancellationSignal ca = new CancellationSignal();
                                                        thumb = ThumbnailUtils.createVideoThumbnail(file, Utils.getBitmapSize(mContext), ca);
                                                    } else {
                                                        thumb = ThumbnailUtils.createVideoThumbnail(message.attachment, MediaStore.Video.Thumbnails.MINI_KIND);
                                                    }
                                                }
                                                if (thumb != null) {
                                                    progressbar.setVisibility(View.VISIBLE);
                                                    progressbar.spin();
                                                    dbHelper.updateGroupMessageData(message.messageId, Constants.TAG_PROGRESS, "");
                                                    message.progress = "";
                                                    String thumbName = System.currentTimeMillis() + ".jpg";
                                                    String savedThumbPath = storageManager.saveImageInStorage(thumb, thumbName, TAG_THUMB).getAbsolutePath();
                                                    if (filePath != null) {
                                                        byte[] bytes = FileUtils.readFileToByteArray(new File(savedThumbPath));
                                                        uploadVideoThumbnail(bytes, null, savedThumbPath, message, null, filePath);
                                                    } else {
                                                        Toast.makeText(mContext, getString(R.string.no_media_found), Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    } else if (message.progress.equals("completed")) {
                                        File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                        Uri fileUri = storageManager.getUriFromFile(file);
                                        if (fileUri != null) {
                                            try {
                                                Intent intent = new Intent();
                                                intent.setAction(Intent.ACTION_VIEW);
                                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                                MimeTypeMap mime = MimeTypeMap.getSingleton();
                                                String ext = storageManager.getExtension(fileUri);
                                                String type = mime.getMimeTypeFromExtension(ext);
                                                intent.setDataAndType(fileUri, type);
                                                stopAudioViewHolder();
                                                startActivity(intent);
                                            } catch (ActivityNotFoundException e) {
                                                Toast.makeText(mContext, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                                e.printStackTrace();
                                            }
                                        } else {
                                            Toast.makeText(mContext, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                                        }
                                    } else if (message.progress.equalsIgnoreCase("")) {
                                        File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                        Uri fileUri = storageManager.getUriFromFile(file);
                                        if (fileUri != null) {
                                            dbHelper.updateGroupMessageData(message.messageId, Constants.TAG_PROGRESS, "completed");
                                            messagesList.get(getAbsoluteAdapterPosition()).progress = "completed";
                                            progressbar.setVisibility(View.GONE);
                                            progressbar.stopSpinning();
                                            downloadicon.setImageResource(R.drawable.play);
                                            uploadimage.performClick();
                                            messageListAdapter.notifyDataSetChanged();
                                        }

                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_GIF:
                        progresslay.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadimage.setVisibility(View.GONE);
                        gifImage.setVisibility(View.VISIBLE);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                        setGifImage(mContext, message.attachment, gifImage);
                        break;
                }
            }
        }

        private boolean containsIllegalCharacters(String displayName)
        {
            final int nameLength = displayName.length();

            for (int i = 0; i < nameLength; i++)
            {
                final char hs = displayName.charAt(i);

                if (0xd800 <= hs && hs <= 0xdbff)
                {
                    final char ls = displayName.charAt(i + 1);
                    final int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;

                    if (0x1d000 <= uc && uc <= 0x1f77f)
                    {
                        return true;
                    }
                }
                else if (Character.isHighSurrogate(hs))
                {
                    final char ls = displayName.charAt(i + 1);

                    if (ls == 0x20e3)
                    {
                        return true;
                    }
                }
                else
                {
                    // non surrogate
                    if (0x2100 <= hs && hs <= 0x27ff)
                    {
                        return true;
                    }
                    else if (0x2B05 <= hs && hs <= 0x2b07)
                    {
                        return true;
                    }
                    else if (0x2934 <= hs && hs <= 0x2935)
                    {
                        return true;
                    }
                    else if (0x3297 <= hs && hs <= 0x3299)
                    {
                        return true;
                    }
                    else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private void setMediaImage(Context mContext, Uri imageUri, File imageFile, ImageView uploadImage) {
            Glide.with(getApplicationContext())
                    .asBitmap()
                    .load(imageUri != null ? imageUri : imageFile)
                    .error(R.drawable.chat_media_placeholder).thumbnail(0.5f)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(uploadImage);
        }

        private void setErrorImage(Context mContext, String imageUrl, ImageView uploadImage) {
            if (TextUtils.isEmpty(imageUrl)) {
                Glide.with(mContext).load(R.drawable.chat_media_placeholder).thumbnail(0.5f)
                        .into(uploadImage);
            } else {
                Glide.with(mContext).load(imageUrl).error(R.drawable.chat_media_placeholder).thumbnail(0.5f)
                        .transform(new BlurTransformation(Constants.BLUR_RADIUS))
                        .into(uploadImage);
            }
        }

        private void setGifImage(Context mContext, String attachment, ImageView gifImage) {
            Glide
                    .with(mContext)
                    .asGif()
                    .transform(new GranularRoundedCorners(18, 18, 0, 0))
                    .load(attachment)
                    .into(gifImage);
        }

        private class ReceivedImageHolder extends RecyclerView.ViewHolder {
            TextView timeText, nameText;
            ImageView uploadimage, downloadicon, gifImage;
            RelativeLayout progresslay, videoprogresslay;
            ProgressWheel progressbar, videoprogressbar;

            ReceivedImageHolder(View itemView) {
                super(itemView);

                uploadimage = itemView.findViewById(R.id.uploadimage);
                progresslay = itemView.findViewById(R.id.progresslay);
                timeText = itemView.findViewById(R.id.text_message_time);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                nameText = itemView.findViewById(R.id.text_message_sender);
                videoprogresslay = itemView.findViewById(R.id.videoprogresslay);
                videoprogressbar = itemView.findViewById(R.id.videoprogressbar);
                gifImage = itemView.findViewById(R.id.gifImage);
            }

            void bind(final GroupMessage message) {
                Log.i(TAG, "ReceivedImageHolder: " + new Gson().toJson(message));
                uploadimage.setVisibility(View.VISIBLE);
                gifImage.setVisibility(View.GONE);
                nameText.setVisibility(View.VISIBLE);
                nameText.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                switch (message.messageType) {
                    case Constants.TAG_IMAGE: {
                        videoprogresslay.setVisibility(View.GONE);
                        downloadicon.setImageResource(R.drawable.download);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Uri fileUri = storageManager.getFileUri(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                            if (fileUri != null) {
                                progresslay.setVisibility(View.GONE);
                                setMediaImage(mContext, fileUri, null, uploadimage);
                            } else {
                                loadBlurImage(message);
                            }
                        } else {
                            File file = storageManager.getSrcFile(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                            if (file != null && !TextUtils.isEmpty(file.getAbsolutePath())) {
                                progresslay.setVisibility(View.GONE);
                                setMediaImage(mContext, null, file, uploadimage);
                            } else {
                                loadBlurImage(message);
                            }
                        }
                        timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setClickEvent(false, false, false, false, true, false);
                                if (!chatLongPressed && !isRecording) {
                                    boolean validFile = false;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        Uri fileUri = storageManager.getFileUri(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                                        if (fileUri != null) {
                                            validFile = true;
                                            videoprogresslay.setVisibility(View.GONE);
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, fileUri, Constants.TAG_MESSAGE, imageView);
                                        }
                                    } else {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                                        if (file != null) {
                                            validFile = true;
                                            videoprogresslay.setVisibility(View.GONE);
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, file.getAbsolutePath(), Constants.TAG_MESSAGE, imageView);
                                        }
                                    }
                                    File imageFile = storageManager.getFile(message.attachment, Constants.TAG_IMAGE);
                                    if (!validFile) {
                                        if (PermissionsUtils.checkStoragePermission(mContext)) {
                                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                                networkSnack();
                                            } else {
                                                ImageDownloader imageDownloader = new ImageDownloader(GroupChatActivity.this) {
                                                    @Override
                                                    protected void onPostExecute(Bitmap imgBitmap) {
                                                        if (imgBitmap == null) {
                                                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                        } else {
                                                            try {
                                                                Uri savedUri = null;
                                                                String savedPath = null;
                                                                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                                    savedUri = storageManager.saveImageInStorageV10(imgBitmap, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                                                                } else {
                                                                    savedPath = storageManager.saveImageInStorage(imgBitmap, getFileName(message.attachment), StorageManager.TAG_IMAGE).getAbsolutePath();

                                                                }
                                                                if (savedUri != null || savedPath != null) {
                                                                    setMediaImage(mContext, savedUri, savedPath != null ? new File(savedPath) : null, uploadimage);
                                                                    progresslay.setVisibility(View.GONE);
                                                                    progressbar.stopSpinning();
                                                                    videoprogresslay.setVisibility(View.GONE);
                                                                } else {
                                                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                                }
                                                            } catch (NullPointerException e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    protected void onProgressUpdate(String... progress) {
                                                        // progressbar.setProgress(Integer.parseInt(progress[0]));
                                                    }
                                                };
                                                imageDownloader.execute(Constants.CHAT_IMG_PATH + message.attachment, Constants.TAG_IMAGE);
                                                progressbar.setVisibility(View.VISIBLE);
                                                progressbar.spin();
                                            }
                                        } else {
                                            requestStoragePermissions();
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_LOCATION: {
                        progresslay.setVisibility(View.GONE);
                        Glide.with(mContext).load(ApplicationClass.getMapUrl(message.lat, message.lon, mContext)).thumbnail(0.5f)
                                .into(uploadimage);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (!chatLongPressed && !isRecording) {
                                    stopAudioViewHolder();
                                    Intent i = new Intent(GroupChatActivity.this, LocationActivity.class);
                                    i.putExtra("from", "view");
                                    i.putExtra("lat", message.lat);
                                    i.putExtra("lon", message.lon);
                                    startActivity(i);
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_VIDEO: {
                        progresslay.setVisibility(View.VISIBLE);
                        progressbar.setVisibility(View.GONE);
                        downloadicon.setImageResource(R.drawable.play);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                        Uri videoUri;
                        Uri thumbUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            videoUri = storageManager.getFileUri(TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                            thumbUri = storageManager.getFileUri(TAG_THUMB, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                        } else {
                            File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                            File thumbFile = storageManager.getSrcFile(TAG_THUMB, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                            videoUri = storageManager.getUriFromFile(file);
                            thumbUri = storageManager.getUriFromFile(thumbFile);
                        }
                        if (videoUri != null) {
                            if (thumbUri != null) {
                                setMediaImage(mContext, thumbUri, null, uploadimage);
                                videoprogresslay.setVisibility(View.GONE);
                            } else {
                                setMediaImage(mContext, videoUri, null, uploadimage);
                                videoprogresslay.setVisibility(View.GONE);
                            }
                        } else {
                            setErrorImage(mContext, Constants.CHAT_IMG_PATH + message.thumbnail, uploadimage);
                            videoprogresslay.setVisibility(View.VISIBLE);
                            videoprogressbar.setVisibility(View.VISIBLE);
                            videoprogressbar.stopSpinning();
                        }
                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setClickEvent(false, false, false, false, true, false);
                                if (!chatLongPressed && !isRecording) {
                                    Uri videoUri;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        videoUri = storageManager.getFileUri(TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                                    } else {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                                        File thumbFile = storageManager.getSrcFile(TAG_THUMB, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                                        videoUri = storageManager.getUriFromFile(file);
                                    }
                                    if (videoUri != null) {
                                        stopAudioViewHolder();
                                        try {
                                            Intent intent = new Intent();
                                            intent.setAction(Intent.ACTION_VIEW);
                                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                            MimeTypeMap mime = MimeTypeMap.getSingleton();
                                            String ext = storageManager.getExtension(videoUri);
                                            String type = mime.getMimeTypeFromExtension(ext);
                                            intent.setDataAndType(videoUri, type);
                                            startActivity(intent);
                                        } catch (ActivityNotFoundException e) {
                                            Toast.makeText(GroupChatActivity.this, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                            e.printStackTrace();
                                        }
                                    } else {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            if (PermissionsUtils.checkStoragePermission(mContext)) {
                                                ImageDownloader imageDownloader = new ImageDownloader(GroupChatActivity.this) {
                                                    @Override
                                                    protected void onPostExecute(Bitmap downloadedBitmap) {
                                                        if (downloadedBitmap == null) {
                                                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                            videoprogresslay.setVisibility(View.GONE);
                                                            videoprogressbar.setVisibility(View.GONE);
                                                            videoprogressbar.stopSpinning();
                                                        } else {
                                                            try {
                                                                Uri thumbUri = null;
                                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                                    thumbUri = storageManager.saveImageInStorageV10(downloadedBitmap, getFileName(message.thumbnail), TAG_THUMB);
                                                                } else {
                                                                    File thumbFile = storageManager.saveImageInStorage(downloadedBitmap, getFileName(message.thumbnail), TAG_THUMB);
                                                                    thumbUri = storageManager.getUriFromFile(thumbFile);
                                                                }
                                                                if (thumbUri != null) {
                                                                    Uri finalThumbUri = thumbUri;

                                                                    DownloadFilesTask downloadFilesTask = new DownloadFilesTask(GroupChatActivity.this) {
                                                                        @Override
                                                                        protected void onPostExecute(String downPath) {
                                                                            videoprogresslay.setVisibility(View.GONE);
                                                                            videoprogressbar.setVisibility(View.GONE);
                                                                            videoprogressbar.stopSpinning();
                                                                            if (downPath == null) {
                                                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                                            } else {
                                                                                setMediaImage(mContext, finalThumbUri, null, uploadimage);
                                                                            }
                                                                        }
                                                                    };
                                                                    downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.messageType);
                                                                }
                                                            } catch (NullPointerException e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    protected void onProgressUpdate(String... progress) {
                                                        // progressbar.setProgress(Integer.parseInt(progress[0]));
                                                    }
                                                };
                                                imageDownloader.execute(Constants.CHAT_IMG_PATH + message.thumbnail, StorageManager.TAG_THUMB);
                                                videoprogresslay.setVisibility(View.VISIBLE);
                                                videoprogressbar.setVisibility(View.VISIBLE);
                                                videoprogressbar.spin();
                                            } else {
                                                requestStoragePermissions();
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_GIF: {
                        progresslay.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadimage.setVisibility(View.GONE);
                        videoprogresslay.setVisibility(View.GONE);
                        gifImage.setVisibility(View.VISIBLE);
                        setGifImage(mContext, message.attachment, gifImage);
                    }
                    break;
                }
            }

            private void loadBlurImage(GroupMessage message) {
                progresslay.setVisibility(View.VISIBLE);
                progressbar.setVisibility(View.VISIBLE);
                progressbar.stopSpinning();
                Glide.with(mContext).load(Constants.CHAT_IMG_PATH + message.attachment).thumbnail(0.5f)
                        .transform(new BlurTransformation(Constants.BLUR_RADIUS))
                        .into(uploadimage);
            }
        }

        private class SentFileHolder extends RecyclerView.ViewHolder {
            TextView filename, timeText, file_type_tv;
            ImageView icon, uploadicon;
            RelativeLayout file_body_lay;
            ProgressWheel progressbar;

            SentFileHolder(View itemView) {
                super(itemView);

                filename = itemView.findViewById(R.id.filename);
                timeText = itemView.findViewById(R.id.text_message_time);
                icon = itemView.findViewById(R.id.icon);
                file_body_lay = itemView.findViewById(R.id.file_body_lay);
                progressbar = itemView.findViewById(R.id.progressbar);
                uploadicon = itemView.findViewById(R.id.uploadicon);
                file_type_tv = itemView.findViewById(R.id.file_type_tv);
            }

            void bind(final GroupMessage message) {
                Log.d(TAG, "SentFileHolder: " + new Gson().toJson(message));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                if (message.messageType.equals(TAG_DOCUMENT)) {
                    icon.setImageResource(R.drawable.icon_file_unknown);
                    file_type_tv.setVisibility(View.VISIBLE);
                    file_type_tv.setText(firstThree(FilenameUtils.getExtension(message.attachment)));
                } else if (message.messageType.equals(StorageManager.TAG_AUDIO)) {
                    icon.setImageResource(R.drawable.mp3);
                    file_type_tv.setVisibility(View.GONE);
                }

                switch (message.progress) {
                    case "":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.spin();
                        uploadicon.setVisibility(View.VISIBLE);
                        filename.setText(getString(R.string.uploading));
                        break;
                    case "completed":
                        progressbar.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.GONE);
                        filename.setText(message.message);
                        break;
                    case "error":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.VISIBLE);
                        filename.setText(getString(R.string.retry));
                        break;
                }

                file_body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!chatLongPressed && !isRecording) {
                            if (message.progress.equals("error")) {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    try {
                                        progressbar.setVisibility(View.VISIBLE);
                                        progressbar.spin();
                                        uploadicon.setVisibility(View.VISIBLE);
                                        filename.setText(getString(R.string.uploading));
                                        dbHelper.updateGroupMessageData(message.messageId, Constants.TAG_PROGRESS, "");
                                        message.progress = "";
                                        String savedPath = "";
                                        File savedFile = storageManager.getSrcFile(TAG_DOCUMENT_SENT, getFileName(message.attachment), TAG_DOCUMENT);
                                        savedPath = savedFile.getAbsolutePath();
                                        if (!TextUtils.isEmpty(savedPath)) {
                                            Intent service = new Intent(mContext, FileUploadService.class);
                                            Bundle b = new Bundle();
                                            b.putSerializable("mdata", message);
                                            b.putString("filepath", savedPath);
                                            b.putString("chatType", "group");
                                            service.putExtras(b);
                                            startService(service);
                                        } else {
                                            Toast.makeText(mContext, mContext.getString(R.string.no_media_found), Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            } else if (message.progress.equals("completed")) {
                                File savedFile = storageManager.getSrcFile(TAG_DOCUMENT_SENT, getFileName(message.attachment), TAG_DOCUMENT);
                                Uri fileUri = storageManager.getUriFromFile(savedFile);
                                if (fileUri != null) {
                                    stopAudioViewHolder();
                                    try {
                                        Intent intent = new Intent();
                                        intent.setAction(Intent.ACTION_VIEW);
                                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                        intent.setDataAndType(fileUri, storageManager.getMimeTypeOfUri(mContext, fileUri));
                                        startActivity(intent);
                                    } catch (ActivityNotFoundException e) {
                                        Toast.makeText(mContext, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                        e.printStackTrace();
                                    }
                                } else {
                                    Toast.makeText(mContext, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });
            }
        }

        private class ReceivedFileHolder extends RecyclerView.ViewHolder {
            TextView filename, timeText, nameText, file_type_tv;
            ImageView icon, downloadicon;
            RelativeLayout file_body_lay;
            ProgressWheel progressbar;

            ReceivedFileHolder(View itemView) {
                super(itemView);

                filename = itemView.findViewById(R.id.filename);
                timeText = itemView.findViewById(R.id.text_message_time);
                icon = itemView.findViewById(R.id.icon);
                file_body_lay = itemView.findViewById(R.id.file_body_lay);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                progressbar = itemView.findViewById(R.id.progressbar);
                nameText = itemView.findViewById(R.id.text_message_sender);
                file_type_tv = itemView.findViewById(R.id.file_type_tv);
            }

            void bind(final GroupMessage message) {
                filename.setText(message.message);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                nameText.setVisibility(View.VISIBLE);
                nameText.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }

                if (message.messageType.equals(TAG_DOCUMENT)) {
                    icon.setImageResource(R.drawable.icon_file_unknown);
                    file_type_tv.setVisibility(View.VISIBLE);
                    file_type_tv.setText(firstThree(FilenameUtils.getExtension(message.attachment)));
                } else if (message.messageType.equals(TAG_AUDIO)) {
                    file_type_tv.setVisibility(View.GONE);
                    icon.setImageResource(R.drawable.mp3);
                }

                Uri documentUri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    documentUri = storageManager.getFileUri(TAG_DOCUMENT, getFileName(message.attachment), TAG_DOCUMENT);
                } else {
                    File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, getFileName(message.attachment), StorageManager.TAG_DOCUMENT);
                    documentUri = storageManager.getUriFromFile(file);
                }
                if (documentUri != null) {
                    downloadicon.setVisibility(View.GONE);
                    progressbar.setVisibility(View.GONE);
                } else {
                    downloadicon.setVisibility(View.VISIBLE);
                    progressbar.setVisibility(View.VISIBLE);
                    progressbar.stopSpinning();
                }
                file_body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setClickEvent(false, false, false, false, true, false);
                        if (!chatLongPressed && !isRecording) {
                            Uri documentUri;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                documentUri = storageManager.getFileUri(TAG_DOCUMENT, getFileName(message.attachment), TAG_DOCUMENT);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, getFileName(message.attachment), StorageManager.TAG_DOCUMENT);
                                documentUri = storageManager.getUriFromFile(file);
                            }
                            if (documentUri != null) {
                                try {
                                    stopAudioViewHolder();
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_VIEW);
                                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    String mimeType = storageManager.getMimeTypeOfUri(mContext, documentUri);
                                    intent.setDataAndType(documentUri, mimeType);
                                    startActivity(intent);
                                } catch (ActivityNotFoundException e) {
                                    Toast.makeText(GroupChatActivity.this, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                    e.printStackTrace();
                                }
                            } else {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                                        DownloadFilesTask downloadFilesTask = new DownloadFilesTask(GroupChatActivity.this) {
                                            @Override
                                            protected void onPostExecute(String downPath) {
                                                progressbar.setVisibility(View.GONE);
                                                progressbar.stopSpinning();
                                                downloadicon.setVisibility(View.GONE);
                                                if (downPath == null) {
                                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                } else {
                                                    //Toast.makeText(mContext, getString(R.string.downloaded), Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        };
                                        downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.messageType);
                                        progressbar.setVisibility(View.VISIBLE);
                                        progressbar.spin();
                                        downloadicon.setVisibility(View.VISIBLE);
                                    } else {
                                        requestStoragePermissions();
                                    }
                                }
                            }
                        }
                    }
                });
            }
        }

        private class SentContactHolder extends RecyclerView.ViewHolder {
            TextView username, phoneno, timeText;

            SentContactHolder(View itemView) {
                super(itemView);
                username = itemView.findViewById(R.id.username);
                phoneno = itemView.findViewById(R.id.phoneno);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(GroupMessage message) {
                username.setText(message.contactName);
                phoneno.setText(message.contactPhoneNo);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
            }
        }

        private class ReceivedContactHolder extends RecyclerView.ViewHolder {
            TextView username, phoneno, timeText, addcontact, nameText;

            ReceivedContactHolder(View itemView) {
                super(itemView);
                username = itemView.findViewById(R.id.username);
                phoneno = itemView.findViewById(R.id.phoneno);
                timeText = itemView.findViewById(R.id.text_message_time);
                addcontact = itemView.findViewById(R.id.addcontact);
                nameText = itemView.findViewById(R.id.text_message_sender);
            }

            void bind(final GroupMessage message) {
                username.setText(message.contactName);
                phoneno.setText(message.contactPhoneNo);
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                nameText.setVisibility(View.VISIBLE);
                nameText.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                addcontact.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!chatLongPressed && !isRecording) {
                            stopAudioViewHolder();
                            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                            intent.putExtra(ContactsContract.Intents.Insert.PHONE, message.contactPhoneNo);
                            intent.putExtra(ContactsContract.Intents.Insert.NAME, message.contactName);
                            startActivity(intent);
                        }
                    }
                });
            }
        }

        private class DateHolder extends RecyclerView.ViewHolder {
            TextView timeText;

            DateHolder(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(final GroupMessage message) {
                setSectionMessage(mContext, message, timeText);
            }
        }

        private class DeleteMsgSent extends RecyclerView.ViewHolder {
            TextView timeText;

            DeleteMsgSent(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(final GroupMessage message) {
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
            }
        }

        private class DeleteMsgReceived extends RecyclerView.ViewHolder {
            TextView timeText, nameText;

            DeleteMsgReceived(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
                nameText = itemView.findViewById(R.id.text_message_sender);
            }

            void bind(final GroupMessage message) {
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                timeText.setText(dateUtils.getTimeFromUTC(message.chatTime));
                nameText.setVisibility(View.VISIBLE);
                nameText.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
            }
        }

        private class SentVoiceHolder extends RecyclerView.ViewHolder {

            ImageView icon, tickimage, uploadicon;
            TextView duration, msg_time, filename;
            SeekBar seekbar;
            ConstraintLayout body_lay;
            ProgressWheel progressbar;
            Context context;

            SentVoiceHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                icon = itemView.findViewById(R.id.icon);
                tickimage = itemView.findViewById(R.id.tickimage);
                duration = itemView.findViewById(R.id.duration);
                msg_time = itemView.findViewById(R.id.text_message_time);
                body_lay = itemView.findViewById(R.id.body_lay);
                progressbar = itemView.findViewById(R.id.progressbar);
                uploadicon = itemView.findViewById(R.id.uploadicon);
                filename = itemView.findViewById(R.id.filename);
                seekbar = itemView.findViewById(R.id.song_seekbar);

            }

            void bind(final GroupMessage message, int pos) {
                Log.i(TAG, "SentVoiceHolder: " + new Gson().toJson(message));
                /*Check message id equals to already playing message id*/
                if (currentMessageId != null && currentMessageId.equals(message.messageId)) {
                    if (MediaPlayerUtils.isPlaying()) {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.play_icon_white));
                        seekbar.setMax(MediaPlayerUtils.getTotalDuration());
                        seekbar.setProgress(MediaPlayerUtils.getCurrentDuration());
                    } else {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        if (file != null) {
                            long totalDuration = storageManager.getMediaDuration(file);
                            duration.setText(milliSecondsToTimer(totalDuration));
                        }
                    }
                    seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            if (fromUser && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                MediaPlayerUtils.applySeekBarValue(progress);
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                            }
                        }
                    });
                } else {
                    icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                    seekbar.setProgress(0);
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                    if (file != null) {
                        long totalDuration = storageManager.getMediaDuration(file);
                        seekbar.setMax((int) totalDuration);
                        duration.setText(milliSecondsToTimer(totalDuration));
                        duration.setVisibility(View.VISIBLE);
                        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                            @Override
                            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                if (fromUser && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                    MediaPlayerUtils.applySeekBarValue(progress);
                                }
                            }

                            @Override
                            public void onStartTrackingTouch(SeekBar seekBar) {

                            }

                            @Override
                            public void onStopTrackingTouch(SeekBar seekBar) {
                                if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                }
                            }
                        });
                    } else {
                        seekbar.setMax(0);
                        duration.setVisibility(View.GONE);
                    }
                }
                msg_time.setText(dateUtils.getTimeFromUTC(message.chatTime));

                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                switch (message.progress) {
                    case "":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.spin();
                        uploadicon.setVisibility(View.VISIBLE);
                        seekbar.setVisibility(View.INVISIBLE);
                        filename.setText(R.string.uploading);
                        filename.setVisibility(View.VISIBLE);
                        break;
                    case "completed":
                        progressbar.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.GONE);
                        seekbar.setVisibility(View.VISIBLE);
                        icon.setVisibility(View.VISIBLE);
                        filename.setVisibility(View.GONE);
                        duration.setVisibility(View.VISIBLE);
                        break;
                    case "error":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.VISIBLE);
                        seekbar.setVisibility(View.INVISIBLE);
                        icon.setVisibility(View.GONE);
                        filename.setText(R.string.retry);
                        filename.setVisibility(View.VISIBLE);
                        break;
                }

                if (message.deliveryStatus != null) {
                    switch (message.deliveryStatus) {
                        case "read":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            break;
                        case "sent":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            break;
                        default:
                            if (message.progress.equals("") || message.progress.equals("error")) {
                                tickimage.setVisibility(View.GONE);
                            } else {
                                tickimage.setVisibility(View.VISIBLE);
                            }
                            tickimage.setImageResource(R.drawable.single_tick);
                            break;
                    }
                }

                body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!chatLongPressed && !isRecording) {
                            if (message.progress.equals("error")) {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    try {
                                        progressbar.setVisibility(View.VISIBLE);
                                        progressbar.spin();
                                        uploadicon.setVisibility(View.VISIBLE);
                                        filename.setText(getString(R.string.uploading));
                                        dbHelper.updateGroupMessageData(message.messageId, Constants.TAG_PROGRESS, "");
                                        message.progress = "";
                                        String savedPath = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName((message.attachment)), TAG_AUDIO).getAbsolutePath();
                                        Intent service = new Intent(mContext, FileUploadService.class);
                                        Bundle b = new Bundle();
                                        b.putSerializable("mdata", message);
                                        b.putString("filepath", savedPath);
                                        b.putString("chatType", "group");
                                        service.putExtras(b);
                                        startService(service);
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            }
                        }

                    }
                });

                icon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!chatLongPressed && !isRecording) {
                            File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            Uri voiceURI = storageManager.getUriFromFile(file);
                            if (voiceURI != null) {
                                duration.setVisibility(View.VISIBLE);
                                if (currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                    if (MediaPlayerUtils.isPlaying()) {
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                        MediaPlayerUtils.pauseMediaPlayer();
                                    } else {
                                        seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                        startPlayer(voiceURI, seekbar.getProgress(), context);
                                    }
                                } else {
                                    stopAudioViewHolder();
                                    currentMessageId = message.messageId;
                                    seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                    startPlayer(voiceURI, seekbar.getProgress(), context);
                                }
                            } else {
                                Toast.makeText(context, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });

                seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if (fromUser && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                            MediaPlayerUtils.applySeekBarValue(progress);
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                        }
                    }
                });
            }
        }

        private class ReceiveVoiceHolder extends RecyclerView.ViewHolder {

            ImageView icon, tickimage, downloadIcon;
            TextView duration, msg_time, file_name, txtSenderName;
            SeekBar seekbar;
            ConstraintLayout body_lay;
            ProgressWheel progressbar;
            Context context;

            ReceiveVoiceHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                icon = itemView.findViewById(R.id.icon);
                txtSenderName = itemView.findViewById(R.id.text_message_sender);
                duration = itemView.findViewById(R.id.duration);
                msg_time = itemView.findViewById(R.id.text_message_time);
                seekbar = itemView.findViewById(R.id.song_seekbar);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadIcon = itemView.findViewById(R.id.downloadicon);
                file_name = itemView.findViewById(R.id.filename);
                body_lay = itemView.findViewById(R.id.body_lay);
            }

            void bind(final GroupMessage message, int pos) {
                Log.d(TAG, "ReceiveVoiceHolder: " + new Gson().toJson(message));
                /*Check message id equals to already playing message id*/
                if (currentMessageId != null && currentMessageId.equals(message.messageId)) {
                    if (MediaPlayerUtils.isPlaying()) {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.play_icon_white));
                        seekbar.setMax(MediaPlayerUtils.getTotalDuration());
                        seekbar.setProgress(MediaPlayerUtils.getCurrentDuration());
                    } else {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                        Uri voiceURI = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        } else {
                            File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            voiceURI = storageManager.getUriFromFile(file);
                        }
                        if (voiceURI != null) {
                            setAudioUri(message, voiceURI);
                        }
                    }
                    seekbar.setEnabled(true);
                    seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            if (fromUser && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                MediaPlayerUtils.applySeekBarValue(progress);
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                            }
                        }
                    });
                } else {
                    icon.setImageResource(R.drawable.pause_icon_white);
                    seekbar.getProgressDrawable().setColorFilter(ContextCompat.getColor(context, R.color.white), PorterDuff.Mode.MULTIPLY);
                    Uri voiceURI = null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        voiceURI = storageManager.getUriFromFile(file);
                    }
                    if (voiceURI != null) {
                        setAudioUri(message, voiceURI);
                    } else {
                        setError();
                    }
                    seekbar.setProgress(0);
                }
                seekbar.getProgressDrawable().setColorFilter(Color.parseColor("#ffffff"), PorterDuff.Mode.MULTIPLY);
                txtSenderName.setVisibility(View.VISIBLE);
                txtSenderName.setText(ApplicationClass.getContactName(mContext, dbHelper.getContactPhone(message.memberId), dbHelper.getContactCountryCode(message.memberId)));
                msg_time.setText(dateUtils.getTimeFromUTC(message.chatTime));

                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }

                body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setClickEvent(false, false, false, false, true, false);
                        if (!chatLongPressed && !isRecording) {
                            Uri voiceURI = null;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                                voiceURI = storageManager.getUriFromFile(file);
                            }
                            if (voiceURI != null) {
                                body_lay.setEnabled(false);
                            } else {
                                downloadFile(message);
                            }
                        }
                    }
                });

                icon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!chatLongPressed && !isRecording) {
                            Uri voiceURI = null;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                                voiceURI = storageManager.getUriFromFile(file);
                            }
                            if (voiceURI != null) {
                                duration.setVisibility(View.VISIBLE);
                                if (currentMessageId != null && currentMessageId.equals(message.messageId)) {
                                    if (MediaPlayerUtils.isPlaying()) {
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                        MediaPlayerUtils.pauseMediaPlayer();
                                    } else {
                                        seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                        startPlayer(voiceURI, seekbar.getProgress(), context);
                                    }
                                } else {
                                    stopAudioViewHolder();
                                    currentMessageId = message.messageId;
                                    seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                    startPlayer(voiceURI, seekbar.getProgress(), context);
                                }
                            } else {
                                Toast.makeText(context, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                            }
                        }

                    }

                });

            }

            private void downloadFile(GroupMessage message) {
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        DownloadFilesTask downloadFilesTask = new DownloadFilesTask(GroupChatActivity.this) {
                            @Override
                            protected void onPostExecute(String downPath) {
                                if (TextUtils.isEmpty(downPath)) {
                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                } else {
                                    Uri voiceURI = null;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        voiceURI = Uri.parse(downPath);
                                    } else {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                                        voiceURI = storageManager.getUriFromFile(file);
                                    }
                                    if (voiceURI != null) {
                                        setAudioUri(message, voiceURI);
                                    }
                                }
                            }
                        };
                        downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.messageType);
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.spin();
                        downloadIcon.setVisibility(View.VISIBLE);
                        icon.setEnabled(true);
                        duration.setEnabled(true);
                        seekbar.setEnabled(true);
                    } else {
                        requestStoragePermissions();
                    }

                }
            }

            private void setAudioUri(GroupMessage message, Uri voiceURI) {
                downloadIcon.setVisibility(View.GONE);
                progressbar.setVisibility(View.GONE);
                duration.setVisibility(View.VISIBLE);
                long totalDuration = storageManager.getAudioDuration(context, voiceURI, TAG_AUDIO);
                duration.setText(milliSecondsToTimer(totalDuration));
                seekbar.setProgress(0);
                seekbar.setMax((int) totalDuration);
                icon.setEnabled(true);
                seekbar.setEnabled(true);
                seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if (fromUser && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                            MediaPlayerUtils.applySeekBarValue(progress);
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.messageId)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                        }
                    }
                });

            }

            public void setError() {
                downloadIcon.setVisibility(View.VISIBLE);
                progressbar.setVisibility(View.VISIBLE);
                duration.setVisibility(View.GONE);
                icon.setEnabled(false);
                seekbar.setEnabled(false);
                progressbar.stopSpinning();
            }
        }

        private void startPlayer(Uri voiceURI, int progress, Context context) {
            try {
                MediaPlayerUtils.startAndPlayMediaPlayer(context, voiceURI, GroupChatActivity.this, progress);
            } catch (IOException e) {
                Log.e(TAG, "startPlayer: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private String milliSecondsToTimer(long milliseconds) {
            String finalTimerString = "";
            String secondsString = "";

            // Convert total duration into time
            int hours = (int) (milliseconds / (1000 * 60 * 60));
            int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
            int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
            // Add hours if there
            if (hours > 0) {
                finalTimerString = hours + ":";
            }

            // Prepending 0 to seconds if it is one digit
            if (seconds < 10) {
                secondsString = "0" + seconds;
            } else {
                secondsString = "" + seconds;
            }

            finalTimerString = finalTimerString + minutes + ":" + secondsString;

            // return timer string
            return finalTimerString;
        }
    }

}
