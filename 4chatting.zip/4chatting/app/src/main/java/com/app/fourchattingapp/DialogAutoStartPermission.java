package com.app.fourchattingapp;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.DialogFragment;

import com.app.helper.callback.OkCallback;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

import static android.content.Context.MODE_PRIVATE;

public class DialogAutoStartPermission extends DialogFragment {

    private static final String TAG = DialogAutoStartPermission.class.getSimpleName();
    private AppCompatTextView txtTitle;
    private ImageView dimenImage;
    private AppCompatTextView txtBackgroundPopup, txtPopup, txtDescription;
    private Button btnAllow, btnDeny;
    private Context context;
    private OkCallback callBack;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.transparent_black)));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            Window window = dialog.getWindow();
            WindowManager.LayoutParams wlp = window.getAttributes();
            wlp.gravity = Gravity.CENTER;
            // wlp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
            window.setAttributes(wlp);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup
            container, @Nullable Bundle savedInstanceState) {
        View itemView = inflater.inflate(R.layout.dialog_autostart_permission, container, false);
        preferences = context.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = preferences.edit();
        findViews(itemView);
        return itemView;

    }

    private void findViews(View itemView) {
        txtTitle = (AppCompatTextView) itemView.findViewById(R.id.txtTitle);
        dimenImage = (ImageView) itemView.findViewById(R.id.dimenImage);
        txtDescription = (AppCompatTextView) itemView.findViewById(R.id.txtDescription);
        btnAllow = (Button) itemView.findViewById(R.id.btnAllow);
        btnDeny = (Button) itemView.findViewById(R.id.btnDeny);

        btnAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putBoolean(Constants.AUTO_START_WINDOW_PERMISSION, false).apply();
                callBack.onOkClicked(true);
            }
        });

        btnDeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putBoolean(Constants.AUTO_START_WINDOW_PERMISSION, false).apply();
                callBack.onOkClicked(false);
            }
        });
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        editor.putBoolean(Constants.AUTO_START_WINDOW_PERMISSION, false).apply();
        super.onDismiss(dialog);
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public void setCallBack(OkCallback callBack) {
        this.callBack = callBack;
    }
}
