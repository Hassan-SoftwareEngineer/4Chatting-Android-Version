package com.app.helper;

import static com.app.utils.Constants.MEMBER;
import static com.app.utils.Constants.TAG_CHANNEL_ID;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_GROUP_MEMBERS;
import static com.app.utils.Constants.TAG_MEMBER_ID;
import static com.app.utils.Constants.TAG_MEMBER_NO;
import static com.app.utils.Constants.TAG_PRIVACY_ABOUT;
import static com.app.utils.Constants.TAG_PRIVACY_LAST_SEEN;
import static com.app.utils.Constants.TAG_PRIVACY_PROFILE;
import static com.app.utils.Constants.TAG_USER_ID;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.GroupFragment;
import com.app.model.CallData;
import com.app.model.ChannelMessage;
import com.app.model.ChannelResult;
import com.app.model.GroupData;
import com.app.model.MessagesData;
import com.app.model.StatusDatas;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;
import com.app.model.AdminChannel;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.model.MediaModelData;
import com.app.model.RecentMessages;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by hitasoft on 30/5/18.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String TAG = DatabaseHandler.class.getSimpleName();
    // Database Info
    private static final String DATABASE_NAME = "db";
    private static final int DATABASE_VERSION = 6;
    private static DatabaseHandler sInstance;
    // Table Names
    private static final String TABLE_CONTACTS = "contacts";
    private static final String TABLE_MESSAGES = "messages";
    private static final String TABLE_RECENTS = "recents";
    private static final String TABLE_GROUP = "group_table";
    private static final String TABLE_GROUP_MEMBERS = "group_members";
    private static final String TABLE_GROUP_MESSAGES = "group_messages";
    private static final String TABLE_GROUP_RECENT_MESSAGES = "group_recent_messages";
    private static final String TABLE_CHANNEL = "channel";
    private static final String TABLE_CHANNEL_MESSAGES = "channel_messages";
    private static final String TABLE_CHANNEL_RECENT_MESSAGES = "channel_recent_messages";
    private static final String TABLE_CALL = "call";
    private static final String TABLE_STATUS = "status";
    private static final String TABLE_STATUS_VIEW = "status_view";
    private static final String[] ALL_TABLES = new String[]{TABLE_CONTACTS, TABLE_MESSAGES,
            TABLE_RECENTS, TABLE_GROUP, TABLE_GROUP_MEMBERS, TABLE_GROUP_MESSAGES, TABLE_GROUP_RECENT_MESSAGES,
            TABLE_CHANNEL, TABLE_CHANNEL_MESSAGES, TABLE_CHANNEL_RECENT_MESSAGES, TABLE_CALL, TABLE_STATUS, TABLE_STATUS_VIEW};

    private StorageManager storageManager;
    private DateUtils dateUtils;
    private File dbFile;
    private static Context mContext;

    /**
     * Constructor should be private to prevent direct instantiation.
     * Make a call to the static method "getInstance()" instead.
     */
    private DatabaseHandler(Context context) {
        super(context, context.getString(R.string.app_name) + DATABASE_NAME, null, DATABASE_VERSION);
        mContext = context;
        storageManager = StorageManager.getInstance(context);
        dateUtils = DateUtils.getInstance(context);
        /*dbFile = mContext.getDatabasePath(DATABASE_NAME);
        if (!dbFile.getParentFile().exists()) {
            dbFile.getParentFile().mkdirs();
        }*/
    }

    public static synchronized DatabaseHandler getInstance(Context context) {
        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        // See this article for more information: http://bit.ly/6LRzfx
        if (sInstance == null) {
            mContext = context;
            sInstance = new DatabaseHandler(context.getApplicationContext());
        }
        return sInstance;
    }

    // Called when the database is created for the FIRST time.
    // If a database already exists on disk with the same DATABASE_NAME, this method will NOT be called.
    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_CONTACT_TABLE = "CREATE TABLE " + TABLE_CONTACTS +
                "(" +
                Constants.TAG_USER_ID + " TEXT PRIMARY KEY," + Constants.TAG_USER_NAME + " TEXT," +
                Constants.TAG_PHONE_NUMBER + " TEXT," + Constants.TAG_COUNTRY_CODE + " TEXT," + Constants.TAG_USER_IMAGE + " TEXT," +
                TAG_PRIVACY_ABOUT + " TEXT," + TAG_PRIVACY_LAST_SEEN + " TEXT," + TAG_PRIVACY_PROFILE + " TEXT," +
                Constants.TAG_BLOCKED_ME + " TEXT," + Constants.TAG_BLOCKED_BYME + " TEXT," + Constants.TAG_ABOUT + " TEXT," +
                Constants.TAG_MUTE_NOTIFICATION + " TEXT," + Constants.TAG_CONTACT_STATUS + " TEXT," + Constants.TAG_SAVED_NAME + " TEXT," +
                Constants.TAG_MUTE_STATUS + " TEXT," + Constants.TAG_FAVOURITED + " TEXT," + Constants.TAG_DELETED_ACCOUNT + " TEXT, " +
                Constants.TAG_WALLPAPER + " TEXT, " + Constants.TAG_UNKNOWN_CONTACT + " TEXT" + ")";

        String CREATE_MESSAGES_TABLE = "CREATE TABLE " + TABLE_MESSAGES +
                "(" +
                Constants.TAG_CHAT_ID + " TEXT," + Constants.TAG_MESSAGE_ID + " TEXT PRIMARY KEY," + TAG_USER_ID + " TEXT," + Constants.TAG_USER_NAME + " TEXT," +
                Constants.TAG_MESSAGE_TYPE + " TEXT," + Constants.TAG_MESSAGE + " TEXT," + Constants.TAG_ATTACHMENT + " TEXT," +
                Constants.TAG_LAT + " TEXT," + Constants.TAG_LON + " TEXT," + Constants.TAG_CONTACT_NAME + " TEXT," +
                Constants.TAG_CONTACT_PHONE_NO + " TEXT," + Constants.TAG_CONTACT_COUNTRY_CODE + " TEXT," + Constants.TAG_CHAT_TIME + " TEXT," +
                Constants.TAG_RECEIVER_ID + " TEXT," + Constants.TAG_SENDER_ID + " TEXT," + Constants.TAG_DELIVERY_STATUS + " TEXT," + Constants.TAG_THUMBNAIL
                + " TEXT," + Constants.TAG_STATUS_DATA + " TEXT," + Constants.TAG_PROGRESS + " TEXT" + ")";

        String CREATE_RECENT_TABLE = "CREATE TABLE " + TABLE_RECENTS +
                "(" +
                Constants.TAG_CHAT_ID + " TEXT PRIMARY KEY," + Constants.TAG_USER_ID + " TEXT," + Constants.TAG_MESSAGE_ID + " TEXT," +
                Constants.TAG_CHAT_TIME + " TEXT," + Constants.TAG_UNREAD_COUNT + " TEXT" + ")";

        String CREATE_GROUP_TABLE = "CREATE TABLE " + TABLE_GROUP + "(" +
                Constants.TAG_GROUP_ID + " TEXT PRIMARY KEY," + Constants.TAG_GROUP_NAME + " TEXT, " + Constants.TAG_GROUP_CREATED_BY + " TEXT, " +
                Constants.TAG_CREATED_AT + " TEXT, " + Constants.TAG_GROUP_IMAGE + " TEXT, " + Constants.TAG_MUTE_NOTIFICATION + " TEXT, " +
                Constants.TAG_WALLPAPER + " TEXT" + ")";

        String CREATE_GROUP_MEMBERS_TABLE = "CREATE TABLE " + TABLE_GROUP_MEMBERS + "(" +
                Constants.TAG_MEMBER_KEY + " TEXT PRIMARY KEY," + Constants.TAG_GROUP_ID + " TEXT," + Constants.TAG_MEMBER_ID + " TEXT, " + Constants.TAG_MEMBER_ROLE + " TEXT " + ")";

        String CREATE_TABLE_GROUP_MESSAGES = "CREATE TABLE " + TABLE_GROUP_MESSAGES +
                "(" + Constants.TAG_MESSAGE_ID + " TEXT PRIMARY KEY," + Constants.TAG_GROUP_ID + " TEXT," + Constants.TAG_MEMBER_ID + " TEXT," + Constants.TAG_GROUP_ADMIN_ID + " TEXT," +
                Constants.TAG_MESSAGE_TYPE + " TEXT," + Constants.TAG_MESSAGE + " TEXT," + Constants.TAG_ATTACHMENT + " TEXT," + Constants.TAG_LAT + " TEXT," +
                Constants.TAG_LON + " TEXT," + Constants.TAG_CONTACT_NAME + " TEXT," + Constants.TAG_CONTACT_PHONE_NO + " TEXT," +
                Constants.TAG_CONTACT_COUNTRY_CODE + " TEXT," + Constants.TAG_CHAT_TIME + " TEXT," + Constants.TAG_DELIVERY_STATUS + " TEXT," + Constants.TAG_THUMBNAIL + " TEXT,"
                + Constants.TAG_IS_DELETE + " TEXT," + Constants.TAG_PROGRESS + " TEXT " + ")";

        String CREATE_TABLE_GROUP_RECENT_MESSAGES = "CREATE TABLE " + TABLE_GROUP_RECENT_MESSAGES +
                "(" +
                Constants.TAG_GROUP_ID + " TEXT PRIMARY KEY," + Constants.TAG_MESSAGE_ID + " TEXT," +
                Constants.TAG_MEMBER_ID + " TEXT," + Constants.TAG_CHAT_TIME + " TEXT," + Constants.TAG_IS_DELETE + " TEXT," + Constants.TAG_UNREAD_COUNT + " TEXT" + ")";

        String CREATE_TABLE_CHANNEL = "CREATE TABLE " + TABLE_CHANNEL +
                "(" +
                Constants.TAG_CHANNEL_ID + " TEXT PRIMARY KEY," + Constants.TAG_CHANNEL_NAME + " TEXT," +
                Constants.TAG_CHANNEL_DES + " TEXT," + Constants.TAG_CHANNEL_IMAGE + " TEXT," + Constants.TAG_CHANNEL_TYPE + " TEXT," +
                Constants.TAG_CHANNEL_ADMIN_ID + " TEXT," + Constants.TAG_CHANNEL_ADMIN_NAME + " TEXT," + Constants.TAG_TOTAL_SUBSCRIBERS + " TEXT," + Constants.TAG_CREATED_AT + " TEXT," +
                Constants.TAG_SUBSCRIBE_STATUS + " TEXT," + Constants.TAG_CHANNEL_CATEGORY + " TEXT," + Constants.TAG_MUTE_NOTIFICATION + " TEXT," + Constants.TAG_REPORT + " TEXT," +
                Constants.TAG_BLOCK_STATUS + " TEXT, " + Constants.TAG_WALLPAPER + " TEXT" + ")";

        String CREATE_TABLE_CHANNEL_MESSAGES = "CREATE TABLE " + TABLE_CHANNEL_MESSAGES +
                "(" + Constants.TAG_MESSAGE_ID + " TEXT PRIMARY KEY," + Constants.TAG_CHANNEL_ID + " TEXT," +
                Constants.TAG_CHAT_TYPE + " TEXT," + Constants.TAG_MESSAGE_TYPE + " TEXT," + Constants.TAG_MESSAGE + " TEXT," + Constants.TAG_ATTACHMENT + " TEXT," + Constants.TAG_LAT + " TEXT," +
                Constants.TAG_LON + " TEXT," + Constants.TAG_CONTACT_NAME + " TEXT," + Constants.TAG_CONTACT_PHONE_NO + " TEXT," +
                Constants.TAG_CONTACT_COUNTRY_CODE + " TEXT," + Constants.TAG_CHAT_TIME + " TEXT," + Constants.TAG_IS_DELETE + " TEXT," + Constants.TAG_DELIVERY_STATUS + " TEXT," + Constants.TAG_THUMBNAIL + " TEXT," + Constants.TAG_PROGRESS + " TEXT " + ")";

        String CREATE_TABLE_CHANNEL_RECENT_MESSAGES = "CREATE TABLE " + TABLE_CHANNEL_RECENT_MESSAGES +
                "(" +
                Constants.TAG_CHANNEL_ID + " TEXT PRIMARY KEY," + Constants.TAG_MESSAGE_ID + " TEXT," +
                Constants.TAG_CHAT_TIME + " TEXT," + Constants.TAG_IS_DELETE + " TEXT," + Constants.TAG_UNREAD_COUNT + " TEXT" + ")";

        String CREATE_CALL_TABLE = "CREATE TABLE " + TABLE_CALL + "(" +
                Constants.TAG_CALL_ID + " TEXT PRIMARY KEY," + Constants.TAG_USER_ID + " TEXT, " + Constants.TAG_TYPE + " TEXT, " + Constants.TAG_IS_ALERT + " TEXT, " +
                Constants.TAG_CALL_STATUS + " TEXT, " + Constants.TAG_CREATED_AT + " TEXT" + ")";


        String CREATE_STATUS_TABLE = "CREATE TABLE " + TABLE_STATUS + "(" +
                Constants.TAG_STATUS_ID + " TEXT PRIMARY KEY," + Constants.TAG_STATUS_TIME + " TEXT, " + Constants.TAG_EXPIRY_TIME + " TEXT, "
                + Constants.TAG_TYPE + " TEXT, " + Constants.TAG_ATTACHMENT + " TEXT, " + Constants.TAG_THUMBNAIL + " TEXT, "
                + Constants.TAG_MESSAGE + " TEXT, " + Constants.TAG_SENDER_ID + " TEXT, " + Constants.TAG_CHAT_ID + " TEXT, " + Constants.TAG_STORY_MEMBERS + " TEXT, "
                + Constants.TAG_STATUS_VIEW + " TEXT" + ")";

        String CREATE_STATUS_VIEW_TABLE = "CREATE TABLE " + TABLE_STATUS_VIEW + "(" + Constants.TAG_MEMBER_KEY + " TEXT PRIMARY KEY," +
                Constants.TAG_STATUS_ID + " TEXT," + Constants.TAG_STATUS_TIME + " TEXT, " + Constants.TAG_MEMBER_ID + " TEXT " + ")";

        db.execSQL(CREATE_CONTACT_TABLE);
        db.execSQL(CREATE_MESSAGES_TABLE);
        db.execSQL(CREATE_RECENT_TABLE);
        db.execSQL(CREATE_GROUP_TABLE);
        db.execSQL(CREATE_GROUP_MEMBERS_TABLE);
        db.execSQL(CREATE_TABLE_GROUP_MESSAGES);
        db.execSQL(CREATE_TABLE_GROUP_RECENT_MESSAGES);
        db.execSQL(CREATE_TABLE_CHANNEL);
        db.execSQL(CREATE_TABLE_CHANNEL_MESSAGES);
        db.execSQL(CREATE_TABLE_CHANNEL_RECENT_MESSAGES);
        db.execSQL(CREATE_CALL_TABLE);
        db.execSQL(CREATE_STATUS_TABLE);
        db.execSQL(CREATE_STATUS_VIEW_TABLE);
    }

    // Called when the database needs to be upgraded.
    // This method will only be called if a database already exists on disk with the same DATABASE_NAME,
    // but the DATABASE_VERSION is different than the version of the database that exists on disk.
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        Log.e(TAG, "onUpgrade: " + oldVersion + " " + newVersion);
        if (oldVersion < DATABASE_VERSION) {
//            dropTables(sqLiteDatabase);
            upgradeTables(sqLiteDatabase);
        }
    }

    private void upgradeTables(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("ALTER TABLE " + TABLE_CONTACTS + "  ADD COLUMN " + Constants.TAG_UNKNOWN_CONTACT + " TEXT");
    }

    private void dropTables(SQLiteDatabase sqLiteDatabase) {
        for (String tableName : ALL_TABLES) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" + tableName + "'");
        }
        onCreate(sqLiteDatabase);
    }



    @Override
    public synchronized void close() {
        super.close();
    }

    // Insert a contact into the database
    public void addContactDetails(String savedName, String id, String name, String number, String countrycode,
                                  String image, String aboutprivacy, String lastseenprivacy,
                                  String profileprivacy, String about, String contactstatus) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            boolean exists = isUserExist(db, id);
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_USER_ID, id);
            values.put(Constants.TAG_USER_NAME, name);
            values.put(Constants.TAG_PHONE_NUMBER, number);
            values.put(Constants.TAG_COUNTRY_CODE, countrycode);
            values.put(Constants.TAG_USER_IMAGE, image);
            values.put(Constants.TAG_PRIVACY_ABOUT, aboutprivacy);
            values.put(Constants.TAG_PRIVACY_LAST_SEEN, lastseenprivacy);
            values.put(Constants.TAG_PRIVACY_PROFILE, profileprivacy);
            values.put(Constants.TAG_ABOUT, about);
            values.put(Constants.TAG_CONTACT_STATUS, contactstatus);
            values.put(Constants.TAG_SAVED_NAME, savedName);
            values.put(Constants.TAG_UNKNOWN_CONTACT, "" + 0);

            /*HashMap<String, String> map = ApplicationClass.getContactOrNot(context, number);
            if (map.get("isAlready").equals("true"))
                values.put(Constants.TAG_SAVED_NAME,map.get(Constants.TAG_USER_NAME));*/

            if (exists) {
                db.update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                        new String[]{id});
            } else {
                values.put(Constants.TAG_BLOCKED_ME, "");
                values.put(Constants.TAG_BLOCKED_BYME, "");
                values.put(Constants.TAG_MUTE_NOTIFICATION, "");
                values.put(Constants.TAG_FAVOURITED, "false");
                db.insert(TABLE_CONTACTS, null, values);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Insert a contact into the database
    public void addContactDetails(String savedName, ContactsData.Result result) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            boolean exists = isUserExist(db, result.user_id);
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_USER_ID, result.user_id);
            values.put(Constants.TAG_USER_NAME, result.user_name);
            values.put(Constants.TAG_PHONE_NUMBER, result.phone_no);
            values.put(Constants.TAG_COUNTRY_CODE, result.country_code);
            values.put(Constants.TAG_USER_IMAGE, result.user_image);
            values.put(Constants.TAG_PRIVACY_ABOUT, result.privacy_about);
            values.put(Constants.TAG_PRIVACY_LAST_SEEN, result.privacy_last_seen);
            values.put(Constants.TAG_PRIVACY_PROFILE, result.privacy_profile_image);
            values.put(Constants.TAG_ABOUT, result.about);
            values.put(Constants.TAG_CONTACT_STATUS, result.contactstatus);
            values.put(Constants.TAG_DELETED_ACCOUNT, TextUtils.isEmpty(result.isDeletedAccount) ? "0" : result.isDeletedAccount);
            values.put(Constants.TAG_SAVED_NAME, savedName);
            values.put(Constants.TAG_UNKNOWN_CONTACT, "" + result.isUnknownContact);

            /*HashMap<String, String> map = ApplicationClass.getContactrNot(context, number);
            if (map.get("isAlready").equals("true"))
                values.put(Constants.TAG_SAVED_NAME,map.get(Constants.TAG_USER_NAME));*/

            Log.e("checkTabledelete","-"+values+" userid "+result.user_id);
            if (exists) {
                db.update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                        new String[]{result.user_id});
            } else {
                values.put(Constants.TAG_BLOCKED_ME, "");
                values.put(Constants.TAG_BLOCKED_BYME, "");
                values.put(Constants.TAG_MUTE_NOTIFICATION, "");
                values.put(Constants.TAG_FAVOURITED, "false");
                db.insert(TABLE_CONTACTS, null, values);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateContactInfo(String userId, String key, String value) {
        if (isUserExist(userId)) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(key, value);
            db.update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                    new String[]{userId});
        }
    }

    public void updateDeletedContacts(Context context, String myContacts) {
        String selectQuery = "UPDATE " + TABLE_CONTACTS + " SET " + Constants.TAG_DELETED_ACCOUNT + " ='1'" +
                " WHERE " + TAG_USER_ID + " NOT IN " + "(" + myContacts + ")" + " AND (" +
                Constants.TAG_DELETED_ACCOUNT + " ISNULL OR " + Constants.TAG_DELETED_ACCOUNT + " == '0' OR " +
                Constants.TAG_DELETED_ACCOUNT + " == ''" + ")" + " AND (" + Constants.TAG_UNKNOWN_CONTACT + " ISNULL OR " +
                Constants.TAG_UNKNOWN_CONTACT + " != '1')";
        Log.d(TAG, "updateDeletedContacts: " + selectQuery);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        cursor.moveToFirst();
        cursor.close();
    }

    public boolean isUserExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isGroupExist(SQLiteDatabase db, String groupId) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP + " WHERE " + Constants.TAG_GROUP_ID + "=?",
                new String[]{groupId});
        return line > 0;
    }

    public boolean isGroupExist(String groupId) {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_GROUP + " WHERE " + Constants.TAG_GROUP_ID + "=?",
                new String[]{groupId});
        return line > 0;
    }

    public boolean isUserExist(String id) {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isChannelExist(String channelId) {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ID + "=?",
                new String[]{channelId});
        return line > 0;
    }

    public boolean isStoryExists(String storyId) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_STATUS + " WHERE " + Constants.TAG_STATUS_ID + "=?",
                new String[]{storyId});
        return line > 0;
    }

    public boolean isStoryUserExists(String senderId) {
        if (senderId != null && !TextUtils.isEmpty(senderId)) {
            long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_STATUS + " WHERE " + Constants.TAG_SENDER_ID + "=?",
                    new String[]{senderId});
            return line > 0;
        }
        return false;
    }

    public ContactsData.Result getContactDetail(String user_id) {
        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "='" + user_id + "'";

        SQLiteDatabase db = getReadableDatabase();
        ContactsData.Result results = new ContactsData().new Result();
        try {
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor != null) {
                cursor.moveToFirst();
                if (cursor.moveToFirst()) {
                    results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                    results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                    results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                    results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                    results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                    results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                    results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                    results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                    results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                    results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                    results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                    results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                    results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                    results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                            results.phone_no, results.country_code);
                    results.saved_name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME));
                    if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)))) {
                        results.isDeletedAccount = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT));
                    }
                    if (results.isDeletedAccount == null) results.isDeletedAccount = "" + 0;
                    Log.e(TAG, "getContactDetail: " + new Gson().toJson(results));
                }
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public String getContactPhone(String user_id) {
        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "='" + user_id + "'";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        String phone_no = "";
        if (cursor != null) {
            cursor.moveToFirst();

            if (cursor.moveToFirst()) {
                phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
            }
            cursor.close();
        }
        return phone_no;
    }

    public String getContactCountryCode(String user_id) {
        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "='" + user_id + "'";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        String countryCode = "";
        if (cursor != null) {
            cursor.moveToFirst();

            if (cursor.moveToFirst()) {
                countryCode = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
            }
            cursor.close();
        }
        return countryCode;
    }

    public List<ContactsData.Result> getStoredContacts(Context context) {
        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "!='" + GetSet.getUserId() + "'" +
                " AND (" + Constants.TAG_DELETED_ACCOUNT + " ISNULL OR " + Constants.TAG_DELETED_ACCOUNT + " == '0'" + ")";
//        Log.d(TAG, "getStoredContacts: " + selectQuery);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<ContactsData.Result> contactAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                // HashMap<String, String> map = ApplicationClass.getContactOrNot(context, phone_no);
                //  if (map.get("isAlready").equals("true")) {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME))
                        , results.phone_no, results.country_code);
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)))) {
                    results.isDeletedAccount = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT));
                }
                if (results.isDeletedAccount == null) results.isDeletedAccount = "" + 0;
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)))) {
                }
                    contactAry.add(results);

                Log.e("checkActiveDB", "-" + new Gson().toJson(results));
                //  }
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return contactAry;
    }


    public List<ContactsData.Result> getDuplicateContacts(Context context) {

        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_PHONE_NUMBER + " IN (" +
                "SELECT " + Constants.TAG_PHONE_NUMBER + " FROM " + TABLE_CONTACTS + " GROUP BY " + Constants.TAG_PHONE_NUMBER +
                " HAVING COUNT(*) > 1)" + " AND " + Constants.TAG_USER_ID + " !='" + GetSet.getUserId() + "'" + " AND " +
                Constants.TAG_DELETED_ACCOUNT + " ISNULL OR " + Constants.TAG_DELETED_ACCOUNT + " = 0";
//        Log.d(TAG, "getDuplicateContacts: " + selectQuery);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<ContactsData.Result> contactList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                // HashMap<String, String> map = ApplicationClass.getContactOrNot(context, phone_no);
                //  if (map.get("isAlready").equals("true")) {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME))
                        , results.phone_no, results.country_code);
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)))) {
                    results.isDeletedAccount = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT));
                }
                if (results.isDeletedAccount == null) results.isDeletedAccount = "" + 0;
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)))) {
                    contactList.add(results);
                }
                //  }
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getDuplicateContacts: " + contactList.size());
        return contactList;
    }


    public List<ContactsData.Result> getStoredContactsForChannel(Context context, String channelAdminId) {

        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_USER_ID + "!='" + GetSet.getUserId() + "'" + " AND "
                + Constants.TAG_USER_ID + "!='" + channelAdminId + "'" + " AND (" + Constants.TAG_DELETED_ACCOUNT + " ISNULL OR " +
                Constants.TAG_DELETED_ACCOUNT + " != '1')";
//        Log.d(TAG, "getStoredContactsForChannel: " + selectQuery);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<ContactsData.Result> contactAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                // HashMap<String, String> map = ApplicationClass.getContactOrNot(context, phone_no);
                //  if (map.get("isAlready").equals("true")) {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME))
                        , results.phone_no, results.country_code);
                if (cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)) != null &&
                        !cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)).equals("")) {
                    contactAry.add(results);
                }
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)))) {
                    results.isDeletedAccount = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT));
                }
                if (results.isDeletedAccount == null) results.isDeletedAccount = "" + 0;
                //  }
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return contactAry;
    }


    public List<String> getAllContactsNumber(Context context) {

        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS;

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<String> contactAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                contactAry.add(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER)));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return contactAry;
    }

    public void updateBlockStatus(String user_id, String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isUserExist(db, user_id);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                    new String[]{user_id});
        }
    }

    public void resetAllBlockStatus(String key) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(key, "");

        db.update(TABLE_CONTACTS, values, key + " =? ",
                new String[]{"block"});
    }

    // Insert Members into the database for Mute Notifications
    public void updateMuteUser(String user_id, String mute) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_MUTE_NOTIFICATION, mute);

            getWritableDatabase().update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                    new String[]{user_id});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateFavUser(String user_id, String fav) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_FAVOURITED, fav);

            getWritableDatabase().update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                    new String[]{user_id});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Insert a message into the database
    public void addMessageData(MessagesData msgData, boolean encrypt) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CHAT_ID, msgData.chat_id);
            values.put(Constants.TAG_MESSAGE_ID, msgData.message_id);
            values.put(Constants.TAG_USER_ID, msgData.user_id);
            values.put(Constants.TAG_USER_NAME, msgData.user_name);
            values.put(Constants.TAG_MESSAGE_TYPE, msgData.message_type);
            if (encrypt) {
                values.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(msgData.message));
                values.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(msgData.attachment != null ? msgData.attachment : ""));
                values.put(Constants.TAG_LAT, ApplicationClass.encryptMessage(msgData.lat != null ? msgData.lat : ""));
                values.put(Constants.TAG_LON, ApplicationClass.encryptMessage(msgData.lon != null ? msgData.lon : ""));
                values.put(Constants.TAG_CONTACT_NAME, ApplicationClass.encryptMessage(msgData.contact_name != null ? msgData.contact_name : ""));
                values.put(Constants.TAG_CONTACT_PHONE_NO, ApplicationClass.encryptMessage(msgData.contact_phone_no != null ? msgData.contact_phone_no : ""));
                values.put(Constants.TAG_CONTACT_COUNTRY_CODE, ApplicationClass.encryptMessage(msgData.contact_country_code != null ? msgData.contact_country_code : ""));
                values.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(msgData.thumbnail != null ? msgData.thumbnail : ""));
                values.put(Constants.TAG_STATUS_DATA, ApplicationClass.encryptMessage(msgData.statusData != null ? msgData.statusData : ""));
            } else {
                values.put(Constants.TAG_MESSAGE, msgData.message);
                values.put(Constants.TAG_ATTACHMENT, msgData.attachment != null ? msgData.attachment : "");
                values.put(Constants.TAG_LAT, msgData.lat != null ? msgData.lat : "");
                values.put(Constants.TAG_LON, msgData.lon != null ? msgData.lon : "");
                values.put(Constants.TAG_CONTACT_NAME, msgData.contact_name != null ? msgData.contact_name : "");
                values.put(Constants.TAG_CONTACT_PHONE_NO, msgData.contact_phone_no != null ? msgData.contact_phone_no : "");
                values.put(Constants.TAG_CONTACT_COUNTRY_CODE, msgData.contact_country_code != null ? msgData.contact_country_code : "");
                values.put(Constants.TAG_THUMBNAIL, msgData.thumbnail != null ? msgData.thumbnail : "");
                values.put(Constants.TAG_STATUS_DATA, msgData.statusData != null ? msgData.statusData : "");
            }
            values.put(Constants.TAG_CHAT_TIME, msgData.chat_time);
            values.put(Constants.TAG_RECEIVER_ID, msgData.receiver_id);
            values.put(Constants.TAG_SENDER_ID, msgData.sender_id);
            values.put(Constants.TAG_DELIVERY_STATUS, msgData.delivery_status);
            values.put(Constants.TAG_PROGRESS, msgData.progress != null ? msgData.progress : "");
            ;

            long result = getWritableDatabase().insertWithOnConflict(TABLE_MESSAGES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
//            Log.d(TAG, "addMessageData: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<MessagesData> getMessages(String chat_id, String offset, String limit) throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        Cursor dbCursor = db.query(TABLE_MESSAGES, null, null, null, null, null, null);
        String[] projection = dbCursor.getColumnNames();
        dbCursor.close();
        String selection = Constants.TAG_CHAT_ID + "=?"; //this must be array
        String[] selectionArgs = new String[]{chat_id}; //this must be array
        String orderBy = Constants.TAG_CHAT_TIME + " DESC " + " LIMIT " + limit + " OFFSET " + offset;
        Cursor cursor = db.query(TABLE_MESSAGES, projection, selection, selectionArgs, null, null, orderBy);

        List<MessagesData> messageAry = new ArrayList<>();
        // looping through all rows and adding to list
        try {
            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
                do {
                    MessagesData results = new MessagesData();
                    results.chat_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_ID));
                    results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                    results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                    results.user_name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_NAME));
                    results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                    results.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                    results.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                    results.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
                    results.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                    results.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                    results.contact_name = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                    results.contact_phone_no = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
                    results.contact_country_code = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                    results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                    results.receiver_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_RECEIVER_ID));
                    results.sender_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
                    results.delivery_status = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELIVERY_STATUS));
                    results.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                    results.statusData = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_DATA)));
                    messageAry.add(results);
                } while (cursor.moveToNext());
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(TAG, "getMessages: " + messageAry.size() + ", " + limit + ", " + offset);
        return messageAry;
    }

    public MessagesData getSingleMessage(String message_id) {

        String selection = Constants.TAG_MESSAGE_ID + "=?"; //this must be array
        String[] selectionArgs = new String[]{message_id}; //this must be array
        SQLiteDatabase db = getReadableDatabase();
        Cursor dbCursor = db.query(TABLE_MESSAGES, null, null, null, null, null, null);
        String[] columnNames = dbCursor.getColumnNames();
        dbCursor.close();
        Cursor cursor = db.query(TABLE_MESSAGES, columnNames, selection, selectionArgs, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor != null && cursor.getCount() > 0) {
            MessagesData results = new MessagesData();
            results.chat_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_ID));
            results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
            results.user_name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_NAME));
            results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
            results.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
            results.attachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
            results.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
            results.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
            results.contact_name = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
            results.contact_phone_no = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
            results.contact_country_code = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
            results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            results.receiver_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_RECEIVER_ID));
            results.sender_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
            results.delivery_status = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELIVERY_STATUS));
            results.thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
            results.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
            results.statusData = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_DATA)));
            cursor.close();
            return results;
        }
        return null;
    }

    public MessagesData getRecentMessage(String userId) {
        String[] projection = {Constants.TAG_USER_ID, Constants.TAG_MESSAGE_ID, Constants.TAG_CHAT_TIME, Constants.TAG_SENDER_ID, Constants.TAG_MESSAGE};
        String selection = Constants.TAG_SENDER_ID + "=?"; //this must be array
        String[] selectionArgs = new String[]{userId}; //this must be array
        String orderBy = Constants.TAG_CHAT_TIME + " DESC LIMIT 1";
        Cursor cursor = getReadableDatabase().query(TABLE_MESSAGES, projection, selection, selectionArgs, null, null, orderBy);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            MessagesData results = new MessagesData();
            results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
            results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            results.sender_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
            results.message = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE));
            cursor.close();
            return results;
        }
        return null;
    }

    public MessagesData getLastMessage(String chatId) {
        String[] projection = {Constants.TAG_USER_ID, Constants.TAG_MESSAGE_ID, Constants.TAG_CHAT_TIME, Constants.TAG_SENDER_ID, Constants.TAG_MESSAGE, Constants.TAG_MESSAGE_TYPE};
        String selection = Constants.TAG_CHAT_ID + " =? /*AND " + Constants.TAG_MESSAGE_TYPE + " !=?*/"; //this must be array
        String[] selectionArgs = new String[]{chatId/*, Constants.TAG_DATE*/}; //this must be array
        String orderBy = Constants.TAG_CHAT_TIME + " ASC LIMIT 1";
        Cursor cursor = getReadableDatabase().query(TABLE_MESSAGES, projection, selection, selectionArgs, null, null, orderBy);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            MessagesData results = new MessagesData();
            results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
            results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            results.sender_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
            results.message = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE));
            results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
            cursor.close();
            return results;
        }
        return null;
    }

    public String getWallpaper(String _id, String type) {
        String[] projection = {Constants.TAG_WALLPAPER};
        String selection;
        Cursor cursor;
        if (type.equals(Constants.TAG_USER)) {
            selection = TAG_USER_ID + "=?";
            String[] selectionArgs = new String[]{_id}; //this must be array
            cursor = getReadableDatabase().query(TABLE_CONTACTS, projection, selection, selectionArgs, null, null, null);
        } else if (type.equals(Constants.TAG_GROUP)) {
            selection = TAG_GROUP_ID + "=?";
            String[] selectionArgs = new String[]{_id}; //this must be array
            cursor = getReadableDatabase().query(TABLE_GROUP, projection, selection, selectionArgs, null, null, null);
        } else {
            selection = TAG_CHANNEL_ID + "=?";
            String[] selectionArgs = new String[]{_id}; //this must be array
            cursor = getReadableDatabase().query(TABLE_CHANNEL, projection, selection, selectionArgs, null, null, null);
        }

        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            String wallpaper = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_WALLPAPER));
            cursor.close();
            Log.d(TAG, "getWallpaper: " + wallpaper);
            return wallpaper;
        }
        return null;
    }

    public GroupMessage getRecentGroupMessage(String groupId) {
        String[] projection = {Constants.TAG_GROUP_ID, Constants.TAG_MESSAGE_ID, Constants.TAG_CHAT_TIME, Constants.TAG_MEMBER_ID, Constants.TAG_MESSAGE};
        String selection = Constants.TAG_GROUP_ID + "=?"; //this must be array
        String[] selectionArgs = new String[]{groupId}; //this must be array
        String orderBy = Constants.TAG_CHAT_TIME + " DESC LIMIT 1";

        Cursor cursor = getReadableDatabase().query(TABLE_GROUP_MESSAGES, projection, selection, selectionArgs, null, null, orderBy);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            GroupMessage results = new GroupMessage();
            results.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
            results.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            results.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
            results.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            results.message = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE));
            cursor.close();
            return results;
        }
        return null;
    }

    public ChannelMessage getRecentChannelMessage(String channelId) {
        String[] projection = {Constants.TAG_CHANNEL_ID, Constants.TAG_MESSAGE_ID, Constants.TAG_CHAT_TIME, Constants.TAG_MESSAGE};
        String selection = Constants.TAG_CHANNEL_ID + "=?"; //this must be array
        String[] selectionArgs = new String[]{channelId}; //this must be array
        String orderBy = Constants.TAG_CHAT_TIME + " DESC LIMIT 1";

        Cursor cursor = getReadableDatabase().query(TABLE_CHANNEL_MESSAGES, projection, selection, selectionArgs, null, null, orderBy);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            ChannelMessage results = new ChannelMessage();
            results.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
            results.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            results.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            results.message = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE));
            cursor.close();
            return results;
        }
        return null;
    }

    public String getSavedName(String userId) {

        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + TAG_USER_ID + "='" + userId + "'";
        String name = "";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME));
            cursor.close();
            return name;
        }
        return name;
    }

    // Delete all chats in the database
    public void deleteAllMessages(String chat_id) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_MESSAGES, Constants.TAG_CHAT_ID + " =? ", new String[]{chat_id});
        } catch (Exception e) {
            Log.e(TAG, "deleteAllChats: " + e.getMessage());
        }
    }

    // Update Recent chats in the database
    public void updateRecentChat(String chat_id, String key, String value) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            // Order of deletions is important when foreign key relationships exist.
            boolean exists = isRecentChatExist(chat_id);
            ContentValues values = new ContentValues();
            values.put(key, value);

            if (exists) {
                db.update(TABLE_RECENTS, values, Constants.TAG_CHAT_ID + " =? ", new String[]{chat_id});
            }
        } catch (Exception e) {
            Log.e(TAG, "updateRecentChat: " + e.getMessage());
        }
    }

    public void deleteRecentChat(String chat_id) {
        if (isRecentChatExist(chat_id)) {
            try {
                SQLiteDatabase db = this.getWritableDatabase();
                // Order of deletions is important when foreign key relationships exist.
                db.delete(TABLE_RECENTS, Constants.TAG_CHAT_ID + " =? ", new String[]{chat_id});
            } catch (Exception e) {
                Log.e(TAG, "deleteRecentChat: " + e.getMessage());
            }
        }
    }

    public boolean isRecentChatExist(String chat_id) {
        Log.d(TAG, "isRecentChatExist: " + chat_id);
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_RECENTS + " WHERE " + Constants.TAG_CHAT_ID + "=?",
                new String[]{chat_id});
        return line > 0;
    }

    public void deleteMessageFromId(String message_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_MESSAGES, Constants.TAG_MESSAGE_ID + " =? ", new String[]{message_id});
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to delete all posts and users");
        }
    }

    public void deleteCallFromId(String callId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_CALL, Constants.TAG_CALL_ID + " =? ", new String[]{callId});
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to delete all posts and users");
        }
    }

    public void deleteGroupMessageFromId(String message_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_GROUP_MESSAGES, Constants.TAG_MESSAGE_ID + " =? ", new String[]{message_id});
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to delete all posts and users");
        }
    }

    public void deleteChannelMessageFromId(String message_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_CHANNEL_MESSAGES, Constants.TAG_MESSAGE_ID + " =? ", new String[]{message_id});
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to delete all posts and users");
        }
    }

    public int getMessagesCount(String chat_id) {
        String selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_CHAT_ID + "='" + chat_id + "'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void updateMessageSentStatus(String message_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isMessageIdExist(message_id);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_DELIVERY_STATUS, "sent");

        if (exists) {
            db.update(TABLE_MESSAGES, values, Constants.TAG_MESSAGE_ID + " =? AND " + Constants.TAG_DELIVERY_STATUS + "!=? ",
                    new String[]{message_id, "read"});
        }
//        if (db.isOpen()) db.close();
    }

    public void updateMessageData(String message_id, String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isMessageIdExist(message_id);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            if (key.equals(Constants.TAG_ATTACHMENT) && value.equals(ApplicationClass.decryptMessage(""))) {

            }
            db.update(TABLE_MESSAGES, values, Constants.TAG_MESSAGE_ID + " =? ",
                    new String[]{message_id});
        }
    }

    public void updateRecentMessageData(String chatId, String key, String value) {
        boolean exists = isRecentMessageIdExist(chatId);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            this.getWritableDatabase().update(TABLE_RECENTS, values, Constants.TAG_CHAT_ID + " =? ",
                    new String[]{chatId});
        }
    }

    public void updateChatSendStatus(String senderId, String receiverId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String chatId = senderId + receiverId;
        boolean exists = isChatIdExist(db, chatId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_DELIVERY_STATUS, "sent");

        if (exists) {
            Log.d(TAG, "updateChatSendStatus: " + chatId);
            db.update(TABLE_MESSAGES, values, Constants.TAG_CHAT_ID + " =? AND "
                            + Constants.TAG_SENDER_ID + " =? AND ("
                            + Constants.TAG_DELIVERY_STATUS + " ISNULL OR " + Constants.TAG_DELIVERY_STATUS + " =?)",
                    new String[]{chatId, senderId, "", Constants.TAG_TRUE});
        }
    }

    public boolean isRecentMessageIdExist(String id) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_RECENTS + " WHERE " + Constants.TAG_MESSAGE_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isMessageIdExist(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_MESSAGE_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public void updateMessageReadStatus(String chat_id, String user_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChatIdExist(db, chat_id);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_DELIVERY_STATUS, "read");

        if (exists) {
            db.update(TABLE_MESSAGES, values, Constants.TAG_CHAT_ID + " =? AND " + Constants.TAG_DELIVERY_STATUS + " ==? AND " + Constants.TAG_RECEIVER_ID + " =? ",
                    new String[]{chat_id, "sent", user_id});
        }
    }

    public boolean isChatIdExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_CHAT_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    // Insert a recent message into the database
    public void addRecentMessages(String chat_id, String user_id, String message_id,
                                  String chat_time, String unread_count) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CHAT_ID, chat_id);
            values.put(Constants.TAG_USER_ID, user_id);
            values.put(Constants.TAG_MESSAGE_ID, message_id);
            values.put(Constants.TAG_CHAT_TIME, chat_time);
            values.put(Constants.TAG_UNREAD_COUNT, unread_count);

            getWritableDatabase().insertWithOnConflict(TABLE_RECENTS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<RecentMessages> getAllRecentMessages(Context context) {

        String selectQueryFav = "SELECT " + TABLE_RECENTS + ".*, " + TABLE_CONTACTS + ".*, " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_TYPE + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_DELIVERY_STATUS + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_PROGRESS + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_SENDER_ID + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_CHAT_TIME + " FROM " + TABLE_RECENTS +
                " LEFT JOIN " + TABLE_MESSAGES + " ON "
                + TABLE_RECENTS + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_CONTACTS + " ON " + TABLE_RECENTS + "." + Constants.TAG_USER_ID +
                " = " + TABLE_CONTACTS + "." + Constants.TAG_USER_ID + " WHERE " + TABLE_CONTACTS
                + "." + Constants.TAG_FAVOURITED + "='true'" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        //        Log.d(TAG, "selectQueryFav: "+ selectQueryFav);
        ArrayList<RecentMessages> recentAry = new ArrayList<>(getRecentMessagesList(context, selectQueryFav));

        String selectQuery = "SELECT " + TABLE_RECENTS + ".*, " + TABLE_CONTACTS + ".*, " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_TYPE + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_MESSAGE + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_DELIVERY_STATUS + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_PROGRESS + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_SENDER_ID + ", " +
                TABLE_MESSAGES + "." + Constants.TAG_CHAT_TIME + " FROM " + TABLE_RECENTS +
                " LEFT JOIN " + TABLE_MESSAGES + " ON "
                + TABLE_RECENTS + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_CONTACTS + " ON " + TABLE_RECENTS + "." + Constants.TAG_USER_ID +
                " = " + TABLE_CONTACTS + "." + Constants.TAG_USER_ID + " WHERE " + TABLE_CONTACTS
                + "." + Constants.TAG_FAVOURITED + "!='true'" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";

//        Log.d(TAG, "selectQuery: "+ selectQuery);
        recentAry.addAll(getRecentMessagesList(context, selectQuery));
//        Log.d(TAG, "getAllRecentMessages: " + new Gson().toJson(recentAry));
        return recentAry;
    }

    public ArrayList<HashMap<String, String>> getSearchContacts(Context context) {

        String selectQueryFav = "SELECT * FROM " + TABLE_RECENTS + " LEFT JOIN " + TABLE_MESSAGES + " ON "
                + TABLE_RECENTS + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_CONTACTS + " ON " + TABLE_RECENTS + "." + Constants.TAG_USER_ID +
                " = " + TABLE_CONTACTS + "." + Constants.TAG_USER_ID + " WHERE " + TABLE_CONTACTS + "."
                + Constants.TAG_FAVOURITED + "='true'" + " AND (" + Constants.TAG_DELETED_ACCOUNT + " ISNULL OR "
                + Constants.TAG_DELETED_ACCOUNT + " != '1')" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
//        Log.d(TAG, "getAllRecentsMessages: " + selectQueryFav);

        ArrayList<HashMap<String, String>> recentAry = new ArrayList<>(getRecentMessageAry(context, selectQueryFav));

        String selectQuery = "SELECT * FROM " + TABLE_RECENTS + " LEFT JOIN " + TABLE_MESSAGES + " ON "
                + TABLE_RECENTS + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_CONTACTS + " ON " + TABLE_RECENTS + "." + Constants.TAG_USER_ID +
                " = " + TABLE_CONTACTS + "." + Constants.TAG_USER_ID + " WHERE " + TABLE_CONTACTS
                + "." + Constants.TAG_FAVOURITED + "!='true'" + " AND (" + Constants.TAG_DELETED_ACCOUNT + " ISNULL OR "
                + Constants.TAG_DELETED_ACCOUNT + " != '1')" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
//        Log.d(TAG, "getSearchContacts: " + selectQuery);

        recentAry.addAll(getRecentMessageAry(context, selectQuery));
//        Log.d(TAG, "getSearchContacts: " + new Gson().toJson(recentAry));
        return recentAry;
    }


    private ArrayList<HashMap<String, String>> getRecentMessageAry(Context context, String selectQuery) {
        ArrayList<HashMap<String, String>> tempAry = new ArrayList<>();
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<>();
                map.put(Constants.TAG_CHAT_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_ID)));
                map.put(Constants.TAG_USER_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID)));
                map.put(Constants.TAG_USER_IMAGE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE)));
                map.put(Constants.TAG_PHONE_NUMBER, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER)));
                map.put(Constants.TAG_COUNTRY_CODE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE)));
                map.put(Constants.TAG_USER_NAME, getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                        map.get(Constants.TAG_PHONE_NUMBER), map.get(Constants.TAG_COUNTRY_CODE)));
                map.put(Constants.TAG_ABOUT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT)));
                map.put(Constants.TAG_PRIVACY_LAST_SEEN, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN)));
                map.put(Constants.TAG_PRIVACY_PROFILE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE)));
                map.put(Constants.TAG_PRIVACY_ABOUT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT)));
                map.put(Constants.TAG_CONTACT_STATUS, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS)));
                map.put(Constants.TAG_BLOCKED_ME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME)));
                map.put(Constants.TAG_BLOCKED_BYME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME)));
                map.put(Constants.TAG_MESSAGE_TYPE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE)));
                map.put(Constants.TAG_MESSAGE_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
                map.put(Constants.TAG_CHAT_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
                map.put(Constants.TAG_DELIVERY_STATUS, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELIVERY_STATUS)));
                map.put(Constants.TAG_UNREAD_COUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
                map.put(Constants.TAG_SENDER_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID)));
                map.put(Constants.TAG_MESSAGE, getMessage(map.get(Constants.TAG_SENDER_ID), map.get(Constants.TAG_MESSAGE_TYPE),
                        ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))), context));
                map.put(Constants.TAG_MUTE_NOTIFICATION, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION)));
                map.put(Constants.TAG_PROGRESS, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS)));
                map.put(Constants.TAG_FAVOURITED, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED)));
                map.put(Constants.TAG_DELETED_ACCOUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)));
                if (map.get(Constants.TAG_DELETED_ACCOUNT) == null)
                    map.put(Constants.TAG_DELETED_ACCOUNT, "0");
                tempAry.add(map);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getRecentMessageAry: " + new Gson().toJson(tempAry));
        return tempAry;
    }

    private ArrayList<RecentMessages> getRecentMessagesList(Context context, String selectQuery) {
        ArrayList<RecentMessages> tempList = new ArrayList<>();
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                RecentMessages recentMessage = new RecentMessages();
                recentMessage.setChatId(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_ID)));
                recentMessage.setUserId(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID)));
                recentMessage.setUserImage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE)));
                recentMessage.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER)));
                recentMessage.setCountryCode(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE)));
                recentMessage.setUserName(getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                        recentMessage.getPhone(), recentMessage.getCountryCode()));
                recentMessage.setAbout(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT)));
                recentMessage.setPrivacyLastSeen(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN)));
                recentMessage.setPrivacyProfileImage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE)));
                recentMessage.setPrivacyAbout(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT)));
                recentMessage.setContactStatus(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS)));
                recentMessage.setBlockedMe(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME)));
                recentMessage.setBlockedByMe(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME)));
                recentMessage.setMessageType(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE)));
                recentMessage.setMessageId(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
                recentMessage.setChatTime(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
                recentMessage.setDeliveryStatus(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELIVERY_STATUS)));
                recentMessage.setUnreadCount(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
                recentMessage.setSenderId(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID)));
                recentMessage.setMessage(getMessage(recentMessage.getSenderId(), recentMessage.getMessageType(),
                        ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))), context));
                recentMessage.setMuteNotification(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION)));
                recentMessage.setProgress(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS)));
                recentMessage.setFavouriteId(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED)));
                recentMessage.setDeletedAccount(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)));
                if (recentMessage.getDeletedAccount() == null)
                    recentMessage.setDeletedAccount("0");
                tempList.add(recentMessage);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getRecentMessagesList: " + tempList.size());
        return tempList;
    }

    public int getUnseenMessagesCount(String sender_id) {
        String selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_DELIVERY_STATUS + " ='sent' AND " + Constants.TAG_SENDER_ID + "='" + sender_id + "'";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    List<MessagesData> getUnseenMessage(String senderId, Context context) {
        String selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_DELIVERY_STATUS + " ='sent' AND "
                + Constants.TAG_SENDER_ID + "='" + senderId + "'" + " ORDER BY " + Constants.TAG_CHAT_TIME + " ASC";
        List<MessagesData> messagesData = new ArrayList<>();
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                MessagesData results = new MessagesData();
                results.chat_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_ID));
                results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_NAME));
                results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                results.attachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
                results.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                results.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                results.contact_name = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                results.contact_phone_no = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
                results.contact_country_code = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                results.receiver_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_RECEIVER_ID));
                results.sender_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
                results.delivery_status = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELIVERY_STATUS));
                results.thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
                results.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                results.statusData = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_DATA)));

                results.message = getMessage(results.user_id, results.message_type,
                        ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))), context);
                messagesData.add(results);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return messagesData;
    }

    List<String> getUnseenMessageUser() {
        List<String> user = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_DELIVERY_STATUS + " ='sent"
                + "' GROUP BY " + Constants.TAG_SENDER_ID + " ORDER BY " + Constants.TAG_CHAT_TIME + " ASC";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                user.add(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return user;
    }

    public void resetUnseenMessagesCount(String user_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isRecentUserIdExist(db, user_id);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_UNREAD_COUNT, "0");

        if (exists) {
            db.update(TABLE_RECENTS, values, Constants.TAG_USER_ID + " =? ",
                    new String[]{user_id});
        }
    }

    public boolean isRecentUserIdExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_RECENTS + " WHERE " + Constants.TAG_USER_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public List<ContactsData.Result> getBlockedContacts(Context context) {

        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS + " WHERE " + Constants.TAG_BLOCKED_BYME + " = '" + Constants.TAG_BLOCK + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        List<ContactsData.Result> contactAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                        results.phone_no, results.country_code);
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                contactAry.add(results);
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return contactAry;
    }

    public void createGroup(String groupId, String groupAdminId, String groupName, String createdAt, String groupImage) {

        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_GROUP_ID, groupId);
            values.put(Constants.TAG_GROUP_CREATED_BY, groupAdminId);
            values.put(Constants.TAG_GROUP_NAME, groupName);
            values.put(Constants.TAG_CREATED_AT, createdAt);
            values.put(Constants.TAG_GROUP_IMAGE, groupImage);
            values.put(Constants.TAG_MUTE_NOTIFICATION, "");
            db.insertWithOnConflict(TABLE_GROUP, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createGroupMembers(String memberKey, String groupId, String memberId, String memberRole) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_MEMBER_KEY, memberKey);
            values.put(Constants.TAG_GROUP_ID, groupId);
            values.put(Constants.TAG_MEMBER_ID, memberId);
            values.put(Constants.TAG_MEMBER_ROLE, memberRole);

            db.insertWithOnConflict(TABLE_GROUP_MEMBERS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateGroupMembers(String memberKey, String groupId, String memberId, String memberRole) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_MEMBER_KEY, memberKey);
            values.put(Constants.TAG_GROUP_ID, groupId);
            values.put(Constants.TAG_MEMBER_ID, memberId);
            values.put(Constants.TAG_MEMBER_ROLE, memberRole);

            db.insertWithOnConflict(TABLE_GROUP_MEMBERS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteMembersFromGroup(String groupId) {
        String deleteQuery = "DELETE FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID +
                "='" + groupId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public List<GroupData> getGroups() {
        String selectQuery = "SELECT  * FROM " + TABLE_GROUP;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        List<GroupData> groupList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                GroupData groupData = new GroupData();
                groupData.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
                groupData.groupName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_NAME));
                groupData.groupAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_CREATED_BY));
                groupData.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
                groupData.groupImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_IMAGE));
                groupList.add(groupData);
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return groupList;
    }

    public GroupData getGroupData(Context context, String groupId) {
        String selectQuery = "SELECT  * FROM " + TABLE_GROUP + " WHERE " + Constants.TAG_GROUP_ID + " ='" + groupId + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isGroupExist(db, groupId);
        if (exists) {
            Cursor cursor = db.rawQuery(selectQuery, null);
            // looping through all rows and adding to list
            GroupData groupData = new GroupData();
            if (cursor != null)
                cursor.moveToFirst();
            groupData.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
            groupData.groupName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_NAME));
            groupData.groupAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_CREATED_BY));
            groupData.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
            groupData.groupImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_IMAGE));
            groupData.muteNotification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
            //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            cursor.close();

            return groupData;
        } else {
            return null;
        }
    }

    public void updateGroupData(String groupId, String key, String value) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isGroupExist(db, groupId);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_GROUP, values, Constants.TAG_GROUP_ID + " =? ",
                    new String[]{groupId});
        }
    }

    public void updateGroup(String groupId, String adminId, String name, String createdAt, String groupImage) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isGroupExist(db, groupId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_GROUP_ID, groupId);
        values.put(Constants.TAG_GROUP_CREATED_BY, adminId);
        values.put(Constants.TAG_GROUP_NAME, name);
        values.put(Constants.TAG_CREATED_AT, createdAt);
        values.put(Constants.TAG_GROUP_IMAGE, groupImage);

        if (exists) {
            db.update(TABLE_GROUP, values, Constants.TAG_GROUP_ID + " =? ",
                    new String[]{groupId});
        }
    }

    public List<GroupData.GroupMembers> getNotGroupMembers(Context context, String groupId) {
        String selectQuery = "SELECT  * FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID + " ='" + groupId + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        List<GroupData.GroupMembers> groupList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                GroupData.GroupMembers groupData = new GroupData().new GroupMembers();
                groupData.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
                groupData.memberRole = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ROLE));
                groupList.add(groupData);
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return groupList;
    }

    public List<ContactsData.Result> getNotGroupMembers(String groupId) {
        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS + " WHERE " + TAG_USER_ID + " NOT IN " +
                "(SELECT " + TAG_MEMBER_ID + " FROM " + TAG_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID + " ='" + groupId + "')";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        List<ContactsData.Result> membersList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                // HashMap<String, String> map = ApplicationClass.getContactOrNot(context, phone_no);
                //  if (map.get("isAlready").equals("true")) {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME))
                        , results.phone_no, results.country_code);
                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT)))) {
                    results.isDeletedAccount = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_DELETED_ACCOUNT));
                }
                if (results.isDeletedAccount == null) results.isDeletedAccount = "" + 0;

                if (!TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)))) {
                    membersList.add(results);
                }
                //  }
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.i(TAG, "getGroupMembers: " + membersList.size());
        return membersList;
    }

    public int getGroupMemberSize(String groupId) {
        String selectQuery = "SELECT  * FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID + " ='" + groupId + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public long isUserIsGroupAdmin(String groupId, String userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP_MEMBERS +
                        " WHERE " + Constants.TAG_GROUP_ID + "=?" + " AND " + TAG_MEMBER_ID + "=?" +
                        " AND " + Constants.TAG_MEMBER_ROLE + "=?",
                new String[]{groupId, userId, Constants.ADMIN});
        return line;
    }

    public List<GroupData.GroupMembers> getThreeMembers(Context context, String groupId) {
        String selectQuery = "SELECT  * FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID + " ='" + groupId + "'" + " LIMIT 5";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        List<GroupData.GroupMembers> groupList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                GroupData.GroupMembers groupData = new GroupData().new GroupMembers();
                groupData.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
                groupData.memberRole = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ROLE));
                groupList.add(groupData);
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return groupList;
    }

    public void addGroupMessages(String messageId, String groupID, String memberId, String adminId, String messageType,
                                 String message, String attachment, String lat, String lon,
                                 String contactName, String contactPhone, String countryCode, String chatTime, String thumbnail, String deliveryStatus) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_GROUP_ID, groupID);
            values.put(Constants.TAG_MEMBER_ID, memberId);
            values.put(Constants.TAG_MESSAGE_ID, messageId);
            values.put(Constants.TAG_GROUP_ADMIN_ID, adminId);
            values.put(Constants.TAG_MESSAGE_TYPE, messageType);
            values.put(Constants.TAG_MESSAGE, message);
            values.put(Constants.TAG_ATTACHMENT, ApplicationClass.decryptMessage(attachment));
            values.put(Constants.TAG_LAT, lat);
            values.put(Constants.TAG_LON, lon);
            values.put(Constants.TAG_CONTACT_NAME, contactName);
            values.put(Constants.TAG_CONTACT_PHONE_NO, contactPhone);
            values.put(Constants.TAG_CONTACT_COUNTRY_CODE, countryCode);
            values.put(Constants.TAG_CHAT_TIME, chatTime);
            values.put(Constants.TAG_THUMBNAIL, ApplicationClass.decryptMessage(thumbnail));
            values.put(Constants.TAG_PROGRESS, "");
            values.put(Constants.TAG_DELIVERY_STATUS, deliveryStatus);

            getWritableDatabase().insertWithOnConflict(TABLE_GROUP_MESSAGES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<GroupMessage> getGroupMessages(String groupId, String offset, String limit, Context context) {

        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" + groupId + "'" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC" + " LIMIT " + limit + " OFFSET " + offset;
//        Log.d(TAG, "getGroupMessages: "+ selectQuery);

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        List<HashMap<String, String>> recentAry = new ArrayList<>();
        List<GroupMessage> messageList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                GroupMessage message = new GroupMessage();
                message.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
                message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                message.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
                message.groupAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ADMIN_ID));
                message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                message.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                message.contactPhoneNo = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
                message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                message.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
                message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));
//                groupMessage.add(message);
                messageList.add(getGroupMessagesByType(this, context, message));
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getGroupMessages: " + messageList.size());
        return messageList;
    }

    public GroupMessage getGroupMessagesByType(DatabaseHandler dbhelper, Context mContext, GroupMessage groupMessage) {
        if (groupMessage.messageType != null) {
            switch (groupMessage.messageType) {
                case "text":
                case Constants.TAG_IMAGE:
                case Constants.TAG_VIDEO:
                case StorageManager.TAG_DOCUMENT:
                case Constants.TAG_LOCATION:
                case "contact":
                case "audio":
                    groupMessage.message = groupMessage.message != null ? groupMessage.message : "";
                    break;
                case "create_group":
                    if (groupMessage.groupAdminId.equals(GetSet.getUserId())) {
                        groupMessage.message = mContext.getString(R.string.you_created_the_group);
                    } else {
                        if (dbhelper.isUserExist(groupMessage.groupAdminId)) {
                            groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.groupAdminId), dbhelper.getContactCountryCode(groupMessage.groupAdminId)) + " " + mContext.getString(R.string.created_the_group);
                        } else {
                            groupMessage.message = mContext.getString(R.string.group_created);
                        }
                    }
                    break;
                case Constants.TAG_GROUP_JOINED:
                    if (groupMessage.memberId.equals(GetSet.getUserId())) {
                        groupMessage.message = mContext.getString(R.string.you) + " " + mContext.getString(R.string.group_joined_description);
                    } else {
                        String memberName = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId));
                        groupMessage.message = memberName + " " + mContext.getString(R.string.group_joined_description);
                    }
                    break;
                case "add_member":
                    if (TextUtils.isEmpty(groupMessage.attachment)) {
                        if (dbhelper.isUserExist(groupMessage.groupAdminId)) {
                            groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.groupAdminId), dbhelper.getContactCountryCode(groupMessage.groupAdminId)) + " " + mContext.getString(R.string.added_you);
                        } else {
                            groupMessage.message = mContext.getString(R.string.you_were_added);
                        }
                    } else {
                        try {
                            JSONArray jsonArray = new JSONArray(groupMessage.attachment);
                            ArrayList<String> members = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                if (jsonObject.getString(TAG_MEMBER_ID).equals(GetSet.getUserId())) {
                                    members.add(mContext.getString(R.string.you));
                                } else if (dbhelper.isUserExist(jsonObject.getString(Constants.TAG_MEMBER_ID))) {
                                    members.add(ApplicationClass.getContactName(mContext, jsonObject.getString(TAG_MEMBER_NO),
                                            dbhelper.getContactCountryCode(jsonObject.getString(Constants.TAG_MEMBER_ID))));
                                }
                            }
                            String memberstr = members.toString().replaceAll("[\\[\\]]|(?<=,)\\s+", "");
                            if (groupMessage.memberId.equals(GetSet.getUserId())) {
                                groupMessage.message = mContext.getString(R.string.you_added) + " " + memberstr;
                            } else {
                                groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.groupAdminId), dbhelper.getContactCountryCode(groupMessage.groupAdminId)) + " " + mContext.getString(R.string.added) + " " + memberstr;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case "group_image":
                case "subject":
                    if (groupMessage.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                        groupMessage.message = mContext.getString(R.string.you) + " " + groupMessage.message;
                    } else {
                        groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId)) + " " + groupMessage.message;
                    }
                    break;
                case "left":
                    if (groupMessage.memberId.equalsIgnoreCase(GetSet.getUserId())) {
                        groupMessage.message = mContext.getString(R.string.you_left);
                    } else {
                        groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId)) + " " + mContext.getString(R.string.left);
                    }
                    break;
                case "remove_member":
                    if (groupMessage.groupAdminId.equals(GetSet.getUserId())) {
                        groupMessage.message = mContext.getString(R.string.you_removed) + " " + ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId));
                    } else {
                        if (groupMessage.memberId.equals(GetSet.getUserId())) {
                            groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.groupAdminId), dbhelper.getContactCountryCode(groupMessage.groupAdminId)) + " " + mContext.getString(R.string.removed_you);
                        } else {
                            groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.groupAdminId), dbhelper.getContactCountryCode(groupMessage.groupAdminId)) + " " + mContext.getString(R.string.removed) + " " +
                                    ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId));
                        }
                    }
                    break;
                case "admin":
                    if (groupMessage.attachment.equals(MEMBER)) {
                        groupMessage.message = mContext.getString(R.string.you_are_no_longer_as_admin);
                    } else {
                        groupMessage.message = mContext.getString(R.string.you_are_now_an_admin);
                    }
                    break;
                case "date":
                    groupMessage.message = dateUtils.getChatDateFromUTC(groupMessage.chatTime);
                    break;
                case "change_number":
                    if (!groupMessage.memberId.equals(GetSet.getUserId())) {
                        groupMessage.message = ApplicationClass.getContactName(mContext, dbhelper.getContactPhone(groupMessage.memberId), dbhelper.getContactCountryCode(groupMessage.memberId)) + " " + groupMessage.message;
                    }
                    break;
            }
        } else {
            groupMessage.message = "";
        }

        groupMessage.message = ApplicationClass.decryptMessage(groupMessage.message);

        return groupMessage;
    }

    public GroupMessage getSingleGroupMessage(String groupId, String messageId) {

        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" + groupId + "'" + " AND " + Constants.TAG_MESSAGE_ID + " ='" + messageId + "'";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        GroupMessage message = new GroupMessage();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            message.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
            message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
            message.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
            message.groupAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ADMIN_ID));
            message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
            message.attachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
            message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
            message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
            message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
            message.contactPhoneNo = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
            message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
            message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            message.thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
            message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
            message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));
        }
        cursor.close();

        return message;
    }

    public void addGroupRecentMsg(String groupID, String messageId, String senderId, String chatTime, String unreadCount) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_GROUP_ID, groupID);
            values.put(Constants.TAG_MEMBER_ID, senderId);
            values.put(Constants.TAG_MESSAGE_ID, messageId);
            values.put(Constants.TAG_CHAT_TIME, chatTime);
            values.put(Constants.TAG_UNREAD_COUNT, unreadCount);

            getWritableDatabase().insertWithOnConflict(TABLE_GROUP_RECENT_MESSAGES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<HashMap<String, String>> getGroupRecentMessages(Context context, boolean addGroupId) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_RECENT_MESSAGES + " LEFT JOIN " + TABLE_GROUP_MESSAGES + " ON " +
                TABLE_GROUP_RECENT_MESSAGES + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_GROUP_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_GROUP + " ON " + TABLE_GROUP_RECENT_MESSAGES + "." + Constants.TAG_GROUP_ID +
                " = " + TABLE_GROUP + "." + Constants.TAG_GROUP_ID + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<HashMap<String, String>> recentAry = new ArrayList<>();
        // looping through all rows and adding to list
        try {
            if (cursor.moveToFirst()) {
                do {
                    HashMap<String, String> map = new HashMap<>();
                    map.put(Constants.TAG_MESSAGE_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
                    map.put(Constants.TAG_GROUP_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID)));
                    map.put(Constants.TAG_MEMBER_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID)));
                    map.put(Constants.TAG_GROUP_IMAGE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_IMAGE)));
                    map.put(Constants.TAG_GROUP_NAME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_NAME)));
                    map.put(Constants.TAG_MESSAGE_TYPE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE)));
                    map.put(Constants.TAG_MESSAGE, getMessage(map.get(Constants.TAG_MEMBER_ID), map.get(Constants.TAG_MESSAGE_TYPE),
                            !TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))) ?
                                    ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)))
                                    : "", context));
                    map.put(Constants.TAG_CHAT_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
                    map.put(Constants.TAG_UNREAD_COUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
                    map.put(Constants.TAG_MUTE_NOTIFICATION, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION)));
                    map.put(Constants.TAG_GROUP_ADMIN_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ADMIN_ID)));
                    map.put(Constants.TAG_ATTACHMENT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                    if (addGroupId && isMemberExist(GetSet.getUserId(), map.get(Constants.TAG_GROUP_ID)) && !ApplicationClass.groupList.contains(map.get(Constants.TAG_GROUP_ID))) {
                        ApplicationClass.groupList.add(map.get(Constants.TAG_GROUP_ID));
                    }
                    recentAry.add(GroupFragment.getMessages(this, context, map));
                } while (cursor.moveToNext());
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(TAG, "getGroupRecentMessages: " + recentAry.size());
        return recentAry;
    }

    public ArrayList<HashMap<String, String>> getGroupUnreadNotification(Context context) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_RECENT_MESSAGES + " LEFT JOIN " + TABLE_GROUP_MESSAGES + " ON " +
                TABLE_GROUP_RECENT_MESSAGES + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_GROUP_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_GROUP + " ON " + TABLE_GROUP_RECENT_MESSAGES + "." + Constants.TAG_GROUP_ID +
                " = " + TABLE_GROUP + "." + Constants.TAG_GROUP_ID + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<HashMap<String, String>> recentAry = new ArrayList<>();
        // looping through all rows and adding to list
        try {
            if (cursor.moveToFirst()) {
                do {
                    HashMap<String, String> map = new HashMap<>();
                    map.put(Constants.TAG_MESSAGE_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
                    map.put(Constants.TAG_GROUP_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID)));
                    map.put(Constants.TAG_MEMBER_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID)));
                    map.put(Constants.TAG_GROUP_IMAGE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_IMAGE)));
                    map.put(Constants.TAG_GROUP_NAME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_NAME)));
                    map.put(Constants.TAG_MESSAGE_TYPE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE)));
                    map.put(Constants.TAG_MESSAGE, getMessage(map.get(Constants.TAG_MEMBER_ID), map.get(Constants.TAG_MESSAGE_TYPE),
                            !TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))) ?
                                    ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)))
                                    : "", context));
                    map.put(Constants.TAG_CHAT_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
                    map.put(Constants.TAG_UNREAD_COUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
                    map.put(Constants.TAG_MUTE_NOTIFICATION, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION)));
                    map.put(Constants.TAG_GROUP_ADMIN_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ADMIN_ID)));
                    map.put(Constants.TAG_ATTACHMENT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                    if (isMemberExist(GetSet.getUserId(), map.get(Constants.TAG_GROUP_ID)) && !ApplicationClass.groupList.contains(map.get(Constants.TAG_GROUP_ID))) {
                        ApplicationClass.groupList.add(map.get(Constants.TAG_GROUP_ID));
                    }
                    recentAry.add(GroupFragment.getMessages(this, context, map));
                } while (cursor.moveToNext());
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
//        Log.d(TAG, "getGroupUnreadNotification: " + recentAry.size());
        return recentAry;
    }

    public List<String> getGroupIdList() {
        if (GetSet.getUserId() != null) {
            String[] projection = {Constants.TAG_GROUP_ID};
            String selection = Constants.TAG_MEMBER_ID + " ==?"; //this must be array
            String[] selectionArgs = new String[]{GetSet.getUserId()}; //this must be array

            Cursor cursor = getWritableDatabase().query(true, TABLE_GROUP_MEMBERS, projection, selection, selectionArgs, null, null, null, null);
            // looping through all rows and adding to list
            List<String> groupList = new ArrayList<>();
            groupList.add(GetSet.getUserId());
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    HashMap<String, String> map = new HashMap<>();
                    groupList.add(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID)));
                } while (cursor.moveToNext());
            }
            cursor.close();
            Log.d(TAG, "getGroupIdList: " + groupList.size());
            return groupList;
        } else {
            return new ArrayList<>();
        }
    }

    public int getGroupMessagesCount(String groupId) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" + groupId + "'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void deleteFromGroup(String groupId, String memberId) {
        String deleteQuery = "DELETE FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID +
                "='" + groupId + "'" + " AND " + Constants.TAG_MEMBER_ID + "='" + memberId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void updateMemberInGroup(GroupData.GroupMembers members, String memberKey) {

        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_MEMBER_ID, members.memberId);
            values.put(Constants.TAG_MEMBER_ROLE, members.memberRole);

            db.update(TABLE_GROUP_MEMBERS, values, Constants.TAG_MEMBER_KEY + " =? ",
                    new String[]{memberKey});
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public boolean isMemberExist(String userId, String groupId) {
        SQLiteDatabase db = this.getWritableDatabase();
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP_MEMBERS +
                        " WHERE " + Constants.TAG_MEMBER_ID + "=?" + " AND " + Constants.TAG_GROUP_ID + "=?",
                new String[]{userId, groupId});
        return line > 0;
    }

    public void deleteGroup(String groupId) {
        String deleteQuery = "DELETE FROM " + TABLE_GROUP + " WHERE " + Constants.TAG_GROUP_ID +
                "='" + groupId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void deleteMembers(String groupId) {
        String deleteQuery = "DELETE FROM " + TABLE_GROUP_MEMBERS + " WHERE " + Constants.TAG_GROUP_ID +
                "='" + groupId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void deleteGroupMessages(String groupId) {
        String deleteQuery = "DELETE FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID +
                "='" + groupId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void deleteGroupRecentChats(String groupId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isRecentGroupIdExist(groupId);
        if (exists) {
            String deleteQuery = "DELETE FROM " + TABLE_GROUP_RECENT_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID +
                    "='" + groupId + "'";
            getWritableDatabase().execSQL(deleteQuery);

        }
    }

    public void updateGroupMessageReadStatus(String group_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isGroupIdExist(group_id);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_DELIVERY_STATUS, "read");

        if (exists) {
            db.update(TABLE_GROUP_MESSAGES, values, Constants.TAG_GROUP_ID + " =? ",
                    new String[]{group_id});
        }
    }

    public boolean isGroupIdExist(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public int getUnseenGroupMessagesCount(String group_id) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_DELIVERY_STATUS + " ISNULL OR "
                + Constants.TAG_DELIVERY_STATUS + " ='' AND " + Constants.TAG_GROUP_ID + "='" + group_id + "'";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void resetUnseenGroupMessagesCount(String group_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isRecentGroupIdExist(group_id);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_UNREAD_COUNT, "0");

        if (exists) {
            db.update(TABLE_GROUP_RECENT_MESSAGES, values, Constants.TAG_GROUP_ID + " =? ",
                    new String[]{group_id});
        }
    }

    public boolean isRecentGroupIdExist(String groupId) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_GROUP_RECENT_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + " =? ",
                new String[]{groupId});
        return line > 0;
    }

    public void updateGroupMessageData(String message_id, String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isGroupMessageIdExist(db, message_id);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_GROUP_MESSAGES, values, Constants.TAG_MESSAGE_ID + " =? ",
                    new String[]{message_id});
        }
    }

    public boolean isGroupMessageIdExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_MESSAGE_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public long isGroupHaveAdmin(String group_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_GROUP_MEMBERS +
                        " WHERE " + Constants.TAG_GROUP_ID + "=?" + " AND " + Constants.TAG_MEMBER_ROLE + "=?",
                new String[]{group_id, "1"});
        return line;
    }

    public GroupData.GroupMembers getAdminFromMembers(String group_id) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MEMBERS +
                " WHERE " + Constants.TAG_GROUP_ID + "='" + group_id + "' AND " + Constants.TAG_MEMBER_ROLE + "='1'";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        GroupData.GroupMembers results = new GroupData().new GroupMembers();
        if (cursor != null) {
            cursor.moveToFirst();

            if (cursor.moveToFirst()) {
                results.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
                results.memberRole = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ROLE));
            }
            cursor.close();
        }
        return results;
    }

    // Insert Members into the database for Mute Notifications
    public void updateMuteGroup(String group_id, String mute) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_MUTE_NOTIFICATION, mute);

            getWritableDatabase().update(TABLE_GROUP, values, Constants.TAG_GROUP_ID + " =? ",
                    new String[]{group_id});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateUserPrivacy(JSONObject jsonObject) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            boolean exists = isUserExist(db, jsonObject.getString(TAG_USER_ID));
            if (exists) {
                ContentValues values = new ContentValues();
                values.put(TAG_USER_ID, jsonObject.getString(TAG_USER_ID));
                values.put(TAG_PRIVACY_LAST_SEEN, jsonObject.getString(TAG_PRIVACY_LAST_SEEN));
                values.put(TAG_PRIVACY_ABOUT, jsonObject.getString(TAG_PRIVACY_ABOUT));
                values.put(TAG_PRIVACY_PROFILE, jsonObject.getString(TAG_PRIVACY_PROFILE));

                db.update(TABLE_CONTACTS, values, Constants.TAG_USER_ID + " =? ",
                        new String[]{jsonObject.getString(TAG_USER_ID)});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addChannel(String channelId, String channelName, String channelDes, String channelImage, String channelType, String adminId,
                           String channelAdminName, String totalSubscribers, String createdAt, String channelCategory, String subscribeStatus,
                           String blockStatus, String report) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CHANNEL_ID, channelId);
            values.put(Constants.TAG_CHANNEL_NAME, channelName);
            values.put(Constants.TAG_CHANNEL_DES, channelDes);
            values.put(Constants.TAG_CHANNEL_IMAGE, channelImage);
            values.put(Constants.TAG_CHANNEL_TYPE, channelType);
            values.put(Constants.TAG_CHANNEL_ADMIN_ID, adminId);
            values.put(Constants.TAG_CHANNEL_ADMIN_NAME, channelAdminName);
            values.put(Constants.TAG_TOTAL_SUBSCRIBERS, totalSubscribers);
            values.put(Constants.TAG_MUTE_NOTIFICATION, "");
            values.put(Constants.SentFileHolder, createdAt);
            values.put(Constants.TAG_CHANNEL_CATEGORY, channelCategory);
            values.put(Constants.TAG_SUBSCRIBE_STATUS, subscribeStatus);
            if (blockStatus != null && !blockStatus.equals("")) {
                values.put(Constants.TAG_BLOCK_STATUS, blockStatus);
            } else {
                values.put(Constants.TAG_BLOCK_STATUS, "0");
            }
            if (report == null || report.equals("")) {
                report = "0";
            }
            values.put(Constants.TAG_REPORT, report);
//            values.put(Constants.TAG_BLOCK_STATUS, blockStatus);

            if (isChannelExist(channelId)) {
                getWritableDatabase().update(TABLE_CHANNEL, values, Constants.TAG_CHANNEL_ID + " =? ",
                        new String[]{channelId});
            } else {
                values.put(Constants.TAG_MUTE_NOTIFICATION, "");
                getWritableDatabase().insert(TABLE_CHANNEL, null, values);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<ChannelResult.Result> getAllChannels() {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL;
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<ChannelResult.Result> channelList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ChannelResult.Result result = new ChannelResult().new Result();
                result.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                result.channelName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME));
                result.channelDes = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES));
                result.channelImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE));
                result.channelType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_TYPE));
                result.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
                result.totalSubscribers = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TOTAL_SUBSCRIBERS));
                result.channelAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_ID));
                result.channelAdminName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_NAME));
                result.muteNotification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                result.channelCategory = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_CATEGORY));
                result.subscribeStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SUBSCRIBE_STATUS));
                result.report = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_REPORT));

                channelList.add(result);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return channelList;
    }

    public List<ChannelResult.Result> getSubscribedChannels(String userId) {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ADMIN_ID + " !='" + userId + "'";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<ChannelResult.Result> channelList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ChannelResult.Result result = new ChannelResult().new Result();
                result.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                result.channelName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME));
                result.channelDes = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES));
                result.channelImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE));
                result.channelType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_TYPE));
                result.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_TIME));
                result.totalSubscribers = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TOTAL_SUBSCRIBERS));
                result.channelAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_ID));
                result.subscribeStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SUBSCRIBE_STATUS));
                result.muteNotification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));

                channelList.add(result);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return channelList;
    }

    public List<String> getChannelIdList() {
        if (GetSet.getUserId() != null) {
            String[] projection = {Constants.TAG_CHANNEL_ID};
            String selection = Constants.TAG_CHANNEL_CATEGORY + " !=? " + " AND " +
                    Constants.TAG_CHANNEL_ADMIN_ID + " ==? " + " OR " +
                    Constants.TAG_SUBSCRIBE_STATUS + " ==?"; //this must be array
            String[] selectionArgs = new String[]{Constants.TAG_ADMIN_CHANNEL, GetSet.getUserId(), Constants.TAG_TRUE}; //this must be array

            Cursor cursor = getWritableDatabase().query(true, TABLE_CHANNEL, projection, selection, selectionArgs, null, null, null, null);
            // looping through all rows and adding to list
            List<String> channelList = new ArrayList<>();
            channelList.add(GetSet.getUserId());
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        HashMap<String, String> map = new HashMap<>();
                        String channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                        if (!channelList.contains(channelId))
                            channelList.add(channelId);
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
            Log.d(TAG, "getChannelIdList: " + channelList.size());
            return channelList;
        } else {
            return new ArrayList<>();
        }
    }

    public List<ChannelResult.Result> getMyChannels(String userId) {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ADMIN_ID + " ='" + userId + "'" + " ORDER BY " + Constants.TAG_CREATED_AT + " DESC";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<ChannelResult.Result> channelList = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ChannelResult.Result result = new ChannelResult().new Result();
                result.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                result.channelName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME));
                result.channelDes = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES));
                result.channelImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE));
                result.channelType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_TYPE));
                result.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.SentFileHolder));
                result.totalSubscribers = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TOTAL_SUBSCRIBERS));
                result.channelAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_ID));
                result.subscribeStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SUBSCRIBE_STATUS));
                result.channelCategory = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_CATEGORY));
                result.report = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_REPORT));

                channelList.add(result);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getMyChannels: " + channelList.size());
        return channelList;
    }

    public ChannelResult.Result getChannelInfo(String channelId) {
        String selectQuery = "SELECT  * FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ID + " ='" +
                channelId + "'";

        if (!isChannelExist(channelId)) {
            return null;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        ChannelResult.Result channelData = new ChannelResult().new Result();
        // looping through all rows and adding to list
        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                channelData.channelAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_ID));
                channelData.channelAdminName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ADMIN_NAME));
                channelData.channelType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_TYPE));
                channelData.totalSubscribers = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TOTAL_SUBSCRIBERS));
                channelData.channelImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE));
                channelData.channelDes = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES));
                channelData.channelName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME));
                channelData.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                channelData.createdTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
                channelData.muteNotification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                channelData.channelCategory = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_CATEGORY));
                channelData.subscribeStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SUBSCRIBE_STATUS));
                channelData.report = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_REPORT));
                channelData.blockStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCK_STATUS));
            }
            cursor.close();
        }
        return channelData;
    }

    public AdminChannel.Result getAdminChannelInfo(String channelId) {
        String selectQuery = "SELECT  * FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ID + " ='" +
                channelId + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        AdminChannel.Result channelData = new AdminChannel().new Result();
        // looping through all rows and adding to list
        if (cursor != null) {
            cursor.moveToFirst();
            if (cursor.moveToFirst()) {
                channelData.channelDes = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES));
                channelData.channelName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME));
                channelData.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                channelData.channelImage = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE));
                channelData.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
            }
            cursor.close();
        }
        return channelData;
    }

    public void updateChannelData(String channelId, String key, String value) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelExist(channelId);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_CHANNEL, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void updateChannelInfo(String channelId, String channelName, String channelDes, String channelImage, String channelType, String adminId, String channelAdminName, String totalSubscribers, String blockStatus) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelExist(channelId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_CHANNEL_ID, channelId);
        values.put(Constants.TAG_CHANNEL_NAME, channelName);
        values.put(Constants.TAG_CHANNEL_DES, channelDes);
        values.put(Constants.TAG_CHANNEL_IMAGE, channelImage);
        values.put(Constants.TAG_CHANNEL_TYPE, channelType);
        values.put(Constants.TAG_CHANNEL_ADMIN_ID, adminId);
        values.put(Constants.TAG_CHANNEL_ADMIN_NAME, channelAdminName);
        values.put(Constants.TAG_TOTAL_SUBSCRIBERS, totalSubscribers);
//        values.put(Constants.TAG_BLOCK_STATUS, blockStatus);

        if (exists) {
            db.update(TABLE_CHANNEL, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void updateChannelWithoutAdminName(String channelId, String channelName, String channelDes, String channelImage, String channelType, String adminId, String totalSubscribers) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelExist(channelId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_CHANNEL_ID, channelId);
        values.put(Constants.TAG_CHANNEL_NAME, channelName);
        values.put(Constants.TAG_CHANNEL_DES, channelDes);
        values.put(Constants.TAG_CHANNEL_IMAGE, channelImage);
        values.put(Constants.TAG_CHANNEL_TYPE, channelType);
        values.put(Constants.TAG_CHANNEL_ADMIN_ID, adminId);
        values.put(Constants.TAG_TOTAL_SUBSCRIBERS, totalSubscribers);

        if (exists) {
            db.update(TABLE_CHANNEL, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void addChannelMessages(String channelId, String chatType, String messageId, String messageType,
                                   String message, String attachment, String lat, String lon,
                                   String contactName, String contactPhone, String countryCode, String chatTime, String thumbnail, String deliveryStatus) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CHANNEL_ID, channelId);
            values.put(Constants.TAG_CHAT_TYPE, chatType);
            values.put(Constants.TAG_MESSAGE_ID, messageId);
            values.put(Constants.TAG_MESSAGE_TYPE, messageType);
            values.put(Constants.TAG_MESSAGE, message);
            values.put(Constants.TAG_ATTACHMENT, attachment);
            values.put(Constants.TAG_LAT, lat);
            values.put(Constants.TAG_LON, lon);
            values.put(Constants.TAG_CONTACT_NAME, contactName);
            values.put(Constants.TAG_CONTACT_PHONE_NO, contactPhone);
            values.put(Constants.TAG_CONTACT_COUNTRY_CODE, countryCode);
            values.put(Constants.TAG_CHAT_TIME, chatTime);
            values.put(Constants.TAG_THUMBNAIL, thumbnail);
            values.put(Constants.TAG_PROGRESS, "");
            values.put(Constants.TAG_DELIVERY_STATUS, deliveryStatus);

            getWritableDatabase().insertWithOnConflict(TABLE_CHANNEL_MESSAGES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addChannelRecentMsgs(String channelId, String messageId, String chatTime, String unreadCount) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CHANNEL_ID, channelId);
            values.put(Constants.TAG_MESSAGE_ID, messageId);
            values.put(Constants.TAG_CHAT_TIME, chatTime);
            values.put(Constants.TAG_UNREAD_COUNT, unreadCount);

            getWritableDatabase().insertWithOnConflict(TABLE_CHANNEL_RECENT_MESSAGES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<ChannelMessage> getChannelMessages(String channelId, String offset, String limit) {

        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='" + channelId + "'" + " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC" + " LIMIT " + limit + " OFFSET " + offset;

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<ChannelMessage> channelMessages = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ChannelMessage message = new ChannelMessage();
                message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                message.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                message.chatType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TYPE));
                message.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                message.contactPhoneNo = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
                message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                message.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
                message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));

                channelMessages.add(message);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return channelMessages;
    }

    public ChannelMessage getSingleChannelMessage(String channelId, String messageId) {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='" + channelId + "'" + " AND " + Constants.TAG_MESSAGE_ID + "='" + messageId + "'";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ChannelMessage message = new ChannelMessage();

        if (cursor.moveToFirst()) {
            message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
            message.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
            message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
            message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
            message.chatType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TYPE));
            message.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
            message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
            message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
            message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
            message.contactPhoneNo = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
            message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
            message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
            message.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
            message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
            message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));
        }
        return message;
    }

    public ArrayList<HashMap<String, String>> getChannelRecentMessages(Context context) {

        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_RECENT_MESSAGES + " LEFT JOIN " + TABLE_CHANNEL_MESSAGES + " ON " +
                TABLE_CHANNEL_RECENT_MESSAGES + "." + Constants.TAG_MESSAGE_ID + " = " + TABLE_CHANNEL_MESSAGES + "." + Constants.TAG_MESSAGE_ID +
                " INNER JOIN " + TABLE_CHANNEL + " ON " + TABLE_CHANNEL_RECENT_MESSAGES + "." + Constants.TAG_CHANNEL_ID +
                " = " + TABLE_CHANNEL + "." + Constants.TAG_CHANNEL_ID + " WHERE " + TABLE_CHANNEL + "." +
                Constants.TAG_CHANNEL_ADMIN_ID + " !='" + GetSet.getUserId() + "' AND " + TABLE_CHANNEL + "." + Constants.TAG_BLOCK_STATUS + " !='1' " +
                " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";

//        Log.d(TAG, "getChannelRecentMessages: " + selectQuery);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<HashMap<String, String>> recentAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<>();
                map.put(Constants.TAG_MESSAGE_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
                map.put(Constants.TAG_CHANNEL_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID)));
                map.put(Constants.TAG_CHANNEL_IMAGE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_IMAGE)));
                map.put(Constants.TAG_CHANNEL_NAME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_NAME)));
                map.put(Constants.TAG_CHANNEL_DES, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_DES)));
                map.put(Constants.TAG_MESSAGE_TYPE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE)));
                ChannelResult.Result info = getChannelInfo(map.get(Constants.TAG_CHANNEL_ID));
                if (map.get(Constants.TAG_MESSAGE_TYPE) != null && map.get(Constants.TAG_MESSAGE_TYPE).equals(Constants.TAG_ISDELETE)) {
                    if (info.adminId != null && info.adminId.equals(GetSet.getUserId())) {
                        map.put(Constants.TAG_MESSAGE, context.getString(R.string.you_delete_this_message));
                    } else {
                        map.put(Constants.TAG_MESSAGE, context.getString(R.string.this_message_was_deleted));
                    }
                } else {
                    if (cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)) != null && !TextUtils.isEmpty(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)))) {
                        map.put(Constants.TAG_MESSAGE, ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE))));
                    } else {
                        map.put(Constants.TAG_MESSAGE, "");
                    }
                }
                map.put(Constants.TAG_CHAT_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
                map.put(Constants.TAG_CHANNEL_TYPE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_TYPE)));
                map.put(Constants.TAG_UNREAD_COUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
                map.put(Constants.TAG_MUTE_NOTIFICATION, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION)));
                map.put(Constants.TAG_CHANNEL_CATEGORY, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_CATEGORY)));
                map.put(Constants.TAG_SUBSCRIBE_STATUS, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SUBSCRIBE_STATUS)));

                recentAry.add(map);
                //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();

//        Log.d(TAG, "getChannelRecentMessages: " + new Gson().toJson(recentAry));
        Log.d(TAG, "getChannelRecentMessages: " + recentAry.size());

        return recentAry;
    }

    public HashMap<String, String> getRecentChannelMsg() {

        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_RECENT_MESSAGES +
                " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC" + " LIMIT " + "'1'";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        HashMap<String, String> map = new HashMap<>();
        if (cursor.moveToFirst()) {
            map.put(Constants.TAG_MESSAGE_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID)));
            map.put(Constants.TAG_CHANNEL_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID)));
            map.put(Constants.TAG_CHAT_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME)));
            map.put(Constants.TAG_UNREAD_COUNT, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_UNREAD_COUNT)));
            //Log.v("Items", "Id="+cursor.getString(0)+"ItemId="+cursor.getString(1)+" Liked="+cursor.getString(2)+" Report="+cursor.getString(3)+" Share="+cursor.getString(4));
        }
        cursor.close();

        return map;
    }

    public int getUnseenChannelMessagesCount(String channelId) {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_DELIVERY_STATUS + " ='' AND " + Constants.TAG_CHANNEL_ID + "='" + channelId + "'";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public boolean isRecentChannelIdExist(SQLiteDatabase db, String channelId) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_CHANNEL_RECENT_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "=?",
                new String[]{channelId});
        return line > 0;
    }

    public void updateChannelMessageData(String message_id, String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelMessageIdExist(db, message_id);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_CHANNEL_MESSAGES, values, Constants.TAG_MESSAGE_ID + " =? ",
                    new String[]{message_id});
        }
    }

    public boolean isChannelMessageIdExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_MESSAGE_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isChannelMessageIdExist(String id) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_MESSAGE_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isChannelIdExist(SQLiteDatabase db, String id) {
        long line = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public boolean isChannelIdExistInMessages(String channelId) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "=?",
                new String[]{channelId});
        return line > 0;
    }

    public boolean isChannelRecentIdExist(String channelId) {
        long line = DatabaseUtils.longForQuery(this.getWritableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL_RECENT_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "=?",
                new String[]{channelId});
        return line > 0;
    }

    public int getChannelMessagesCount(String channelId) {
        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='" + channelId + "'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void updateChannelMessageReadStatus(String channelId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelExist(channelId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_DELIVERY_STATUS, "read");
        if (exists) {
            db.update(TABLE_CHANNEL_MESSAGES, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void updateChannelReadData(String channelId, String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isChannelIdExist(db, channelId);
        ContentValues values = new ContentValues();
        values.put(key, value);

        if (exists) {
            db.update(TABLE_CHANNEL_MESSAGES, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void resetUnseenChannelMessagesCount(String channelId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isRecentChannelIdExist(db, channelId);
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_UNREAD_COUNT, "0");

        if (exists) {
            db.update(TABLE_CHANNEL_RECENT_MESSAGES, values, Constants.TAG_CHANNEL_ID + " =? ",
                    new String[]{channelId});
        }
    }

    public void deleteChannelMessages(String channelId) {
        String deleteQuery = "DELETE FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID +
                "='" + channelId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void deleteChannel(String channelId) {
        String deleteQuery = "DELETE FROM " + TABLE_CHANNEL + " WHERE " + Constants.TAG_CHANNEL_ID +
                "='" + channelId + "'";
        getWritableDatabase().execSQL(deleteQuery);
    }

    public void deleteChannelRecentMessages(String channelId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isRecentChannelIdExist(db, channelId);
        if (exists) {
            String deleteQuery = "DELETE FROM " + TABLE_CHANNEL_RECENT_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID +
                    "='" + channelId + "'";
            getWritableDatabase().execSQL(deleteQuery);

        }
    }

    // Insert a recent call into the database

    public void addRecentCall(String call_id, String user_id, String type,
                              String call_status, String created_at, String isAlert) {
        try {
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_CALL_ID, call_id);
            values.put(Constants.TAG_USER_ID, user_id);
            values.put(Constants.TAG_TYPE, type);
            values.put(Constants.TAG_CALL_STATUS, call_status);
            values.put(Constants.TAG_CREATED_AT, created_at);
            values.put(Constants.TAG_IS_ALERT, isAlert);

            getWritableDatabase().insertWithOnConflict(TABLE_CALL, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<ContactsData.Result> getRecentCall() {
        String selectQuery = "SELECT * FROM " + TABLE_CALL + " INNER JOIN " + TABLE_CONTACTS + " ON " + TABLE_CALL + "." + Constants.TAG_USER_ID + " = " +
                TABLE_CONTACTS + "." + Constants.TAG_USER_ID + " ORDER BY " + Constants.TAG_CREATED_AT + " DESC";
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        ArrayList<ContactsData.Result> recentAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ContactsData.Result result = new ContactsData().new Result();
                result.callId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CALL_ID));
                result.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
                result.type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TYPE));
                result.callStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CALL_STATUS));
                result.callCreatedAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
                result.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                result.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                result.phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                result.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                result.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                        result.phoneNumber, result.country_code);
                result.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                result.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                result.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                result.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                result.isAlert = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_ALERT));
                result.isSelected = "0";
                result.blockStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                recentAry.add(result);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return recentAry;
    }

    public boolean isCallIdExist(String id) {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CALL + " WHERE " + Constants.TAG_CALL_ID + "=?",
                new String[]{id});
        return line > 0;
    }

    public CallData.Result getCallData(String Id) {
        String selectQuery = "SELECT * FROM " + TABLE_CALL + " WHERE " + Constants.TAG_CALL_ID + " ='" + Id + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        boolean exists = isCallIdExist(Id);
        if (exists) {
            Cursor cursor = db.rawQuery(selectQuery, null);
            // looping through all rows and adding to list
            CallData.Result data = new CallData().new Result();
            if (cursor != null)
                cursor.moveToFirst();
            data.callId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CALL_ID));
            data.userId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID));
            data.type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TYPE));
            data.callStatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CALL_STATUS));
            data.createdAt = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CREATED_AT));
            cursor.close();
            return data;
        } else {
            return null;
        }
    }

    public boolean isRecentChatIndicationExist() {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_RECENTS + " WHERE " + Constants.TAG_UNREAD_COUNT + "!=?",
                new String[]{"0"});
        return line > 0;
    }

    public boolean isRecentGroupIndicationExist() {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_GROUP_RECENT_MESSAGES + " WHERE " + Constants.TAG_UNREAD_COUNT + "!=?",
                new String[]{"0"});

        return line > 0;
    }

    public boolean isRecentChannelIndicationExist() {
        if (GetSet.getUserId() != null) {
            long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL_RECENT_MESSAGES
                            + " INNER JOIN " + Constants.TAG_CHANNEL + " ON "
                            + Constants.TAG_CHANNEL + "." + Constants.TAG_CHANNEL_ID + " = " + TABLE_CHANNEL_RECENT_MESSAGES + "." + Constants.TAG_CHANNEL_ID
                            + " AND " + Constants.TAG_CHANNEL + "." + Constants.TAG_CHANNEL_ADMIN_ID + " IS NOT NULL AND "
                            + Constants.TAG_CHANNEL + "." + Constants.TAG_CHANNEL_ADMIN_ID + " !=?"
                            + " WHERE " + TABLE_CHANNEL_RECENT_MESSAGES + "." + Constants.TAG_UNREAD_COUNT + " !=? "
                    ,
                    new String[]{GetSet.getUserId(), "0"});
            return line > 0;
        }
        return false;
    }

    public boolean isMissedCallIndicationExist() {
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CALL + " WHERE " + Constants.TAG_IS_ALERT + "!=?",
                new String[]{"1"});
        return line > 0;
    }

    public void clearDB(Context context) {
        SQLiteDatabase db = getWritableDatabase(); // helper is object extends SQLiteOpenHelper
        for (String tableName : ALL_TABLES) {
            db.delete(tableName, null, null);
        }
    }

    public List<MediaModelData> getMedia(String chat_id, String type, Context context) throws Exception {
        String selectQuery = "";

        if (type.equals(Constants.TAG_CHANNEL)) {
            selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='" +
                    chat_id + "' AND " /*+ Constants.TAG_PROGRESS + "='completed'" + " AND "*/ + Constants.TAG_MESSAGE_TYPE + " IN " + "('image','video','document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        } else if (type.equals(Constants.TAG_GROUP)) {
            selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" +
                    chat_id + "' AND " /*+ Constants.TAG_PROGRESS + "='completed'" + " AND " */ + Constants.TAG_MESSAGE_TYPE + " IN " + "('image','video','document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        } else {
            selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_CHAT_ID + "='" +
                    GetSet.getUserId() + chat_id + "' AND "/* + Constants.TAG_PROGRESS + "='completed'" + " AND " */ + Constants.TAG_MESSAGE_TYPE + " IN " + "('image','video','document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        }

        StorageManager storageManager = StorageManager.getInstance(context);

        if (!selectQuery.equals("")) {
            Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
            List<MediaModelData> messageAry = new ArrayList<>();
            // looping through all rows and adding to list
            if (cursor.moveToFirst()) {
                do {
                    MediaModelData results = new MediaModelData();
                    results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                    results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                    results.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                    results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                    results.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
                    File file = null;
                    if (results.message_type.equalsIgnoreCase("video")) {
                        file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, results.attachment, StorageManager.TAG_VIDEO);
                    } else if (results.message_type.equalsIgnoreCase("document")) {
                        file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT_SENT, results.attachment, StorageManager.TAG_DOCUMENT);
                    } else if (results.message_type.equalsIgnoreCase("image")) {
                        file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, results.attachment, StorageManager.TAG_IMAGE);
                    }
                    if (file != null) {
                        messageAry.add(results);
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Uri fileUri = null;
                            if (results.message_type.equalsIgnoreCase("video")) {
                                fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, results.attachment, StorageManager.TAG_VIDEO);
                            } else if (results.message_type.equalsIgnoreCase("document")) {
                                fileUri = storageManager.getFileUri(StorageManager.TAG_DOCUMENT, results.attachment, StorageManager.TAG_DOCUMENT);
                            } else if (results.message_type.equalsIgnoreCase("image")) {
                                fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, results.attachment, StorageManager.TAG_IMAGE);
                            }
                            if (fileUri != null) {
                                messageAry.add(results);
                            }
                        } else {
                            if (results.message_type.equalsIgnoreCase("video")) {
                                file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, results.attachment, StorageManager.TAG_VIDEO);
                            } else if (results.message_type.equalsIgnoreCase("document")) {
                                file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, results.attachment, StorageManager.TAG_DOCUMENT);
                            } else if (results.message_type.equalsIgnoreCase("image")) {
                                file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, results.attachment, StorageManager.TAG_IMAGE);
                            }
                            if (file != null) {
                                messageAry.add(results);
                            }
                        }
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
            Log.i(TAG, "getMedia: " + messageAry.size());
            return messageAry;
        }
        return null;
    }

    public List<MediaModelData> getDocMedia(String chat_id, String type, Context context) throws Exception {
        String selectQuery = "";

        if (type.equals(Constants.TAG_CHANNEL)) {
            selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='" +
                    chat_id + "' AND " /*+ Constants.TAG_PROGRESS + "='completed'" + " AND "*/ + Constants.TAG_MESSAGE_TYPE + " IN " + "('document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        } else if (type.equals(Constants.TAG_GROUP)) {
            selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" +
                    chat_id + "' AND " /*+ Constants.TAG_PROGRESS + "='completed'" + " AND " */ + Constants.TAG_MESSAGE_TYPE + " IN " + "('document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        } else {
            selectQuery = "SELECT * FROM " + TABLE_MESSAGES + " WHERE " + Constants.TAG_CHAT_ID + "='" +
                    GetSet.getUserId() + chat_id + "' AND "/* + Constants.TAG_PROGRESS + "='completed'" + " AND " */ + Constants.TAG_MESSAGE_TYPE + " IN " + "('document')" +
                    " ORDER BY " + Constants.TAG_CHAT_TIME + " DESC";
        }

        StorageManager storageManager = StorageManager.getInstance(context);

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<MediaModelData> messageAry = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                MediaModelData results = new MediaModelData();
                results.message_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                results.message_type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                results.attachment = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT)));
                results.chat_time = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                results.thumbnail = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL)));
                File file = null;
                if (results.message_type.equalsIgnoreCase("video")) {
                    file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, results.attachment, StorageManager.TAG_VIDEO);
                } else if (results.message_type.equalsIgnoreCase("document")) {
                    file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT_SENT, results.attachment, StorageManager.TAG_DOCUMENT);
                } else if (results.message_type.equalsIgnoreCase("image")) {
                    file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, results.attachment, StorageManager.TAG_IMAGE);
                }
                if (file != null) {
                    messageAry.add(results);
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = null;
                        if (results.message_type.equalsIgnoreCase("video")) {
                            fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, results.attachment, StorageManager.TAG_VIDEO);
                        } else if (results.message_type.equalsIgnoreCase("document")) {
                            fileUri = storageManager.getFileUri(StorageManager.TAG_DOCUMENT, results.attachment, StorageManager.TAG_DOCUMENT);
                        } else if (results.message_type.equalsIgnoreCase("image")) {
                            fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, results.attachment, StorageManager.TAG_IMAGE);
                        }
                        if (fileUri != null) {
                            messageAry.add(results);
                        }
                    } else {
                        if (results.message_type.equalsIgnoreCase("video")) {
                            file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, results.attachment, StorageManager.TAG_VIDEO);
                        } else if (results.message_type.equalsIgnoreCase("document")) {
                            file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, results.attachment, StorageManager.TAG_DOCUMENT);
                        } else if (results.message_type.equalsIgnoreCase("image")) {
                            file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, results.attachment, StorageManager.TAG_IMAGE);
                        }
                        if (file != null) {
                            messageAry.add(results);
                        }
                    }
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.i(TAG, "getDocMedia: " + messageAry.size());
        return messageAry;
    }

    public void createStatus(String status_id, String time, String type, String senderId,
                             String attachment, String message, String isViewed, String thumbnail,
                             String expiryTime, String members) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_STATUS_ID, status_id);
            values.put(Constants.TAG_STATUS_TIME, time);
            values.put(Constants.TAG_TYPE, type);
            values.put(Constants.TAG_SENDER_ID, senderId);
            values.put(Constants.TAG_ATTACHMENT, attachment);
            values.put(Constants.TAG_MESSAGE, message);
            values.put(Constants.TAG_STATUS_VIEW, isViewed);
            values.put(Constants.TAG_THUMBNAIL, thumbnail);
            values.put(Constants.TAG_STORY_MEMBERS, members);
            values.put(Constants.TAG_EXPIRY_TIME, expiryTime);

            db.insertWithOnConflict(TABLE_STATUS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createStatusView(String statusId, String senderId) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_STATUS_ID, statusId);
            values.put(Constants.TAG_MEMBER_ID, senderId);
            values.put(Constants.TAG_STATUS_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
            values.put(Constants.TAG_MEMBER_KEY, statusId + senderId);

            db.insertWithOnConflict(TABLE_STATUS_VIEW, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteStatus(String storyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // Order of deletions is important when foreign key relationships exist.
            db.delete(TABLE_STATUS, Constants.TAG_STATUS_ID + " =? ", new String[]{storyId});
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to delete all posts and users");
        }
    }

    public List<StatusDatas> getSingleUserStatus(String userId) {
        String selectQuery = "SELECT * FROM " + TABLE_STATUS + " WHERE " + Constants.TAG_SENDER_ID + "='" + userId + "'" + " ORDER BY " + Constants.TAG_STATUS_TIME + " ASC";

        List<StatusDatas> data = new ArrayList<>();
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                StatusDatas datas = new StatusDatas();
                datas.mSenderId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
                datas.mStatusTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_TIME));
                datas.mStatusId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_ID));
                datas.mAttachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
                datas.mThumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
                datas.mType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TYPE));
                datas.mMessage = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                datas.mIsSeen = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_VIEW)));
                data.add(datas);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.i(TAG, "getSingleUserStatus: " + data.size());
        return data;
    }

    public StatusDatas getSingleStatus(String statusID) {
        String selectQuery = "SELECT * FROM " + TABLE_STATUS + " WHERE " + Constants.TAG_STATUS_ID + "='" + statusID + "'";

        StatusDatas datas = new StatusDatas();
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        if (cursor != null)
            cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            datas.mSenderId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
            datas.mStatusTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_TIME));
            datas.mStatusId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_ID));
            datas.mAttachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
            datas.mThumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
            datas.mType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TYPE));
            datas.mMessage = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
        }
        cursor.close();
        return datas;
    }

    private void deleteOldStatus() {
        String currentTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
        String[] projection = {Constants.TAG_STATUS_ID, Constants.TAG_ATTACHMENT, Constants.TAG_THUMBNAIL,
                Constants.TAG_EXPIRY_TIME, Constants.TAG_SENDER_ID, Constants.TAG_TYPE};
        String selection = Constants.TAG_EXPIRY_TIME + "<?"; //this must be array
        String[] selectionArgs = new String[]{currentTime}; //this must be array

        Cursor cursor = getWritableDatabase().query(TABLE_STATUS, projection, selection, selectionArgs, null, null, null);
        if (cursor.getCount() > 0 && cursor.moveToFirst()) {
            do {
                String statusId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_ID));
                String fileName = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
                String thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
                String senderId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
                String type = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_TYPE));
                try {
                    if (senderId.equals(GetSet.getUserId())) {
                        storageManager.deleteStory(fileName, thumbnail, "ownstory");
                    } else {
                        storageManager.deleteStory(fileName, thumbnail, "");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                deleteStatus(statusId);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public String getUserstatusUnSeenCount(String userId) {
        String count = "SELECT COUNT(status_view) from " + TABLE_STATUS + " WHERE " + Constants.TAG_STATUS_VIEW + "='0' AND "+Constants.TAG_SENDER_ID+"='" + userId + "'";
        String line = DatabaseUtils.stringForQuery(getReadableDatabase(), count,null);
        return line;
    }



    public List<ContactsData.Result> getStatusContactData(Context context) {
        deleteOldStatus();

        List<ContactsData.Result> contactData = new ArrayList<>();

        if (isStoryUserExists(GetSet.getUserId())) {
            ContactsData.Result results = new ContactsData().new Result();
            results.user_id = GetSet.getUserId();
            results.user_name = context.getString(R.string.you);
            results.user_image = GetSet.getImageUrl();
            results.is_View = "1";
            results.blockedme = "";
            results.blockedbyme = "";
            results.phone_no = GetSet.getphonenumber();
            results.country_code = GetSet.getcountrycode();
            results.privacy_last_seen = "";
            results.privacy_profile_image = "";
            results.privacy_about = "";
            results.about = "";
            results.mute_notification = "";
            results.contactstatus = "";
            results.favourited = "";

            contactData.add(results);

        }

        String selectQueryUnseen = "SELECT * FROM " + TABLE_STATUS + " JOIN " +
                TABLE_CONTACTS + " WHERE " + TABLE_STATUS + "." + Constants.TAG_SENDER_ID + "=" +
                TABLE_CONTACTS + "." + TAG_USER_ID + " AND " + TABLE_STATUS + "." + Constants.TAG_SENDER_ID + "!='" + GetSet.getUserId()
                + "' AND " + "(" + TABLE_CONTACTS + "." + Constants.TAG_CONTACT_STATUS + "='true' " + " AND "
                + TABLE_CONTACTS + "." + Constants.TAG_DELETED_ACCOUNT + " ISNULL OR " + TABLE_CONTACTS + "." + Constants.TAG_DELETED_ACCOUNT + " = 0"
                + ")" + " GROUP BY " + Constants.TAG_SENDER_ID + " ORDER BY " + TABLE_STATUS + "." + Constants.TAG_STATUS_VIEW + " ASC,"
                + TABLE_STATUS + "." + Constants.TAG_STATUS_TIME + " DESC";
//        Log.d(TAG, "getStatusContactData: " + selectQueryUnseen);

        contactData.addAll(getContact(context, selectQueryUnseen));

//        Log.d(TAG, "getStatusContactData: " + new Gson().toJson(contactData));
//        Log.d(TAG, "getStatusContactData: " + contactData.size());

        return contactData;
    }

    private List<ContactsData.Result> getContact(Context context, String query) {

        List<ContactsData.Result> data = new ArrayList<>();
        Cursor cursor = getReadableDatabase().rawQuery(query, null);
        if (cursor.getCount() > 0 && cursor.moveToFirst()) {
            do {
                ContactsData.Result results = new ContactsData().new Result();
                results.user_id = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SENDER_ID));
                results.user_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE));
                results.phone_no = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER));
                results.country_code = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE));
                if (results.user_id.equals(GetSet.getUserId())) {
                    results.user_name = context.getString(R.string.you);
                } else {
                    results.user_name = getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                            results.phone_no, results.country_code);
                }
                results.privacy_last_seen = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_LAST_SEEN));
                results.privacy_profile_image = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_PROFILE));
                results.privacy_about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PRIVACY_ABOUT));
                results.blockedme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_ME));
                results.blockedbyme = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_BLOCKED_BYME));
                results.about = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ABOUT));
                results.mute_notification = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MUTE_NOTIFICATION));
                results.contactstatus = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_STATUS));
                results.favourited = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_FAVOURITED));
                //results.is_View = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_VIEW));

                String unseencount = getUserstatusUnSeenCount(results.user_id);
                if(unseencount.equalsIgnoreCase("0")){
                    results.is_View = "1";
                }else results.is_View = "0";

                results.saved_name = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME));

                HashMap<String, String> map = ApplicationClass.getContactOrNot(context, results.phone_no);
                if (results.user_id.equals(GetSet.getUserId())) {
                    data.add(results);
                } else if (map.get("isAlready").equals("true")) {
                    data.add(results);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        return data;
    }

    public ArrayList<HashMap<String, String>> getViewedContact(Context context, String storyId) {
        ArrayList<HashMap<String, String>> viewedContact = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_STATUS_VIEW + " JOIN " + TABLE_CONTACTS + " WHERE " + Constants.TAG_STATUS_ID + "='" + storyId + "' AND " + TABLE_STATUS_VIEW + "." + Constants.TAG_MEMBER_ID + "=" +
                TABLE_CONTACTS + "." + TAG_USER_ID + " ORDER BY " + TABLE_STATUS_VIEW + "." + Constants.TAG_STATUS_TIME + " DESC";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<>();
                map.put(TAG_USER_ID, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_ID)));
                map.put(Constants.TAG_USER_IMAGE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_USER_IMAGE)));
                map.put(Constants.TAG_PHONE_NUMBER, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PHONE_NUMBER)));
                map.put(Constants.TAG_COUNTRY_CODE, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_COUNTRY_CODE)));
                map.put(Constants.TAG_USER_NAME, getUserName(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_SAVED_NAME)),
                        map.get(Constants.TAG_PHONE_NUMBER), map.get(Constants.TAG_COUNTRY_CODE)));
                map.put(Constants.TAG_STATUS_TIME, cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STATUS_TIME)));
                viewedContact.add(map);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return viewedContact;
    }

    public void updateStatusSeen(String statusId) {
        if (isStoryExists(statusId)) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_STATUS_VIEW, "1");
            db.update(TABLE_STATUS, values, Constants.TAG_STATUS_ID + " =? ",
                    new String[]{statusId});
        }
    }

    public void updateCallAlert(String callId) {
        if (isCallIdExist(callId)) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Constants.TAG_IS_ALERT, "1");
            db.update(TABLE_CALL, values, Constants.TAG_CALL_ID + " =? ",
                    new String[]{callId});
        }
    }

    public String getStatusMember(String statusId) {
        String selectQuery = "SELECT * FROM " + TABLE_STATUS +
                " WHERE " + Constants.TAG_STATUS_ID + "='" + statusId + "'";

        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        String members = "";
        if (cursor != null) {
            cursor.moveToFirst();

            if (cursor.moveToFirst()) {
                members = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_STORY_MEMBERS)).trim();
            }
            cursor.close();
        }
        return members;
    }

    public List<GroupMessage> getGroupUnreadMessages(String groupId, Context context) {
        String selectQuery = "SELECT * FROM " + TABLE_GROUP_MESSAGES + " WHERE " + Constants.TAG_GROUP_ID + "='" + groupId
                + "' AND (" + Constants.TAG_DELIVERY_STATUS + " ISNULL OR "
                + Constants.TAG_DELIVERY_STATUS + "!='read')" + " ORDER BY " + Constants.TAG_CHAT_TIME + " ASC";
//        Log.d(TAG, "getGroupUnreadMessages: " + selectQuery);
        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<GroupMessage> groupMessage = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                GroupMessage message = new GroupMessage();
                message.groupId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ID));
                message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                message.memberId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MEMBER_ID));
                message.groupAdminId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_GROUP_ADMIN_ID));
                message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                message.attachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
                message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                message.contactPhoneNo = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO));
                message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                message.thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
                message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));
                groupMessage.add(getGroupMessagesByType(this, context, message));
            } while (cursor.moveToNext());
        }
        cursor.close();
        Log.d(TAG, "getGroupUnreadMessages: " + groupMessage.size());
        return groupMessage;
    }

    public List<ChannelMessage> getChannelUnreadMessages(String channelId) {

        String selectQuery = "SELECT * FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "='"
                + channelId + "' AND " + Constants.TAG_DELIVERY_STATUS + "!='read' " + " ORDER BY " + Constants.TAG_CHAT_TIME + " ASC";

        Cursor cursor = getWritableDatabase().rawQuery(selectQuery, null);
        List<ChannelMessage> channelMessages = new ArrayList<>();
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ChannelMessage message = new ChannelMessage();
                message.messageId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_ID));
                message.channelId = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHANNEL_ID));
                message.messageType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE_TYPE));
                message.message = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_MESSAGE)));
                message.chatType = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TYPE));
                message.attachment = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_ATTACHMENT));
                message.lat = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LAT)));
                message.lon = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_LON)));
                message.contactName = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_NAME)));
                message.contactPhoneNo = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_PHONE_NO)));
                message.contactCountryCode = ApplicationClass.decryptMessage(cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CONTACT_COUNTRY_CODE)));
                message.chatTime = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_CHAT_TIME));
                message.thumbnail = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_THUMBNAIL));
                message.progress = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_PROGRESS));
                message.isDelete = cursor.getString(cursor.getColumnIndexOrThrow(Constants.TAG_IS_DELETE));

                channelMessages.add(message);
            } while (cursor.moveToNext());
        }
        cursor.close();
//        Log.i(TAG, "getChannelUnreadMessages: " + channelMessages.size());
        return channelMessages;
    }

    public boolean getChannelUnreadCount(String channelId) {
        Log.i(TAG, "getChannelUnreadCount: " + channelId);
        long line = DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT COUNT(*) FROM " + TABLE_CHANNEL_MESSAGES + " WHERE " + Constants.TAG_CHANNEL_ID + "=?" +
                        " AND " + Constants.TAG_DELIVERY_STATUS + "!=? AND " + Constants.TAG_MESSAGE_TYPE + "!=?" + " ORDER BY " + Constants.TAG_CHAT_TIME + " ASC",
                new String[]{"1", "read", "create_channel"});
        Log.i(TAG, "getChannelUnreadCount: " + line);
        return line > 0;
    }

    public String getUserName(String name, String phoneNumber, String countryCode) {
        if (name != null && !name.equals("")) {
            return name;
        } else {
            if (countryCode != null && !countryCode.equals("")) {
                return "+" + countryCode + " " + phoneNumber;
            } else {
                return phoneNumber;
            }
        }
    }

    private String getMessage(String userId, String messageType, String message, Context context) {
        if (messageType != null && messageType.equals(Constants.TAG_ISDELETE)) {
            if (userId != null && userId.equals(GetSet.getUserId())) {
                return context.getString(R.string.you_delete_this_message);
            } else {
                return context.getString(R.string.this_message_was_deleted);
            }
        } else {
            return message;
        }
    }

    public void updateWallpaper(String _id, String type, String value) {
        switch (type) {
            case Constants.TAG_USER:
                updateContactInfo(_id, Constants.TAG_WALLPAPER, value);
                break;
            case Constants.TAG_GROUP:
                updateGroupData(_id, Constants.TAG_WALLPAPER, value);
                break;
            case Constants.TAG_CHANNEL:
                updateChannelData(_id, Constants.TAG_WALLPAPER, value);
                break;
        }
    }

    public void updateWallpaper(String type, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_WALLPAPER, value);
        switch (type) {
            case Constants.TAG_USER:
                db.update(TABLE_CONTACTS, values, null, null);
                break;
            case Constants.TAG_GROUP:
                db.update(TABLE_GROUP, values, null, null);
                break;
            case Constants.TAG_CHANNEL:
                db.update(TABLE_CHANNEL, values, null, null);
                break;
        }
    }

    public void resetWallpaper() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_WALLPAPER, "");
        String whereClause = Constants.TAG_WALLPAPER + " ISNULL OR " + Constants.TAG_WALLPAPER + " =?"; //this must be array
        String[] selectionArgs = new String[]{""}; //this must be array
        db.update(TABLE_CONTACTS, values, whereClause, selectionArgs);
        db.update(TABLE_GROUP, values, whereClause, selectionArgs);
        db.update(TABLE_CHANNEL, values, whereClause, selectionArgs);
    }

    public void setDefaultWallpaper(String filePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.TAG_WALLPAPER, "");
        String whereClause = Constants.TAG_WALLPAPER + " ISNULL OR " + Constants.TAG_WALLPAPER + " =?"; //this must be array
        String[] selectionArgs = new String[]{""}; //this must be array
        db.update(TABLE_CONTACTS, values, whereClause, selectionArgs);
        db.update(TABLE_GROUP, values, whereClause, selectionArgs);
        db.update(TABLE_CHANNEL, values, whereClause, selectionArgs);
    }

    public void backupDatabase(String dbName) {
        Log.d(TAG, "backupDatabase: " + dbFile.getAbsolutePath());
        File outputFile = new File(storageManager.getDirectory(StorageManager.TAG_DOCUMENT_SENT, StorageManager.TAG_DOCUMENT), dbName);
        if (outputFile.exists()) outputFile.delete();
        try {
            FileInputStream fis = new FileInputStream(dbFile);
            // Open the empty db as the output stream
            OutputStream output = new FileOutputStream(outputFile);
            // Transfer bytes from the input file to the output file
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
            // Close the streams
            output.flush();
            output.close();
            fis.close();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                storageManager.saveFileInStorageV10(outputFile, dbName, StorageManager.TAG_DOCUMENT, StorageManager.TAG_DOCUMENT);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
