package com.app.helper.screenlock;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class ScreenLockUtils {
    private ScreenLockUtils() {
    }

    /**
     * Use this method to prevent from creating dialog fragment more than one.
     *
     * <p>Consider a case that user click button so fast that show more than one dialog fragment.
     *
     * @param hostFragment The host fragment of dialog fragment
     * @param fClass       The dialog fragment you want to show singleton
     * @param <T>          The dialog fragment class
     * @return The dialog fragment instance, it may be new or from dialog fragment manager
     */
    @SuppressWarnings("unchecked")
    public static <T extends DialogFragment> T showSingletonFragment(
            Fragment hostFragment, Class<T> fClass) {
        // Use class name to tag the fragment
        String fragmentName = fClass.getName();
        FragmentManager fm = hostFragment.getChildFragmentManager();
        fm.executePendingTransactions();

        // If this dialog fragment isn't in fragment manager, then create new one
        T fragmentInManager = (T) fm.findFragmentByTag(fragmentName);
        if (fragmentInManager == null) {
            fragmentInManager = createFragment(fClass);
            fragmentInManager.show(fm, fragmentName);
        }

        return fragmentInManager;
    }

    /**
     * Create fragment from class
     */
    private static <T extends Fragment> T createFragment(Class<T> fClass) {
        try {
            return fClass.newInstance();
        } catch (IllegalAccessException ignored) {
            throw new RuntimeException("Failed to create fragment instance");
        } catch (InstantiationException ignored) {
            throw new RuntimeException("Failed to create fragment instance");
        }
    }
}
