package com.app.fourchattingapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract;
import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.app.helper.DatabaseHandler;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MobileNumberActivity extends BaseActivity {
    private static final String TAG = MobileNumberActivity.class.getSimpleName();
    private static final int APP_REQUEST_CODE = 9002;
    private ApiInterface apiInterface;
    private DatabaseHandler dbHelper;
    private ActivityResultLauncher<Intent> otpResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_kit);
        dbHelper = DatabaseHandler.getInstance(this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        initActivityResult();

        verifyMobileNo();
//        signIn("7200348126", "+91", "IN");
//        signIn("9360810959", "+91", "IN");
//        signIn("9360810958", "+91", "IN");
//        signIn("9597477853", "+91", "IN");
    }

    private void initActivityResult() {
        otpResultLauncher = registerForActivityResult(new FirebaseAuthUIActivityResultContract(), new ActivityResultCallback<FirebaseAuthUIAuthenticationResult>() {
            @Override
            public void onActivityResult(FirebaseAuthUIAuthenticationResult result) {
                if (result.getResultCode() == RESULT_OK) {
                    // Successfully signed in
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if (user != null && user.getPhoneNumber() != null) {
                        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                        try {
                            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(user.getPhoneNumber(), null);
//                            String regionCode = phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(phNumber.getCountryCode()));
                            String regionCode = phoneUtil.getRegionCodeForNumber(numberProto);
//                            Log.d(TAG, "onActivityResult: " + regionCode);
                            signIn("" + numberProto.getNationalNumber(), "" + numberProto.getCountryCode(), regionCode);

                        } catch (NumberParseException e) {
                            Log.e(TAG, "NumberParseException: " + e.getMessage());
                            makeToast(getString(R.string.something_wrong));
                            finish();
                        }
                    }
                    AuthUI.getInstance()
                            .signOut(MobileNumberActivity.this)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                public void onComplete(@NonNull Task<Void> task) {

                                }
                            });
                    // ...
                } else {
                    finish();
                }
            }
        });
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    public void verifyMobileNo() {
        if (NetworkStatus.isConnected()) {
            // Choose authentication providers
            List<AuthUI.IdpConfig> providers = Arrays.asList(
                    new AuthUI.IdpConfig.PhoneBuilder().build());
            // Create and launch sign-in intent
            Intent intent = AuthUI.getInstance()
                    .createSignInIntentBuilder()
                    .setAvailableProviders(providers)
                    .setIsSmartLockEnabled(false)
                    .setTheme(R.style.OTPTheme)
                    .build();
            otpResultLauncher.launch(intent);
        } else {
            makeToast(getString(R.string.no_internet_connection));
        }
    }

    void signIn(String number, String code, String countryName) {
        number = number.replaceAll("[^0-9]", "");
        if (number.startsWith("0")) {
            number = number.replaceFirst("^0+(?!$)", "");
        }
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_PHONE_NUMBER, number);
        map.put(Constants.TAG_COUNTRY_CODE, code);
        map.put(Constants.TAG_COUNTRY, countryName);

        Call<HashMap<String, String>> call = apiInterface.signin(map);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                dbHelper.clearDB(getApplicationContext());
                HashMap<String, String> userdata = response.body();
                if (userdata.get("status").equals("true")) {
                    GetSet.setToken(userdata.get("token"));
                    GetSet.setUserId(userdata.get("_id"));
                    GetSet.setUserName(userdata.get("user_name"));
                    GetSet.setImageUrl(userdata.get("user_image"));
                    GetSet.setphonenumber(userdata.get("phone_no"));
                    GetSet.setcountrycode(userdata.get("country_code"));
                    goToProfile(countryName);
                } else if (userdata.get("status").equals("false")) {
                    makeToast(userdata.get("message"));
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                t.printStackTrace();
                call.cancel();
                makeToast(getString(R.string.something_wrong));
                finish();
            }
        });
    }

    private void goToProfile(String countryName) {
        Intent i = new Intent(getApplicationContext(), ProfileInfo.class);
        i.putExtra("from", "welcome");
        i.putExtra("country_name", countryName);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}
