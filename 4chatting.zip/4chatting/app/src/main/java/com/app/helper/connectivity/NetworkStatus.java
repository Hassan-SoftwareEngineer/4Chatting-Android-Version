package com.app.helper.connectivity;

public class NetworkStatus {
    // Global variable used to store network state
    public static boolean isConnected = false;

    public static boolean isConnected() {
        return isConnected;
    }
}
