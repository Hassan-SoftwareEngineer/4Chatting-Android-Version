package com.app.utils;


/*import com.hitasoft.app.addons.livebroadcast.model.LiveStreamRequest;
import com.hitasoft.app.addons.livebroadcast.model.LiveStreamResponse;
import com.hitasoft.app.addons.livebroadcast.model.StartStreamResponse;
import com.hitasoft.app.addons.livebroadcast.model.StreamDetails;*/

import com.app.model.AdminChannel;
import com.app.model.AdminChannelMsg;
import com.app.model.BlocksData;
import com.app.model.CallData;
import com.app.model.ChangeNumberResult;
import com.app.model.ChannelChatResult;
import com.app.model.ChannelInfoResponse;
import com.app.model.ChannelResult;
import com.app.model.ChannelSubscribersId;
import com.app.model.CheckForUpdateResponse;
import com.app.model.ContactsData;
import com.app.model.GroupChatResult;
import com.app.model.GroupInvite;
import com.app.model.GroupResult;
import com.app.model.GroupUpdateResult;
import com.app.model.HelpData;
import com.app.model.ModifyGroupResponse;
import com.app.model.OfflineStoryDeleteResponse;
import com.app.model.RecentChatList;
import com.app.model.SaveMyContacts;
import com.app.model.StatusResult;
import com.app.model.TermsAndPrivacyResponse;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

/**
 * Created by hitasoft on 24/1/18.
 */

public interface ApiInterface {

    @GET("service/checkforupdates")
    Call<CheckForUpdateResponse> checkForUpdates();

    @FormUrlEncoded
    @POST("service/signin")
    Call<HashMap<String, String>> signin(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/updatemycontacts")
    Call<ContactsData> updateMyContacts(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/updatemyprofile")
    Call<HashMap<String, String>> updatemyprofile(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @Multipart
    @POST("service/upmyprofile")
    Call<HashMap<String, String>> upmyprofile(@Header("Authorization") String user_token, @Part MultipartBody.Part image, @Part("user_id") RequestBody user_id);

    @Multipart
    @POST("service/upmychat")
    Call<HashMap<String, String>> upMyChat(@Header("Authorization") String user_token, @Part MultipartBody.Part attachment, @Part("user_id") RequestBody user_id);

    @FormUrlEncoded
    @POST("service/pushsignin")
    Call<Map<String, String>> pushsignin(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/deviceinfo")
    Call<Map<String, String>> getDeviceInfo(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/userexists")
    Call<Map<String, String>> checkUserExists(@Header("Authorization") String user_token, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST("service/pushsignout")
    Call<Map<String, String>> pushsignout(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @GET("service/getuserprofile/{phone_no}/{contact_id}")
    Call<Map<String, String>> getUserProfile(@Header("Authorization") String user_token, @Path("phone_no") String phone_no, @Path("contact_id") String contact_id);

    @GET("service/recentchats/{user_id}")
    Call<RecentChatList> recentChats(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @FormUrlEncoded
    @POST("service/chatreceived")
    Call<Map<String, String>> messageReceived(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/privatechatreceived")
    Call<Map<String, String>> chatReceived(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/deleteprivatechat")
    Call<HashMap<String, String>> callDeleteChatApi(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @Multipart
    @POST("service/upmychat")
    Call<Map<String, String>> upchat(@Header("Authorization") String user_token, @Part MultipartBody.Part attachment, @Part("user_id") RequestBody user_id);

    @GET("service/getblockstatus/{user_id}")
    Call<BlocksData> getblockstatus(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @Multipart
    @POST("service/modifyGroupimage")
    Call<HashMap<String, String>> uploadGroupImage(@Header("Authorization") String user_token, @Part MultipartBody.Part image, @Part("group_id") RequestBody groupId);

    @GET("/service/groupinvites/{user_id}")
    Call<GroupInvite> getGroupInvites(@Header("Authorization") String token, @Path("user_id") String userId);

    @FormUrlEncoded
    @POST("service/groupinfo")
    Call<GroupResult> getGroupInfo(@Header("Authorization") String token, @Field("group_list") String group_list);

    @Multipart
    @POST("service/upmygroupchat")
    Call<HashMap<String, String>> upMyGroupChat(@Header("Authorization") String user_token, @Part MultipartBody.Part attachment, @Part("user_id") RequestBody user_id);

    @FormUrlEncoded
    @POST("service/modifyGroupinfo")
    Call<GroupUpdateResult> updateGroup(@Header("Authorization") String user_token, @Field("group_id") String groupId,
                                        @Field("group_name") String groupName);

    @FormUrlEncoded
    @POST("service/modifyGroupinfo")
    Call<GroupUpdateResult> updateGroup(@Header("Authorization") String user_token, @Field("group_id") String groupId,
                                        @Field("group_members") JSONArray members);

    @GET("service/recentgroupchats/{user_id}")
    Call<GroupChatResult> getRecentGroupChats(@Header("Authorization") String token, @Path("user_id") String userId);

    @FormUrlEncoded
    @POST("service/groupchatreceived")
    Call<Map<String, String>> groupChatReceived(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/savemycontacts")
    Call<SaveMyContacts> saveMyContacts(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/updatemyprivacy")
    Call<HashMap<String, String>> updateMyPrivacy(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/modifyGroupmembers")
    Call<ModifyGroupResponse> modifyGroupMembers(@Header("Authorization") String user_token, @Field("user_id") String userId, @Field("group_id") String groupId,
                                                 @Field("group_members") JSONArray members);

    @GET("service/MySubscribedChannels/{user_id}")
    Call<ChannelInfoResponse> getMySubscribedChannels(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/MyChannels/{user_id}")
    Call<ChannelInfoResponse> getMyChannels(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/helps")
    Call<HelpData> getHelpList();

    @Multipart
    @POST("service/modifyChannelImage")
    Call<HashMap<String, String>> uploadChannelImage(@Header("Authorization") String user_token, @Part MultipartBody.Part body, @Part("channel_id") RequestBody channelID);

    @GET("service/recentcalls/{user_id}")
    Call<CallData> recentCalls(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @FormUrlEncoded
    @POST("service/channelinfo")
    Call<ChannelInfoResponse> getChannelInfo(@Header("Authorization") String user_token, @Field("channel_list") JSONArray channelList);

    @FormUrlEncoded
    @POST("service/updatemychannel")
    Call<HashMap<String, String>> updateChannel(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> map);

    @Multipart
    @POST("service/upmychannelchat")
    Call<HashMap<String, String>> uploadChannelChat(@Header("Authorization") String user_token, @Part MultipartBody.Part attachment, @Part("channel_id") RequestBody channel_Id, @Part("user_id") RequestBody userId);

    @Multipart
    @POST("service/upmychannelchat")
    Call<Map<String, String>> upChannelChat(@Header("Authorization") String user_token, @Part MultipartBody.Part attachment, @Part("channel_id") RequestBody channel_Id, @Part("user_id") RequestBody userId);

    @GET("service/recentChannelChats/{user_id}")
    Call<ChannelChatResult> recentChannelChats(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @GET("service/adminchannels/{user_id}")
    Call<AdminChannel> getAdminChannels(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @GET("service/msgfromadminchannels/{timestamp}")
    Call<AdminChannelMsg> getMsgFromAdminChannels(@Header("Authorization") String user_token, @Path("timestamp") String timestamp);

    @GET("service/recentChannelInvites/{user_id}")
    Call<ChannelResult> getRecentChannelInvites(@Header("Authorization") String user_token, @Path("user_id") String user_id);

    @GET("service/AllPublicChannels/{user_id}/{search_string}/{offset}/{limit}")
    Call<ChannelInfoResponse> getAllPublicChannels(@Header("Authorization") String user_token, @Path("user_id") String user_id, @Path("search_string") String search, @Path("offset") String offSet, @Path("limit") String limit);

    @GET("service/channelSubscribers/{channel_id}/{phone_no}/{offset}/{limit}")
    Call<ContactsData> getChannelSubscribers(@Header("Authorization") String user_token, @Path("channel_id") String channel_id, @Path("phone_no") String phoneNo, @Path("offset") String offSet, @Path("limit") String limit);

    @GET("service/channelsubscriberids/{channel_id}")
    Call<ChannelSubscribersId> getChannelSubscriberIds(@Header("Authorization") String user_token, @Path("channel_id") String channel_id);

    @GET("service/MyGroups/{user_id}")
    Call<GroupResult> getMyGroups(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/deleteMyAccount/{user_id}")
    Call<HashMap<String, String>> deleteMyAccount(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/verifyMyNumber/{user_id}/{phone_no}")
    Call<Map<String, String>> verifyNewNumber(@Header("Authorization") String user_token, @Path("user_id") String userId, @Path("phone_no") String phoneNumber);


    @GET("service/changeMyNumber/{user_id}/{phone_no}/{country_code}")
    Call<ChangeNumberResult> changeMyNumber(@Header("Authorization") String user_token, @Path("user_id") String userId, @Path("phone_no") String phoneNumber, @Path("country_code") String countryCode);

    @FormUrlEncoded
    @POST("service/reportchannel")
    Call<HashMap<String, String>> reportChannel(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("service/clearchannelinvites")
    Call<HashMap<String, String>> clearChannelInvites(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("service/channelchatreceived")
    Call<HashMap<String, String>> channelChatReceived(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("service/storyreceived")
    Call<HashMap<String, String>> storyReceived(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("service/clearofflinedeletedstories")
    Call<HashMap<String, String>> clearOfflineDeletedStories(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @GET("service/recentofflinestories/{user_id}")
    Call<StatusResult> getOfflineStories(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/recentviewedstories/{user_id}")
    Call<StatusResult> getRecentViewedStories(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @FormUrlEncoded
    @POST("service/clearstoryviewed")
    Call<HashMap<String, String>> storyViewed(@Header("Authorization") String user_token, @FieldMap HashMap<String, String> hashMap);

    @GET("service/offlinedeletedstories/{user_id}")
    Call<OfflineStoryDeleteResponse> offlineDeletedStories(@Header("Authorization") String user_token, @Path("user_id") String userId);

    @GET("service/termsandpolicy")
    Call<TermsAndPrivacyResponse> termsAndPrivacy();

    //Addon Live Stream
    /*@POST("service/streams")
    Call<LiveStreamResponse> getCurrentStreams(@Header("Authorization") String user_token, @Body LiveStreamRequest request);

    @FormUrlEncoded
    @POST("service/streams")
    Call<StreamDetails> getStreamDetails(@Header("Authorization") String user_token, @Field(Constants.TAG_USER_ID) String userId, @Field(Constants.TAG_NAME) String streamName);

    @DELETE("service/streams/delete/{user_id}/{name}")
    Call<Map<String, String>> deleteVideo(@Header("Authorization") String user_token, @Path(Constants.TAG_USER_ID) String userId, @Path(Constants.TAG_NAME) String streamName);

    @FormUrlEncoded
    @POST("service/streams/report")
    Call<Map<String, String>> reportStream(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @GET("service/streams/create/{userId}")
    Call<HashMap<String, String>> getStreamName(@Header("Authorization") String user_token, @Path("userId") String publisherId);

    @FormUrlEncoded
    @POST("service/streams/start ")
    Call<StartStreamResponse> startStream(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST("service/streams/stop")
    Call<Map<String, String>> stopStream(@Header("Authorization") String user_token, @FieldMap Map<String, String> params);

    @Multipart
    @POST("service/streams/uploadstream")
    Call<Map<String, String>> uploadStreamImage(@Header("Authorization") String user_token, @Part MultipartBody.Part image, @Part("publisher_id") RequestBody publisherId, @Part("name") RequestBody streamName);*/
}

