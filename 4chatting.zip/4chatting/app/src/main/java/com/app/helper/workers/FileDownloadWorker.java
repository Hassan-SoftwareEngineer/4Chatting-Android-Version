package com.app.helper.workers;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.exifinterface.media.ExifInterface;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.helper.StorageManager;
import com.app.fourchattingapp.ApplicationClass;
import com.app.utils.Constants;

import java.io.IOException;
import java.io.InputStream;

public class FileDownloadWorker extends Worker {
    private static final String TAG = FileDownloadWorker.class.getSimpleName();
    private Context context;
    private StorageManager storageManager;

    public FileDownloadWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params) {
        super(context, params);
        this.context = context;
        this.storageManager = StorageManager.getInstance(context);
    }

    @Override
    public Result doWork() {
        // Do the work here--in this case, download the file.
        String attachment = getInputData().getString(Constants.TAG_ATTACHMENT);
        String fileType = getInputData().getString(Constants.TAG_TYPE);
        String from = getInputData().getString(Constants.TAG_FROM);
        if (fileType.equals(StorageManager.TAG_IMAGE)) {
            try {
                Log.d(TAG, "doWork: " + attachment);
                InputStream inputStream = ApplicationClass.getInputStream(attachment);
                Bitmap bitmap = downloadImage(attachment);
                Bitmap rotatedBitmap = null;
                if (bitmap == null) {
                    return null;
                } else {
                    try {
                        ExifInterface exif = new ExifInterface(inputStream);
                        rotatedBitmap = ApplicationClass.getRotatedBitmap(exif, bitmap);
                        storageManager.saveBitmap(rotatedBitmap, storageManager.getFileName(attachment), from);
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                        Log.e(TAG, "doInBackground: " + e.getMessage());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // Indicate whether the work finished successfully with the Result
        return Result.success();
    }

    public Bitmap downloadImage(String src) {
        try {
            InputStream inputStream = ApplicationClass.getInputStream(src);
            return BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}