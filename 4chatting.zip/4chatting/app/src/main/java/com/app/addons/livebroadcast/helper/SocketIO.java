package com.app.addons.livebroadcast.helper;

import android.content.Context;
import android.util.Log;

import com.app.addons.livebroadcast.utils.StreamConstants;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;

public class SocketIO {
    private static final String TAG = SocketIO.class.getSimpleName();
    private static Socket mSocket;
    private Context mContext;
    private SocketEvents events;
    private SocketIO socketIO;

    public SocketIO(Context mContext) {
        this.mContext = mContext;
        if (mSocket == null) {
            Log.d(TAG, "SocketIO: " + StreamConstants.STREAM_SOCKET_IO_URL);
            try {
                mSocket = IO.socket(StreamConstants.STREAM_SOCKET_IO_URL);
                /*mSocket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        Log.v(TAG, "EVENT_CONNECT");
                    }
                }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                    @Override
                    public void call(Object... args) {
                        Log.e(TAG, "EVENT_DISCONNECT");
                    }
                });*/
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        }
    }

    public Socket getInstance() {
        return mSocket;
    }

    public void setSocketEvents(SocketEvents events) {
        this.events = events;
    }

    public interface SocketEvents {

    }

}
