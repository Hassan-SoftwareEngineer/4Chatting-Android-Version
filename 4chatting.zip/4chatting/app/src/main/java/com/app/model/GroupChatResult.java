package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;

public final class GroupChatResult {
    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public HashMap<String, GroupMessage> result;

}
