package com.app.model;

import com.google.gson.annotations.Expose;

import java.io.Serializable;

public class BaseResponse implements Serializable {

    @Expose
    private String status;

    @Expose
    private String message;

    public boolean isSuccessful() {
        return status != null && status.equals("true");
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
