package com.app.helper.connectivity.base;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;

public abstract class ConnectivityProviderBaseImpl implements ConnectivityProvider {
    private static final String TAG = ConnectivityProviderBaseImpl.class.getSimpleName();
    private Handler handler = new Handler(Looper.getMainLooper());
    private List<ConnectivityStateListener> listeners = new ArrayList<>();
    private boolean subscribed = false;

    public void addListener(ConnectivityProvider.ConnectivityStateListener listener) {
        listeners.add(listener);
        listener.onStateChange(getNetworkState()); // propagate an initial state
        verifySubscription();
    }

    public void removeListener(ConnectivityStateListener listener) {
        listeners.remove(listener);
        verifySubscription();
    }

    private void verifySubscription() {
        if (!subscribed && listeners.size() > 0) {
            subscribe();
            subscribed = true;
        } else if (subscribed && listeners.isEmpty()) {
            unsubscribe();
            subscribed = false;
        }
    }

    protected void dispatchChange(ConnectivityProvider.NetworkState state) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                for (ConnectivityStateListener listener : listeners) {
                    listener.onStateChange(state);
                }
            }
        });
    }

    protected abstract void subscribe();

    protected abstract void unsubscribe();

}
