package com.app.helper.event;

import com.app.model.ChannelMessage;

public class NewChannelMessageEvent {
    private ChannelMessage channelMessage;

    public NewChannelMessageEvent(ChannelMessage channelMessage) {
        this.channelMessage = channelMessage;
    }

    public ChannelMessage getChannelMessage() {
        return channelMessage;
    }

    public void setChannelMessage(ChannelMessage channelMessage) {
        this.channelMessage = channelMessage;
    }
}
