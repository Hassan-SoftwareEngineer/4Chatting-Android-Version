package com.app.fourchattingapp;


import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CHANNELS;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CHANNEL_HEADER;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CHATS;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CHATS_HEADER;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CONTACTS;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CONTACTS_HEADER;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_GROUPS;
import static com.app.fourchattingapp.ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_GROUP_HEADER;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.helper.StorageManager.TAG_VIDEO_SENT;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.model.ChannelMessage;
import com.app.model.ChannelResult;
import com.app.model.MessagesData;
import com.app.model.SearchData;
import com.app.external.RandomString;
import com.app.helper.BitmapCompression;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.ExternalUploadService;
import com.app.helper.NetworkUtil;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.helper.Utils;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import droidninja.filepicker.utils.ContentUriUtils;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by hitasoft on 9/8/18.
 */
public class ExternalShareActivity extends BaseActivity implements View.OnClickListener, SocketConnection.ExternalUploadListener {

    private final String TAG = this.getClass().getSimpleName();
    private Context mContext;
    TextView title;
    ImageView backbtn, searchbtn, optionbtn, cancelbtn;
    RecyclerView recyclerView;
    EditText searchView;
    RelativeLayout searchLay;
    RelativeLayout mainLay;
    LinearLayout buttonLayout, btnNext;
    private int uploadCount = 0;
    String from = "", id = "";
    LinearLayoutManager linearLayoutManager;
    RecyclerViewAdapter recyclerViewAdapter;
    List<SearchData> filteredList = new ArrayList<>();
    List<SearchData> searchList = new ArrayList<>();
    List<SearchData> chatList = new ArrayList<>();
    List<SearchData> groupList = new ArrayList<>();
    List<SearchData> channelList = new ArrayList<>();
    List<SearchData> selectedList = new ArrayList<>();
    List<SearchData> contactsList = new ArrayList<>();
    StorageManager storageManager;
    MessagesData externalData;
    ApiInterface apiInterface;
    ArrayList<Uri> externalImageUris = new ArrayList<>();
    Uri externalImageUri;
    int uriSize = -1;
    ProgressDialog progressDialog;
    String sendVideoPath = "";
    private DateUtils dateUtils;
    SocketConnection socketConnection;
    private MessagesData mData;
    private DatabaseHandler dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forward_activity);
        mContext = this;
        socketConnection = SocketConnection.getInstance(this);
        dbhelper = DatabaseHandler.getInstance(this);

        title = findViewById(R.id.title);
        backbtn = findViewById(R.id.backbtn);
        searchbtn = findViewById(R.id.searchbtn);
        optionbtn = findViewById(R.id.optionbtn);
        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);
        buttonLayout = findViewById(R.id.buttonLayout);
        cancelbtn = findViewById(R.id.cancelbtn);
        searchLay = findViewById(R.id.searchLay);
        mainLay = findViewById(R.id.mainLay);
        btnNext = findViewById(R.id.btnNext);
        apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
        dateUtils = DateUtils.getInstance(this);
        socketConnection.setForwardActivityListener(this);

        title.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        searchbtn.setVisibility(View.VISIBLE);
        optionbtn.setVisibility(View.GONE);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        searchbtn.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        cancelbtn.setOnClickListener(this);
        btnNext.setOnClickListener(this);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        storageManager = StorageManager.getInstance(this);
        title.setText(getString(R.string.forward_to));

        externalData = new MessagesData();
        from = "external";
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if (type.startsWith("image/") || type.startsWith("video/")) {
                handleSendSingleMedia(intent);
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
            uriSize = handleSendMultipleImages(intent);
        }

        SearchData data = new SearchData();
        List<SearchData> tempChat = new ArrayList<>();
        for (HashMap<String, String> hashMap : dbhelper.getSearchContacts(this)) {
            if (!hashMap.get(Constants.TAG_USER_ID).equals(GetSet.getUserId())) {
                data = new SearchData();
                data.viewType = VIEW_TYPE_CHATS;
                data.user_id = hashMap.get(Constants.TAG_USER_ID);
                data.user_name = hashMap.get(Constants.TAG_USER_NAME);
                data.user_image = hashMap.get(Constants.TAG_USER_IMAGE);
                data.phone_no = hashMap.get(Constants.TAG_PHONE_NUMBER);
                data.blockedbyme = hashMap.get(Constants.TAG_BLOCKED_BYME);
                data.blockedme = hashMap.get(Constants.TAG_BLOCKED_ME);
                tempChat.add(data);
            }
        }
        if (tempChat.size() > 0) {
            data = new SearchData();
            data.viewType = VIEW_TYPE_CHATS_HEADER;
            tempChat.add(0, data);/*First item - Contact Header*/
        }
        searchList.addAll(tempChat);

        List<SearchData> tempGroup = new ArrayList<>();
        for (HashMap<String, String> hashMap : dbhelper.getGroupRecentMessages(this, true)) {
            if (!hashMap.get(Constants.TAG_GROUP_ID).equals(id) && dbhelper.isMemberExist(GetSet.getUserId(), hashMap.get(Constants.TAG_GROUP_ID))) {
                data = new SearchData();
                data.viewType = VIEW_TYPE_GROUPS;
                data.groupId = hashMap.get(Constants.TAG_GROUP_ID);
                data.groupName = hashMap.get(Constants.TAG_GROUP_NAME);
                data.groupImage = hashMap.get(Constants.TAG_GROUP_IMAGE);
                tempGroup.add(data);
            }
        }
        if (tempGroup.size() > 0) {
            data = new SearchData();
            data.viewType = VIEW_TYPE_GROUP_HEADER;
            tempGroup.add(0, data);/*First item - Group Header*/
        }
        searchList.addAll(tempGroup);

//        if (!from.equalsIgnoreCase("external")) {
        List<SearchData> tempChannel = new ArrayList<>();
        List<ChannelResult.Result> subscribedChannels = dbhelper.getMyChannels(GetSet.getUserId());
        for (ChannelResult.Result result : subscribedChannels) {
            data = new SearchData();
            data.viewType = VIEW_TYPE_CHANNELS;
            data.channelId = result.channelId;
            data.channelType = result.channelType;
            data.channelName = result.channelName;
            data.channelImage = result.channelImage;
            data.channelAdminId = result.channelAdminId != null ? result.channelAdminId : result.adminId;
            tempChannel.add(data);
        }
        if (tempChannel.size() > 0) {
            data = new SearchData();
            data.viewType = VIEW_TYPE_CHANNEL_HEADER;
            tempChannel.add(0, data);/*First item - Group Header*/
        }
        searchList.addAll(tempChannel);
//        }


        List<SearchData> tempContacts = new ArrayList<>();
        for (ContactsData.Result result : dbhelper.getStoredContacts(this)) {
            if (!result.user_id.equals(GetSet.getUserId()) && !isUserChatAlready(result.user_id, tempChat) && !result.user_id.equals(id)) {
                data = new SearchData();
                data.viewType = VIEW_TYPE_CONTACTS;
                data.user_id = result.user_id;
                data.user_name = result.user_name;
                data.user_image = result.user_image;
                data.phone_no = result.phone_no;
                data.blockedme = result.blockedme;
                data.blockedbyme = result.blockedbyme;
                tempContacts.add(data);
            }
        }
        if (tempContacts.size() > 0) {
            data = new SearchData();
            data.viewType = VIEW_TYPE_CONTACTS_HEADER;
            tempContacts.add(0, data);/*First item - Contact Header*/
        }
        searchList.addAll(tempContacts);

        filteredList = new ArrayList<>();
        filteredList.addAll(searchList);

        linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);

        recyclerViewAdapter = new RecyclerViewAdapter(this);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();

        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    cancelbtn.setVisibility(View.VISIBLE);
                } else {
                    cancelbtn.setVisibility(View.GONE);
                }
                recyclerViewAdapter.getFilter().filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        socketConnection.setForwardActivityListener(null);
    }

    void handleSendSingleMedia(Intent intent) {
        externalImageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        externalImageUris = new ArrayList<>();
        externalImageUris.add(externalImageUri);
    }

    int handleSendMultipleImages(Intent intent) {
        externalImageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        return externalImageUris.size();
    }

    private void uploadImage(byte[] imageBytes, String imagePath, String videoPath, String fileType) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("attachment", "openImage.jpg", requestFile);

        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call = apiInterface.upMyChat(GetSet.getToken(), body, userid);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> result = response.body();
                Log.d(TAG, "uploadImage: " + result);
                if (result.get(Constants.TAG_STATUS).equals("true")) {
                    String apiFileName = result.get(Constants.TAG_USER_IMAGE);
                    if (fileType.equals("image")) {
                        uploadCount++;
                        storageManager.renameFile(null, imagePath, apiFileName, StorageManager.TAG_IMAGE);
                        for (SearchData selectedUser : selectedList) {
                            if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_CHATS ||
                                    selectedUser.viewType == VIEW_TYPE_CONTACTS) {
                                emitMessage(selectedUser, apiFileName);
                            } else if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_GROUPS) {
                                emitGroupMessage(selectedUser, apiFileName);
                            } else if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_CHANNELS) {
                                emitChannelMessage(selectedUser, apiFileName);
                            }
                        }
                        if (externalImageUris.size() == uploadCount) {
                            finish();
                        }
                    } else {
                        storageManager.renameFile(null, imagePath, apiFileName, StorageManager.TAG_THUMB);
                        Intent service = new Intent(mContext, ExternalUploadService.class);
                        Bundle b = new Bundle();
                        b.putSerializable("selectedList", (Serializable) selectedList);
                        b.putSerializable(Constants.TAG_TYPE, StorageManager.TAG_VIDEO);
                        b.putSerializable(Constants.TAG_THUMBNAIL, apiFileName);
                        b.putSerializable(Constants.TAG_ATTACHMENT, videoPath);
                        b.putInt(Constants.TAG_NOTIFICATION_ID, uploadCount);
                        service.putExtras(b);
                        startService(service);
                    }
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                call.cancel();
            }
        });
    }

    public void emitMessage(SearchData selectedUser, String newFileName) {
//            if (!selectedUser.blockedme.equals("block")) {
        try {
            MessagesData mdata = getExternalData(Constants.TAG_IMAGE, newFileName, "", selectedUser);
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            dbhelper.addMessageData(mdata, true);
            dbhelper.addRecentMessages(mdata.chat_id, mdata.receiver_id, mdata.message_id, currentUTCTime, "0");

            JSONObject jobj = new JSONObject();
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_USER_ID, mdata.user_id);
            message.put(Constants.TAG_USER_NAME, mdata.user_name);
            message.put(Constants.TAG_MESSAGE_TYPE, mdata.message_type);
            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(mdata.attachment));
            message.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(mdata.thumbnail));
            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
            message.put(Constants.TAG_CHAT_ID, mdata.chat_id);
            message.put(Constants.TAG_MESSAGE_ID, mdata.message_id);
            message.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
            message.put(Constants.TAG_SENDER_ID, mdata.user_id);
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
            message.put(Constants.TAG_BLOCK_STATUS, "" + selectedUser.blockedme.equals("block"));
            message.put(Constants.TAG_BLOCKED_BY, selectedUser.blockedme.equals("block") ? mdata.receiver_id : "");
            message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
            jobj.put(Constants.TAG_SENDER_ID, mdata.user_id);
            jobj.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
            jobj.put("message_data", message);
            socketConnection.startChat(jobj);
        } catch (JSONException e) {
            e.printStackTrace();
        }
//            }
    }

    private void emitGroupMessage(SearchData selectedUser, String newFileName) {
        try {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            GroupMessage gdata = getExternalGroupData(Constants.TAG_IMAGE, newFileName, "", selectedUser);
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_GROUP_ID, gdata.groupId);
            message.put(Constants.TAG_GROUP_NAME, gdata.groupName);
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
            message.put(Constants.TAG_MESSAGE_TYPE, gdata.messageType);
            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
            message.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(""));
            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(gdata.message));
            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
            message.put(Constants.TAG_MESSAGE_ID, gdata.messageId);
            message.put(Constants.TAG_MEMBER_ID, gdata.memberId);
            message.put(Constants.TAG_MEMBER_NAME, gdata.memberName);
            message.put(Constants.TAG_MEMBER_NO, gdata.memberNo);
            Log.d(TAG, "emitGroupMessage: " + message);
            socketConnection.messageToGroup(message);

            dbhelper.addGroupMessages(gdata.messageId, gdata.groupId, GetSet.getUserId(), "", gdata.messageType,
                    ApplicationClass.encryptMessage(gdata.message), ApplicationClass.encryptMessage(newFileName), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""),
                    ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""),
                    currentUTCTime, ApplicationClass.encryptMessage(""), "read");
            dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_PROGRESS, "completed");
            dbhelper.addGroupRecentMsg(gdata.groupId, gdata.messageId, GetSet.getUserId(), currentUTCTime, "0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void emitChannelMessage(SearchData selectedUser, String newFileName) {
        try {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            ChannelMessage channelData = getExternalChannelData(Constants.TAG_IMAGE, newFileName, "", selectedUser);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_CHANNEL_ID, channelData.channelId);
            jsonObject.put(Constants.TAG_CHANNEL_NAME, channelData.channelName);
            jsonObject.put(Constants.TAG_CHAT_TYPE, channelData.chatType);
            jsonObject.put(Constants.TAG_MESSAGE_ID, channelData.messageId);
            jsonObject.put(Constants.TAG_MESSAGE_TYPE, channelData.messageType);
            jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(channelData.message));
            jsonObject.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(channelData.attachment));
            jsonObject.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(channelData.thumbnail));
            jsonObject.put(Constants.TAG_CHAT_TIME, channelData.chatTime);
            jsonObject.put(Constants.TAG_ADMIN_ID, channelData.channelAdminId);
            Log.d(TAG, "emitChannelMessage: " + jsonObject);
            socketConnection.messageToChannel(jsonObject);

            dbhelper.addChannelMessages(channelData.channelId, Constants.TAG_CHANNEL, channelData.messageId, channelData.messageType,
                    ApplicationClass.encryptMessage(channelData.message), ApplicationClass.encryptMessage(channelData.attachment), "", "", "",
                    "", "", currentUTCTime, ApplicationClass.encryptMessage(channelData.thumbnail), "read");
            dbhelper.updateChannelMessageData(channelData.messageId, Constants.TAG_PROGRESS, "completed");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private MessagesData getExternalData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        String chatId = GetSet.getUserId() + selectedUser.user_id;
        MessagesData data = new MessagesData();
        data.chat_id = chatId;

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                data.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                ;
                data.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                data.progress = "completed";
                break;
            case "document":
                data.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        data.user_id = GetSet.getUserId();
        data.user_name = GetSet.getUserName();
        data.message_type = type;
        data.message = msg;
        data.message_id = messageId;
        data.chat_time = currentUTCTime;
        data.delivery_status = "";
        data.receiver_id = selectedUser.user_id;
        data.sender_id = GetSet.getUserId();
        data.thumbnail = thumbPath;
        data.attachment = mediaPath;
        data.statusData = "";
        data.lat = "";
        data.lon = "";
        data.contact_name = "";
        data.contact_phone_no = "";
        data.contact_country_code = "";

        Log.d(TAG, "getExternalData: " + new Gson().toJson(data));
        return data;
    }

    private GroupMessage getExternalGroupData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        GroupMessage groupMessage = new GroupMessage();

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                groupMessage.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                groupMessage.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                groupMessage.progress = "completed";
                break;
            case "document":
                groupMessage.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        groupMessage.groupId = selectedUser.groupId;
        groupMessage.groupName = selectedUser.groupName;
        groupMessage.memberId = GetSet.getUserId();
        groupMessage.memberName = GetSet.getUserName();
        groupMessage.memberNo = GetSet.getphonenumber();
        groupMessage.messageType = type;
        groupMessage.message = msg;
        groupMessage.messageId = messageId;
        groupMessage.chatTime = currentUTCTime;
        groupMessage.deliveryStatus = "";
        groupMessage.progress = "completed";
        groupMessage.thumbnail = thumbPath;
        groupMessage.attachment = mediaPath;

        Log.d(TAG, "getExternalGroupData: " + new Gson().toJson(groupMessage));
        return groupMessage;
    }

    private ChannelMessage getExternalChannelData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        ChannelMessage channelMessage = new ChannelMessage();

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                channelMessage.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                channelMessage.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                channelMessage.progress = "completed";
                break;
            case "document":
                channelMessage.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        channelMessage.channelId = selectedUser.channelId;
        channelMessage.channelName = selectedUser.channelName;
        channelMessage.channelAdminId = selectedUser.channelAdminId;
        channelMessage.chatType = Constants.TAG_CHANNEL;
        channelMessage.messageType = type;
        channelMessage.message = msg;
        channelMessage.messageId = messageId;
        channelMessage.chatTime = currentUTCTime;
        channelMessage.deliveryStatus = "";
        channelMessage.progress = "completed";
        channelMessage.thumbnail = thumbPath;
        channelMessage.attachment = mediaPath;

        Log.d(TAG, "getExternalChannelData: " + new Gson().toJson(channelMessage));
        return channelMessage;
    }

    private boolean isUserChatAlready(String user_id, List<SearchData> tempChat) {
        for (SearchData searchData : tempChat) {
            if (user_id.equals(searchData.user_id)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        if (searchLay.getVisibility() == View.VISIBLE) {
            searchView.setText("");
            searchLay.setVisibility(View.GONE);
            title.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.VISIBLE);
            ApplicationClass.hideSoftKeyboard(this, searchView);
        } else {
            finish();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.searchbtn:
                title.setVisibility(View.GONE);
                searchLay.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.GONE);
                ApplicationClass.showKeyboard(this, searchView);
                break;
            case R.id.cancelbtn:
                searchView.setText("");
                break;
            case R.id.btnNext:
                btnNext.setEnabled(false);
                if (progressDialog != null && !progressDialog.isShowing())
                    progressDialog.show();
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (!externalImageUris.isEmpty()) {
                        if (externalImageUris.size() <= 10) {
                            shareMultiple();
                        } else {
                            progressDialog.dismiss();
                            btnNext.setEnabled(true);
                            Toast.makeText(getApplicationContext(), "Please select maximum 10 files", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                break;
        }
    }

    private void shareMultiple() {
        for (Uri uri : externalImageUris) {
            String mimeType = storageManager.getMimeTypeOfUri(mContext, uri);
            if (mimeType.startsWith("image/")) {
                BitmapCompression imageCompression = new BitmapCompression(mContext, uri, null) {
                    @Override
                    protected void onPostExecute(Bitmap compressedBitmap) {
                        String fileName = System.currentTimeMillis() + ".jpg";
                        String savedPath = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();
                        byte[] bytes = StorageManager.bitmapToByteArray(compressedBitmap);
                        uploadImage(bytes, savedPath, null, StorageManager.TAG_IMAGE);
                    }
                };
                imageCompression.execute();
            } else {
                String filePath = "";
                String savedVideoPath = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String extension = storageManager.getExtension(uri);
                    String tempPath = storageManager.fileFromContentUri(mContext, uri, extension);
                    savedVideoPath = storageManager.saveFileInStorage(new File(tempPath), TAG_VIDEO_SENT);
                } else {
                    try {
                        filePath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), uri);
                        savedVideoPath = storageManager.saveFileInStorage(new File(filePath), TAG_VIDEO_SENT);
                    } catch (URISyntaxException | NullPointerException e) {
                        e.printStackTrace();
                    }
                }
                Bitmap thumb = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        CancellationSignal ca = new CancellationSignal();
                        thumb = ThumbnailUtils.createVideoThumbnail(new File(savedVideoPath), Utils.getBitmapSize(mContext), ca);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    thumb = ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Video.Thumbnails.MINI_KIND);
                }
                if (thumb != null) {
                    String fileName = System.currentTimeMillis() + ".jpg";
                    String savedThumbPath = storageManager.saveImageInStorage(thumb, fileName, StorageManager.TAG_THUMB).getAbsolutePath();
                    byte[] bytes = StorageManager.bitmapToByteArray(thumb);
                    uploadImage(bytes, savedThumbPath, savedVideoPath, StorageManager.TAG_VIDEO);
                }
            }
        }
    }

    private void blockChatConfirmDialog(String userId) {
        final Dialog dialog = new Dialog(ExternalShareActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);

        yes.setText(getString(R.string.unblock));
        no.setText(getString(R.string.cancel));
        title.setText(R.string.unblock_message);

        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                    jsonObject.put(Constants.TAG_TYPE, "unblock");
                    Log.v(TAG, "block=" + jsonObject);
                    socketConnection.block(jsonObject);
                    dbhelper.updateBlockStatus(userId, Constants.TAG_BLOCKED_BYME, "unblock");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public String getMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = this.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        Log.d(TAG, "getMimeType: " + mimeType);
        return mimeType;
    }

    @Override
    public void onExternalUploaded(String progress) {
        if (progress.equals("completed")) {
            uploadCount++;
        }
        if (externalImageUris.size() == uploadCount) {
            finish();
        }
    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {

        public static final int VIEW_TYPE_CHATS_HEADER = 1;
        public static final int VIEW_TYPE_CHATS = 2;
        public static final int VIEW_TYPE_GROUP_HEADER = 3;
        public static final int VIEW_TYPE_GROUPS = 4;
        public static final int VIEW_TYPE_CHANNEL_HEADER = 5;
        public static final int VIEW_TYPE_CHANNELS = 6;
        public static final int VIEW_TYPE_CONTACTS_HEADER = 7;
        public static final int VIEW_TYPE_CONTACTS = 8;

        Context context;
        private SearchFilter mFilter;

        public RecyclerViewAdapter(Context context) {
            this.context = context;
            mFilter = new SearchFilter(RecyclerViewAdapter.this);
        }

        @Override
        public Filter getFilter() {
            return mFilter;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = null;

            if (viewType == VIEW_TYPE_CHATS_HEADER) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_search_header, parent, false);
                return new HeaderViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_CHATS) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_blocked_contacts, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_GROUP_HEADER) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_search_header, parent, false);
                return new HeaderViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_GROUPS) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_blocked_contacts, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_CHANNEL_HEADER) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_search_header, parent, false);
                return new HeaderViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_CHANNELS) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_blocked_contacts, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_CONTACTS_HEADER) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_search_header, parent, false);
                return new HeaderViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_CONTACTS) {
                itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_blocked_contacts, parent, false);
                return new MyViewHolder(itemView);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

            if (getItemViewType(position) == VIEW_TYPE_CHATS_HEADER) {
                ((HeaderViewHolder) holder).txtHeader.setText(getString(R.string.chat));
            } else if (getItemViewType(position) == VIEW_TYPE_GROUP_HEADER) {
                ((HeaderViewHolder) holder).txtHeader.setText(getString(R.string.group));
            } else if (getItemViewType(position) == VIEW_TYPE_CHANNEL_HEADER) {
                ((HeaderViewHolder) holder).txtHeader.setText(getString(R.string.channels));
            } else if (getItemViewType(position) == VIEW_TYPE_CONTACTS_HEADER) {
                ((HeaderViewHolder) holder).txtHeader.setText(getString(R.string.contacts));
            } else {
                final SearchData data = filteredList.get(position);
                if (selectedList.contains(filteredList.get(position))) {
                    ((MyViewHolder) holder).btnSelect.setChecked(true);
                } else {
                    ((MyViewHolder) holder).btnSelect.setChecked(false);
                }

                if (getItemViewType(position) == VIEW_TYPE_CHATS || getItemViewType(position) == VIEW_TYPE_CONTACTS) {
                    ((MyViewHolder) holder).name.setText(data.user_name);
                    if (data.user_id != null) {
                        ContactsData.Result result = dbhelper.getContactDetail(data.user_id);
                        DialogActivity.setProfileImage(result, ((MyViewHolder) holder).profileimage, context);
                    } else {
                        Glide.with(context).load(R.drawable.temp)
                                .apply(new RequestOptions().placeholder(R.drawable.temp).error(R.drawable.temp))
                                .into(((MyViewHolder) holder).profileimage);
                    }
                } else if ((getItemViewType(position) == VIEW_TYPE_GROUPS)) {
                    ((MyViewHolder) holder).name.setText(data.groupName);
                    Glide.with(context).load(Constants.CHAT_IMG_PATH + data.groupImage)
                            .apply(new RequestOptions().placeholder(R.drawable.create_group).error(R.drawable.create_group))
                            .into(((MyViewHolder) holder).profileimage);

                } else if (getItemViewType(position) == VIEW_TYPE_CHANNELS) {
                    ((MyViewHolder) holder).name.setText("" + data.channelName);
                    Glide.with(context).load(Constants.CHAT_IMG_PATH + data.channelImage)
                            .apply(new RequestOptions().placeholder(R.drawable.temp).error(R.drawable.temp))
                            .into(((MyViewHolder) holder).profileimage);
                }
            }
        }

        @Override
        public int getItemViewType(int position) {
            if (filteredList.get(position).viewType == VIEW_TYPE_CHATS_HEADER) {
                return VIEW_TYPE_CHATS_HEADER;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_CHATS) {
                return VIEW_TYPE_CHATS;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_GROUP_HEADER) {
                return VIEW_TYPE_GROUP_HEADER;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_GROUPS) {
                return VIEW_TYPE_GROUPS;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_CHANNEL_HEADER) {
                return VIEW_TYPE_CHANNEL_HEADER;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_CHANNELS) {
                return VIEW_TYPE_CHANNELS;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_CONTACTS_HEADER) {
                return VIEW_TYPE_CONTACTS_HEADER;
            } else if (filteredList.get(position).viewType == VIEW_TYPE_CONTACTS) {
                return VIEW_TYPE_CONTACTS;
            }
            return 0;
        }

        @Override
        public int getItemCount() {
            return filteredList.size();
        }

        public class SearchFilter extends Filter {
            private RecyclerViewAdapter mAdapter;

            private SearchFilter(RecyclerViewAdapter mAdapter) {
                super();
                this.mAdapter = mAdapter;
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                filteredList.clear();
                chatList.clear();
                channelList.clear();
                groupList.clear();
                contactsList.clear();
                final FilterResults results = new FilterResults();
                if (constraint.length() == 0) {
                    filteredList.addAll(searchList);
                } else {
                    final String filterPattern = constraint.toString().toLowerCase().trim();

                    for (SearchData data : searchList) {
                        if (data.viewType == VIEW_TYPE_CHATS_HEADER) {
                            chatList.add(data);
                        } else if (data.viewType == VIEW_TYPE_CHATS) {
                            if (data.user_name.toLowerCase().startsWith(filterPattern)) {
                                chatList.add(data);
                            }
                        } else if (data.viewType == VIEW_TYPE_GROUP_HEADER) {
                            groupList.add(data);
                        } else if (data.viewType == VIEW_TYPE_GROUPS) {
                            if (data.groupName.toLowerCase().startsWith(filterPattern)) {
                                groupList.add(data);
                            }
                        } else if (data.viewType == VIEW_TYPE_CHANNEL_HEADER) {
                            if (!from.equalsIgnoreCase("external"))
                                channelList.add(data);
                        } else if (data.viewType == VIEW_TYPE_CHANNELS) {
                            if (data.channelName.toLowerCase().startsWith(filterPattern)) {
                                if (!from.equalsIgnoreCase("external"))
                                    channelList.add(data);
                            }
                        } else if (data.viewType == VIEW_TYPE_CONTACTS_HEADER) {
                            contactsList.add(data);
                        } else if (data.viewType == VIEW_TYPE_CONTACTS) {
                            if (data.user_name.toLowerCase().startsWith(filterPattern)) {
                                contactsList.add(data);
                            }
                        }
                    }

                    if (chatList.size() > 1) {
                        filteredList.addAll(chatList);
                    }
                    if (groupList.size() > 1) {
                        filteredList.addAll(groupList);
                    }
                    if (channelList.size() > 1) {
                        filteredList.addAll(channelList);
                    }
                    if (contactsList.size() > 1) {
                        filteredList.addAll(contactsList);
                    }
                }

                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                this.mAdapter.notifyDataSetChanged();
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

            LinearLayout parentlay;
            TextView name;
            ImageView profileimage;
            View profileview;
            AppCompatRadioButton btnSelect;

            public MyViewHolder(View view) {
                super(view);

                parentlay = view.findViewById(R.id.parentlay);
                profileimage = view.findViewById(R.id.profileimage);
                name = view.findViewById(R.id.txtName);
                profileview = view.findViewById(R.id.profileview);
                btnSelect = view.findViewById(R.id.btnSelect);

                btnSelect.setVisibility(View.VISIBLE);
                parentlay.setOnClickListener(this);
                btnSelect.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.parentlay:
                    case R.id.btnSelect:
                        if (filteredList.get(getAbsoluteAdapterPosition()).viewType == VIEW_TYPE_CHATS) {
                            ContactsData.Result result = dbhelper.getContactDetail(filteredList.get(getAbsoluteAdapterPosition()).user_id);
                            if (result.blockedbyme.equals("block")) {
                                btnSelect.setChecked(false);
                                blockChatConfirmDialog(result.user_id);
                            } else {
                                if (!selectedList.contains(filteredList.get(getAbsoluteAdapterPosition()))) {
                                    selectedList.add(filteredList.get(getAbsoluteAdapterPosition()));
                                    btnSelect.setChecked(true);
                                } else {
                                    btnSelect.setChecked(false);
                                    selectedList.remove(filteredList.get(getAbsoluteAdapterPosition()));
                                }
                                notifyDataSetChanged();
                            }
                        } else {
                            if (!selectedList.contains(filteredList.get(getAbsoluteAdapterPosition()))) {
                                selectedList.add(filteredList.get(getAbsoluteAdapterPosition()));
                                btnSelect.setChecked(true);
                            } else {
                                btnSelect.setChecked(false);
                                selectedList.remove(filteredList.get(getAbsoluteAdapterPosition()));
                            }
                            notifyDataSetChanged();
                        }
                        break;
                }
            }
        }

        public class HeaderViewHolder extends RecyclerView.ViewHolder {

            TextView txtHeader;

            public HeaderViewHolder(View view) {
                super(view);
                txtHeader = view.findViewById(R.id.txtHeader);
            }
        }
    }

}
