package com.app.helper.connectivity;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.app.helper.connectivity.base.ConnectivityProvider;
import com.app.helper.connectivity.base.ConnectivityProviderBaseImpl;


@RequiresApi(api = Build.VERSION_CODES.N)
public class ConnectivityProviderImpl extends ConnectivityProviderBaseImpl {
    private static final String TAG = ConnectivityProviderImpl.class.getSimpleName();
    private ConnectivityManager cm;
    private ConnectivityCallback networkCallback = new ConnectivityCallback();

    public ConnectivityProviderImpl(ConnectivityManager cm) {
        this.cm = cm;
    }

    @Override
    protected void subscribe() {
        cm.registerDefaultNetworkCallback(networkCallback);
    }

    @Override
    protected void unsubscribe() {
        cm.unregisterNetworkCallback(networkCallback);
    }

    @Override
    public NetworkState getNetworkState() {
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        if (capabilities != null) {
            return ConnectivityProvider.NetworkState.ConnectedState.Connected(capabilities);
        } else {
            return ConnectivityProvider.NetworkState.NotConnectedState;
        }
    }

    private class ConnectivityCallback extends ConnectivityManager.NetworkCallback {
        @Override
        public void onAvailable(@NonNull Network network) {
            Log.d(TAG, "onAvailable: " + network);
            NetworkStatus.isConnected = true; // Global Static Variable
        }

        @Override
        public void onCapabilitiesChanged(@NonNull Network network, @NonNull NetworkCapabilities networkCapabilities) {
            dispatchChange(ConnectivityProvider.NetworkState.ConnectedState.Connected(networkCapabilities));
        }

        @Override
        public void onLost(@NonNull Network network) {
            dispatchChange(ConnectivityProvider.NetworkState.NotConnectedState);
            NetworkStatus.isConnected = false; // Global Static Variable
        }
    }
}
