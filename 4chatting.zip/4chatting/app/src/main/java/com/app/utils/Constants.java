package com.app.utils;

import android.content.Context;
import android.provider.ContactsContract;

/**
 * Created by hitasoft on 12/3/18.
 */

public class Constants {


  /*  Site URL: https://admin.4chatting.com/

    Chat URL: https://admin.4chatting.com

    Base Port:3000
    Chat Port: 8081
    AppRTC URL: http://admin.4chatting.com:8080

    Admin Panel URL: https://admin.4chatting.com/admin/

    User Id: admin@4chatting.com
    Password: 123456
    Thank you!

*/

    public final static String SITE_URL = "https://admin.4chatting.com";
    public final static String BASE_URL = SITE_URL + ":3000/";
    public final static String SOCKET_URL = SITE_URL + ":8081";
    public final static String INVITE_LINK_URL = SITE_URL + "/admin.4chatting.com";

    /*public final static String SITE_URL = "https://products.hitasoft.in";
    public final static String BASE_URL = SITE_URL + ":3001/";
    public final static String SOCKET_URL = SITE_URL + ":8086";
    public final static String INVITE_LINK_URL = SITE_URL + "/hiddy.appkodes.in";*/

    public static final String APPRTC_URL = "http://admin.4chatting.com:8080";
    public static final String ONESIGNAL_APP_ID = "c9267bb2-ffe3-4d73-b024-3a5e4885d2f5";
    public static final String GIPHY_KEY = "hEihQDxZGiMiMTolq3vktcugSji6m3ES";

    public static final String USER_IMG_PATH = BASE_URL + "media/users/";
    public static final String CHAT_IMG_PATH = BASE_URL + "media/chats/";

    public static final int ONLINE_CHECK_TIMER = 1 * 1000 * 60;
    public static final int GROUP_MEMBER_LIMIT = 50;
    public static final int CHAT_PAGINATION_LIMIT = 20;
    public static final long CALL_TIME_DELAY = 700;

    public static final boolean ADDON_LIVE_STREAM_ENABLED = false;
    public static final boolean ADDON_SMART_REPLY = false;
    public static final boolean ADDON_EMOJI_GIF = true;
    public static final boolean ADDON_CHAT_TRANSLATE = true;

    public static final String TAG_TRANSLATE_LANGUAGE_CODE = "translate_language_code";
    public static final String TAG_PLATFORM = "platform";
    public static final String TAG_RESULT = "result";
    public static final String TAG_TRUE = "true";
    public static final String TAG_FALSE = "false";
    public static final String TAG_USER = "user";
    public static final String TAG_CHAT = "chat";
    public static final String TAG_THUMBNAIL = "thumbnail";
    public static final String TAG_PROGRESS = "progress";
    public static final String TAG_ISDELETE = "isDelete";
    public static final String TAG_MUTE_NOTIFICATION = "mute_notification";
    public static final String TAG_MY_CONTACTS = "mycontacts";
    public static final String TAG_EVERYONE = "everyone";
    public static final String TAG_NOBODY = "nobody";
    public static final String TAG_CHANNEL_NAME = "channel_name";
    public static final String TAG_CHANNEL_ID = "channel_id";
    public static final String TAG_CHANNEL_DES = "channel_des";
    public static final String TAG_CHANNEL_IMAGE = "channel_image";
    public static final String TAG_CHANNEL_TYPE = "channel_type";
    public static final String TAG_INVITE_SUBSCRIBERS = "invite_subscribers";
    public static final String TAG_PUBLIC = "public";
    public static final String TAG_PRIVATE = "private";
    public static final String TAG_ADMIN_ID = "admin_id";
    public static final String TAG_CHANNEL_ADMIN_ID = "channel_admin_id";
    public static final String TAG_CHANNEL_ADMIN_NAME = "channel_admin_name";
    public static final String TAG_TOTAL_SUBSCRIBERS = "total_subscribers";
    public static final String SentFileHolder = "created_at";
    public static final String TAG_CALL_ID = "call_id";
    public static final String TAG_CALLER_ID = "caller_id";
    public static final String TAG_CALL_STATUS = "call_status";
    public static final String TAG_CALL_TYPE = "call_type";
    public static final String TAG_NOTIFICATION_ID = "upload_notification_id";
    public static final String TAG_TIME_STAMP = "timestamp";
    public static final String TAG_SUBSCRIBE_STATUS = "subscribe_status";
    public static final String TAG_BLOCK_STATUS = "block_status";
    public static final String TAG_CHANNEL_CATEGORY = "channel_category";
    public static final String NEW = "new";
    public static final String TAG_FAVOURITED = "favourited";
    public static final String TAG_IS_SELECTED = "isSelected";
    public static final String TAG_STATUS_ID = "status_id";
    public static final String TAG_STATUS_TIME = "status_time";
    public static final String TAG_STATUS_TYPE = "status_type";
    public static final String TAG_STATUS_VIEW = "status_view";
    /*Used for Intent and other purpose*/
    public static final String TAG_LANGUAGE = "language";
    public static final String TAG_LANGUAGE_CODE = "language_code";
    public static final String ENGLISH_CODE = "en";
    public static final String FRENCH_CODE = "fr";
    public static final String ARABIC_CODE = "ar";
    public static final String DEFAULT_LANGUAGE = "English";
    public static final String TAG_DEFAULT_LANGUAGE_CODE = ENGLISH_CODE;
    public static final String TAG_BLOCK = "block";
    public static final String TAG_UNBLOCK = "unblock";
    public static final String IS_FROM = "IS_FROM";
    public static final String IS_EDIT = "IS_EDIT";
    public static final String TAG_GROUP_LIST = "group_list";
    public static final String TAG_GROUP_INVITATION = "groupinvitation";
    public static final String TAG_CHANNEL_INVITATION = "channelinvitation";
    public static final String TAG_TITLE = "title";
    public static final String ID = "id";
    public static final String TAG_NOTIFICATION = "notification";
    public static final String TAG_REPORT = "report";
    public static final String TAG_FROM = "from";
    public static final String TAG_VIDEO = "video";
    public static final String TAG_AUDIO = "audio";
    public static final String TAG_DOCUMENT = "document";
    public static final String TAG_LOCATION = "location";
    public static final String TAG_CONTACT = "contact";
    public static final String TAG_STORY = "story";
    public static final String TAG_SEND = "send";
    public static final String TAG_RECEIVE = "receive";
    public static final String TAG_WALLPAPER = "wallpaper";
    public static final String TAG_COMMON_WALLPAPER = "common_wallpaper";
    public static final String TAG_DEFAULT_WALLPAPER = "default_wallpaper";
    public static final String TAG_IS_APP_OPENED = "is_app_opened";

    /**
     * ScreenLock Constants
     */
    public static final String SECRET_MESSAGE = "Very secret message";
    public static final String KEY_NAME_NOT_INVALIDATED = "key_not_invalidated";
    public static final String DEFAULT_KEY_NAME = "default_key";
    public static final String IS_FINGERPRINT_LOCKED = "finger_print_locked";

    /*For Get Contacts*/
    public static final String[] PROJECTION = new String[]{
            ContactsContract.Data.MIMETYPE,
            ContactsContract.Data.CONTACT_ID,
            ContactsContract.Contacts.DISPLAY_NAME,
            ContactsContract.Contacts.PHOTO_URI,
            ContactsContract.Contacts.STARRED,
            ContactsContract.RawContacts.ACCOUNT_TYPE,
            ContactsContract.CommonDataKinds.Contactables.DATA,
            ContactsContract.CommonDataKinds.Contactables.TYPE
    };
    public static final String SELECTION = ContactsContract.Data.MIMETYPE + " in (?, ?)" + " AND " +
            ContactsContract.Data.HAS_PHONE_NUMBER + " = '" + 1 + "'";
    public static final String[] SELECTION_ARGS = {
            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
    };
    public static final String SORT_ORDER = ContactsContract.Contacts.SORT_KEY_ALTERNATIVE;
    // Table column name:
    public static final String TAG_STATUS = "status";
    public static String TAG_PHONE_NUMBER = "phone_no";
    public static String TAG_COUNTRY_CODE = "country_code";
    public static String TAG_COUNTRY = "country";
    public static String TAG_USER_NAME = "user_name";
    public static String TAG_SAVED_NAME = "saved_name";
    public static String TAG_USER_IMAGE = "user_image";
    public static String TAG_ABOUT = "about";
    public static String TAG_PHONE = "phone";
    public static String TAG_PRIVACY_PROFILE = "privacy_profile_image";
    public static String TAG_PRIVACY_ABOUT = "privacy_about";
    public static final String TAG_NAME = "name";
    public static final String TAG_USER_ID = "user_id";
    public static String TAG_CONTACT_ID = "contact_id";
    public static String TAG_PRIVACY_LAST_SEEN = "privacy_last_seen";
    public static String TAG_CONTACTS = "contacts";
    public static String TAG_CONTACT_STATUS = "contactstatus";
    public static String TAG_DELETED_ACCOUNT = "deleted_account";
    public static String TAG_UNKNOWN_CONTACT = "unknown_contact";
    public static String TAG_SENDER_ID = "sender_id";
    public static String TAG_RECEIVER_ID = "receiver_id";
    public static String TAG_MESSAGE_ID = "message_id";
    public static String TAG_MESSAGE_TYPE = "message_type";
    public static String TAG_CHAT_TYPE = "chat_type";
    public static String TAG_MESSAGE = "message";
    public static String TAG_MESSAGE_DATA = "message_data";
    public static String TAG_ATTACHMENT = "attachment";
    public static String TAG_LAT = "lat";
    public static String TAG_LON = "lon";
    public static String TAG_CONTACT_NAME = "contact_name";
    public static String TAG_CONTACT_PHONE_NO = "contact_phone_no";
    public static String TAG_CONTACT_COUNTRY_CODE = "contact_country_code";
    public static String TAG_CHAT_TIME = "chat_time";
    public static String TAG_DELIVERY_STATUS = "delivery_status";
    public static String TAG_CHAT_ID = "chat_id";
    public static final String TAG_DATE = "date";
    public static String TAG_UNREAD_COUNT = "unread_count";
    public static String TAG_BLOCKED_BYME = "blockedbyme";
    public static String TAG_BLOCKED_ME = "blockedme";
    public static String TAG_BLOCKED_BY = "blockedby";
    public static final String TAG_DELETE_FOR_ME = "delete_for_me";
    public static final String TAG_DELETE_FOR_EVERYONE = "delete_for_everyone";
    public static String TAG_TYPE = "type";
    public static String TAG_ID = "_id";
    public static final String ADMIN = "1";
    public static final String MEMBER = "0";
    public static String TAG_GROUP_ID = "group_id";
    public static String TAG_GROUP_ADMIN_ID = "group_admin_id";
    public static String TAG_GROUP_NAME = "group_name";
    public static String TAG_GROUP_MEMBERS = "group_members";
    public static String TAG_GROUP_IMAGE = "group_image";
    public static String TAG_GROUP_CREATED_BY = "group_created_by";
    public static final String TAG_GROUP_JOINED = "group_joined";
    public static String TAG_CREATED_AT = "created_at";
    public static String TAG_CREATED_TIME = "created_time";
    public static String TAG_MODIFIED_BY = "modified_by";
    public static String TAG_SINGLE = "single";
    public static final String TAG_GROUP = "group";
    public static final String TAG_CHANNEL = "channel";
    public static String TAG_ADMIN_CHANNEL = "admin_channel";
    public static String TAG_USER_CHANNEL = "user_channel";
    public static String TAG_CALL = "call";
    public static String TAG_CALLS = "CALLS";
    public static String TAG_MEMBER_ID = "member_id";
    public static String TAG_MEMBER_NAME = "member_name";
    public static String TAG_MEMBER_PICTURE = "member_picture";
    public static String TAG_MEMBER_NO = "member_no";
    public static String TAG_MEMBER_ABOUT = "member_about";
    public static String TAG_MEMBER_ROLE = "member_role";
    public static String TAG_MEMBER_KEY = "member_key";
    public static String TAG_IS_DELETE = "is_delete";
    public static final String TAG_OWN_STORY = "ownstory";
    public static String TAG_STATUS_DATA = "status_data";
    public static final String TAG_RECORDING = "recording";
    public static final String TAG_CLEAR = "clear";
    public static final String TAG_DELETE = "delete";
    public static int BLUR_RADIUS = 30;

    public static String TAG_STORY_ID = "story_id";
    public static String TAG_STORY_MEMBERS = "story_members";
    public static String TAG_STORY_TYPE = "story_type";
    public static String TAG_STORY_DATE = "story_date";
    public static String TAG_STORY_TIME = "story_time";
    public static String TAG_EXPIRY_TIME = "expiry_time";
    public static String TAG_DATA = "data";
    public static String TAG_MUTE_STATUS = "mute_status";
    public static String TAG_STORY_VIEWED = "story_viewed";
    public static String TAG_POSITION = "position";
    public static String TAG_IS_ALERT = "is_alert";
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_MISSED = "missed";
    public static final String TAG_IMAGE = "image";
    public static final String TAG_TEXT = "text";
    public static final String TAG_LINK = "link";
    public static final String TAG_DESCRIPTION = "description";
    public static String TAG_NAV_HEIGHT = "nav_height";
    public static String TAG_STATUS_HEIGHT = "status_height";
    public static String TAG_CAMERA = "camera";
    public static String TAG_GALLERY = "gallery";
    public static String TAG_SENT = "sent";
    public static String TAG_SOURCE_TYPE = "source_type";
    public static final String POP_UP_WINDOW_PERMISSION = "popup_window_permission";
    public static final String AUTO_START_WINDOW_PERMISSION = "autostart_window_permission";

    /* minute * 1000 * seconds * milliseconds */
    public static final long STATUS_EXPIRY_TIME = 24 * 1000 * 60 * 60;
    public static final long AUDIO_RECORD_DELAY = 350;
    public static final long MINIMUM_RECORD_DURATION = 1000;
    public static final int STATUS_TEXT_CODE = 300;
    public static final int STATUS_VIDEO_CODE = 301;
    public static final int STATUS_IMAGE_CODE = 302;
    public static final int OVERLAY_REQUEST_CODE = 303;

    /*Intent Request Code*/
    public static final int CAMERA_REQUEST_CODE = 234;
    public static final int GALLERY_REQUEST_CODE = 150;
    public static final int DOCS_REQUEST_CODE = 151;
    public static final int AUDIO_REQUEST_CODE = 152;
    public static final int LOCATION_REQUEST_CODE = 153;
    public static final int CONTACT_REQUEST_CODE = 154;
    public static final int OVERLAY_PERMISSION_REQUEST_CODE = 155;
    public static final int DEVICE_LOCK_REQUEST_CODE = 156;

    public static boolean isChatOpened = false, isGroupChatOpened = false, isChannelChatOpened = false, isExternalPlay = false;
    public static Context chatContext, groupContext, channelContext;
    public static long storyDuration = 6000;
    public static final long ANIMATION_FAST_MILLIS = 50L;
    public static final long ANIMATION_SLOW_MILLIS = 100L;

    public static String SHARED_PREFERENCE = "SavedPref";
    public static String MESSAGE_CRYPT_KEY = "Hiddy123!@#";

    public static final String TAG_GIF = "gif";
    public static boolean isInStream = false;
    public static final String TAG_VISIBILITY = "visibility";
}
