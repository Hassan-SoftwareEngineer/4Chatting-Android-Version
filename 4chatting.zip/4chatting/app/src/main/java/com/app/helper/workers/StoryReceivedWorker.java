package com.app.helper.workers;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StoryReceivedWorker extends Worker {
    private static final String TAG = StoryReceivedWorker.class.getSimpleName();
    private Context mContext;

    public StoryReceivedWorker(
            @NonNull Context appContext,
            @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);
        mContext = appContext;
    }

    @NonNull
    @NotNull
    @Override
    public Result doWork() {
        // To acknowledge the message has been delivered
        HashMap<String, String> params = new HashMap<>();
        params.put(Constants.TAG_USER_ID, getInputData().getString(Constants.TAG_USER_ID));
        params.put(Constants.TAG_STORY_ID, getInputData().getString(Constants.TAG_STORY_ID));
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<HashMap<String, String>> call = apiInterface.storyReceived(GetSet.getToken(), params);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {

            }
        });
        return Result.success();
    }
}
