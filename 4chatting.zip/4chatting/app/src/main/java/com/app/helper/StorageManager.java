package com.app.helper;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.coremedia.iso.IsoFile;
import com.app.fourchattingapp.BuildConfig;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * Created by hitasoft on 7/3/17.
 */

public class StorageManager {

    /*Constants for file manipulation*/
    public static final String TAG_STATUS = "status";
    public static final String TAG_SENT = "sent";
    public static final String TAG_IMAGE = "image";
    public static final String TAG_IMAGE_SENT = "image_sent";
    public static final String TAG_VIDEO_SENT = "video_sent";
    public static final String TAG_AUDIO_SENT = "audio_sent";
    public static final String TAG_DOCUMENT_SENT = "document_sent";
    public static final String TAG_AUDIO = "audio";
    public static final String TAG_VIDEO = "video";
    public static final String TAG_THUMB = "thumb";
    public static final String TAG_DOCUMENT = "document";
    public static final String TAG_PROFILE = "profile";
    public static final String TAG_WALLPAPER = "wallpaper";
    private static StorageManager mInstance;
    private final String TAG = this.getClass().getSimpleName();
    private Context mContext;

    public StorageManager(Context mContext) {
        this.mContext = mContext;
    }

    public static synchronized StorageManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new StorageManager(context);
        }
        return mInstance;
    }

    public String getFolderPathQ(String from) {
        String path = "";
        switch (from) {
            case Constants.TAG_IMAGE:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/";
                break;
            case Constants.TAG_WALLPAPER:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Wallpaper/";
                break;
            case "sent":
            case TAG_IMAGE_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/Sent/";
                break;
            case "profile":
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/.Profile/";
                break;
            case TAG_THUMB:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/.thumbnails/";
                break;
            case TAG_AUDIO:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Audios/";
                break;
            case TAG_AUDIO_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Audios/Sent/";
                break;
            case TAG_VIDEO:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Videos/";
                break;
            case TAG_VIDEO_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Videos/Sent/";
                break;
            case TAG_DOCUMENT_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Files/Sent/";
                break;
            case TAG_DOCUMENT:
            default:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Files/";
                break;
        }
//        Log.d(TAG, "getFolderPathQ: " + path);
        return path;
    }

    public String getSentPathQ(String from) {
        String path = "";
        switch (from) {
            case Constants.TAG_IMAGE:
                path = "/" + "Images/";
                break;
            case "sent":
            case TAG_IMAGE_SENT:
                path = "/" + "Images/Sent/";
                break;
            case "profile":
                path = "/" + "Images/.Profile/";
                break;
            case TAG_THUMB:
                path = "/" + "Images/.thumbnails/";
                break;
            case TAG_WALLPAPER:
                path = "/" + "Wallpaper/";
                break;
            case "audio":
                path = "/" + "Audios/";
                break;
            case TAG_AUDIO_SENT:
                path = "/" + "Audios/Sent/";
                break;
            case TAG_VIDEO:
                path = "/" + "Videos/";
                break;
            case TAG_VIDEO_SENT:
                path = "/" + "Videos/Sent/";
                break;
            case TAG_DOCUMENT_SENT:
                path = "/" + "Files/Sent/";
                break;
            case TAG_DOCUMENT:
            default:
                path = "/" + "Files/";
                break;
        }
        Log.d(TAG, "getSentPathQ: " + path);
        return path;
    }

    public String getFolderPath(String from) {
        String path = "";
        switch (from) {
            case Constants.TAG_IMAGE:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/";
                break;
            case "sent":
            case TAG_IMAGE_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/Sent/";
                break;
            case TAG_PROFILE:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/.Profile/";
                break;
            case TAG_THUMB:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Images/.thumbnails/";
                break;
            case TAG_WALLPAPER:
                path = File.separator + mContext.getString(R.string.app_name) +
                        File.separator + mContext.getString(R.string.app_name) + "Wallpaper" + File.separator;
                break;
            case "audio":
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Audios/";
                break;
            case TAG_AUDIO_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Audios/Sent/";
                break;
            case TAG_VIDEO:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Videos/";
                break;
            case TAG_VIDEO_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Videos/Sent/";
                break;
            case TAG_DOCUMENT_SENT:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Files/Sent/";
                break;
            case TAG_DOCUMENT:
            default:
                path = "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + "Files/";
                break;
        }
        Log.d(TAG, "getFolderPath: " + path);
        return path;
    }


    public String getStatusPath(String fileType) {
        String path;
        if (fileType.equals(TAG_IMAGE)) {
            path = "/" + mContext.getString(R.string.app_name) + "Images" + "/"
                    + mContext.getString(R.string.app_name) + "Statuses/";
        } else {
            path = "/" + mContext.getString(R.string.app_name) + "Videos" + "/"
                    + mContext.getString(R.string.app_name) + "Statuses/";
        }
        return path;
    }

    public String fileFromContentUri(Context context, Uri contentUri, String ext) {
        // Preparing Temp file name
        String fileName = "TEMP_" + System.currentTimeMillis() + "." + ext;
        File tempFile = new File(context.getExternalCacheDir(), fileName);
        try {
            // Creating Temp file
            tempFile.createNewFile();
            FileOutputStream oStream = new FileOutputStream(tempFile);
            InputStream inputStream = context.getContentResolver().openInputStream(contentUri);
            IOUtils.copy(inputStream, oStream);
            oStream.flush();
        } catch (Exception e) {
            Log.e(TAG, "fileFromContentUri: " + e.getMessage());
        }
        Log.d(TAG, "fileFromContentUri: " + tempFile.exists());
        if (tempFile != null) {
            Log.d(TAG, "fileFromContentUri: " + tempFile.getAbsolutePath());
        }
        return tempFile.getAbsolutePath();
    }

    public File saveImageInStorage(Bitmap bitmap, String fileName, String from) {
        File savedFile = saveBitmap(bitmap, fileName, from);
        if (savedFile != null) {
            Log.d(TAG, "saveImageInStorage: " + savedFile.getAbsolutePath());
        }
        return savedFile;
    }

    public Uri saveImageInStorageV10(Bitmap bitmap, String fileName, String from) {
        Uri savedUri = null;
        Uri mediaContentUri;
        mediaContentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        ContentValues values = getContentValues(mContext, from, fileName, "image/*");
        savedUri = mContext.getContentResolver().insert(mediaContentUri, values);
        try {
            OutputStream outputStream = mContext.getContentResolver().openOutputStream(savedUri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.close();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            mContext.getContentResolver().update(savedUri, values, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(TAG, "saveImageInStorageV10: " + savedUri + ", " + fileName);
        return savedUri;
    }

    public Uri saveFileInStorageV10(File srcFile, String fileName, String from, String fileType) {
        Uri savedUri = null;
        Uri mediaContentUri = null;
        ContentValues values = null;
        switch (fileType) {
            case Constants.TAG_IMAGE:
                mediaContentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                values = getContentValues(mContext, from, fileName, "image/*");
                break;
            case Constants.TAG_AUDIO:
                mediaContentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                values = getContentValues(mContext, from, fileName, "audio/*");
                break;
            case Constants.TAG_VIDEO:
                mediaContentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                values = getContentValues(mContext, from, fileName, "video/mp4");
                break;
            case TAG_DOCUMENT:
                mediaContentUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
                values = getContentValues(mContext, from, fileName, getMimeType(srcFile.getAbsolutePath()));
                break;
        }
        savedUri = mContext.getContentResolver().insert(mediaContentUri, values);
        if (savedUri != null) {
            ParcelFileDescriptor pfd;
            try {
                pfd = mContext.getContentResolver().openFileDescriptor(savedUri, "w");
                FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor());
                InputStream in = new FileInputStream(srcFile);
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                out.close();
                in.close();
                pfd.close();
                switch (fileType) {
                    case Constants.TAG_IMAGE:
                        values.put(MediaStore.Images.Media.IS_PENDING, 0);
                        break;
                    case Constants.TAG_AUDIO:
                        values.put(MediaStore.Audio.Media.IS_PENDING, 0);
                        break;
                    case Constants.TAG_VIDEO:
                        values.put(MediaStore.Video.Media.IS_PENDING, 0);
                        break;
                    case TAG_DOCUMENT:
                        values.put(MediaStore.Files.FileColumns.IS_PENDING, 0);
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            mContext.getContentResolver().update(savedUri, values, null, null);
            Log.d(TAG, "saveUriInStorageV10: " + savedUri);
            return savedUri;
        }
        return null;
    }

    public String saveFileInStorage(File src, String from) {
        File savedFile = null;
        String fileName = src.getName();
        File destDir = createDirectory(from);

        if (src != null && src.exists()) {
            try {
                File newFile = new File(destDir.getAbsoluteFile(), fileName);
                InputStream inputStream = new FileInputStream(src);
                OutputStream outputStream = new FileOutputStream(newFile);
                byte[] buf = new byte[1024];
                int bytesRead;

                while ((bytesRead = inputStream.read(buf)) > 0) {
                    outputStream.write(buf, 0, bytesRead);
                }

                outputStream.flush();
                inputStream.close();
                outputStream.close();
                savedFile = newFile;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (savedFile != null) {
            Log.d(TAG, "saveFileInStorage: " + savedFile.getAbsolutePath());
            return savedFile.getAbsolutePath();
        } else {
            return null;
        }
    }

    public String saveFileInGallery(File src, String fileName, String from) {
        File savedFile = null;
        File destDir = createDirectory(from);

        if (src != null && src.exists()) {
            try {
                File newFile = new File(destDir.getAbsoluteFile(), fileName);
                InputStream inputStream = new FileInputStream(src);
                OutputStream outputStream = new FileOutputStream(newFile);
                byte[] buf = new byte[1024];
                int bytesRead;

                while ((bytesRead = inputStream.read(buf)) > 0) {
                    outputStream.write(buf, 0, bytesRead);
                }

                outputStream.flush();
                inputStream.close();
                outputStream.close();
                savedFile = newFile;
                Utils.refreshGallery(TAG, mInstance.mContext, newFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (savedFile != null) {
            Log.d(TAG, "saveFileInStorage: " + savedFile.getAbsolutePath());
            return savedFile.getAbsolutePath();
        } else {
            return null;
        }
    }

    public void saveUriToSent(Uri fileUri, String from, String fileType, String fileName) {
        File root = getDirectory(from, fileType);
        File destFile = new File(root, fileName);
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            bis = new BufferedInputStream(mContext.getContentResolver().openInputStream(fileUri));
            bos = new BufferedOutputStream(new FileOutputStream(destFile, false));
            byte[] buf = new byte[1024];
            bis.read(buf);
            do {
                bos.write(buf);
            } while (bis.read(buf) != -1);
            Log.d(TAG, "saveUriToSent: ");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bis != null) bis.close();
                if (bos != null) bos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ContentValues getContentValues(Context mContext, String from, String
            fileName, String mimeType) {
        String directory = "";
        ContentValues values = new ContentValues();
        switch (from) {
            case TAG_IMAGE:
            case TAG_WALLPAPER: {
                directory = Environment.DIRECTORY_PICTURES + getFolderPathQ(from);
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.TITLE, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Images.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            break;
            case TAG_IMAGE_SENT:
            case TAG_THUMB: {
                directory = Environment.DIRECTORY_PICTURES + getFolderPathQ(from);
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Images.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            break;
            case TAG_VIDEO: {
                directory = Environment.DIRECTORY_MOVIES + getFolderPathQ(from);
                values.put(MediaStore.Video.Media.TITLE, fileName);
                values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Video.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.Video.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Video.Media.IS_PENDING, 1);
            }
            break;
            case TAG_VIDEO_SENT: {
                directory = Environment.DIRECTORY_MOVIES + getFolderPathQ(from);
                values.put(MediaStore.Video.Media.TITLE, fileName);
                values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Video.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.Video.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Video.Media.IS_PENDING, 1);
            }
            break;
            case TAG_AUDIO: {
                directory = Environment.DIRECTORY_MUSIC + getFolderPathQ(from);
                values.put(MediaStore.Audio.Media.TITLE, fileName);
                values.put(MediaStore.Audio.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Audio.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Audio.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            }
            break;
            case TAG_AUDIO_SENT: {
                directory = Environment.DIRECTORY_MUSIC + getFolderPathQ(from);
                values.put(MediaStore.Audio.Media.TITLE, fileName);
                values.put(MediaStore.Audio.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Audio.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Audio.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            }
            break;
            case TAG_DOCUMENT: {
                directory = Environment.DIRECTORY_DOCUMENTS + getFolderPathQ(from);
                values.put(MediaStore.MediaColumns.TITLE, fileName);
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.MediaColumns.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, directory);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            break;
            case TAG_DOCUMENT_SENT: {
                directory = Environment.DIRECTORY_DOCUMENTS + getFolderPathQ(from);
                values.put(MediaStore.MediaColumns.TITLE, fileName);
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.MediaColumns.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, directory);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            break;
            default:
                directory = Environment.DIRECTORY_PICTURES + getFolderPathQ(from);
                values.put(MediaStore.Files.FileColumns.TITLE, fileName);
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, mimeType);
                values.put(MediaStore.Files.FileColumns.DATE_ADDED, System.currentTimeMillis() / 1000);
                values.put(MediaStore.Images.Media.RELATIVE_PATH, directory);
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                break;
        }
        return values;
    }

    public File saveBitmap(Bitmap bitmap, String fileName, String from) {
        File mDestDir = createDirectory(from);
        File mDestFile = new File(mDestDir, fileName);
        try {
            FileOutputStream out = new FileOutputStream(mDestFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            return mDestFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public File saveBitmapInExternal(Bitmap scaledBitmap, String fileName, String from) {
        File mDestDir = new File(getExtFilesDir() + File.separator + "Wallpaper");
        if (!mDestDir.exists()) mDestDir.mkdirs();
        File mDestFile = new File(mDestDir, fileName);
        if (mDestFile != null && mDestFile.exists()) mDestFile.delete();
        try {
            FileOutputStream out = new FileOutputStream(mDestFile);
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            return mDestFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public File saveStatusFile(Bitmap bitmap, File srcFile, String fileName, String from) {
        File mDestDir;
        if (from.equals(TAG_SENT)) {
            mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Sent");
        } else if (from.equals(TAG_THUMB)) {
            mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Thumb");
        } else {
            mDestDir = new File(getExtFilesDir(), "Statuses");
        }
        if (!mDestDir.exists()) {
            mDestDir.mkdirs();
        }
        Log.e("checkDownloadFile","-downloadMana");
        File mDestFile = new File(mDestDir, fileName);
        if (bitmap != null) {
            try {
                FileOutputStream out = new FileOutputStream(mDestFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                out.flush();
                out.close();
                return mDestFile;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                InputStream inputStream = new FileInputStream(srcFile);
                OutputStream outputStream = new FileOutputStream(mDestFile);
                byte[] buf = new byte[1024];
                int bytesRead;

                while ((bytesRead = inputStream.read(buf)) > 0) {
                    outputStream.write(buf, 0, bytesRead);
                }

                outputStream.flush();
                inputStream.close();
                outputStream.close();
                return mDestFile;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public File getStatusFile(String fileName, String from) {
        File mDestDir;
        if (from.equals(TAG_SENT)) {
            mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Sent");
        } else if (from.equals(TAG_THUMB)) {
            mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Thumb");
        } else {
            mDestDir = new File(getExtFilesDir(), "Statuses");
        }

        if (!mDestDir.exists()) {
            return null;
        } else {
            File mDestFile = new File(mDestDir, fileName);
            if (mDestFile.exists()) {
                Log.d(TAG, "getStatusFile: " + mDestFile + ", " + from);
                return mDestFile;
            }
        }
        return null;
    }

    public void deleteStory(String attachment, String thumbnail, String way) {
        Log.d(TAG, "deleteStory: " + attachment + ", " + way);
        if (way.equals("ownstory")) {
            if (!TextUtils.isEmpty(attachment)) {
                File mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Sent");
                File mDestFile = new File(mDestDir, attachment);
                if (mDestFile.exists()) mDestFile.delete();
            }
            if (!TextUtils.isEmpty(thumbnail)) {
                File mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Thumb");
                File mDestFile = new File(mDestDir, thumbnail);
                if (mDestFile.exists()) mDestFile.delete();
            }
        } else {
            if (!TextUtils.isEmpty(attachment)) {
                File mDestDir = new File(getExtFilesDir(), "Statuses");
                File mDestFile = new File(mDestDir, attachment);
                if (mDestFile.exists()) mDestFile.delete();
            }
            if (!TextUtils.isEmpty(thumbnail)) {
                File mDestDir = new File(getExtFilesDir() + File.separator + "Statuses", "Thumb");
                File mDestFile = new File(mDestDir, thumbnail);
                if (mDestFile.exists()) mDestFile.delete();
            }
        }
    }

    public File getImage(String from, String imageName) {

        File mediaImage = null;
        try {
            String root = "";
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                root = mContext.getExternalCacheDir().toString();
            } else {
                root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
            }

            File myDir = new File(root);
            if (!myDir.exists())
                return null;

            String path = getFolderPath(from);
            mediaImage = new File(myDir.getPath() + path + imageName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mediaImage;
    }

    public boolean checkIfImageExists(String from, String imageName) {
        File file = getImage(from, imageName);
        return file.exists();
    }

    public boolean renameFile(Uri fileUri, String filePath, String newFileName, String fileType) {
        boolean renamed = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            File from = new File(filePath);
            File to = new File(from.getParentFile(), newFileName);
            renamed = from.renameTo(to);
            Log.e("checkData","- renameFile "+to.getAbsolutePath());
            /*
            try {
                ContentResolver contentResolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                switch (fileType) {
                    case Constants.TAG_IMAGE:
                        contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, newFileName);
                        contentResolver.update(fileUri, contentValues, null, null);
                        renamed = true;
                        break;
                    case Constants.TAG_AUDIO:
                        contentValues.put(MediaStore.Audio.Media.DISPLAY_NAME, newFileName);
                        contentResolver.update(fileUri, contentValues, null, null);
                        renamed = true;
                        break;
                    case Constants.TAG_VIDEO:
                        contentValues.put(MediaStore.Video.Media.DISPLAY_NAME, newFileName);
                        contentResolver.update(fileUri, contentValues, null, null);
                        renamed = true;
                        break;
                    case TAG_DOCUMENT:
                        *//*final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                        // Check for the freshest data.
                        contentResolver.takePersistableUriPermission(fileUri, takeFlags);
                        Uri docUri = MediaStore.getDocumentUri(context, fileUri);
                        DocumentsContract.renameDocument(contentResolver, docUri, newFileName);*//*
                        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newFileName);
                        contentResolver.update(fileUri, contentValues, null, null);
                        renamed = true;
                        break;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        */
        } else {
            File from = new File(filePath);
            File to = new File(from.getParentFile(), newFileName);
            renamed = from.renameTo(to);
        }
        Log.d(TAG, "renameFile: " + renamed+" ");
        return renamed;
    }

    Long getImageIdFromDisplayName(String displayName) {
        Cursor cursor = null;
        String[] ID_COLUMN = {BaseColumns._ID};
        String[] projection;
        projection = new String[]{MediaStore.Images.Media._ID};
        Uri extUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        // TODO This will break if we have no matching item in the MediaStore.
        /*cursor = MediaStore.Images.Media.query(context.getContentResolver(),
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                ID_COLUMN, null, null, null);
*/
        cursor = mContext.getContentResolver().query(extUri, projection,
                MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?", new String[]{displayName}, null);
        assert cursor != null;
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            int columnIndex = cursor.getColumnIndex(projection[0]);
            long fileId = cursor.getLong(columnIndex);

            cursor.close();
            return fileId;
        }
        return null;
    }

    public File getFile(String fileName, String fileType, String from) {
        String root = null;

        if (fileType.equals("audio")) {
            fileType = "Audios";
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                root = mContext.getExternalCacheDir().toString();
            } else {
                root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).toString();
            }
        } else if (fileType.equals("video")) {
            fileType = "Videos";
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                root = mContext.getExternalCacheDir().toString();
            } else {
                root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).toString();
            }
        } else {
            fileType = "Files";
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                root = mContext.getExternalCacheDir().toString();
            } else {
                root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).toString();
            }
        }
        File myDir = new File(root);
        if (!myDir.exists())
            return null;

        if (from.equals("sent")) {
            from = "Sent/";
        } else {
            from = "";
        }

        File dir = new File(myDir.getPath() + "/" + mContext.getString(R.string.app_name) + "/" + mContext.getString(R.string.app_name) + fileType + "/" + from + "/" + fileName);
        Log.e(TAG, "getFile: " + dir.getAbsolutePath());
        return dir;
    }

    public Uri getFileUri(String from, String fileName, String fileType) {
        Uri fileUri = null;

        switch (fileType) {
            case TAG_AUDIO:
                fileUri = getAudioUriFromName(fileName, from);
                break;
            case Constants.TAG_IMAGE:
            case TAG_THUMB:
                fileUri = getImageUriFromName(fileName, from);
                break;
            case TAG_VIDEO:
                fileUri = getVideoUriFromName(fileName, from);
                break;
            case TAG_DOCUMENT:
            default:
                fileUri = getDocumentUriFromName(fileName, from);
                break;
        }
        /*if (fileUri != null) {
            Log.e(TAG, "getFileUri: " + fileUri.getPath() + " ," + fileName + ", " + fileType + ", " + from);
        }*/
        return fileUri;
    }

    public File getSrcFile(String from, String fileName, String fileType) {
        File root = getDirectory(from, fileType);
        if (root != null && !root.exists())
            return null;
        File dir = new File(root, fileName);
        if (dir.exists()) {
            Log.d(TAG, "getSrcFile: " + dir.getAbsolutePath());
            return dir;
        }
        return null;
    }

    // url = file path or whatever suitable URL you want.
    public String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    public String getMimeTypeOfUri(Context context, Uri uri) {
        String mimeType = null;
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            ContentResolver cr = context.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }

    public String getExtension(Uri uri) {
        String extension;

        //Check uri format to avoid null
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            //If scheme is a content
            final MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(mContext.getContentResolver().getType(uri));
        } else {
            //If scheme is a File
            //This will replace white spaces with %20 and also other special characters. This will avoid returning null values on file name with spaces and special characters.
            extension = MimeTypeMap.getFileExtensionFromUrl(getUriFromFile(new File(uri.getPath())).toString());

        }
        Log.d(TAG, "getExtension: " + extension);
        return extension;
    }

    public Uri getUriFromFile(File dir) {
        if (dir != null && dir.exists()) {
            return FileProvider.getUriForFile(mContext, BuildConfig.APPLICATION_ID + ".provider", dir);
        } else {
            return null;
        }
    }

    public File getFile(String fileName, String from) {
        File sdcard = null;

        switch (from) {
            case Constants.TAG_IMAGE:
            case "sent":
            case TAG_IMAGE_SENT:
            case "profile":
            case TAG_THUMB:
            case Constants.TAG_STATUS:
                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                    sdcard = mContext.getExternalCacheDir();
                } else {
                    sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                }

                break;

            case "audio":
            case TAG_AUDIO_SENT:
                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                    sdcard = mContext.getExternalCacheDir();
                } else {
                    sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
                }
                break;

            case TAG_VIDEO:
            case TAG_VIDEO_SENT:
                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                    sdcard = mContext.getExternalCacheDir();
                } else {
                    sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
                }

                break;

            case TAG_DOCUMENT_SENT:
            case TAG_DOCUMENT:
            default:
                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                    sdcard = mContext.getExternalCacheDir();
                } else {
                    sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                }
                break;
        }

        String path = getFolderPath(from);
        File file = new File(sdcard.getAbsoluteFile(), path + fileName);
        if (file.exists()) {
            return file;
        }
        return null;
    }

    public boolean checkFileExists(String fileName, String fileType) {
        boolean isFileExists = false;
        switch (fileType) {
            case Constants.TAG_IMAGE: {
                File file = getSrcFile(StorageManager.TAG_IMAGE_SENT, fileName, Constants.TAG_IMAGE);
                if (file != null) {
                    isFileExists = true;
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = getFileUri(StorageManager.TAG_IMAGE, fileName, StorageManager.TAG_IMAGE);
                        if (fileUri != null) {
                            isFileExists = true;
                        }
                    } else {
                        file = getSrcFile(StorageManager.TAG_IMAGE, fileName, StorageManager.TAG_IMAGE);
                        if (file != null) {
                            isFileExists = true;
                        }
                    }
                }
                break;
            }
            case Constants.TAG_VIDEO: {
                File file = getSrcFile(StorageManager.TAG_VIDEO_SENT, fileName, Constants.TAG_VIDEO);
                if (file != null) {
                    isFileExists = true;
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = getFileUri(StorageManager.TAG_VIDEO, fileName, StorageManager.TAG_VIDEO);
                        if (fileUri != null) {
                            isFileExists = true;
                        }
                    } else {
                        file = getSrcFile(StorageManager.TAG_VIDEO, fileName, StorageManager.TAG_VIDEO);
                        if (file != null) {
                            isFileExists = true;
                        }
                    }
                }
                break;
            }
            case Constants.TAG_DOCUMENT: {
                File file = getSrcFile(StorageManager.TAG_DOCUMENT_SENT, fileName, Constants.TAG_DOCUMENT);
                if (file != null) {
                    isFileExists = true;
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = getFileUri(StorageManager.TAG_DOCUMENT, fileName, StorageManager.TAG_DOCUMENT);
                        if (fileUri != null) {
                            isFileExists = true;
                        }
                    } else {
                        file = getSrcFile(StorageManager.TAG_DOCUMENT, fileName, StorageManager.TAG_DOCUMENT);
                        if (file != null) {
                            isFileExists = true;
                        }
                    }
                }
                break;
            }
            case Constants.TAG_AUDIO: {
                File file = getSrcFile(StorageManager.TAG_AUDIO_SENT, fileName, Constants.TAG_AUDIO);
                if (file != null) {
                    isFileExists = true;
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = getFileUri(StorageManager.TAG_AUDIO, fileName, StorageManager.TAG_AUDIO);
                        if (fileUri != null) {
                            isFileExists = true;
                        }
                    } else {
                        file = getSrcFile(StorageManager.TAG_AUDIO, fileName, StorageManager.TAG_AUDIO);
                        if (file != null) {
                            isFileExists = true;
                        }
                    }
                }
                break;
            }
        }
        Log.d(TAG, "checkFileExists: " + isFileExists);
        return isFileExists;
    }

    public boolean checkFileExistsInSent(String fileName, String from, String fileType) {
        boolean isFileExists = false;
        File root = getDirectory(from, fileType);
        File srcFile = new File(root, fileName);
        if (srcFile != null && srcFile.exists()) {
            isFileExists = true;
        }
        Log.d(TAG, "checkFileExistsInSent: " + isFileExists);
        return isFileExists;
    }

    public void saveFileToSent(File fromFile, String attachment, String from, String fileType) {
        File root = getDirectory(from, fileType);
        File toFile = new File(root, attachment);
        try {
            FileUtils.copyFile(fromFile, toFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the Uri which can be used to delete/work with images in the photo gallery.
     *
     * @param displayName Path to IMAGE on SD card
     * @return Uri in the format of... content://media/external/images/media/[NUMBER]
     */
    private Uri getImageUriFromName(String displayName, String from) {
        String relativePath;
        if (from.equals(TAG_STATUS)) {
            relativePath = Environment.DIRECTORY_PICTURES + getStatusPath(TAG_IMAGE);
        } else {
            relativePath = Environment.DIRECTORY_PICTURES + getFolderPathQ(from);
        }

        Uri returnUri = null;
        // which image properties are we querying
        String[] projection = new String[]{
                MediaStore.Images.Media._ID
        };

        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }
        String selection = MediaStore.Images.Media.RELATIVE_PATH + " == ? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + " == ?" + " or " +
                MediaStore.MediaColumns.TITLE + " == ?";
        String[] selectionArgs = new String[]{
                relativePath, displayName
        };
        ContentResolver resolver = mContext.getContentResolver();
        Cursor imageCursor = resolver.query(collection, projection, selection, selectionArgs, null);
        int columnIndexID;
        if (imageCursor != null) {
            columnIndexID = imageCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            if (imageCursor.moveToFirst()) {
                long imageId = imageCursor.getLong(columnIndexID);
                returnUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageId);
            }
            imageCursor.close();
        }
        if (returnUri != null) {
            Log.d(TAG, "getImageUriFromName: " + returnUri.getPath());
        }
        return returnUri;
    }

    private Uri getAudioUriFromName(String displayName, String from) {
        String relativePath = Environment.DIRECTORY_MUSIC + getFolderPathQ(from);
        Uri returnUri = null;
        // which image properties are we querying
        String[] projection = new String[]{
                MediaStore.Audio.Media._ID
        };
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        }
//        Log.d(TAG, "getAudioUriFromName: " + relativePath);
        String selection = MediaStore.Audio.Media.RELATIVE_PATH + " ==? AND " +
                MediaStore.Audio.Media.DISPLAY_NAME + " == ?";
        String[] selectionArgs = new String[]{relativePath, displayName};
        ContentResolver resolver = mContext.getContentResolver();
        Cursor cursor = resolver.query(collection, projection, selection, selectionArgs, null);
        int columnIndexID;
        if (cursor != null) {
            columnIndexID = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            if (cursor.moveToFirst()) {
                long imageId = cursor.getLong(columnIndexID);
                returnUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, imageId);
            }
            cursor.close();
        }
        if (returnUri != null) {
            Log.d(TAG, "getAudioUriFromName: " + returnUri.getPath());
        }
        return returnUri;
    }

    private Uri getVideoUriFromName(String displayName, String from) {
        String relativePath;
        if (from.equals(TAG_STATUS)) {
            relativePath = Environment.DIRECTORY_MOVIES + getStatusPath(TAG_VIDEO);
        } else {
            relativePath = Environment.DIRECTORY_MOVIES + getFolderPathQ(from);
        }
        Log.d(TAG, "getVideoUriFromName: " + relativePath + ", " + displayName + ", " + from);
        Uri returnUri = null;
        // which image properties are we querying
        String[] projection = new String[]{
                MediaStore.Video.Media._ID
        };
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);

            String selection = MediaStore.Video.Media.RELATIVE_PATH + " ==? AND " +
                    MediaStore.Video.Media.DISPLAY_NAME + " == ?";
            String[] selectionArgs = new String[]{relativePath, displayName};
            ContentResolver resolver = mContext.getContentResolver();
            Cursor cursor = resolver.query(collection, projection, selection, selectionArgs, null);
            int columnIndexID;
            if (cursor != null) {
                columnIndexID = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                if (cursor.moveToFirst()) {
                    long imageId = cursor.getLong(columnIndexID);
                    returnUri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, imageId);
                }
                cursor.close();
            }
            if (returnUri != null) {
                Log.d(TAG, "getVideoUriFromName: " + returnUri.getPath());
            }
        }
        return returnUri;
    }

    private Uri getDocumentUriFromName(String displayName, String from) {
        String relativePath = Environment.DIRECTORY_DOCUMENTS + getFolderPathQ(from);
        Uri returnUri = null;
        // which image properties are we querying
        String[] projection = new String[]{
                MediaStore.Files.FileColumns._ID
        };
        Uri collection;
        collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        String selection = MediaStore.Files.FileColumns.RELATIVE_PATH + " ==? AND " +
                MediaStore.Files.FileColumns.DISPLAY_NAME + " == ?";
        String[] selectionArgs = new String[]{relativePath, displayName};
        ContentResolver resolver = mContext.getContentResolver();
        Cursor cursor = resolver.query(collection, projection, selection, selectionArgs, null);
        int columnIndexID;
        if (cursor != null) {
            columnIndexID = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
            if (cursor.moveToFirst()) {
                long imageId = cursor.getLong(columnIndexID);
                returnUri = ContentUris.withAppendedId(collection, imageId);
            }
            cursor.close();
        }
        if (returnUri != null) {
            Log.d(TAG, "getFileUriFromName: " + returnUri.getPath());
        }
        return returnUri;
    }

    public Uri getUriFromId(long fileId, String from) {
        Uri returnUri = null;
        Uri collection;
        switch (from) {
            case TAG_IMAGE:
                collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                break;
            case TAG_AUDIO:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
                } else {
                    collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                break;
            case TAG_VIDEO:
                collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                break;
            default:
                collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
                break;
        }
        returnUri = ContentUris.withAppendedId(collection, fileId);
        if (returnUri != null) {
            Log.d(TAG, "getUriFromId: " + returnUri.getPath());
        }
        return returnUri;
    }

    void checkDeleteFile(String name, String fileType, String from) {
        if (fileType != null) {
            File file = getImage(from, name);
            if (file.exists()) {
                deleteFileFromMediaStore(file);
            } else {
                File otherFile = getFile(name, fileType, from);
                Log.d(TAG, "checkDeleteFile: " + otherFile.getAbsolutePath());
                if (otherFile.exists()) {
                    deleteFileFromMediaStore(otherFile);
                }
            }
        }
    }

    private void deleteFileFromMediaStore(final File file) {
        final ContentResolver contentResolver = mContext.getContentResolver();
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        final Uri uri = MediaStore.Files.getContentUri("external");
        final int result = contentResolver.delete(uri,
                MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
        if (result == 0) {
            final String absolutePath = file.getAbsolutePath();
            if (!absolutePath.equals(canonicalPath)) {
                contentResolver.delete(uri,
                        MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
            }
        }
    }

    public boolean deleteUri(Context mContext, Uri fileUri) {
        ContentResolver contentResolver = this.mContext.getContentResolver();
        //delete object using resolver
        try {
            contentResolver.delete(fileUri, null, null);
            Log.d(TAG, "deleteUri: " + "true");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteFile(String filePath) {
        if (!TextUtils.isEmpty(filePath)) {
            File file = new File(filePath);
            if (file.exists()) {
                return file.delete();
            }
        }
        return false;
    }

    public File createCacheFile(String fileName) {
        return new File(getExtCachesDir(), fileName);
    }

    public String getFileName(String filePath) {
        String imgSplit = filePath;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1);
        }
        return imgSplit;
    }

    public void deleteCacheDirs() {
        if (Environment.getExternalStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED)) {
            File cacheDirs = ContextCompat.getExternalCacheDirs(mContext)[0];
            if (cacheDirs != null) {
                if (cacheDirs.isDirectory()) {
                    for (File files : cacheDirs.listFiles()) {
                        if (files != null) files.delete();
                    }
                } else {
                    cacheDirs.delete();
                }
            }
        } else {
            File cacheDirs = mContext.getCacheDir();
            if (cacheDirs != null) {
                if (cacheDirs.isDirectory()) {
                    for (File files : cacheDirs.listFiles()) {
                        if (files != null) files.delete();
                    }
                } else {
                    cacheDirs.delete();
                }
            }
        }
    }

    public File getExtFilesDir() {
        File mDataDir = ContextCompat.getExternalFilesDirs(mContext, null)[0];
        if (!mDataDir.exists()) {
            mDataDir.mkdirs();
        }
        if (mDataDir.exists()) return mDataDir;
        else return null;
    }

    public File createDirectory(String from) {
        File folder = null;
        switch (from) {
            case StorageManager.TAG_IMAGE_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
                }
            }
            break;
            case StorageManager.TAG_IMAGE: {
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
            }
            break;
            case TAG_AUDIO_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + getFolderPath(from));
                }
            }
            break;
            case TAG_AUDIO:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + getFolderPath(from));
                break;
            case TAG_VIDEO_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + getFolderPath(from));
                }
            }
            break;
            case TAG_VIDEO:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + getFolderPath(from));
                break;
            case TAG_DOCUMENT_SENT:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + getFolderPath(from));
                }
                break;
            case TAG_DOCUMENT:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + getFolderPath(from));
                break;
            case TAG_THUMB:
            case TAG_PROFILE:
            case TAG_WALLPAPER:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
                }
                break;
            default:
                break;
        }
        if (!folder.exists()) {
            folder.mkdirs();
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (from.equals("sent") || from.equals(Constants.TAG_STATUS) || from.equals(TAG_PROFILE) ||
                    from.equals(TAG_THUMB) || from.equals(StorageManager.TAG_VIDEO_SENT) ||
                    from.equals(StorageManager.TAG_AUDIO_SENT) || from.equals(StorageManager.TAG_DOCUMENT_SENT)) {
                File noMediaFile = new File(folder.getAbsoluteFile(), ".nomedia");
                try {
                    if (!noMediaFile.exists()) {
                        noMediaFile.createNewFile();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return folder;
    }

    public File getDirectory(String from, String fileType) {
        File folder = null;
        switch (from) {
            case StorageManager.TAG_IMAGE_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
                }
            }
            break;
            case StorageManager.TAG_IMAGE: {
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
            }
            break;
            case TAG_AUDIO_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + getFolderPath(from));
                }
            }
            break;
            case TAG_AUDIO:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + getFolderPath(from));
                break;
            case TAG_VIDEO_SENT: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + getFolderPath(from));
                }
            }
            break;
            case TAG_VIDEO:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) + getFolderPath(from));
                break;
            case TAG_DOCUMENT_SENT:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + getFolderPath(from));
                }
                break;
            case TAG_DOCUMENT:
                folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + getFolderPath(from));
                break;
            case TAG_THUMB:
            case TAG_PROFILE:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getSentPathQ(from));
                } else {
                    folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + getFolderPath(from));
                }
                break;
            case TAG_STATUS: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    folder = new File(getExtFilesDir() + getStatusPath(fileType));
                } else {
                    if (fileType.equals(TAG_IMAGE)) {
                        folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), getStatusPath(fileType));
                    } else {
                        folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), getStatusPath(fileType));
                    }
                }
            }
            break;
            default:
                break;
        }
        Log.d(TAG, "getDirectory: " + folder);
        if (folder.exists()) {
            return folder;
        }
        return null;
    }

    public int getMediaDuration(Context context, Uri fileUri) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        mmr.setDataSource(context, fileUri);
        String durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        try {
            int duration = Integer.parseInt(durationStr);
            return duration;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getMediaDuration(File srcFile) {
        int duration = 0;
        if (srcFile != null && srcFile.length() > 0) {
            try {
                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                mmr.setDataSource(srcFile.getAbsolutePath());
                String durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                duration = Integer.parseInt(durationStr);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        Log.d(TAG, "getMediaDuration: " + duration);
        return duration;
    }

    public long getMediaDuration(Context mContext, String filePath) {
        long duration = 0;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(filePath);
        if (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) != null) {
            duration = Long.parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            try {
                retriever.release();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            IsoFile isoFile = null;
            try {
                isoFile = new IsoFile(filePath);
                double lengthInSeconds = (double)
                        isoFile.getMovieBox().getMovieHeaderBox().getDuration() /
                        isoFile.getMovieBox().getMovieHeaderBox().getTimescale();
                duration = (Math.round(lengthInSeconds * 1000));
            } catch (IOException e) {
                e.printStackTrace();
                duration = 0;
            }
        }
        Log.d(TAG, "getMediaDuration: " + duration);
        return duration;
    }

    public long getAudioDuration(Context context, Uri fileUri, String fileType) {
        long duration = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (fileType.equals(TAG_AUDIO)) {
                String[] projection = new String[]{
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.DISPLAY_NAME,
                        MediaStore.Audio.Media.DURATION,
                        MediaStore.Audio.Media.SIZE
                };
                Cursor cursor = context.getContentResolver().query(fileUri, projection, null, null, null);
                if (cursor != null && cursor.getCount() != 0) {
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
                    cursor.moveToFirst();
                    duration = cursor.getLong(columnIndex);
                }
                if (cursor != null) {
                    cursor.close();
                }
            } else {
                String[] projection = new String[]{
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DURATION,
                        MediaStore.Video.Media.SIZE
                };
                Cursor cursor = context.getContentResolver().query(fileUri, projection, null, null, null);
                if (cursor != null && cursor.getCount() != 0) {
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
                    cursor.moveToFirst();
                    duration = cursor.getLong(columnIndex);
                }
                if (cursor != null) {
                    cursor.close();
                }
            }
        } else {
            duration = getMediaDuration(context, fileUri);
        }
        Log.d(TAG, "getAudioDuration: " + duration);
        return duration;
    }

    public File getExtCachesDir() {
        File mDataDir = ContextCompat.getExternalCacheDirs(mContext)[0];
        if (!mDataDir.exists()) {
            mDataDir.mkdirs();
        }
        if (mDataDir.exists()) return mDataDir;
        else return null;
    }

    public File saveToCacheDir(Bitmap bitmap, String filename) {
        boolean stored = false;
        File mDataDir = null;
        if (Environment.getExternalStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED)) {
            mDataDir = ContextCompat.getExternalCacheDirs(mContext)[0];
            if (!mDataDir.exists()) {
                mDataDir.mkdirs();
            }
        } else {
            mDataDir = mContext.getCacheDir();
            if (!mDataDir.exists()) {
                mDataDir.mkdirs();
            }
        }

        File file = new File(mDataDir.getAbsoluteFile(), filename);
        if (file.exists())
            stored = true;

        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
            stored = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stored ? file : null;
    }

    public File saveToCacheDir(File srcFile, String filename) {
        boolean stored = false;
        File mDataDir = null;
        if (Environment.getExternalStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED)) {
            mDataDir = ContextCompat.getExternalCacheDirs(mContext)[0];
            if (!mDataDir.exists()) {
                mDataDir.mkdirs();
            }
        } else {
            mDataDir = mContext.getCacheDir();
            if (!mDataDir.exists()) {
                mDataDir.mkdirs();
            }
        }

        File file = new File(mDataDir.getAbsoluteFile(), filename);
        if (file.exists())
            stored = true;

        try {
            FileOutputStream out = new FileOutputStream(file);
            InputStream in = new FileInputStream(srcFile);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.flush();
            out.close();
            stored = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stored ? file : null;
    }

    public File saveUriToFile(Context mContext, Uri uri, File destDir, String fileName) {
        if (!destDir.exists()) destDir.mkdirs();
        // Create file path inside app's data dir
        File file = new File(destDir, fileName);
        try {
            InputStream inputStream = mContext.getContentResolver().openInputStream(uri);
            if (inputStream == null)
                return null;
            OutputStream outputStream = new FileOutputStream(file);
            byte[] buf = new byte[1024];
            int len;
            while ((len = inputStream.read(buf)) > 0)
                outputStream.write(buf, 0, len);
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        Log.d(TAG, "saveUriToFile: " + file.getAbsolutePath());
        return file;
    }


    public static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    public static byte[] bitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream blob = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0 /* Ignored for PNGs */, blob);
        byte[] byteArray = blob.toByteArray();
        return byteArray;
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public Bitmap getThumbnailFromVideo(File mSrcFile) {
        Bitmap thumb = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                thumb = ThumbnailUtils.createVideoThumbnail(mSrcFile,
                        Utils.getBitmapSize(mContext), null);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            thumb = ThumbnailUtils.createVideoThumbnail(mSrcFile.getAbsolutePath(), MediaStore.Video.Thumbnails.MINI_KIND);
        }
        return thumb;
    }

    public Bitmap getFrameAtTime(File mSrcFile, int time) {
        Bitmap thumb = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            retriever.setDataSource(mSrcFile.getAbsolutePath());
            thumb = retriever.getFrameAtTime(time * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        } else {
            thumb = ThumbnailUtils.createVideoThumbnail(mSrcFile.getAbsolutePath(), MediaStore.Video.Thumbnails.MINI_KIND);
        }
        Log.d(TAG, "getFrameAtTime: " + mSrcFile + ", " + time);
        Log.d(TAG, "getFrameAtTime: " + (thumb == null));
        return thumb;
    }

    public void writeToFile(String data, Context context) {
        try {
            File file = new File(getExtCachesDir(), "Log_" + System.currentTimeMillis() + ".txt");
            FileOutputStream outputStream = new FileOutputStream(file);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            outputStreamWriter.write(data);
            outputStreamWriter.close();
            Log.d(TAG, "writeToFile: " + file.getAbsolutePath() + ", " + (file.exists()));
            saveFileInStorageV10(file, file.getName(), TAG_DOCUMENT, TAG_DOCUMENT);
        } catch (IOException e) {
            Log.e(TAG, "File write failed: " + e.getMessage());
        }
    }
}


