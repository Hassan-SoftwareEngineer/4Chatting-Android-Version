package com.app.helper;

import static android.content.Context.MODE_PRIVATE;
import static com.app.utils.Constants.ADMIN;
import static com.app.utils.Constants.MEMBER;
import static com.app.utils.Constants.TAG_ADMIN_ID;
import static com.app.utils.Constants.TAG_CHANNEL_ID;
import static com.app.utils.Constants.TAG_CHANNEL_NAME;
import static com.app.utils.Constants.TAG_CONTACT_STATUS;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_GROUP_NAME;
import static com.app.utils.Constants.TAG_ID;
import static com.app.utils.Constants.TAG_MEMBER_ID;
import static com.app.utils.Constants.TAG_MY_CONTACTS;
import static com.app.utils.Constants.TAG_NOBODY;
import static com.app.utils.Constants.TAG_TRUE;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.Person;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.CallActivity;
import com.app.fourchattingapp.ChannelChatActivity;
import com.app.fourchattingapp.ChannelRequestActivity;
import com.app.fourchattingapp.ChatActivity;
import com.app.fourchattingapp.GroupChatActivity;
import com.app.fourchattingapp.MainActivity;
import com.app.model.ChannelMessage;
import com.app.model.ChannelResult;
import com.app.model.GroupData;
import com.app.model.MessagesData;
import com.google.gson.Gson;
import com.app.apprtc.util.AppRTCUtils;
import com.app.helper.event.NewChannelMessageEvent;
import com.app.helper.event.NewGroupMessageEvent;
import com.app.helper.event.NewMessageEvent;
import com.app.helper.workers.ChannelChatWorker;
import com.app.helper.workers.FileDownloadWorker;
import com.app.helper.workers.GroupChatReceivedWorker;
import com.app.helper.workers.MessageReceivedWorker;
import com.app.fourchattingapp.R;
import com.app.model.AdminChannel;
import com.app.model.AdminChannelMsg;
import com.app.model.ChannelInfoResponse;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.onesignal.OSNotification;
import com.onesignal.OSNotificationOpenedResult;
import com.onesignal.OSNotificationReceivedEvent;
import com.onesignal.OneSignal;
import com.onesignal.shortcutbadger.ShortcutBadger;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@SuppressWarnings("unused")
public class NotificationServiceExtension implements OneSignal.OSRemoteNotificationReceivedHandler, OneSignal.OSNotificationOpenedHandler {

    private final static String TAG = NotificationServiceExtension.class.getSimpleName();
    public static final int SUMMARY_ID = 0;
    public static final int UNREAD_ID = 1;
    public static String GROUP_KEY;
    DatabaseHandler dbhelper;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    ApiInterface apiInterface;
    StorageManager storageManager;
    private DateUtils dateUtils;
    private Utils utils;
    private Context mContext;
    private Ringtone ringtone;
    private int totalCount = 0;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private String notificationChannelName = "";
    private NotificationManager mNotifyManager;
    private HashMap<Integer, Notification> notificationHashMap = new HashMap<>();

    @Override
    public void remoteNotificationReceived(Context context, OSNotificationReceivedEvent notificationReceivedEvent) {
        OSNotification notification = notificationReceivedEvent.getNotification();
        mContext = context;
        GROUP_KEY = mContext.getString(R.string.app_name) + "_Group";
        // Example of modifying the notification's accent color
        /*OSMutableNotification mutableNotification = notification.mutableCopy();
        mutableNotification.setExtender(builder -> {
            Log.e(TAG, "remoteNotificationReceived: "+ notification.getRawPayload());
            return builder;
        });*/
        notificationChannelName = mContext.getString(R.string.app_name);
        mNotifyManager = createNotificationChannel(notificationChannelName);
        JSONObject data = notification.getAdditionalData();
        notificationHashMap = new HashMap<>();
        Log.i(TAG, "remoteNotificationReceived: " + data);
        notificationReceivedEvent.complete(null);
        dbhelper = DatabaseHandler.getInstance(mContext);
        storageManager = StorageManager.getInstance(mContext);
        pref = mContext.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        dateUtils = DateUtils.getInstance(mContext);
        utils = new Utils(mContext);
        if (pref.getBoolean("isLogged", false)) {
            GetSet.setUserId(pref.getString("userId", null));
            GetSet.setToken(pref.getString("token", null));
        }

        if (!TextUtils.isEmpty(data.toString())) {
            long sendTime = dateUtils.getTimeInMillisFromUTC(dateUtils.getCurrentUTCTime());
            try {
                JSONObject messageData = data.getJSONObject("message_data");
                String chatType = messageData.optString(Constants.TAG_CHAT_TYPE, "");
                if (chatType.equals(Constants.TAG_SINGLE)) {
                    String sender_id = messageData.optString("sender_id", "");
                    if (ApplicationClass.getCurrentActivity() == null) {
                        MessagesData mdata = getMessagesByType(messageData);
                        updateUnReadMessage(mdata);
                        messageReceived(mdata);
                        showSmallNotification(messageData);
                        if (ChatActivity.tempUserId != null && ChatActivity.tempUserId.equalsIgnoreCase(sender_id)) {
                            EventBus.getDefault().post(new NewMessageEvent(mdata));
                        }
                    } else {
                        if (ApplicationClass.getCurrentActivity() instanceof ChatActivity) {
                            if (ChatActivity.tempUserId != null && !ChatActivity.tempUserId.equalsIgnoreCase(sender_id)) {
                                showSmallNotification(messageData);
                            }
                        } else {
                            showSmallNotification(messageData);
                        }
                    }
                } else if (chatType.equals(Constants.TAG_GROUP)) {
                    String groupId = messageData.optString(Constants.TAG_GROUP_ID, "");
                    String memberId = messageData.optString(Constants.TAG_MEMBER_ID, "");
                    String msgType = messageData.optString(Constants.TAG_MESSAGE_TYPE, "");
                    if (ApplicationClass.getCurrentActivity() == null) {
                        GroupMessage groupMessage = getGroupMessagesByType(messageData);
                        groupChatReceived(groupMessage);
                        if (!memberId.equals(GetSet.getUserId()) && dbhelper.isGroupExist(groupId) && !msgType.equals("admin") && !msgType.equals("subject") && !msgType.equals("group_image") &&
                                /*!msgType.equals("add_member") &&*/ !msgType.equals("remove_member") && !msgType.equals("left") && !msgType.equals(Constants.TAG_ISDELETE)) {
                            showSmallNotification(messageData);
                        }
                        if (GroupChatActivity.tempGroupId != null && GroupChatActivity.tempGroupId.equalsIgnoreCase(groupId)) {
                            EventBus.getDefault().post(new NewGroupMessageEvent(groupMessage));
                        }
                    } else {
                        if (!memberId.equals(GetSet.getUserId()) && dbhelper.isGroupExist(groupId) && !msgType.equals("admin") && !msgType.equals("subject") && !msgType.equals("group_image") &&
                                /*!msgType.equals("add_member") &&*/ !msgType.equals("remove_member") && !msgType.equals("left") && !msgType.equals(Constants.TAG_ISDELETE)) {
                            if (ApplicationClass.getCurrentActivity() != null && !(ApplicationClass.getCurrentActivity() instanceof GroupChatActivity)) {
                                showSmallNotification(messageData);
                            } else {
                                if (GroupChatActivity.tempGroupId != null && !GroupChatActivity.tempGroupId.equalsIgnoreCase(groupId)) {
                                    showSmallNotification(messageData);
                                }
                            }
                        }
                    }

                } else if (chatType.equals(Constants.TAG_CHANNEL)) {
                    String channelId = messageData.optString(Constants.TAG_CHANNEL_ID, "");
                    String msgType = messageData.optString(Constants.TAG_MESSAGE_TYPE, "");
                    if (ApplicationClass.getCurrentActivity() == null) {
                        String messageFrom = "";
                        JSONObject jobj = data.getJSONObject("message_data");
                        if (jobj.has(Constants.TAG_MESSAGE_ID)) {
                            messageFrom = "channel";
                            ChannelMessage channelMessage = getChannelMessagesByType(new JSONObject().put("message_data", messageData));
                            channelChatReceived(channelMessage.channelId, channelMessage.messageId);
                            if (dbhelper.isChannelExist(channelId) && !msgType.equals("subject") && !msgType.equals("channel_image") && !msgType.equals("channel_des")) {
                                showSmallNotification(messageData);
                            }
                            if (ChannelChatActivity.tempChannelId != null && ChannelChatActivity.tempChannelId.equalsIgnoreCase(channelId)) {
                                EventBus.getDefault().post(new NewChannelMessageEvent(channelMessage));
                            }
                        } else {
                            AdminChannelMsg.Result adminMessage = getAdminChannelMessagesByType(new JSONObject().put("message_data", messageData));
                            channelChatReceived(adminMessage.channelId, adminMessage.messageId);
                            showSmallNotification(messageData);
                        }
                    }
                    if (dbhelper.isChannelExist(channelId) && !msgType.equals("subject") && !msgType.equals("channel_image") && !msgType.equals("channel_des")) {
                        ChannelResult.Result results = dbhelper.getChannelInfo(channelId);
                        messageData.put(Constants.TAG_CHANNEL_NAME, results.channelName);
                        if (ApplicationClass.getCurrentActivity() != null) {
                            if (ChannelChatActivity.tempChannelId != null && !ChannelChatActivity.tempChannelId.equalsIgnoreCase(channelId))
                                showSmallNotification(messageData);
                        }
                    }
                } else if (chatType.equals(Constants.TAG_CALL)) {
                    String userId = messageData.optString("caller_id", "");
                    if (dbhelper.isUserExist(userId)) {
                        onCallReceive(messageData, sendTime);
                    } else {
                        getUserInfo(userId, messageData, sendTime);
                    }
                } else if (chatType.equalsIgnoreCase(Constants.TAG_GROUP_INVITATION)) {
                    String adminId = messageData.optString(Constants.TAG_ADMIN_ID, "");
                    if (!adminId.equalsIgnoreCase(GetSet.getUserId())) {
                        showSmallNotification(messageData);
                    }
                } else if (chatType.equalsIgnoreCase(Constants.TAG_CHANNEL_INVITATION)) {
                    showSmallNotification(messageData);
                } else if (chatType.equalsIgnoreCase(Constants.TAG_ISDELETE)) {
                    showSmallNotification(messageData);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public MessagesData getMessagesByType(JSONObject data) {
        MessagesData mdata = Utils.getMessageFromJson(data);
        if (mdata.message_type != null && mdata.message_type.equals(Constants.TAG_ISDELETE)) {
            dbhelper.updateMessageData(mdata.message_id, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
            if (ApplicationClass.isStringNotNull(mdata.attachment)) {
                storageManager.checkDeleteFile(mdata.attachment, mdata.message_type, "receive");
                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_ATTACHMENT, "");
                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_THUMBNAIL, "");
            }

        } else {
            if (!dbhelper.isMessageIdExist(mdata.message_id)) {
                MessagesData tempMessageData = Utils.getMessageData(GetSet.getUserId() + mdata.user_id, mdata.message_id, mdata.user_id, "", mdata.message_type, mdata.message, mdata.attachment, mdata.lat, mdata.lon, mdata.contact_name, mdata.contact_phone_no, mdata.contact_country_code, mdata.chat_time, GetSet.getUserId(), mdata.user_id, "sent", mdata.thumbnail, mdata.statusData, "");
                dbhelper.addMessageData(tempMessageData, false);
            }
        }
        return mdata;
    }

    public void updateUnReadMessage(MessagesData messagesData) {
        int unseenCount = dbhelper.getUnseenMessagesCount(messagesData.user_id);
        if (ApplicationClass.isStringNotNull(messagesData.message_type) && messagesData.message_type.equals(Constants.TAG_ISDELETE)) {
            if (dbhelper.isRecentMessageIdExist(messagesData.message_id)) {
                dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.user_id, messagesData.user_id, messagesData.message_id, messagesData.chat_time, "" + unseenCount);
            }
        } else {
            MessagesData lastMessage = dbhelper.getRecentMessage(messagesData.user_id);
            if (lastMessage != null && !TextUtils.isEmpty(lastMessage.message_id)) {
                dbhelper.addRecentMessages(GetSet.getUserId() + lastMessage.user_id, lastMessage.user_id, lastMessage.message_id, lastMessage.chat_time, "" + unseenCount);
            } else {
                dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.user_id, messagesData.user_id, messagesData.message_id, messagesData.chat_time, "" + unseenCount);
            }
        }
    }

    void messageReceived(final MessagesData mdata) {
        OneTimeWorkRequest chatReceivedRequest = new OneTimeWorkRequest.Builder(MessageReceivedWorker.class).setInputData(createInputData(mdata)).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();
        WorkManager.getInstance(mContext).enqueue(chatReceivedRequest);
    }

    private Data createInputData(final MessagesData messagesData) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_SENDER_ID, messagesData.sender_id);
        builder.putString(Constants.TAG_RECEIVER_ID, messagesData.receiver_id);
        builder.putString(Constants.TAG_MESSAGE_ID, messagesData.message_id);
        return builder.build();
    }

    private void getUserInfo(String memberId, JSONObject data, long sendTime) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                try {
                    Log.v(TAG, "getUserInfo: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));

                        onCallReceive(data, sendTime);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.e(TAG, "getUserInfo: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void groupChatReceived(GroupMessage message) {
        OneTimeWorkRequest chatReceivedRequest = new OneTimeWorkRequest.Builder(GroupChatReceivedWorker.class).setInputData(createGroupInputData(message)).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();
        WorkManager.getInstance(mContext).enqueue(chatReceivedRequest);
    }

    private Data createGroupInputData(GroupMessage message) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_MESSAGE_ID, message.messageId);
        return builder.build();
    }

    private void channelChatReceived(String channelId, String messageId) {
        OneTimeWorkRequest chatReceivedRequest = new OneTimeWorkRequest.Builder(ChannelChatWorker.class).setInputData(createChannelChatData(channelId, messageId)).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();
        WorkManager.getInstance(mContext).enqueue(chatReceivedRequest);
    }

    private Data createChannelChatData(String channelId, String messageId) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_CHANNEL_ID, channelId);
        builder.putString(Constants.TAG_MESSAGE_ID, messageId);
        return builder.build();
    }

    private void onCallReceive(JSONObject data, long sendTime) {
        String callerId = data.optString("caller_id", "");
        String type = data.optString(Constants.TAG_TYPE, "");
        String callId = data.optString("call_id", "");
        String unixStamp = data.optString("created_at", "");
        String call_type = data.optString("call_type", "");
        String roomId = data.optString("room_id", "");
        String platform = data.optString(Constants.TAG_PLATFORM, "");
        long diffInMs = System.currentTimeMillis() - sendTime;
        long diffSeconds = diffInMs / 1000;
        /*Log.v("FCM", "sendTime=" + sendTime);
        Log.v("FCM", "diffInSec=" + diffSeconds);
        Log.v("FCM", "now=" + System.currentTimeMillis());*/


        Log.e("checkReceiveCal","-"+call_type);
        if (call_type.equalsIgnoreCase("created")) {
            TelephonyManager telephony = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
            int isPhoneCallOn = -1;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                 if ( ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED ) {
                    Log.e("checkReceiveCal","-checkinside");
                    isPhoneCallOn = telephony.getCallStateForSubscription();
                } else {
                    /*if (ApplicationClass.getCurrentActivity() != null && ApplicationClass.getCurrentActivity() instanceof CallActivity) {
                        CallActivity activity = (CallActivity) ApplicationClass.getCurrentActivity();
                        activity.finish();
                        CallActivity.isInCall = false;
                    } else*/
                    if (ApplicationClass.getCurrentActivity() == null || !(ApplicationClass.getCurrentActivity() instanceof CallActivity)) {
                        CallActivity.isInCall = false;
                        new Handler(Looper.getMainLooper()).post(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(mContext, mContext.getString(R.string.enable_read_phone_state), Toast.LENGTH_SHORT).show();
                                        mContext.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + mContext.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                                    }
                                }
                        );
                    }
                }
            } else {
                isPhoneCallOn = telephony.getCallState();
                dbhelper.addRecentCall(callId, callerId, type, "incoming", unixStamp, "1");
            }
            ContactsData.Result results = dbhelper.getContactDetail(callerId);
            Log.e("checkReceiveCal","- 2nd way "+isPhoneCallOn);
            if (diffSeconds < 30 && !results.blockedbyme.equals(Constants.TAG_BLOCK) && !CallActivity.isInCall && isPhoneCallOn == 0) {
                //CallActivity.isInCall = true;
                AppRTCUtils appRTCUtils = new AppRTCUtils(mContext);
                Intent intent = appRTCUtils.connectToRoom(callerId, "receive", type);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("call_id", callId);
                intent.putExtra("room_id", roomId);
                intent.putExtra(Constants.TAG_PLATFORM, platform);
                mContext.startActivity(intent);
            }
        } else if (call_type.equalsIgnoreCase("ended")) {
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (ApplicationClass.getCurrentActivity() != null) {
                        if (ApplicationClass.getCurrentActivity() instanceof CallActivity) {
                            CallActivity activity = (CallActivity) ApplicationClass.getCurrentActivity();
                            if (activity.userid.equals(callerId)) {
                                CallActivity.isInCall = false;
                                if (activity.isCallAttend) {
                                    CallActivity.toastText = mContext.getString(R.string.call_ended);
                                } else {
                                    CallActivity.toastText = mContext.getString(R.string.call_declined);
                                }
                                activity.finishAndRemoveTask();
                            }
                        }
                    } else {
                        if (CallActivity.callActivity != null && CallActivity.userid.equals(callerId)) {
                            CallActivity.isInCall = false;
                            if (CallActivity.isCallAttend) {
                                CallActivity.toastText = mContext.getString(R.string.call_ended);
                            } else {
                                CallActivity.toastText = mContext.getString(R.string.call_declined);
                            }
                            CallActivity.callActivity.finishAndRemoveTask();
                        }
                    }
                }
            }, 500);
        } else if (call_type.equals(Constants.TAG_MISSED)) {
            dbhelper.addRecentCall(callId, callerId, type, Constants.TAG_MISSED, unixStamp, "1");
            if (CallActivity.callActivity != null && CallActivity.userid.equals(callerId)) {
                CallActivity.isInCall = false;
                if (CallActivity.isCallAttend) {
                    CallActivity.toastText = mContext.getString(R.string.call_ended);
                } else {
                    CallActivity.toastText = mContext.getString(R.string.call_declined);
                }
//                CallActivity.callActivity.finishAndRemoveTask();
            }
            if (dbhelper.isUserExist(callerId)) {
                ContactsData.Result results = dbhelper.getContactDetail(callerId);
                if (results != null && !results.mute_notification.equals("true")) {//User Not Blocked Notifications
                    if (ChatActivity.tempUserId != null && !ChatActivity.tempUserId.equalsIgnoreCase(callerId)) {
                        long when = System.currentTimeMillis();
                        String userName = ApplicationClass.getContactName(mContext, results.phone_no, results.country_code);
                        String userId = data.optString(Constants.TAG_CALLER_ID, "");
                        String message;
                        if (type.equals(Constants.TAG_VIDEO)) {
                            message = getLocaleString(R.string.missed_video_call);
                        } else {
                            message = getLocaleString(R.string.missed_voice_call);
                        }
                        Intent intent = new Intent(mContext, MainActivity.class);
                        intent.putExtra(Constants.TAG_CALL_ID, callId);
                        intent.putExtra(Constants.IS_FROM, Constants.TAG_CALL);
                        if (ApplicationClass.isScreenLockOpened) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        }
                        Person person = getPerson(results);
                        NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(person);
                        style.addMessage(getMessage(message, dateUtils.getTimeInMillisFromUTC(unixStamp), person));
                        style.setGroupConversation(false);
                        style.setConversationTitle(userName);
                        NotificationCompat.Builder notification = createCallNotificationBuilder();
                        notification.setStyle(style);
                        notification.setContentIntent(setIntent(intent));
                        notification.setWhen(when);
                        long notifyId = Long.parseLong(results.phone_no);
                        showNotification(notification.build(), (int) notifyId);
                    }
                }
            }
        }
    }

    public void showSmallNotification(JSONObject jsonObject) {
        try {
            Intent intent = null;
            String channelName = mContext.getString(R.string.app_name);

            int count = 0;
//            if (addUnreadSingleNotification()>0){
//                count = addUnreadSingleNotification();
//            }else if (addUnreadGroupNotification()>0){
//                count = addUnreadGroupNotification() ;
//            }else  if (addUnreadChannelNotification()>0){
//                count = addUnreadChannelNotification() ;
//            }else{
//                count = addUnreadSingleNotification();
//            }

            count = addUnreadSingleNotification();
         //   count = addUnreadSingleNotification() + addUnreadGroupNotification() + addUnreadChannelNotification();
            totalCount = count;

            if (jsonObject.get(Constants.TAG_CHAT_TYPE).equals(Constants.TAG_GROUP)) {
                String group_id = jsonObject.optString(Constants.TAG_GROUP_ID, "");
                String phone_no = jsonObject.optString(Constants.TAG_MEMBER_NO, "");
                String name = ApplicationClass.getContactName(mContext, phone_no, "");
                intent = new Intent(mContext, GroupChatActivity.class);
                intent.putExtra("group_id", group_id);
                intent.putExtra("notification", "true");
            } else if (jsonObject.get(Constants.TAG_CHAT_TYPE).equals(Constants.TAG_CHANNEL)) {
                String channel_id = jsonObject.optString(Constants.TAG_CHANNEL_ID, "");
                intent = new Intent(mContext, ChannelChatActivity.class);
                intent.putExtra("channel_id", channel_id);
                intent.putExtra("notification", "true");
            } else if (jsonObject.get(Constants.TAG_CHAT_TYPE).equals(Constants.TAG_GROUP_INVITATION)) {
                String group_id = jsonObject.optString(Constants.ID, "");
                intent = new Intent(mContext, MainActivity.class);
                intent.putExtra("group_id", group_id);
                intent.putExtra(Constants.IS_FROM, "group");
            } else if (jsonObject.get(Constants.TAG_CHAT_TYPE).equals(Constants.TAG_CHANNEL_INVITATION)) {
                String channel_id = jsonObject.optString(Constants.ID, "");
                intent = new Intent(mContext, MainActivity.class);
                intent.putExtra("channel_id", channel_id);
                intent.putExtra(Constants.IS_FROM, "channel");
            }

            if (count > 0) {
                int uniqueInt = (int) (System.currentTimeMillis() & 0xfffffff);
                if (intent == null) {
                    intent = new Intent(mContext, MainActivity.class);
                }
                intent.putExtra("notification", "true");
                PendingIntent resultPendingIntent;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    resultPendingIntent = PendingIntent.getActivity(mContext, uniqueInt, intent, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_ONE_SHOT);
                } else {
                    resultPendingIntent = PendingIntent.getActivity(mContext, uniqueInt, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
                }

                Notification summaryNotification = getSummaryNotification(count, resultPendingIntent);
                showNotification(summaryNotification, count);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private NotificationManager createNotificationChannel(String channelName) {
        NotificationManager mNotifyManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(mContext.getString(R.string.notification_channel_id), channelName, importance);
            AudioAttributes audioAttributes = new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).setUsage(AudioAttributes.USAGE_NOTIFICATION).build();
            notificationChannel.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, audioAttributes);
            notificationChannel.enableVibration(true);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationChannel.enableLights(true);
            notificationChannel.setShowBadge(true);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        return mNotifyManager;
    }

    private Notification getSummaryNotification(int count, PendingIntent resultPendingIntent) {
        NotificationCompat.Builder mBuilder = null;
        mBuilder = new NotificationCompat.Builder(mContext, mContext.getString(R.string.notification_channel_id)).setContentTitle(mContext.getString(R.string.app_name)).setContentText("" + count + " " + mContext.getString(R.string.new_messages)).setSmallIcon(R.drawable.notification).setContentIntent(resultPendingIntent).setOnlyAlertOnce(false).setAutoCancel(false).setBadgeIconType((NotificationCompat.BADGE_ICON_SMALL)).setStyle(new NotificationCompat.InboxStyle().setSummaryText("" + count + " " + mContext.getString(R.string.unread_notification))).setGroup(GROUP_KEY).setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mBuilder.setGroupSummary(true);
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            mBuilder.setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH);
        }

        return mBuilder.build();
    }

    public NotificationCompat.Builder createUnReadNotificationBuilder(boolean autoCancel) {
        NotificationCompat.Builder mBuilder = null;
        mBuilder = new NotificationCompat.Builder(mContext, mContext.getString(R.string.notification_channel_id)).setTicker(mContext.getString(R.string.app_name)).setSmallIcon(R.drawable.notification).setGroup(GROUP_KEY).setColor(ContextCompat.getColor(mContext, R.color.colorAccent)).setAutoCancel(false).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL).setOnlyAlertOnce(true).setSilent(true).setGroupSummary(false);
        return mBuilder;
    }

    public NotificationCompat.Builder createCallNotificationBuilder() {
        NotificationCompat.Builder mBuilder = null;
        mBuilder = new NotificationCompat.Builder(mContext, mContext.getString(R.string.notification_channel_id)).setTicker(mContext.getString(R.string.app_name)).setSmallIcon(R.drawable.notification).setColor(ContextCompat.getColor(mContext, R.color.colorAccent)).setAutoCancel(false).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL).setOnlyAlertOnce(true).setGroupSummary(false);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            mBuilder.setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH);
        }
        return mBuilder;
    }

    private void setUnReadNotificationParams(NotificationCompat.Builder mBuilder, int size, String chatTime, NotificationCompat.MessagingStyle style) {
//        mBuilder.setNumber(size);
        mBuilder.setWhen(dateUtils.getTimeInMillisFromUTC(chatTime));
        mBuilder.setStyle(style);
    }

    private int addUnreadSingleNotification() {
        List<String> userListId = dbhelper.getUnseenMessageUser();
        int count = 0;
        for (String s : userListId) {
            NotificationCompat.Builder mBuilder;
            mBuilder = createUnReadNotificationBuilder(false);
            Intent intent = new Intent();
            intent = new Intent(mContext, ChatActivity.class);
            if (ApplicationClass.isScreenLockOpened) {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            }
            intent.putExtra("user_id", s);
            intent.putExtra("notification", "true");
            mBuilder.setContentIntent(setIntent(intent));

            String userName = "", imgUrl = "";
            long notifyId;
            if (s != null && !s.equals(GetSet.getUserId())) {
                ContactsData.Result result = dbhelper.getContactDetail(s);
                if (result.phone_no != null && !result.mute_notification.equals("true")) {
                    notifyId = Long.parseLong(result.phone_no);

                    if (!result.user_name.equals("")) {
                        Person userPerson = getPerson(s);

                        NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(userPerson);
                        List<MessagesData> unSeenMessage = dbhelper.getUnseenMessage(s, mContext);
                        if (!unSeenMessage.isEmpty()) {
                            for (MessagesData messagesData : unSeenMessage) {
                                if (messagesData.message_type.equals(Constants.TAG_LINK)) {
                                    try {
                                        JSONObject messageObject = new JSONObject(messagesData.message);
                                        StringBuilder builder = new StringBuilder();
                                        builder.append(messageObject.optString(Constants.TAG_NAME));
                                        builder.append("\n");
                                        builder.append(messageObject.optString(Constants.TAG_DESCRIPTION));
                                        builder.append("\n");
                                        builder.append(messageObject.optString(Constants.TAG_LINK));
                                        style.addMessage(getMessage(builder.toString(), dateUtils.getTimeInMillisFromUTC(messagesData.chat_time), userPerson));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    style.addMessage(getMessage(messagesData.message, dateUtils.getTimeInMillisFromUTC(messagesData.chat_time), userPerson));
                                }
                                count++;
                            }
                            setUnReadNotificationParams(mBuilder, unSeenMessage.size(), unSeenMessage.get(unSeenMessage.size() - 1).chat_time, style);
                            addUnReadNotification(mBuilder.build(), (int) notifyId);
                        }
                    }
                }

            }
        }
        Log.d(TAG, "addUnreadSingleNotification: " + count);
        return count;
    }

    private int addUnreadGroupNotification() {
        int count = 0;
        NotificationCompat.Builder notification = createUnReadNotificationBuilder(true);
        Intent intent = new Intent(mContext, GroupChatActivity.class);
        if (ApplicationClass.isScreenLockOpened) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        }
        intent.putExtra("notification", "true");
        ArrayList<HashMap<String, String>> recentMsg = dbhelper.getGroupUnreadNotification(mContext);
        if (recentMsg.isEmpty()) {
            return count;
        } else {
            for (HashMap<String, String> map : recentMsg) {
                if (map.get(TAG_GROUP_ID) != null /*&& ApplicationClass.isStringNotNull(map.get(Constants.TAG_MUTE_NOTIFICATION))*/ && !map.get(Constants.TAG_MUTE_NOTIFICATION).equals("true")) {
                    if (map.get(Constants.TAG_UNREAD_COUNT) != null && Integer.parseInt(map.get(Constants.TAG_UNREAD_COUNT)) > 0) {
                        Log.d(TAG, "addUnreadGroupNotification: " + map.get(Constants.TAG_GROUP_ID) + ", " + map.get(Constants.TAG_UNREAD_COUNT));
                        List<GroupMessage> unreadMsg = dbhelper.getGroupUnreadMessages(map.get(TAG_GROUP_ID), mContext);
                        if (!unreadMsg.isEmpty()) {
                            String groupId = map.get(TAG_GROUP_ID);
                            intent.putExtra("group_id", groupId);
                            BigInteger notify = new BigInteger(groupId.replaceAll("[^\\d.]", ""));
                            int notifyId = notify.intValue();
                            IconCompat icon;
                            Bitmap bitmap = null;
                            GroupData groupData = dbhelper.getGroupData(mContext, map.get(TAG_GROUP_ID));
                            if (groupData.groupImage != null && !TextUtils.isEmpty(groupData.groupImage)) {
                                if (groupData.groupImage.contains(Constants.CHAT_IMG_PATH)) {
                                    bitmap = getUserBitMap(groupData.groupImage);
                                } else {
                                    bitmap = getUserBitMap(Constants.CHAT_IMG_PATH + groupData.groupImage);
                                }
                            }
                            if (bitmap == null) {
                                bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.temp);
                            }
                            icon = IconCompat.createWithBitmap(getCircleBitmap(bitmap));

                            Person groupPerson = new Person.Builder().setName(map.get(TAG_GROUP_NAME)).setIcon(icon).build();
                            NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(groupPerson);
                            style.setGroupConversation(true);
                            style.setConversationTitle(map.get(TAG_GROUP_NAME) + " " + getUnreadMessageString(unreadMsg.size()));
                            notification.setStyle(style);
                            for (GroupMessage groupMessage : unreadMsg) {
                                count++;
                                ContactsData.Result userData = getUserData(groupMessage.memberId);
                                Person userPerson = getPerson(userData.user_id);
                                if (!TextUtils.isEmpty(groupMessage.messageType) && groupMessage.messageType.equals(Constants.TAG_LINK)) {
                                    try {
                                        JSONObject messageObject = new JSONObject(groupMessage.message);
                                        StringBuilder builder = new StringBuilder();
                                        builder.append(messageObject.optString(Constants.TAG_NAME));
                                        builder.append("\n");
                                        builder.append(messageObject.optString(Constants.TAG_DESCRIPTION));
                                        builder.append("\n");
                                        builder.append(messageObject.optString(Constants.TAG_LINK));
                                        style.addMessage(getMessage(builder.toString(), dateUtils.getTimeInMillisFromUTC(groupMessage.chatTime), userPerson));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    style.addMessage(getMessage(groupMessage.message, dateUtils.getTimeInMillisFromUTC(groupMessage.chatTime), userPerson));
                                }
                            }
                            notification.setContentIntent(setIntent(intent));
                            setUnReadNotificationParams(notification, unreadMsg.size(), unreadMsg.get(unreadMsg.size() - 1).chatTime, style);
                            addUnReadNotification(notification.build(), (int) notifyId);
                        }

                    }
                }
            }
        }
        Log.d(TAG, "addUnreadGroupNotification: " + count);
        return count;
    }

    private int addUnreadChannelNotification() {
        int count = 0;
        ArrayList<HashMap<String, String>> recentMsg = dbhelper.getChannelRecentMessages(mContext);
        if (recentMsg.isEmpty()) {
            return count;
        } else {
            for (HashMap<String, String> map : recentMsg) {
                if (map.get(Constants.TAG_UNREAD_COUNT) != null && Integer.parseInt(map.get(Constants.TAG_UNREAD_COUNT)) > 0 && !map.get(Constants.TAG_MUTE_NOTIFICATION).equals("true")) {
                    if (map.get(TAG_CHANNEL_ID) != null) {
                        NotificationCompat.Builder mBuilder = createUnReadNotificationBuilder(true);
                        String channelId = map.get(TAG_CHANNEL_ID);
                        Intent intent;
                        if (!TextUtils.isEmpty(map.get(Constants.TAG_MESSAGE_TYPE)) && map.get(Constants.TAG_MESSAGE_TYPE).equals("create_channel")) {
                            intent = new Intent(mContext, ChannelRequestActivity.class);
                        } else {
                            intent = new Intent(mContext, ChannelChatActivity.class);
                            intent.putExtra("notification", "true");
                        }
                        if (ApplicationClass.isScreenLockOpened) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        }
                        intent.putExtra(TAG_CHANNEL_ID, channelId);
                        BigInteger notify = new BigInteger(channelId.replaceAll("[^\\d.]", ""));
                        int notifyId = notify.intValue();
                        ChannelResult.Result channelInfo = dbhelper.getChannelInfo(channelId);
                        String name = "";
                        if (map.get(Constants.TAG_CHANNEL_CATEGORY).equalsIgnoreCase(Constants.TAG_ADMIN_CHANNEL)) {
                            name = mContext.getString(R.string.admin);
                        } else {
                            name = channelInfo.channelName;
                        }

                        if (name == null || TextUtils.isEmpty(name)) {
                            name = mContext.getString(R.string.admin);
                        }


//                        if (dbhelper.getChannelUnreadCount(channelId)) {
                        List<ChannelMessage> unSeenMessage = dbhelper.getChannelUnreadMessages(channelId);
                        IconCompat icon;
                        Bitmap bitmap = null;
                        if (channelInfo.channelImage != null && !TextUtils.isEmpty(channelInfo.channelImage)) {
                            if (channelInfo.channelImage.contains(Constants.CHAT_IMG_PATH)) {
                                bitmap = getUserBitMap(channelInfo.channelImage);
                            } else {
                                bitmap = getUserBitMap(Constants.CHAT_IMG_PATH + channelInfo.channelImage);
                            }
                        }
                        if (bitmap == null) {
                            bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.temp);
                        }
                        icon = IconCompat.createWithBitmap(getCircleBitmap(bitmap));
                        Person userPerson = new Person.Builder().setName(name).setIcon(icon).build();
                        if (unSeenMessage.size() > 0) {
                            NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(userPerson);
                            style.setGroupConversation(true);
                            style.setConversationTitle(channelInfo.channelName);
                            for (ChannelMessage channelMessage : unSeenMessage) {
                                count++;
                                if (!TextUtils.isEmpty(userPerson.getName())) {
                                    if (!TextUtils.isEmpty(channelMessage.message)) {
                                        if (!TextUtils.isEmpty(channelMessage.messageType) && channelMessage.messageType.equals(Constants.TAG_LINK)) {
                                            try {
                                                JSONObject messageObject = new JSONObject(channelMessage.message);
                                                StringBuilder builder = new StringBuilder();
                                                builder.append(messageObject.optString(Constants.TAG_NAME));
                                                builder.append("\n");
                                                builder.append(messageObject.optString(Constants.TAG_DESCRIPTION));
                                                builder.append("\n");
                                                builder.append(messageObject.optString(Constants.TAG_LINK));
                                                style.addMessage(getMessage(builder.toString(), dateUtils.getTimeInMillisFromUTC(channelMessage.chatTime), userPerson));
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                        } else {
                                            style.addMessage(getMessage(channelMessage.message, dateUtils.getTimeInMillisFromUTC(channelMessage.chatTime), userPerson));
                                        }
                                    } else {
                                        if (!TextUtils.isEmpty(channelMessage.messageType) && channelMessage.messageType.equals("create_channel")) {
                                            if (("" + channelInfo.channelCategory).equals(Constants.TAG_ADMIN_CHANNEL)) {
                                                style.addMessage(getMessage(mContext.getString(R.string.admin_channel), dateUtils.getTimeInMillisFromUTC(channelMessage.chatTime), userPerson));
                                            } else {
                                                style.addMessage(getMessage(mContext.getString(R.string.channel_invitation), dateUtils.getTimeInMillisFromUTC(channelMessage.chatTime), userPerson));
                                            }
                                        } else {
                                            style.addMessage(getMessage("", dateUtils.getTimeInMillisFromUTC(channelMessage.chatTime), userPerson));
                                        }
                                    }
                                }
                            }
                            mBuilder.setContentIntent(setIntent(intent));
                            setUnReadNotificationParams(mBuilder, unSeenMessage.size(), unSeenMessage.get(unSeenMessage.size() - 1).chatTime, style);
                            addUnReadNotification(mBuilder.build(), (int) notifyId);
                        }
//                        }
                    }
                }
            }
        }
        Log.d(TAG, "addUnreadChannelNotification: " + count);
        return count;
    }

    private String getUnreadMessageString(int count) {
        return mContext.getString(R.string.unread_message_count, count);
    }

    private NotificationCompat.MessagingStyle getMessageStyle(String userId, String message, String chatTime) {
        Person userPerson = getPerson(userId);
        NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(userPerson);
        style.addMessage(getMessage(message, dateUtils.getTimeInMillisFromUTC(chatTime), userPerson));
        return style;
    }

    private Bitmap getCircleBitmap(Bitmap bitmap) {
        int dimension = Math.min(bitmap.getWidth(), bitmap.getHeight());
        bitmap = ThumbnailUtils.extractThumbnail(bitmap, dimension, dimension);
        final Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        /*final Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);*/
        final Canvas canvas = new Canvas(output);
        final int color = Color.RED;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawOval(rectF, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        bitmap.recycle();

        return output;
    }

    private PendingIntent setIntent(Intent intent) {
        int uniqueInt = (int) (System.currentTimeMillis() & 0xfffffff);
        PendingIntent resultPendingIntent;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            resultPendingIntent = PendingIntent.getActivity(mContext, uniqueInt, intent, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_ONE_SHOT);
        } else {
            resultPendingIntent = PendingIntent.getActivity(mContext, uniqueInt, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
        }
        return resultPendingIntent;
    }

    private ContactsData.Result getUserData(String userId) {
        ContactsData.Result result = dbhelper.getContactDetail(userId);

        if (result.privacy_profile_image != null && result.privacy_profile_image.equalsIgnoreCase(TAG_MY_CONTACTS)) {
            if (result.contactstatus != null && result.contactstatus.equalsIgnoreCase(TAG_TRUE) && !result.user_image.equals("")) {
                result.user_image = Constants.USER_IMG_PATH + result.user_image;
            } else {
                result.user_image = "";
            }

        } else if (result.privacy_profile_image != null && result.privacy_profile_image.equalsIgnoreCase(TAG_NOBODY)) {
            result.user_image = "";
        } else {
            if (result.user_image != null && !TextUtils.isEmpty(result.user_image))
                result.user_image = Constants.USER_IMG_PATH + result.user_image;
            else result.user_image = "";
        }
        return result;
    }

    public Person getPerson(String userId) {
        ContactsData.Result userData = getUserData(userId);
        IconCompat icon;
        Bitmap bitmap = null;
        if (userData.user_image != null && !TextUtils.isEmpty(userData.user_image)) {
            if (userData.user_image.contains(Constants.USER_IMG_PATH)) {
                bitmap = getUserBitMap(userData.user_image);
            } else {
                bitmap = getUserBitMap(Constants.USER_IMG_PATH + userData.user_image);
            }
        }
        if (bitmap == null) {
            bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.temp);
        }
        icon = IconCompat.createWithBitmap(getCircleBitmap(bitmap));
        return new Person.Builder().setName(userData.user_name).setIcon(icon).build();
    }

    public Person getPerson(ContactsData.Result userData) {
        IconCompat icon;
        Bitmap bitmap = null;
        if (userData.user_image != null && !TextUtils.isEmpty(userData.user_image)) {
            if (userData.user_image.contains(Constants.USER_IMG_PATH)) {
                bitmap = getUserBitMap(userData.user_image);
            } else {
                bitmap = getUserBitMap(Constants.USER_IMG_PATH + userData.user_image);
            }
        }
        if (bitmap == null) {
            bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.temp);
        }
        icon = IconCompat.createWithBitmap(getCircleBitmap(bitmap));
        return new Person.Builder().setName(userData.user_name).setIcon(icon).build();
    }

    public NotificationCompat.MessagingStyle.Message getMessage(String message, Long time, Person sender/*,String imgUrl*/) {
        return new NotificationCompat.MessagingStyle.Message(message, time, sender);
    }

    private NotificationCompat.InboxStyle inboxStyle(List<GroupMessage> messages) {
        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        for (GroupMessage message : messages) {
            if (messages.indexOf(message) > 6) {
                break;
            }
            style.addLine(message.memberName + ":" + message.message);
        }
        return style;
    }

    public Bitmap getUserBitMap(String src) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            File file = storageManager.getSrcFile(StorageManager.TAG_PROFILE, storageManager.getFileName(src), StorageManager.TAG_IMAGE);
            if (file != null && file.exists()) {
                return getBitMapFromFile(file);
            } else {
                downloadBitMap(src);
                return getPlaceHolderBitmap();
            }
        } else {
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                File file = storageManager.getSrcFile(StorageManager.TAG_PROFILE, storageManager.getFileName(src), StorageManager.TAG_IMAGE);
                if (file != null && file.exists()) {
                    return getBitMapFromFile(file);
                } else {
                    downloadBitMap(src);
                    return getPlaceHolderBitmap();
                }
            } else {
                return getPlaceHolderBitmap();
            }
        }
    }

    private Bitmap getBitMapFromFile(File file) {
        Log.d(TAG, "getBitMapFromFile: " + file.getAbsolutePath());
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        return bitmap;
    }

    private Bitmap getPlaceHolderBitmap() {
        return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.temp);
    }

    private void downloadBitMap(String src) {
        Constraints constraints = new Constraints.Builder().setRequiresBatteryNotLow(true).setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest periodicWorkRequest = new OneTimeWorkRequest.Builder(FileDownloadWorker.class).setInputData(createDownloadInputData(src)).setConstraints(constraints).build();
        WorkManager.getInstance(mContext).enqueue(periodicWorkRequest);
    }

    private Data createDownloadInputData(String url) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_ATTACHMENT, url);
        builder.putString(Constants.TAG_TYPE, StorageManager.TAG_IMAGE);
        builder.putString(Constants.TAG_FROM, StorageManager.TAG_PROFILE);
        return builder.build();
    }

    /*private Bitmap downloadBitMap(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }*/

    private void showNotification(Notification notification, int id) {
        for (Map.Entry<Integer, Notification> map : notificationHashMap.entrySet()) {
            mNotifyManager.notify(map.getKey(), map.getValue());
        }
        Log.d(TAG, "showNotification: " + totalCount);
        mNotifyManager.notify(SUMMARY_ID, notification);
        ShortcutBadger.applyCount(mContext, totalCount); //for 1.1.4+
    }

    private void addUnReadNotification(Notification notification, int id) {
        notificationHashMap.put(id, notification);
    }

    private void checkDeviceState() {
        AudioManager am = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
        int mode = am.getRingerMode();

        switch (mode) {
            case AudioManager.RINGER_MODE_NORMAL:
                if ((1 == Settings.System.getInt(mContext.getContentResolver(), Settings.System.VIBRATE_WHEN_RINGING, 0))) {
                    playNotificationSound();
                    playNotificationVibrate();
                } else {
                    playNotificationSound();
                }
                break;
            case AudioManager.RINGER_MODE_SILENT:
                break;
            case AudioManager.RINGER_MODE_VIBRATE:
                playNotificationVibrate();
                break;
        }
    }

    private void playNotificationSound() {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (ringtone == null) {
            ringtone = RingtoneManager.getRingtone(mContext, notification);
        }
        if (!ringtone.isPlaying()) {
            ringtone.play();
        }
    }

    private void playNotificationVibrate() {
        Vibrator vibrator = (Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE);
        long[] pattern = new long[]{1000, 1000};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(pattern, -1);
        }
    }

    public String getLocaleString(int stringId) {
        Configuration configuration = new Configuration(mContext.getResources().getConfiguration());
        configuration.setLocale(new Locale(pref.getString(Constants.TAG_LANGUAGE_CODE, Constants.TAG_DEFAULT_LANGUAGE_CODE)));
        return mContext.createConfigurationContext(configuration).getResources().getString(stringId);
    }

    private GroupMessage getGroupMessagesByType(JSONObject data) {
        GroupMessage groupMessage = new Gson().fromJson(data.toString(), GroupMessage.class);
            /*
            GroupMessage mdata = new GroupMessage();
            JSONObject jobj = data.getJSONObject("message_data");
            mdata.groupId = jobj.optString(TAG_GROUP_ID, "");
            mdata.groupName = jobj.optString(TAG_GROUP_NAME, "");
            mdata.memberId = jobj.optString(Constants.TAG_MEMBER_ID, "");
            mdata.memberName = jobj.optString(Constants.TAG_MEMBER_NAME, "");
            mdata.memberNo = jobj.optString(Constants.TAG_MEMBER_NO, "");
            mdata.messageType = jobj.optString(Constants.TAG_MESSAGE_TYPE, "");
            mdata.message = jobj.optString(Constants.TAG_MESSAGE, "");
            mdata.messageId = jobj.optString(Constants.TAG_MESSAGE_ID, "");
            mdata.chatTime = jobj.optString(Constants.TAG_CHAT_TIME, "");
            try {
                mdata.attachment = "" + data.getJSONArray(Constants.TAG_ATTACHMENT);
            } catch (JSONException e) {
                mdata.attachment = data.optString(Constants.TAG_ATTACHMENT, "");
            }
            mdata.thumbnail = jobj.optString(Constants.TAG_THUMBNAIL, "");
            mdata.lat = jobj.optString(Constants.TAG_LAT, "");
            mdata.lon = jobj.optString(Constants.TAG_LON, "");
            mdata.contactName = jobj.optString(Constants.TAG_CONTACT_NAME, "");
            mdata.contactPhoneNo = jobj.optString(Constants.TAG_CONTACT_PHONE_NO, "");
            mdata.contactCountryCode = jobj.optString(Constants.TAG_CONTACT_COUNTRY_CODE, "");
            mdata.groupAdminId = jobj.optString(Constants.TAG_GROUP_ADMIN_ID, "");*/
        if (groupMessage.messageType != null) {
            switch (groupMessage.messageType) {
                case "subject":
                    dbhelper.updateGroupData(groupMessage.groupId, Constants.TAG_GROUP_NAME, groupMessage.groupName);
                    break;
                case "group_image":
                    dbhelper.updateGroupData(groupMessage.groupId, Constants.TAG_GROUP_IMAGE, groupMessage.attachment);
                    break;
                case Constants.TAG_GROUP_JOINED: {
                    GroupData groupData = dbhelper.getGroupData(mContext, groupMessage.groupId);
                    String memberId = groupMessage.memberId;
                    String memberRole;
                    if (groupData.groupMembers == null || groupData.groupMembers.size() == 0) {
                        memberRole = ADMIN;
                    } else {
                        memberRole = MEMBER;
                    }
                    String memberKey = groupMessage.groupId + memberId;
                    dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, groupMessage.memberId, memberRole);
                }
                case "add_member":
                    if (!groupMessage.attachment.equals("")) {
                        try {
                            JSONArray jsonArray = new JSONArray(groupMessage.attachment);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String memberId = jsonObject.getString(Constants.TAG_MEMBER_ID);
                                String memberRole = jsonObject.getString(Constants.TAG_MEMBER_ROLE);
                                if (!dbhelper.isUserExist(memberId)) {
                                    String memberKey = groupMessage.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                    getUserData(memberKey, groupMessage.groupId, memberId, memberRole);
                                } else {
                                    String memberKey = groupMessage.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                    dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, memberId, memberRole);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case "left":
                case "remove_member":
                    dbhelper.deleteFromGroup(groupMessage.groupId, groupMessage.memberId);
                    break;
                case "admin":
                    if (!dbhelper.isUserExist(groupMessage.memberId)) {
                        String memberKey = groupMessage.groupId + groupMessage.memberId;
                        getUserData(memberKey, groupMessage.groupId, groupMessage.memberId, groupMessage.attachment);
                    } else {
                        String memberKey = groupMessage.groupId + groupMessage.memberId;
                        dbhelper.updateGroupMembers(memberKey, groupMessage.groupId, groupMessage.memberId, groupMessage.attachment);
                    }
                    break;
                case "change_number":
                    dbhelper.updateContactInfo(groupMessage.memberId, Constants.TAG_COUNTRY_CODE, groupMessage.contactCountryCode);
                    dbhelper.updateContactInfo(groupMessage.memberId, Constants.TAG_PHONE_NUMBER, groupMessage.contactPhoneNo);
                    break;
                case Constants.TAG_ISDELETE:
                    dbhelper.updateGroupMessageData(groupMessage.messageId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                    if (ApplicationClass.isStringNotNull(groupMessage.attachment)) {
                        storageManager.checkDeleteFile(groupMessage.attachment, groupMessage.messageType, "receive");
                        dbhelper.updateMessageData(groupMessage.messageId, Constants.TAG_ATTACHMENT, "");
                        dbhelper.updateMessageData(groupMessage.messageId, Constants.TAG_THUMBNAIL, "");
                    }
                    break;
                default:
                    dbhelper.addGroupMessages(groupMessage.messageId, groupMessage.groupId, groupMessage.memberId, groupMessage.groupAdminId, groupMessage.messageType, groupMessage.message, groupMessage.attachment, groupMessage.lat, groupMessage.lon, groupMessage.contactName, groupMessage.contactPhoneNo, groupMessage.contactCountryCode, groupMessage.chatTime, groupMessage.thumbnail, "");

                    int unseenCount = dbhelper.getUnseenGroupMessagesCount(groupMessage.groupId);
                    GroupMessage lastMessage = dbhelper.getRecentGroupMessage(groupMessage.groupId);
                    if (lastMessage != null && !TextUtils.isEmpty(lastMessage.messageId)) {
                        dbhelper.addGroupRecentMsg(lastMessage.groupId, lastMessage.messageId, lastMessage.memberId, lastMessage.chatTime, "" + unseenCount);
                    } else {
                        dbhelper.addGroupRecentMsg(groupMessage.groupId, groupMessage.messageId, groupMessage.memberId, groupMessage.chatTime, "" + unseenCount);
                    }
                        /*dbhelper.addGroupRecentMsgs(mdata.groupId, mdata.messageId,
                                mdata.memberId, mdata.chatTime, "" + unseenCount);*/
                    break;
            }
        }
        return groupMessage;
    }

    private void getUserData(String memberKey, String groupId, String memberId, String memberRole) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                try {
                    Log.v(TAG, "getUserData: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (response.isSuccessful() && userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(mContext, userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE), userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));
                        dbhelper.createGroupMembers(memberKey, groupId, memberId, memberRole);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.v(TAG, "getUserData Failed" + t.getMessage());
                call.cancel();
            }
        });
    }

    private ChannelMessage getChannelMessagesByType(JSONObject data) {
        ChannelMessage mdata = new ChannelMessage();
        String messageFrom = "";
        try {
            JSONObject jobj = data.getJSONObject("message_data");
            if (jobj.has(Constants.TAG_MESSAGE_ID)) {
                messageFrom = "channel";
                mdata.channelId = jobj.optString(TAG_CHANNEL_ID, "");
                mdata.channelAdminId = jobj.optString(TAG_ADMIN_ID, "");
                mdata.channelName = jobj.optString(TAG_CHANNEL_NAME, "");
                mdata.messageType = jobj.optString(Constants.TAG_MESSAGE_TYPE, "");
                mdata.chatType = jobj.optString(Constants.TAG_CHAT_TYPE, "");
                mdata.message = jobj.optString(Constants.TAG_MESSAGE, "");
                mdata.messageId = jobj.optString(Constants.TAG_MESSAGE_ID, "");
                mdata.chatTime = jobj.optString(Constants.TAG_CHAT_TIME, "");
                mdata.attachment = jobj.optString(Constants.TAG_ATTACHMENT, "");
                mdata.thumbnail = jobj.optString(Constants.TAG_THUMBNAIL, "");
                mdata.lat = jobj.optString(Constants.TAG_LAT, "");
                mdata.lon = jobj.optString(Constants.TAG_LON, "");
                mdata.contactName = jobj.optString(Constants.TAG_CONTACT_NAME, "");
                mdata.contactPhoneNo = jobj.optString(Constants.TAG_CONTACT_PHONE_NO, "");
                mdata.contactCountryCode = jobj.optString(Constants.TAG_CONTACT_COUNTRY_CODE, "");
                mdata.deliveryStatus = "";
            }
            if (messageFrom.equals("channel")) {
                if (!dbhelper.isChannelExist(mdata.channelId)) {
                    getChannelInfo(mdata.channelId);
                }
            }

            if (messageFrom.equals("channel")) {
                switch (mdata.messageType) {
                    case "subject":
                        dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_NAME, mdata.channelName);
                        break;
                    case "channel_image":
                        dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_IMAGE, mdata.attachment);
                        break;
                    case "channel_des":
                        dbhelper.updateChannelData(mdata.channelId, Constants.TAG_CHANNEL_DES, mdata.message);
                        break;
                    case Constants.TAG_ISDELETE:
                        dbhelper.updateChannelData(mdata.channelId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                        if (ApplicationClass.isStringNotNull(mdata.attachment)) {
                            storageManager.checkDeleteFile(mdata.attachment, mdata.messageType, "receive");
                            dbhelper.updateMessageData(mdata.messageId, Constants.TAG_ATTACHMENT, "");
                            dbhelper.updateMessageData(mdata.messageId, Constants.TAG_THUMBNAIL, "");
                        }
                        break;
                    default:
                        dbhelper.addChannelMessages(mdata.channelId, mdata.chatType, mdata.messageId, mdata.messageType, mdata.message, mdata.attachment, mdata.lat, mdata.lon, mdata.contactName, mdata.contactPhoneNo, mdata.contactCountryCode, mdata.chatTime, mdata.thumbnail, "");
                        int unseenCount = dbhelper.getUnseenChannelMessagesCount(mdata.channelId);
                        ChannelMessage lastMessage = dbhelper.getRecentChannelMessage(mdata.channelId);
                        if (lastMessage != null && !TextUtils.isEmpty(lastMessage.messageId)) {
                            dbhelper.addChannelRecentMsgs(lastMessage.channelId, lastMessage.messageId, lastMessage.chatTime, "" + unseenCount);
                        } else {
                            dbhelper.addChannelRecentMsgs(mdata.channelId, mdata.messageId, mdata.chatTime, "" + unseenCount);
                        }
//                        dbhelper.addChannelRecentMsgs(mdata.channelId, mdata.messageId,
//                                mdata.chatTime, String.valueOf(unseenCount));
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mdata;
    }

    private AdminChannelMsg.Result getAdminChannelMessagesByType(JSONObject data) {
        AdminChannelMsg.Result channelMessage = new AdminChannelMsg().new Result();
        String messageFrom = "";
        try {
            JSONObject jobj = data.getJSONObject("message_data");
            messageFrom = "admin_channel";
            channelMessage.channelId = jobj.optString(TAG_CHANNEL_ID, "");
            channelMessage.messageType = jobj.optString(Constants.TAG_MESSAGE_TYPE, "");
            channelMessage.message = jobj.optString(Constants.TAG_MESSAGE, "");
            channelMessage.messageId = jobj.optString(Constants.TAG_ID, "");
            channelMessage.messageDate = jobj.optString("message_date", "");
            channelMessage.messageAt = jobj.optString("message_at", "");
            channelMessage.attachment = jobj.optString(Constants.TAG_ATTACHMENT, "");
            channelMessage.thumbnail = jobj.optString(Constants.TAG_THUMBNAIL, "");
            channelMessage.chatType = jobj.optString(Constants.TAG_CHAT_TYPE, "");
            channelMessage.progress = jobj.optString(Constants.TAG_PROGRESS, "");
            if (!dbhelper.isChannelExist(channelMessage.channelId)) {
                getAdminChannels();
            }

            switch (channelMessage.messageType) {
                case "subject":
//                        dbhelper.updateChannelData(chData.channelId, Constants.TAG_CHANNEL_NAME, chData.channelName);
                    break;
                case "channel_image":
                    dbhelper.updateChannelData(channelMessage.channelId, Constants.TAG_CHANNEL_IMAGE, channelMessage.attachment);
                    break;
                case "channel_des":
                    dbhelper.updateChannelData(channelMessage.channelId, Constants.TAG_CHANNEL_DES, channelMessage.message);
                    break;
                case Constants.TAG_ISDELETE:
                    dbhelper.updateChannelData(channelMessage.channelId, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                    if (ApplicationClass.isStringNotNull(channelMessage.attachment)) {
                        storageManager.checkDeleteFile(channelMessage.attachment, channelMessage.messageType, "receive");
                        dbhelper.updateMessageData(channelMessage.messageId, Constants.TAG_ATTACHMENT, "");
                        dbhelper.updateMessageData(channelMessage.messageId, Constants.TAG_THUMBNAIL, "");
                    }
                    break;
                default:
                    if (dbhelper.isChannelExist(channelMessage.channelId)) {
                        dbhelper.addChannelMessages(channelMessage.channelId, channelMessage.chatType, channelMessage.messageId, channelMessage.messageType, ApplicationClass.encryptMessage(channelMessage.message), channelMessage.attachment, "", "", "", "", "", channelMessage.messageDate, channelMessage.thumbnail, "");

                        int unseenCount = dbhelper.getUnseenChannelMessagesCount(channelMessage.channelId);
                        ChannelMessage lastMessage = dbhelper.getRecentChannelMessage(channelMessage.channelId);
                        if (lastMessage != null && !TextUtils.isEmpty(lastMessage.messageId)) {
                            Log.d(TAG, "addChannelRecentMsgs: " + ApplicationClass.decryptMessage(lastMessage.message));
                            dbhelper.addChannelRecentMsgs(lastMessage.channelId, lastMessage.messageId, lastMessage.chatTime, "" + unseenCount);
                        } else {
                            dbhelper.addChannelRecentMsgs(channelMessage.channelId, channelMessage.messageId, channelMessage.messageDate, "" + unseenCount);
                        }
//                            dbhelper.addChannelRecentMsgs(channelMessage.channelId, channelMessage.messageId, channelMessage.chatTime, "" + unseenCount);
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return channelMessage;
    }

    private void getChannelInfo(String channelId) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(channelId);
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<ChannelInfoResponse> call = apiInterface.getChannelInfo(GetSet.getToken(), jsonArray);
        call.enqueue(new Callback<ChannelInfoResponse>() {
            @Override
            public void onResponse(Call<ChannelInfoResponse> call, Response<ChannelInfoResponse> response) {
                if (response.isSuccessful() && response.body().status != null && response.body().status.equalsIgnoreCase(TAG_TRUE)) {
                    for (ChannelResult.Result result : response.body().result) {
                        dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, result.channelImage, result.channelType, result.channelAdminId, result.channelAdminName, result.totalSubscribers, result.createdAt, Constants.TAG_USER_CHANNEL, "", result.blockStatus, result.report);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChannelInfoResponse> call, Throwable t) {
                Log.e(TAG, "getChannelInfo: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getAdminChannels() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<AdminChannel> call3 = apiInterface.getAdminChannels(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<AdminChannel>() {
            @Override
            public void onResponse(Call<AdminChannel> call, Response<AdminChannel> response) {
                Log.v(TAG, "getAdminChannels: " + new Gson().toJson(response.body()));
                if (response.isSuccessful() && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                    /*Get Channels from Admin*/
                    for (AdminChannel.Result result : response.body().result) {
                        if (!dbhelper.isChannelExist(result.channelId)) {
                            dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, "", Constants.TAG_PUBLIC, "", "", "", result.createdAt, Constants.TAG_ADMIN_CHANNEL, "", "", "0");
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<AdminChannel> call, Throwable t) {
                Log.e(TAG, "getAdminChannels: " + t.getMessage());
                call.cancel();
            }
        });
    }

    @Override
    public void notificationOpened(OSNotificationOpenedResult result) {
        Log.d(TAG, "notificationOpened: ");
    }
}