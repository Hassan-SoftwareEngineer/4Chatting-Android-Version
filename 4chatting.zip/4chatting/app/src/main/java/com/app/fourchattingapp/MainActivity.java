package com.app.fourchattingapp;

import static android.Manifest.permission.BLUETOOTH_CONNECT;
import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static com.app.fourchattingapp.CallFragment.callFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.app.helper.AutoStartPermissionHelper;
import com.app.helper.CallNotificationService;
import com.app.helper.DatabaseHandler;
import com.app.helper.SocketConnection;
import com.app.helper.Utils;
import com.app.helper.callback.OkCallback;
import com.app.helper.connectivity.NetworkStatus;
import com.app.helper.event.CallReceiveEvent;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener, TabLayout.OnTabSelectedListener, SocketConnection.OnUpdateTabIndication, CallFragment.ClearLogFunction, SocketConnection.OnlineCallbackListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    public CircleImageView userImage;
    Toolbar toolbar;
    AppBarLayout appBarLayout;
    ViewPagerAdapter adapter;
    TabLayout tabLayout;
    ViewPager viewPager;
    ImageView navBtn, fab, searchBtn, closeDelete, deleteLog;
    DatabaseHandler dbhelper;
    DrawerLayout drawer;
    NavigationView navigationView;
    LinearLayout  fabSearch;
    RelativeLayout usrLayout;
    TextView userName, logCount;
    RelativeLayout deleteLay;
    private Utils utils;
    SocketConnection socketConnection;
    ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean isFromNotification = false;
    boolean doubleBackToExit = false;

    BottomNavigationView bottom_menu;
    private AlertDialog callDialog;
    private ActivityResultLauncher<String[]> callPermissionResult;
    DialogOverLayPermission dialogOverLayPermission;
    DialogAutoStartPermission dialogAutostartPermission;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    Handler onlineHandler = new Handler(Looper.myLooper());
    Runnable onlineRunnable = new Runnable() {
        @Override
        public void run() {
            if (NetworkStatus.isConnected()) {
                updateOnlineStatus();
            }
            onlineHandler.postDelayed(onlineRunnable, Constants.ONLINE_CHECK_TIMER);
        }
    };

    //for tecno
    SharedPreferences sharedPrefs;
    SharedPreferences.Editor editorTecno;
    Boolean isSettingsIn = false;
    Boolean isAutoStartIn = false;
    ImageView close;

    //updated the POWERMANAGER_INTENTS 26/06/2019
    public static final List<Intent> POWERMANAGER_INTENTS = Arrays.asList(new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")), new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")), new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")), new Intent().setComponent(new ComponentName("com.huawei.systemmanager", Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity" : "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")), new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity")), new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerSaverModeActivity")), new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.sysfloatwindow.FloatWindowListActivity")), new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.floatwindow.FloatWindowListActivity")), new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")), new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")), new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")), new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")), new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")), new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity")), new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")).setData(Uri.parse("mobilemanager://function/entry/AutoStart")), new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.security.SHOW_APPSEC")).addCategory(Intent.CATEGORY_DEFAULT).putExtra("packageName", BuildConfig.APPLICATION_ID), new Intent().setComponent(new ComponentName("com.htc.pitroad", "com.htc.pitroad.landingpage.activity.LandingPageActivity")), new Intent().setComponent(new ComponentName("com.transsion.phonemanager", "com.itel.autobootmanager.activity.AutoBootMgrActivity")));

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            //w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            w.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }*/
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow(); // in Activity's onCreate() for instance
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }*/
        super.onCreate(savedInstanceState);
        initValues();
        //setStatusBarGradient(this);
        setContentView(R.layout.activity_main);
//        Log.v(TAG, "onCreate: " + GetSet.getToken());
//        Log.v(TAG, "onCreate: " + DateUtils.getInstance(this).getCurrentUTCTime());
        initView();

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  drawer.close();
            }
        });
        bottom_menu.setItemIconTintList(null);
        sendPing();
        if (ApplicationClass.isRTL()) {
            navBtn.setRotation(180);
        } else {
            navBtn.setRotation(0);
        }
        setupViewPager(viewPager);
        viewPager.setOffscreenPageLimit(3);
        View header = navigationView.getHeaderView(0);
        dbhelper = DatabaseHandler.getInstance(this);
        SocketConnection.getInstance(this).setOnUpdateTabIndication(this);
        initOverLayPermissionDialog();
        initAutoStartPermissionDialog();

        userImage = header.findViewById(R.id.userImage);
        usrLayout = header.findViewById(R.id.usrLayout);
        userName = header.findViewById(R.id.userName);

        tabLayout.addOnTabSelectedListener(this);
        navigationView.setNavigationItemSelectedListener(this);
        navBtn.setOnClickListener(this);
        searchBtn.setOnClickListener(this);
        usrLayout.setOnClickListener(this);
        deleteLog.setOnClickListener(this);
        closeDelete.setOnClickListener(this);

        updateTabIndication();

        final ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                Log.v("Drawer", "Drawer Opened");
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                Log.v("Drawer", "Drawer Closed");
            }
        };
        drawer.addDrawerListener(toggle);
        drawer.post(new Runnable() {
            @Override
            public void run() {
                toggle.syncState();
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tabLayout != null && tabLayout.getSelectedTabPosition() == 0) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{READ_CONTACTS}, 101);
                    } else {
                        Intent s = new Intent(getApplicationContext(), SelectContact.class);
                        s.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                        startActivity(s);
                    }
                }
            }
        });

        navigationView.post(new Runnable() {
            @Override
            public void run() {
                Resources r = getResources();
                DisplayMetrics metrics = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getMetrics(metrics);
                int width = metrics.widthPixels;

                float screenWidth = width / r.getDisplayMetrics().density;
                float navWidth = screenWidth - 56;

                navWidth = Math.min(navWidth, 320);

                int newWidth = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, navWidth, r.getDisplayMetrics());

                DrawerLayout.LayoutParams params = (DrawerLayout.LayoutParams) navigationView.getLayoutParams();
                params.width = newWidth;
                navigationView.setLayoutParams(params);
            }
        });

        if (viewPager != null && getIntent().getStringExtra(Constants.IS_FROM) != null) {
            if (getIntent().getStringExtra(Constants.IS_FROM).equalsIgnoreCase("group")) {
                viewPager.setCurrentItem(1);
                changeIcon(1);
            } else if (getIntent().getStringExtra(Constants.IS_FROM).equalsIgnoreCase("channel")) {
                viewPager.setCurrentItem(2);
                 changeIcon(2);
            } else if (getIntent().getStringExtra(Constants.IS_FROM).equalsIgnoreCase(Constants.TAG_CALL)) {
                viewPager.setCurrentItem(3);
                 changeIcon(3);
            }
        }
        else {
            changeIcon(0);
        }
        initCallPermission();
        checkCallPermissions();


        bottom_menu.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.menuChat:
                        viewPager.setCurrentItem(0);
                        break;
                    case R.id.menuGroup:
                        viewPager.setCurrentItem(1);
                        break;
                    case R.id.menuChannel:
                        viewPager.setCurrentItem(2);
                        break;
                    case R.id.menuCall:
                        viewPager.setCurrentItem(3);
                        break;

                }
                return false;
            }
        });

//        startPowerSaverIntent(this);
    }

    private void initValues() {
        preferences = getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = preferences.edit();
        sharedPrefs = getSharedPreferences("MyPref", 0);
        editorTecno = sharedPrefs.edit();
        utils = new Utils(this);
        utils.getNavigationBarHeight();
        utils.getStatusBarHeight();
        socketConnection = SocketConnection.getInstance(this);
        if (getIntent().getStringExtra("notification") != null) {
            Constants.isChatOpened = true;
            isFromNotification = true;
        } else {
            NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancelAll();
        }
        if (isFromNotification) {
            Constants.isChatOpened = true;
            isFromNotification = true;
            Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
            intent.putExtra("user_id", intent.getStringExtra("user_id"));
            intent.putExtra("notification", intent.getStringExtra("notification"));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            overridePendingTransition(0, 0);
            startActivity(intent);
        }
    }

    private void initView() {
        toolbar = findViewById(R.id.toolbar);
        viewPager = findViewById(R.id.viewpager);
        navBtn = findViewById(R.id.navBtn);
        drawer = findViewById(R.id.drawer_layout);
        tabLayout = findViewById(R.id.tabs);
        navigationView = findViewById(R.id.nav_view);
        fab = findViewById(R.id.fab);
        searchBtn = findViewById(R.id.searchBtn);
        logCount = findViewById(R.id.logCount);
        closeDelete = findViewById(R.id.closeDelete);
        deleteLog = findViewById(R.id.deleteLog);
        deleteLay = findViewById(R.id.deleteLay);
        fabSearch = findViewById(R.id.fabSearch);
        bottom_menu=findViewById(R.id.bottom_menu);
        close=findViewById(R.id.close);
    }

    private void updateOnlineStatus() {
        socketConnection.goLive();
    }

    private boolean isCallable(Context context, Intent intent) {
        try {
            if (intent == null || context == null) {
                return false;
            } else {
                List<ResolveInfo> list = context.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
                return list.size() > 0;
            }
        } catch (Exception ignored) {
            return false;
        }
    }

    private void updateTabIndication() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            View selected = tab.getCustomView();
            ImageView indication = selected.findViewById(R.id.indication);

            if (i == 0) {
                if (dbhelper.isRecentChatIndicationExist()) {
                    indication.setVisibility(View.VISIBLE);
                } else {
                    indication.setVisibility(View.GONE);
                }
            } else if (i == 1) {
                if (dbhelper.isRecentGroupIndicationExist()) {
                    indication.setVisibility(View.VISIBLE);
                } else {
                    indication.setVisibility(View.GONE);
                }
            } else if (i == 2) {
                if (dbhelper.isRecentChannelIndicationExist()) {
                    indication.setVisibility(View.VISIBLE);
                } else {
                    indication.setVisibility(View.GONE);
                }
            } else if (i == 3) {
                if (dbhelper.isMissedCallIndicationExist()) {
                    indication.setVisibility(View.VISIBLE);
                } else {
                    indication.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        if (doubleBackToExit) {
            overridePendingTransition(0, 0);
            finishAffinity();
        } else {
            if (!(ApplicationClass.getCurrentActivity() instanceof CallActivity) && CallActivity.isInCall) {
                Intent callNotificationService = new Intent(getBaseContext(), CallNotificationService.class);
                if(Build.VERSION.SDK_INT==Build.VERSION_CODES.S){
                    startService(callNotificationService);
                }
                else  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(callNotificationService);
                } else {
                    startService(callNotificationService);
                }
            }

            this.doubleBackToExit = true;
            makeToast(getString(R.string.back_button_exit_description));
            new Handler(Looper.getMainLooper()).postDelayed(() -> doubleBackToExit = false, 1500);
        }
    }

    private void initOverLayPermissionDialog() {
        dialogOverLayPermission = new DialogOverLayPermission();
        dialogOverLayPermission.setContext(this);
        dialogOverLayPermission.setCancelable(false);
        dialogOverLayPermission.setCallBack(new OkCallback() {
            @Override
            public void onOkClicked(Object o) {
                boolean isAllow = (boolean) o;
                if (isAllow) {
                    requestOverLayPermission();
                }
                dialogOverLayPermission.dismissAllowingStateLoss();
            }
        });
    }

    private void openPermissionDialog() {
        if (preferences.getBoolean(Constants.POP_UP_WINDOW_PERMISSION, true)) {
            if (dialogOverLayPermission != null && !dialogOverLayPermission.isAdded()) {
                dialogOverLayPermission.show(getSupportFragmentManager(), "OverLayPermissionDialog");
            }
        }
    }

    private boolean checkOverLayPermission() {
        //Android M Or Over
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean isOverLayEnabled = Settings.canDrawOverlays(this);
            if (isOverLayEnabled)
                editor.putBoolean(Constants.POP_UP_WINDOW_PERMISSION, false).apply();
            return isOverLayEnabled;
        }
        return true;
    }

    private void requestOverLayPermission() {
        // Check if Android M or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Show alert dialog to the user saying a separate permission is needed
            // Launch the settings activity if the user prefers
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, Constants.OVERLAY_REQUEST_CODE);
        }
    }

    private void initAutoStartPermissionDialog() {
        dialogAutostartPermission = new DialogAutoStartPermission();
        dialogAutostartPermission.setContext(this);
        dialogAutostartPermission.setCancelable(true);
        dialogAutostartPermission.setCallBack(new OkCallback() {
            @Override
            public void onOkClicked(Object o) {
                boolean isAllow = (boolean) o;
                if (isAllow) {
                    Intent intent = new Intent(getApplicationContext(), AccountActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                }
                dialogAutostartPermission.dismissAllowingStateLoss();
            }
        });
    }

    private void openAutoStartPermissionDialog() {
        if (preferences.getBoolean(Constants.AUTO_START_WINDOW_PERMISSION, true)) {
            if (dialogAutostartPermission != null && !dialogAutostartPermission.isAdded()) {
                dialogAutostartPermission.show(getSupportFragmentManager(), "AutoStartPermissionDialog");
            }
        }
    }

    public static void setStatusBarGradient(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            Drawable background = activity.getResources().getDrawable(R.drawable.gradient);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(activity.getResources().getColor(android.R.color.transparent));
            window.setNavigationBarColor(activity.getResources().getColor(android.R.color.transparent));
            window.setBackgroundDrawable(background);
        }
    }

    private void setupViewPager(ViewPager viewPager) {
        adapter = new ViewPagerAdapter(getSupportFragmentManager(), MainActivity.this);
        adapter.addFragment(new ChatFragment(), getString(R.string.chat));
        adapter.addFragment(new GroupFragment(), getString(R.string.group));
        adapter.addFragment(new ChannelFragment(), getString(R.string.channels));
        adapter.addFragment(new CallFragment(), getString(R.string.calls));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        // Iterate over all tabs and set the custom view
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adapter.getTabView(i, this));
        }
        adapter.setOnSelectView(this, tabLayout, 0);

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                
              changeIcon(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void changeIcon(int position){
        switch (position){
            case 0:
                bottom_menu.getMenu().getItem(0).setIcon(R.drawable.chat_active);
                bottom_menu.getMenu().getItem(1).setIcon(R.drawable.group_nonactive);
                bottom_menu.getMenu().getItem(2).setIcon(R.drawable.channel_nonactive);
                bottom_menu.getMenu().getItem(3).setIcon(R.drawable.call_nonactive);
                toolbar.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                break;
            case 1:
                bottom_menu.getMenu().getItem(0).setIcon(R.drawable.chat_nonactive);
                bottom_menu.getMenu().getItem(1).setIcon(R.drawable.group_active);
                bottom_menu.getMenu().getItem(2).setIcon(R.drawable.channel_nonactive);
                bottom_menu.getMenu().getItem(3).setIcon(R.drawable.call_nonactive);
                toolbar.setBackground(getResources().getDrawable(R.drawable.toolbar));
                break;
            case 2:
                bottom_menu.getMenu().getItem(0).setIcon(R.drawable.chat_nonactive);
                bottom_menu.getMenu().getItem(1).setIcon(R.drawable.group_nonactive);
                bottom_menu.getMenu().getItem(2).setIcon(R.drawable.channel_active);
                bottom_menu.getMenu().getItem(3).setIcon(R.drawable.call_nonactive);
                toolbar.setBackground(getResources().getDrawable(R.drawable.toolbar));
                break;
            case 3:
                bottom_menu.getMenu().getItem(0).setIcon(R.drawable.chat_nonactive);
                bottom_menu.getMenu().getItem(1).setIcon(R.drawable.group_nonactive);
                bottom_menu.getMenu().getItem(2).setIcon(R.drawable.channel_nonactive);
                bottom_menu.getMenu().getItem(3).setIcon(R.drawable.call_active);
                toolbar.setBackground(getResources().getDrawable(R.drawable.toolbar));
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.OVERLAY_REQUEST_CODE) {
            /*if (!checkOverLayPermission()) {
                openPermissionDialog();
            }*/
        }
    }

    public void miOverLayPermission() {
        String deviceName = getDeviceName();
        Log.i(TAG, "miOverLayPermission: " + deviceName);
        if (deviceName.contains("Xiaomi")) {
            Intent localIntent = new Intent("miui.intent.action.APP_PERM_EDITOR");
            localIntent.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity");
            localIntent.putExtra("extra_pkgname", getPackageName());
            startActivity(localIntent);
        }
    }


    public static boolean isMIUI() {
        String device = Build.MANUFACTURER;
        return device.equals("Xiaomi");
        /*if (device.equals("Xiaomi")) {
            try {
                Properties prop = new Properties();
                prop.load(new FileInputStream(new File(Environment.getRootDirectory(), "build.prop")));
                return prop.getProperty("ro.miui.ui.version.code", null) != null
                        || prop.getProperty("ro.miui.ui.version.name", null) != null
                        || prop.getProperty("ro.miui.internal.storage", null) != null;
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return false;*/
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.v("requestCode", "requestCode=" + requestCode);
        switch (requestCode) {
            case 101:
                int permContacts = ContextCompat.checkSelfPermission(MainActivity.this, READ_CONTACTS);
                if (permContacts == PackageManager.PERMISSION_GRANTED) {
                    Intent s = new Intent(this, SelectContact.class);
                    s.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                    startActivity(s);
                }
                break;
            case 100:
                boolean isContactEnabled = false;

                for (String permission : permissions) {
                    if (permission.equals(READ_CONTACTS)) {
                        if (ActivityCompat.checkSelfPermission(MainActivity.this, READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                            isContactEnabled = true;
                        }
                    }
                }

                if (!isContactEnabled) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
                            requestPermission(new String[]{READ_CONTACTS}, 100);
                        } else {
                            Toast.makeText(getApplicationContext(), R.string.contact_permission_error, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                } else {
                    onResumeFunction();
                }
                break;
            case 103:
                int permissionPushnotification = ContextCompat.checkSelfPermission(MainActivity.this, POST_NOTIFICATIONS);

                break;
        }
    }

    private void requestPermission(String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(MainActivity.this, permissions, requestCode);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.navBtn:
                drawer.openDrawer(GravityCompat.START);
                break;
            case R.id.searchBtn:
                startActivity(new Intent(this, SearchActivity.class));
                break;
            case R.id.usrLayout:
                ApplicationClass.preventMultiClick(usrLayout);
                Intent p = new Intent(this, ProfileActivity.class);
                p.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                startActivity(p);
                drawer.closeDrawer(GravityCompat.START);
                break;
            case R.id.deleteLog:
                deleteLay.setVisibility(View.GONE);
                callFragment.deleteCallLog("delete");
                break;
            case R.id.closeDelete:
                deleteLay.setVisibility(View.GONE);
                isDeleteVisible(false, 0);
                callFragment.deleteCallLog("clear");
                break;

        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Log.v("onNavigation", "=" + item.getTitle());
        int id = item.getItemId();
        switch (id) {
            case R.id.yourrides_menu:
                Intent channel = new Intent(MainActivity.this, MyChannelsActivity.class);
                startActivity(channel);
                break;
            case R.id.wallet_menu:
                Intent account = new Intent(MainActivity.this, AccountActivity.class);
                startActivity(account);
                break;
            case R.id.invite_menu:
                Intent g = new Intent(Intent.ACTION_SEND);
                g.setType("text/plain");
                g.putExtra(Intent.EXTRA_TEXT, getString(R.string.invite_message) + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName());
                startActivity(Intent.createChooser(g, "Share"));
                break;
            case R.id.help_menu:
                Intent help = new Intent(MainActivity.this, HelpActivity.class);
                startActivity(help);
                break;
            //Addon Live Stream
            case R.id.streams_menu:
                /*Intent streams = new Intent(MainActivity.this, StreamListActivity.class);
                startActivity(streams);*/
                break;
            //Addon Live Stream
            case R.id.user_streams_menu:
                /*Intent myVideos = new Intent(MainActivity.this, UserVideoActivity.class);
                myVideos.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(myVideos);*/
                break;
        }
        //  switchActivityByNavigation(id, item);
        drawer.closeDrawer(GravityCompat.START);
        return false;
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        adapter.setOnSelectView(this, tabLayout, tab.getPosition());
        if (tab.getPosition() == 0) {
            if (deleteLay.getVisibility() == View.VISIBLE) {
                fabSearch.setVisibility(View.VISIBLE);
            }
            fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.floating_message));
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (drawer != null) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{READ_CONTACTS}, 101);
                    } else {
                        Intent s = new Intent(getApplicationContext(), SelectContact.class);
                        s.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                        startActivity(s);
                    }
                }
            });
        } else if (tab.getPosition() == 1) {
            if (deleteLay.getVisibility() == View.VISIBLE) {
                fabSearch.setVisibility(View.VISIBLE);
            }
            fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.floating_group));
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (drawer != null) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    Intent s = new Intent(getApplicationContext(), NewGroupActivity.class);
                    s.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                    startActivity(s);
                }
            });
        } else if (tab.getPosition() == 2) {
            if (deleteLay.getVisibility() == View.VISIBLE) {
                fabSearch.setVisibility(View.VISIBLE);
            }
            fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.floating_channel));
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (drawer != null) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    Intent s = new Intent(getApplicationContext(), CreateChannelActivity.class);
                    s.putExtra(Constants.TAG_USER_ID, GetSet.getUserId());
                    startActivity(s);
//                    Toast.makeText(MainActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();
                }
            });
        } else if (tab.getPosition() == 3) {
            if (deleteLay.getVisibility() == View.VISIBLE) {
                fabSearch.setVisibility(View.GONE);
            }
            fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.floating_call));
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (drawer != null) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    Intent s = new Intent(getApplicationContext(), CallContactActivity.class);
                    startActivity(s);
                }
            });
        }
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
        adapter.setUnSelectView(this, tabLayout, tab.getPosition());
    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    @Override
    public void updateIndication() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateTabIndication();
            }
        });
    }

    @Override
    public void isDeleteVisible(boolean isDelete, int count) {
        if (isDelete) {
            fabSearch.setVisibility(View.GONE);
            deleteLay.setVisibility(View.VISIBLE);
            logCount.setText("" + count);
        } else {
            fabSearch.setVisibility(View.VISIBLE);
            deleteLay.setVisibility(View.GONE);
        }
    }

    @Override
    public void onChatBoxJoined() {
        sendPing();
    }

    private void sendPing() {
        onlineHandler.post(onlineRunnable);
    }

    private void removePing() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                onlineHandler.removeCallbacks(onlineRunnable);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        socketConnection.setOnlineCallBackListener(this);
        if (!checkOverLayPermission()) {
            openPermissionDialog();
        } else if (checkOverLayPermission()) {
            if (Build.BRAND.equalsIgnoreCase("TECNO")) {
                enableProtectesApps();
            }else{
                enablePostNotification();
            }
        } else {
            if (AutoStartPermissionHelper.getInstance().isAutoStartPermissionAvailable(this) || isMIUI()) {
                openAutoStartPermissionDialog();
            }else{
                 enablePostNotification();
            }
        }


        onResumeFunction();

        if (isSettingsIn) {
            if (Build.BRAND.equalsIgnoreCase("TECNO")) {
                enableAutoStart();
            }

        }

    }

    public void enablePostNotification(){
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS},103);
            }
            else {
               Log.e("showNotification","-pushNotification False");
            }
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        removePing();
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(CallReceiveEvent event) {
        Log.d(TAG, "onMessageEvent: ");
        if (event != null && event.getCallType() != null) {
            updateTabIndication();
        }
    }


    private void enableProtectesApps() {
        Log.d(TAG, "enableAutoStart: " + Build.BRAND);
        sharedPrefs = getSharedPreferences("MyPref", 0);
        editorTecno = sharedPrefs.edit();
        isSettingsIn = sharedPrefs.getBoolean("isSettingsIn", false);
        if (!isSettingsIn) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            ViewGroup viewGroup = findViewById(android.R.id.content);
            View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dialog_overlay_permission_call, viewGroup, false);
            builder.setView(dialogView);
            AlertDialog alertDialog = builder.create();
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorTransparent)));
            TextView txtDescription = dialogView.findViewById(R.id.txtDescription);
            Button allowButton = dialogView.findViewById(R.id.btnAllow);
            Button denyButton = dialogView.findViewById(R.id.btnDeny);
            txtDescription.setText(String.format(getString(R.string.pop_up_permission_tecno), getString(R.string.app_name)));
            allowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editorTecno.putBoolean("isSettingsIn", true);
                    editorTecno.apply();
                    Intent intent = new Intent();
                    // com.cyin.himgr.widget.activity.MainSettingGpActivity
                    intent.setClassName("com.transsion.phonemaster", "com.cyin.himgr.widget.activity.MainSettingGpActivity");
                    startActivity(intent);
                    alertDialog.dismiss();
                }
            });
            denyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                    if (!checkOverLayPermission()) {
                        openPermissionDialog();
//            miOverLayPermission();
                    }

                }
            });

            alertDialog.show();
        }
    }

    private void onResumeFunction() {
        SocketConnection.getInstance(this).setOnUpdateTabIndication(this);
        updateTabIndication();
        userName.setText(GetSet.getUserName());
        Glide.with(MainActivity.this).load(Constants.USER_IMG_PATH + GetSet.getImageUrl()).apply(new RequestOptions().placeholder(R.drawable.temp).error(R.drawable.temp)).into(userImage);
    }

    private void initCallPermission() {
        callPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }
                if (granted) {

                } else {
                    boolean neverAsked = false;
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, x.getKey())) {
                                callPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                            break;
                        }
                    }
                }
            }
        });
    }

    private void checkCallPermissions() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ) {
            if (ContextCompat.checkSelfPermission(MainActivity.this, READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(MainActivity.this, BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                openCallPermissionDialog();
            }
        }else{
                AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);

                //Setting message manually and performing action on button click
                builder2.setMessage("Click on Preferred Engine to open, then select \n Speech services by Google")
                        .setCancelable(false)
                        .setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                //Open Android Text-To-Speech Settings
                                startActivity(Build.VERSION.SDK_INT >= 14 ?
                                        new Intent().setAction("com.android.settings.TTS_SETTINGS").setFlags(Intent.FLAG_ACTIVITY_NEW_TASK) :
                                        new Intent().addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName("com.android.settings", "com.android.settings.TextToSpeechSettings")).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"selection denied",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder2.create();
                //Setting the title manually
                alert.setTitle("Check Preferred Engine for translation");
                alert.show();
            }
    }

    private void openCallPermissionDialog() {
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dialog_call_permission, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setView(dialogView);
        Button btnAllow = dialogView.findViewById(R.id.btnAllow);
        builder.setCancelable(false);
        btnAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callDialog != null) {
                    callDialog.dismiss();
                }
                AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);

                //Setting message manually and performing action on button click
                builder2.setMessage("Click on Preferred Engine to open, then select \n Speech services by Google")
                        .setCancelable(false)
                        .setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                //Open Android Text-To-Speech Settings
                                startActivity(Build.VERSION.SDK_INT >= 14 ?
                                        new Intent().setAction("com.android.settings.TTS_SETTINGS").setFlags(Intent.FLAG_ACTIVITY_NEW_TASK) :
                                        new Intent().addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName("com.android.settings", "com.android.settings.TextToSpeechSettings")).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"selection denied",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder2.create();
                //Setting the title manually
                alert.setTitle("Check Preferred Engine for translation");
                alert.show();

                callPermissionResult.launch(new String[]{READ_PHONE_STATE, BLUETOOTH_CONNECT});
            }
        });
        callDialog = builder.create();
        callDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorTransparent)));
        callDialog.show();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.v(TAG, "onPause");
        SocketConnection.getInstance(this).setOnUpdateTabIndication(null);
        socketConnection.setOnlineCallBackListener(this);
    }


    //for tecno device

    private void enableAutoStart() {
        Log.d(TAG, "enableAutoStart: " + Build.BRAND);
        sharedPrefs = getSharedPreferences("MyPref", 0);
        editorTecno = sharedPrefs.edit();
        isAutoStartIn = sharedPrefs.getBoolean("isAutoStartIn", false);
        if (!isAutoStartIn) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            ViewGroup viewGroup = findViewById(android.R.id.content);
            View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dialog_overlay_permission_autostart, viewGroup, false);
            builder.setView(dialogView);
            AlertDialog alertDialog = builder.create();
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorTransparent)));
            TextView txtEnable = dialogView.findViewById(R.id.txtEnable);
            Button allowButton = dialogView.findViewById(R.id.btnAllow);
            Button denyButton = dialogView.findViewById(R.id.btnDeny);
            txtEnable.setText(String.format(getString(R.string.pop_up_permission_autostart_tecno_step3), getString(R.string.app_name)));
            allowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editorTecno.putBoolean("isAutoStartIn", true);
                    editorTecno.apply();
                    Intent intent = new Intent();
                    // com.cyin.himgr.widget.activity.MainSettingGpActivity
                    intent.setClassName("com.transsion.phonemaster", "com.cyin.himgr.widget.activity.MainActivity");
                    startActivity(intent);
                    alertDialog.dismiss();
                }
            });
            denyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                    if (!checkOverLayPermission()) {
                        openPermissionDialog();
//            miOverLayPermission();
                    }

                }
            });

            alertDialog.show();
        }
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();
        Context context;

        public ViewPagerAdapter(FragmentManager manager, Context context) {
            super(manager);
            this.context = context;
        }

        public View getTabView(int position, Context context) {
            // Given you have a custom layout in `res/layout/custom_tab.xml` with a TextView and ImageView
            View v = LayoutInflater.from(context).inflate(R.layout.tab_layout, null);
            TextView tabName = v.findViewById(R.id.tabName);
            tabName.setText(mFragmentTitleList.get(position));
            // ImageView indication = (ImageView) v.findViewById(R.id.indication);
            return v;
        }

        public void setOnSelectView(Context mContext, TabLayout tabLayout, int position) {
            TabLayout.Tab tab = tabLayout.getTabAt(position);
            View selected = tab.getCustomView();
            TextView tabName = selected.findViewById(R.id.tabName);
            tabName.setTextColor(mContext.getResources().getColor(R.color.primarytext));
        }

        public void setUnSelectView(Context mContext, TabLayout tabLayout, int position) {
            TabLayout.Tab tab = tabLayout.getTabAt(position);
            View selected = tab.getCustomView();
            TextView iv_text = selected.findViewById(R.id.tabName);
            iv_text.setTextColor(mContext.getResources().getColor(R.color.secondarytext));
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

}
