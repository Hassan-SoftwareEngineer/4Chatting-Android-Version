package com.app.fourchattingapp;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.app.helper.DatabaseHandler;
import com.app.helper.StorageManager;
import com.app.fourchattingapp.R;
import com.app.model.MediaModelData;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DocumentFragment extends Fragment {
    private static final String ARG_PARAM1 = "user_id";
    private static final String ARG_PARAM2 = "type";
    String userId = "", type = "", TAG = "DocumentFragment";
    RecyclerView recyclerView;
    Context context;
    DatabaseHandler dbhelper;
    StorageManager storageManager;
    BottomSheetBehavior bottomSheetBehavior;
    private TextView empty_view;


    public DocumentFragment() {

    }

    static DocumentFragment newInstance(String param1, String param2) {
        DocumentFragment fragment = new DocumentFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            userId = getArguments().getString(ARG_PARAM1);
            type = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_imageitem_list, container, false);
        context = view.getContext();
        recyclerView = view.findViewById(R.id.recyclerView);
        empty_view = view.findViewById(R.id.empty_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(context, RecyclerView.VERTICAL, false));

        storageManager = StorageManager.getInstance(context);
        dbhelper = DatabaseHandler.getInstance(context);

        setMediaAdapter();

        return view;
    }

    private void setMediaAdapter() {
        List<MediaModelData> data = new ArrayList<>();
        try {
            data = dbhelper.getDocMedia(userId, type, context);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!data.isEmpty()) {
            DocumentAdapter adapter = new DocumentAdapter(context, data);
            recyclerView.setAdapter(adapter);
        } else {
            empty_view.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.ViewHolder> {
        Context context;
        List<MediaModelData> data;

        DocumentAdapter(Context context, List<MediaModelData> data) {
            this.context = context;
            this.data = data;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.document_item, parent
                    , false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.icon.setImageResource(R.drawable.icon_file_unknown);
            holder.filename.setText(data.get(position).attachment);
            holder.file_type_tv.setText(FilenameUtils.getExtension(data.get(position).attachment));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }


        private class ViewHolder extends RecyclerView.ViewHolder {
            ImageView icon;
            TextView file_type_tv, filename;

            ViewHolder(View itemView) {
                super(itemView);

                icon = itemView.findViewById(R.id.icon);
                file_type_tv = itemView.findViewById(R.id.file_type_tv);
                filename = itemView.findViewById(R.id.filename);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MediaModelData message = data.get(getAbsoluteAdapterPosition());
                        openMedia(message);
                    }
                });
            }
        }

        private void openMedia(MediaModelData message) {
            String type = message.message_type;
            Uri fileUri = null;
            File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT_SENT, message.attachment, StorageManager.TAG_DOCUMENT);
            if (file != null) {
                fileUri = storageManager.getUriFromFile(file);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    fileUri = storageManager.getFileUri(StorageManager.TAG_DOCUMENT, message.attachment, StorageManager.TAG_DOCUMENT);
                } else {
                    file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, message.attachment, StorageManager.TAG_DOCUMENT);
                    if (file != null) {
                        fileUri = storageManager.getUriFromFile(file);
                    }
                }
            }

            if (fileUri != null) {
                openMediaIntent(fileUri);
            } else {
                showToast(context, context.getString(R.string.no_media));
            }
        }

        private void openMediaIntent(Uri fileUri) {
            try {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                MimeTypeMap mime = MimeTypeMap.getSingleton();
                String ext = storageManager.getExtension(fileUri);
                String mimeType = mime.getMimeTypeFromExtension(ext);
                intent.setDataAndType(fileUri, mimeType);
                context.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                showToast(context, context.getString(R.string.no_application));
                e.printStackTrace();
            }
        }

        void showToast(Context context, String text) {
            Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
        }
    }
}
