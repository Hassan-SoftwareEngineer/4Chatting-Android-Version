package com.app.helper;

import static android.Manifest.permission.READ_CONTACTS;
import static com.app.utils.Constants.TAG_CONTACT_STATUS;
import static com.app.utils.Constants.TAG_ID;
import static com.app.utils.Constants.TAG_MEMBER_ID;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.app.external.RandomString;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.WelcomeActivity;
import com.app.model.BlocksData;
import com.app.model.CallData;
import com.app.model.ChannelMessage;
import com.app.model.ChannelResult;
import com.app.model.GroupChatResult;
import com.app.model.GroupData;
import com.app.model.GroupInvite;
import com.app.model.MessagesData;
import com.app.model.OfflineStoryDeleteResponse;
import com.app.model.RecentChat;
import com.app.model.RecentGroupMessage;
import com.app.model.SaveMyContacts;
import com.app.model.StatusResult;
import com.google.gson.Gson;
import com.app.helper.event.NewMessageEvent;
import com.app.helper.workers.ChannelChatWorker;
import com.app.helper.workers.ChannelInvitationWorker;
import com.app.helper.workers.GroupChatReceivedWorker;
import com.app.helper.workers.MessageReceivedWorker;
import com.app.helper.workers.StoryDeletedWorker;
import com.app.helper.workers.StoryReceivedWorker;
import com.app.helper.workers.StoryViewedWorker;
import com.app.helper.workers.UserIsActiveWorker;
import com.app.fourchattingapp.R;
import com.app.model.AdminChannel;
import com.app.model.AdminChannelMsg;
import com.app.model.ChannelChatResult;
import com.app.model.ChannelInfoResponse;
import com.app.model.ContactsData;
import com.app.model.GroupMessage;
import com.app.model.RecentChatList;
import com.app.model.RecentMessages;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.onesignal.OSDeviceState;
import com.onesignal.OneSignal;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by hitasoft on 5/7/18.
 */

public class ForegroundService extends Service implements SocketConnection.ForegroundListener {

    private static final String TAG = ForegroundService.class.getSimpleName();
    public static boolean IS_SERVICE_RUNNING = false;
    Thread recentChatThread, getBlockThread, checkDevice, groupInvitesThread, recentGroupChatThread, saveContacts,
            recentCallThread, recentChannelChatThread, adminChannelThread, channelInvitesThread,
            offlineStoriesThread, offlineStoriesViewedThread, offlineStoryDeleteThread;
    ApiInterface apiInterface;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    NotificationManager mNotifyManager;
    NotificationCompat.Builder mBuilder;
    int count = 13;
    Context context = this;
    private DateUtils dateUtils;
    private Utils utils;
    private String from = null;
    private final ExecutorService mExecutorService = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        Log.v(TAG, "onCreate");
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        dateUtils = DateUtils.getInstance(this);
        utils = new Utils(this);
        startForegroundService();
    }

    private void startForegroundService() {
        String channelId = getString(R.string.notification_channel_foreground_service);
        CharSequence channelName = getString(R.string.app_name);
        int importance = NotificationManager.IMPORTANCE_LOW;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            notificationChannel.enableVibration(false);
            notificationChannel.setShowBadge(false);
            notificationChannel.setSound(null, null);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        mBuilder = new NotificationCompat.Builder(this, channelId);
        mBuilder.setContentTitle(getString(R.string.app_name))
                .setNumber(0)
                .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                .setContentText(getString(R.string.checking_new_messages))
                .setSmallIcon(R.drawable.notification);
        startForeground(1, mBuilder.build());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra(Constants.TAG_FROM)) {
            from = intent.getStringExtra(Constants.TAG_FROM);
        }
        if (intent != null && intent.getAction().equals("start")) {
            IS_SERVICE_RUNNING = true;
            Log.v(TAG, "Received Start Foreground Intent ");
            //Toast.makeText(this, "Service Started!", Toast.LENGTH_SHORT).show();
            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            dbhelper = DatabaseHandler.getInstance(this);
            SocketConnection.resetSocket();
            socketConnection = SocketConnection.getInstance(this);
            if (socketConnection != null) {
                socketConnection.setForegroundListener(this);
            }

            recentChatThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getRecentChats();
                }
            });
            recentChatThread.start();

            saveContacts = new Thread(new Runnable() {
                @Override
                public void run() {
                    if (checkCallPermission()) {
                        getContactTask();
                    }
                }
            });
            saveContacts.start();

            checkDevice = new Thread(new Runnable() {
                @Override
                public void run() {
                    checkDeviceInfo();
                }
            });
            checkDevice.start();

            getBlockThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getBlockStatus();
                }
            });
            getBlockThread.start();

            groupInvitesThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getGroupInvites();
                }
            });
            groupInvitesThread.start();

            recentCallThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    recentCalls();
                }
            });
            recentCallThread.start();

            recentChannelChatThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getRecentChannelChats();
                }
            });
            recentChannelChatThread.start();

            adminChannelThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getAdminChannels();
                }
            });
            adminChannelThread.start();

            channelInvitesThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getChannelInvites();
                }
            });
            channelInvitesThread.start();

            offlineStoriesThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getOfflineStories();
                }
            });
            offlineStoriesThread.start();

            offlineStoriesViewedThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    getRecentViewedStories();
                }
            });
            offlineStoriesViewedThread.start();
            offlineStoryDeleteThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    offlineDeletedStories();
                }
            });
            offlineStoryDeleteThread.start();

        } else if (intent == null || intent.getAction().equals("stop")) {
            stopForegroundService();
        }
        return START_STICKY;
    }

    private void stopService() {
        count--;
        Log.v(TAG, "stopService: " + count);
        if (count == 0) {
            stopForegroundService();
        }
    }

    private void stopForegroundService() {
        IS_SERVICE_RUNNING = false;
        Log.i(TAG, "Received Stop Foreground Intent");
        stopForeground(true);
        stopSelf();
        if (socketConnection != null)
            socketConnection.setForegroundListener(null);
    }

    void getRecentChats() {
        Call<RecentChatList> call = apiInterface.recentChats(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<RecentChatList>() {
            @Override
            public void onResponse(Call<RecentChatList> call, Response<RecentChatList> response) {
                if (response.isSuccessful()) {
                    RecentChatList data = response.body();
                    if (data.status.equals("true")) {
                        Map<String, RecentChat> result = data.result;
                        for (Map.Entry<String, RecentChat> chatEntry : result.entrySet()) {
                            RecentChat recentChat = chatEntry.getValue();
                            RecentMessages messagesData = recentChat.messagesData;
//                            Log.v(TAG, "recentChatsResponse: " + new Gson().toJson(messagesData));
                            if (messagesData.userId != null) {

                                MessagesData tempMessageData = Utils.getMessageData(GetSet.getUserId() + messagesData.userId, messagesData.messageId, messagesData.userId, "",
                                        messagesData.messageType, messagesData.message, messagesData.attachment, messagesData.lat, messagesData.lon, !TextUtils.isEmpty(messagesData.contactName) ? messagesData.contactName : "",
                                        !TextUtils.isEmpty(messagesData.contactPhoneNo) ? messagesData.contactPhoneNo : ((messagesData.phone != null) ? messagesData.phone : ""),
                                        messagesData.contactCountryCode, messagesData.chatTime, GetSet.getUserId(), messagesData.userId, "sent", messagesData.thumbnail,
                                        messagesData.statusData, "");
                                dbhelper.addMessageData(tempMessageData, false);

                                int unseenCount = dbhelper.getUnseenMessagesCount(messagesData.userId);
                                if (!TextUtils.isEmpty(messagesData.messageType) && messagesData.messageType.equals(Constants.TAG_ISDELETE)) {
                                    if (dbhelper.isRecentMessageIdExist(messagesData.messageId)) {
                                        dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.userId, messagesData.userId, messagesData.messageId, messagesData.chatTime, "" + unseenCount);
                                    }
                                } else {
                                    MessagesData lastMessage = dbhelper.getRecentMessage(messagesData.userId);
                                    if (lastMessage != null && !TextUtils.isEmpty(lastMessage.message_id)) {
                                        dbhelper.addRecentMessages(GetSet.getUserId() + lastMessage.user_id, lastMessage.user_id, lastMessage.message_id, lastMessage.chat_time, "" + unseenCount);
                                    } else {
                                        dbhelper.addRecentMessages(GetSet.getUserId() + messagesData.userId, messagesData.userId, messagesData.messageId, messagesData.chatTime, "" + unseenCount);
                                    }
                                }
                                chatReceived(messagesData);
                                if (!dbhelper.isUserExist(messagesData.userId)) {
                                    getUserProfile(messagesData);
                                } else {
                                    setMessagesListener(messagesData);
                                }
                            }
                        }
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<RecentChatList> call, Throwable t) {
                Log.e(TAG, "getRecentChats: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void setMessagesListener(RecentMessages mdata) {
        if (socketConnection != null) {
            socketConnection.setRecentListener(true);
        } else {
            EventBus.getDefault().post(new NewMessageEvent(null));
        }
    }

    void chatReceived(final RecentMessages mdata) {
        OneTimeWorkRequest chatReceivedRequest =
                new OneTimeWorkRequest.Builder(MessageReceivedWorker.class)
                        .setInputData(createInputData(mdata))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(chatReceivedRequest);
    }

    private Data createInputData(final RecentMessages messagesData) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_SENDER_ID, messagesData.senderId);
        builder.putString(Constants.TAG_RECEIVER_ID, messagesData.receiverId);
        builder.putString(Constants.TAG_MESSAGE_ID, messagesData.messageId);
        return builder.build();
    }

    void getUserProfile(final RecentMessages mdata) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), mdata.userId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
//                    Log.v(TAG, "getUserProfile: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String savedName = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            savedName = map.get(Constants.TAG_USER_NAME);
                        }
                        ContactsData.Result result = new ContactsData().new Result();
                        result.user_id = userdata.get(Constants.TAG_ID);
                        result.user_name = userdata.get(Constants.TAG_USER_NAME);
                        result.saved_name = savedName;
                        result.phone_no = userdata.get(Constants.TAG_PHONE_NUMBER);
                        result.country_code = userdata.get(Constants.TAG_COUNTRY_CODE);
                        result.user_image = userdata.get(Constants.TAG_USER_IMAGE);
                        result.privacy_about = userdata.get(Constants.TAG_PRIVACY_ABOUT);
                        result.privacy_last_seen = userdata.get(Constants.TAG_PRIVACY_LAST_SEEN);
                        result.privacy_profile_image = userdata.get(Constants.TAG_PRIVACY_PROFILE);
                        result.about = userdata.get(Constants.TAG_ABOUT);
                        result.contactstatus = userdata.get(Constants.TAG_CONTACT_STATUS);
                        result.isDeletedAccount = "" + 0;
                        result.isUnknownContact = "" + 1;
                        dbhelper.addContactDetails(savedName, result);
                        setMessagesListener(mdata);
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.v("Contacts Failed", "TEST" + t.getMessage());
                call.cancel();
            }
        });

    }

    @Override
    public void onChatBoxJoined() {
        if (GetSet.getUserId() != null) {
            ApplicationClass.groupList = dbhelper.getGroupIdList();
            ApplicationClass.channelList = dbhelper.getChannelIdList();
            if (socketConnection != null) socketConnection.goLive();
        }
    }

    private void getContactTask() {
        mExecutorService.execute(new Runnable() {
            public void run() {
                List<String> myContacts = new ArrayList<>();
                myContacts = utils.getMyContactList(context);
                Log.e(TAG, "getContactList: " + myContacts.size());
                saveMyContacts(myContacts);
            }
        });
    }

    void saveMyContacts(List<String> myContacts) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, "" + myContacts);
//        Log.v(TAG, "saveMyContacts: " + new Gson().toJson(myContacts));
        Call<SaveMyContacts> call = apiInterface.saveMyContacts(GetSet.getToken(), map);
        call.enqueue(new Callback<SaveMyContacts>() {
            @Override
            public void onResponse(Call<SaveMyContacts> call, Response<SaveMyContacts> response) {
                updateMyContacts(myContacts);
            }

            @Override
            public void onFailure(Call<SaveMyContacts> call, Throwable t) {
                Log.e(TAG, "saveMyContacts: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void updateMyContacts(List<String> myContacts) {
        List<String> contacts = new ArrayList<>();
        contacts = dbhelper.getAllContactsNumber(this);
        for (String contact : contacts) {
            if (!myContacts.contains(contact)) {
                myContacts.add(contact.replaceAll("[^0-9]", ""));
            }
        }
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_CONTACTS, "" + myContacts);
        map.put(Constants.TAG_PHONE_NUMBER, GetSet.getphonenumber());
        Log.d(TAG, "updateMyContacts: " + new Gson().toJson(map));
        Call<ContactsData> call3 = apiInterface.updateMyContacts(GetSet.getToken(), map);
        call3.enqueue(new Callback<ContactsData>() {
            @Override
            public void onResponse(Call<ContactsData> call, Response<ContactsData> response) {
                if (response.isSuccessful()) {
                    ContactsData data = response.body();
                    if (data.status.equals("true")) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                new UpdateContactTask(data).execute();
                            }
                        });
                    } else {
                        stopService();
                    }
                } else {
                    stopService();
                }
            }

            @Override
            public void onFailure(Call<ContactsData> call, Throwable t) {
                Log.e(TAG, "updateMyContacts: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class UpdateContactTask extends AsyncTask<Void, Integer, Void> {
        ContactsData data = new ContactsData();
        List<String> tempContacts = new ArrayList<>();

        public UpdateContactTask(ContactsData data) {
            this.data = data;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            tempContacts.add(GetSet.getUserId());
            for (ContactsData.Result result : data.result) {
//                Log.i(TAG, "doInBackground: " + new Gson().toJson(data.result));
                if (!result.user_id.equals(GetSet.getUserId())) {
                    tempContacts.add(result.user_id);
                }
                String name = "";
                HashMap<String, String> map;
                map = ApplicationClass.getContactOrNot(getApplicationContext(), result.phone_no);
                if (map.get("isAlready").equals("true")) {
                    name = map.get(Constants.TAG_USER_NAME);
                }
                result.isDeletedAccount = "0";
                result.isUnknownContact = "0";
                dbhelper.addContactDetails(name, result);
            }
            if (socketConnection != null) {
                socketConnection.setRecentListener();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            updateDeletedContacts(tempContacts);
            stopService();
        }
    }

    private void updateDeletedContacts(List<String> tempContacts) {
        String array = null;
        array = String.join(",", tempContacts).replaceAll("([^,]+)", "\"$1\"");
//        Log.d(TAG, "updateDeletedContacts: " + array);
        dbhelper.updateDeletedContacts(context, array);
    }

    private void getDuplicateContacts() {
        List<ContactsData.Result> duplicateList = dbhelper.getDuplicateContacts(context);
        for (ContactsData.Result result : duplicateList) {
            checkUserIsActive(result);
        }
    }

    private void checkUserIsActive(ContactsData.Result result) {
        OneTimeWorkRequest userActiveRequest =
                new OneTimeWorkRequest.Builder(UserIsActiveWorker.class)
                        .setInputData(createUserInputData(result))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(userActiveRequest);
    }

    private Data createUserInputData(ContactsData.Result result) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, result.user_id);
        return builder.build();
    }

    void getBlockStatus() {
        Call<BlocksData> call = apiInterface.getblockstatus(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<BlocksData>() {
            @Override
            public void onResponse(Call<BlocksData> call, Response<BlocksData> response) {
                try {
                    Log.v(TAG, "getBlockStatusRes: " + response.isSuccessful() + " " + new Gson().toJson(response.body()));
                    BlocksData data = response.body();
                    if (data.status != null && data.status.equals("true")) {
                        ArrayList<BlocksData.Blockedme> blockedme = data.blockedme;
                        if (blockedme.size() == 0) {
                            dbhelper.resetAllBlockStatus(Constants.TAG_BLOCKED_ME);
                        } else {
                            for (int i = 0; i < blockedme.size(); i++) {
                                BlocksData.Blockedme block = blockedme.get(i);
                                dbhelper.updateBlockStatus(block.user_id, Constants.TAG_BLOCKED_ME, "block");
                            }
                        }

                        ArrayList<BlocksData.Blockedbyme> blockedbyme = data.blockedbyme;
                        if (blockedbyme.size() == 0) {
                            dbhelper.resetAllBlockStatus(Constants.TAG_BLOCKED_BYME);
                        } else {
                            for (int i = 0; i < blockedbyme.size(); i++) {
                                BlocksData.Blockedbyme block = blockedbyme.get(i);
                                dbhelper.updateBlockStatus(block.buser_id, Constants.TAG_BLOCKED_BYME, "block");
                            }
                        }
                    } else {

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

                stopService();
            }

            @Override
            public void onFailure(Call<BlocksData> call, Throwable t) {
                Log.v(TAG, "getBlockStatus: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    void checkDeviceInfo() {
        if (NetworkStatus.isConnected()) {
            final String deviceId = android.provider.Settings.Secure.getString(getApplicationContext().getContentResolver(),
                    android.provider.Settings.Secure.ANDROID_ID);

            Map<String, String> map = new HashMap<>();
            map.put("user_id", GetSet.getUserId());
            map.put("device_id", deviceId);
            Call<Map<String, String>> call3 = apiInterface.getDeviceInfo(GetSet.getToken(), map);
            call3.enqueue(new Callback<Map<String, String>>() {
                @Override
                public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                    if (response.isSuccessful()) {
                        Map<String, String> data = response.body();
                        if (data.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                            if (from == null || !from.equals("login")) {
                                addDeviceId();
                            }
                        } else {
                            logout();
                        }
                    } else {
                        logout();
                    }
                    stopService();
                }

                @Override
                public void onFailure(Call<Map<String, String>> call, Throwable t) {
                    call.cancel();
                    stopService();
                }
            });
        } else {
            stopService();
        }
    }

    private void addDeviceId() {
        OSDeviceState deviceState = OneSignal.getDeviceState();
        if (deviceState != null) {
            String oneSignalId = deviceState.getUserId();
            sendTokenToServer(oneSignalId);
        }
    }

    private void sendTokenToServer(String oneSignalId) {
        final String deviceId = android.provider.Settings.Secure.getString(getContentResolver(),
                android.provider.Settings.Secure.ANDROID_ID);

        Map<String, String> map = new HashMap<>();
        map.put("user_id", GetSet.getUserId());
        map.put("device_type", "1");
        map.put("device_id", deviceId);
        if (!TextUtils.isEmpty(oneSignalId)) {
            map.put("device_token", oneSignalId);
            map.put("onesignal_id", oneSignalId);
        }

        Log.d(TAG, "sendTokenToServer: " + new Gson().toJson(map));
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call = apiInterface.pushsignin(GetSet.getToken(), map);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                Map<String, String> data = response.body();
                if (response.isSuccessful()) {
                    if (!data.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
//                        makeToast(data.get(Constants.TAG_MESSAGE));
                        logout();
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
                Log.e(TAG, "addDeviceId: " + t.getMessage());
            }
        });
    }

    private void logout() {
        GetSet.logout();
        SharedPreferences settings = getSharedPreferences("SavedPref", Context.MODE_PRIVATE);
        settings.edit().clear().apply();
        Intent logout = new Intent(getApplicationContext(), WelcomeActivity.class);
        logout.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(logout);
    }

    private void getGroupInvites() {
        final ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GroupInvite> call = apiInterface.getGroupInvites(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<GroupInvite>() {
            @Override
            public void onResponse(Call<GroupInvite> call, Response<GroupInvite> response) {
                if (response.isSuccessful()) {
                    GroupInvite groupInvite = response.body();
                    if (groupInvite.status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        Map<String, GroupData> userdata = groupInvite.result;
                        for (Map.Entry<String, GroupData> groupDataEntry : userdata.entrySet()) {
                            GroupData groupData = groupDataEntry.getValue();
                            if (!dbhelper.isGroupExist(groupData.groupId)) {
                                dbhelper.createGroup(groupData.groupId, groupData.groupAdminId,
                                        groupData.groupName, groupData.createdAt, groupData.groupImage);
                                addGroupId(groupData.groupId);

                                for (GroupData.GroupMembers groupMember : groupData.groupMembers) {
                                    if (!dbhelper.isUserExist(groupMember.memberId)) {
                                        String memberKey = groupData.groupId + groupMember.memberId;
                                        getUserData(memberKey, groupData.groupId, groupMember.memberId, groupMember.memberRole);
                                    } else {
                                        String memberKey = groupData.groupId + groupMember.memberId;
                                        dbhelper.createGroupMembers(memberKey, groupData.groupId, groupMember.memberId,
                                                groupMember.memberRole);
                                    }
                                }

                                String currentUTCTime = DateUtils.getInstance(context).getCurrentUTCTime();
                                RandomString randomString = new RandomString(10);
                                String messageId = groupData.groupId + randomString.nextString();

                                dbhelper.addGroupMessages(messageId, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "create_group",
                                        "", "", "", "", "", "", "",
                                        groupData.createdAt, "", groupData.groupAdminId.equals(GetSet.getUserId()) ? "read" : "");
                                int unseenCount = dbhelper.getUnseenGroupMessagesCount(groupData.groupId);
                                dbhelper.addGroupRecentMsg(groupData.groupId, messageId, GetSet.getUserId(), currentUTCTime, "" + unseenCount);

                                if (!groupData.groupAdminId.equals(GetSet.getUserId())) {
                                    String messageId2 = groupData.groupId + randomString.nextString();
                                    dbhelper.addGroupMessages(messageId2, groupData.groupId, GetSet.getUserId(), groupData.groupAdminId, "add_member",
                                            "", "", "", "",
                                            "", "", "", groupData.createdAt, "", "");
                                    unseenCount = dbhelper.getUnseenGroupMessagesCount(groupData.groupId);
                                    dbhelper.addGroupRecentMsg(groupData.groupId, messageId, GetSet.getUserId(), currentUTCTime, "" + unseenCount);
                                }
                            }
                            try {
                                JSONObject jobj = new JSONObject();
                                jobj.put(Constants.TAG_GROUP_ID, groupData.groupId);
                                jobj.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                                if (socketConnection != null)
                                    socketConnection.joinGroup(jobj);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if (socketConnection != null)
                                socketConnection.clearGroupInvitations(groupData.groupId);
                        }
                        if (socketConnection != null)
                            socketConnection.setRecentGroupListener();
                    }
                    getGroupChats();
                } else {
                    getGroupChats();
                }
            }

            @Override
            public void onFailure(Call<GroupInvite> call, Throwable t) {
                Log.e(TAG, "getGroupInvitesFailure: " + t.getMessage());
                call.cancel();
                getGroupChats();
            }
        });
    }

    private void getGroupChats() {
        stopService();
        recentGroupChatThread = new Thread(new Runnable() {
            @Override
            public void run() {
                recentGroupChats();
            }
        });
        recentGroupChatThread.start();
    }

    private void addGroupId(String groupId) {
        if (!ApplicationClass.groupList.contains(groupId)) {
            ApplicationClass.groupList.add(groupId);
            if (socketConnection != null)
                socketConnection.goLive();
        }
    }

    private void removeGroupId(String groupId) {
        if (ApplicationClass.groupList.contains(groupId)) {
            ApplicationClass.groupList.remove(groupId);
            if (socketConnection != null)
                socketConnection.goLive();
        }
    }

    void recentGroupChats() {
        Call<GroupChatResult> call = apiInterface.getRecentGroupChats(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<GroupChatResult>() {
            @Override
            public void onResponse(Call<GroupChatResult> call, Response<GroupChatResult> response) {
                if (response.isSuccessful()) {
                    Log.e("checkGroupRect", "-" + new Gson().toJson(response.body()));
                    GroupChatResult data = response.body();
                    if (data.status.equals("true")) {
                        Map<String, GroupMessage> groupData = data.result;
                        for (Map.Entry<String, GroupMessage> groupMessageEntry : groupData.entrySet()) {
                            GroupMessage mdata = groupMessageEntry.getValue();
                            if (mdata.memberId != null) {
                                switch (mdata.messageType) {
                                    case "subject":
                                        dbhelper.updateGroupData(mdata.groupId, Constants.TAG_GROUP_NAME, mdata.groupName);
                                        if (socketConnection != null)
                                            socketConnection.updateGroupInfo(mdata);
                                        break;
                                    case "group_image":
                                        dbhelper.updateGroupData(mdata.groupId, Constants.TAG_GROUP_IMAGE, mdata.attachment);
                                        if (socketConnection != null)
                                            socketConnection.updateGroupInfo(mdata);
                                        break;
                                    case Constants.TAG_GROUP_JOINED:
                                        if (mdata.memberId.equals(GetSet.getUserId())) {
                                            mdata.message = context.getString(R.string.you) + " " + context.getString(R.string.group_joined_description);
                                        } else {
                                            mdata.message = mdata.memberName + " " + context.getString(R.string.group_joined_description);
                                        }
                                        dbhelper.updateGroupMembers(mdata.groupId + mdata.memberId, mdata.groupId, mdata.memberId, mdata.attachment);
                                        if (socketConnection != null)
                                            socketConnection.updateGroupInfo(mdata);
                                        break;
                                    case "add_member":
                                        if (!TextUtils.isEmpty(mdata.attachment)) {
                                            try {
                                                JSONArray jsonArray = new JSONArray(mdata.attachment);
                                                for (int i = 0; i < jsonArray.length(); i++) {
                                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                                    String memberId = jsonObject.getString(Constants.TAG_MEMBER_ID);
                                                    String memberRole = jsonObject.getString(Constants.TAG_MEMBER_ROLE);
                                                    if (!dbhelper.isUserExist(memberId)) {
                                                        String memberKey = mdata.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                                        getUserData(memberKey, mdata.groupId, memberId, memberRole);
                                                    } else {
                                                        String memberKey = mdata.groupId + jsonObject.getString(TAG_MEMBER_ID);
                                                        dbhelper.updateGroupMembers(memberKey, mdata.groupId, memberId, memberRole);
                                                    }
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        if (socketConnection != null)
                                            socketConnection.updateGroupInfo(mdata);
                                        break;
                                    case "left":
                                    case "remove_member":
                                        dbhelper.deleteFromGroup(mdata.groupId, mdata.memberId);
                                        removeGroupId(mdata.groupId);
                                        if (socketConnection != null)
                                            socketConnection.updateGroupInfo(mdata);
                                        break;
                                    case "admin":
                                        if (!dbhelper.isUserExist(mdata.memberId)) {
                                            String memberKey = mdata.groupId + mdata.memberId;
                                            getUserData(memberKey, mdata.groupId, mdata.memberId, mdata.attachment);
                                        } else {
                                            String memberKey = mdata.groupId + mdata.memberId;
                                            dbhelper.updateGroupMembers(memberKey, mdata.groupId, mdata.memberId, mdata.attachment);
                                        }
                                        break;
                                    case "change_number":
                                        dbhelper.updateContactInfo(mdata.memberId, Constants.TAG_COUNTRY_CODE, mdata.contactCountryCode);
                                        dbhelper.updateContactInfo(mdata.memberId, Constants.TAG_PHONE_NUMBER, mdata.contactPhoneNo);
                                        break;
                                }

                                if (mdata.memberId.equalsIgnoreCase(GetSet.getUserId()) && (mdata.messageType.equals("text") || mdata.messageType.equals("link") || mdata.messageType.equals("image") ||
                                        mdata.messageType.equals("audio") || mdata.messageType.equals("video") || mdata.messageType.equals("document") ||
                                        mdata.messageType.equals("location") || mdata.messageType.equals("contact"))) {


                                } else if (!mdata.memberId.equalsIgnoreCase(GetSet.getUserId()) && mdata.messageType.equals("admin")) {

                                } else if (mdata.messageType.equalsIgnoreCase("remove_member") && (!dbhelper.isUserExist(mdata.memberId))) {

                                } else {

                                    dbhelper.addGroupMessages(mdata.messageId, mdata.groupId, mdata.memberId, mdata.groupAdminId, mdata.messageType,
                                            mdata.message, mdata.attachment, mdata.lat, mdata.lon,
                                            mdata.contactName, mdata.contactPhoneNo, mdata.contactCountryCode, mdata.chatTime, mdata.thumbnail, "");

                                    int unseenCount = dbhelper.getUnseenGroupMessagesCount(mdata.groupId);
                                    GroupMessage lastMessage = dbhelper.getRecentGroupMessage(mdata.groupId);
                                    if (lastMessage != null && !TextUtils.isEmpty(lastMessage.messageId)) {
                                        Log.d(TAG, "addGroupRecentMsg: " + ApplicationClass.decryptMessage(lastMessage.message));
                                        dbhelper.addGroupRecentMsg(lastMessage.groupId, lastMessage.messageId, lastMessage.memberId, lastMessage.chatTime, "" + unseenCount);
                                    } else {
                                        dbhelper.addGroupRecentMsg(mdata.groupId, mdata.messageId,
                                                mdata.memberId, mdata.chatTime, "" + unseenCount);
                                    }
//                                    dbhelper.addGroupRecentMsg(mdata.groupId, mdata.messageId,
//                                            mdata.memberId, mdata.chatTime, String.valueOf(unseenCount));
                                }
                                groupChatReceived(mdata);
                            }
                        }
                        if (socketConnection != null)
                            socketConnection.setRecentGroupListener();
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<GroupChatResult> call, Throwable t) {
                Log.e(TAG, "recentGroupChats: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private GroupMessage getGroupMessages(RecentGroupMessage recentGroupMessage) {
        GroupMessage mdata = new GroupMessage();
        mdata.attachment = recentGroupMessage.attachment.toString();
        mdata.chatTime = recentGroupMessage.chatTime;
        mdata.groupId = recentGroupMessage.groupId;
        mdata.groupAdminId = recentGroupMessage.groupAdminId;
        mdata.contactCountryCode = recentGroupMessage.contactCountryCode;
        mdata.contactName = recentGroupMessage.contactName;
        mdata.contactPhoneNo = recentGroupMessage.contactPhoneNo;
        mdata.createdAt = recentGroupMessage.createdAt;
        mdata.deliveryStatus = recentGroupMessage.deliveryStatus;
        mdata.groupImage = recentGroupMessage.groupImage;
        mdata.groupName = recentGroupMessage.groupName;
        mdata.isDelete = recentGroupMessage.isDelete;
        mdata.lat = recentGroupMessage.lat;
        mdata.lon = recentGroupMessage.lon;
        mdata.memberId = recentGroupMessage.memberId;
        mdata.memberName = recentGroupMessage.memberName;
        mdata.memberNo = recentGroupMessage.memberNo;
        mdata.messageId = recentGroupMessage.messageId;
        mdata.message = recentGroupMessage.message;
        mdata.messageType = recentGroupMessage.messageType;
        mdata.progress = recentGroupMessage.progress;
        mdata.thumbnail = recentGroupMessage.thumbnail;
        return mdata;
    }

    private void groupChatReceived(GroupMessage message) {
        OneTimeWorkRequest chatReceivedRequest =
                new OneTimeWorkRequest.Builder(GroupChatReceivedWorker.class)
                        .setInputData(createGroupInputData(message))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(chatReceivedRequest);
    }

    private Data createGroupInputData(GroupMessage message) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_MESSAGE_ID, message.messageId);
        return builder.build();
    }

    void recentCalls() {
        Call<CallData> call3 = apiInterface.recentCalls(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<CallData>() {
            @Override
            public void onResponse(Call<CallData> call, Response<CallData> response) {
                try {
                    Log.v(TAG, "recentCallsResponse: " + new Gson().toJson(response.body()));
                    CallData data = response.body();
                    if (response.isSuccessful()) {
                        if (data != null && data.status.equals("true")) {
                            for (CallData.Result result : data.result) {
                                if (result.messageData != null) {
                                    if (result.messageData.callerId != null) {
                                        String isAlert = "1";
                                        if (result.messageData.callStatus.equals(Constants.TAG_MISSED)) {
                                            isAlert = "0";
                                        }
                                        dbhelper.addRecentCall(result.messageData.callId, result.messageData.callerId,
                                                result.messageData.type, result.messageData.callStatus, result.messageData.createdAt, isAlert);
                                        if (!dbhelper.isUserExist(result.messageData.callerId)) {
//                                            getUserInfo(result.messageData.callerId);
                                        }
                                    }
                                } else {
                                    if (result.callerId != null) {
                                        String isAlert = "1";
                                        if (result.callStatus.equals("missed")) {
                                            isAlert = "0";
                                        }
                                        dbhelper.addRecentCall(result.callId, result.callerId, result.type, result.callStatus, result.createdAt, isAlert);
                                        if (!dbhelper.isUserExist(result.callerId)) {
//                                            getUserInfo(result.callerId);
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                stopService();
            }

            @Override
            public void onFailure(Call<CallData> call, Throwable t) {
                Log.v("Contacts Failed", "TEST" + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void getChannelInvites() {
        Call<ChannelResult> call = apiInterface.getRecentChannelInvites(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<ChannelResult>() {
            @Override
            public void onResponse(Call<ChannelResult> call, Response<ChannelResult> response) {
                if (response.isSuccessful()) {
                    if (response.body() != null && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        ChannelResult data = response.body();
                        Map<String, ChannelResult.Result> channelData = data.result;
                        for (Map.Entry<String, ChannelResult.Result> groupMessageEntry : channelData.entrySet()) {
                            ChannelResult.Result result = groupMessageEntry.getValue();
                            dbhelper.addChannel(result.channelId, result.channelName, result.channelDes,
                                    result.channelImage, result.channelType, result.adminId,
                                    result.channelAdminName, result.totalSubscribers, result.createdTime,
                                    Constants.TAG_USER_CHANNEL, "", result.blockStatus, result.report);
                            if (!dbhelper.isChannelIdExistInMessages(result.channelId)) {
                                String currentUTCTime = DateUtils.getInstance(context).getCurrentUTCTime();
                                RandomString randomString = new RandomString(10);
                                String messageId = result.channelId + randomString.nextString();
                                dbhelper.addChannelMessages(result.channelId, Constants.TAG_CHANNEL, messageId, "create_channel",
                                        "", "", "", "", "", "", "",
                                        currentUTCTime, "", "");

                                int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                                dbhelper.addChannelRecentMsgs(result.channelId, messageId, currentUTCTime, "" + unseenCount);
                            }
                            channelInviteReceived(result);
                        }
                        if (socketConnection != null)
                            socketConnection.setRecentChannelChatListener();
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<ChannelResult> call, Throwable t) {
                Log.e(TAG, "getChannelInvites: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void channelInviteReceived(ChannelResult.Result result) {
        OneTimeWorkRequest chatReceivedRequest =
                new OneTimeWorkRequest.Builder(ChannelInvitationWorker.class)
                        .setInputData(createChannelInviteData(result))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(chatReceivedRequest);
    }

    private Data createChannelInviteData(ChannelResult.Result result) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_CHANNEL_ID, result.channelId);
        return builder.build();
    }

    private void getRecentChannelChats() {
        Call<ChannelChatResult> call = apiInterface.recentChannelChats(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<ChannelChatResult>() {
            @Override
            public void onResponse(Call<ChannelChatResult> call, Response<ChannelChatResult> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        HashMap<String, ChannelMessage> channelData = response.body().result;
                        for (Map.Entry<String, ChannelMessage> channelEntry : channelData.entrySet()) {
                            ChannelMessage channelMessage = channelEntry.getValue();
                            if (!dbhelper.isChannelExist(channelMessage.channelId)) {
                                getChannelInfo(channelMessage);
                            } else {
                                addChannelMessages(channelMessage);
                                channelChatReceived(channelMessage);
                            }
                        }
                        if (socketConnection != null)
                            socketConnection.setRecentChannelChatListener();
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<ChannelChatResult> call, Throwable t) {
                Log.e(TAG, "getRecentChannelChats: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void channelChatReceived(ChannelMessage channelMessage) {
        OneTimeWorkRequest chatReceivedRequest =
                new OneTimeWorkRequest.Builder(ChannelChatWorker.class)
                        .setInputData(createChannelChatData(channelMessage))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(chatReceivedRequest);
    }

    private Data createChannelChatData(ChannelMessage channelMessage) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_CHANNEL_ID, channelMessage.channelId);
        builder.putString(Constants.TAG_MESSAGE_ID, channelMessage.messageId);
        return builder.build();
    }

    private void addChannelMessages(ChannelMessage channelMessage) {
        dbhelper.addChannelMessages(channelMessage.channelId, channelMessage.chatType, channelMessage.messageId,
                channelMessage.messageType, channelMessage.message, channelMessage.attachment, channelMessage.lat, channelMessage.lon,
                channelMessage.contactName, channelMessage.contactPhoneNo, channelMessage.contactCountryCode,
                channelMessage.chatTime, channelMessage.thumbnail != null ? channelMessage.thumbnail : "", "");

        int unseenCount = dbhelper.getUnseenChannelMessagesCount(channelMessage.channelId);
        ChannelMessage lastMessage = dbhelper.getRecentChannelMessage(channelMessage.channelId);
        if (lastMessage != null && !TextUtils.isEmpty(lastMessage.messageId)) {
            Log.d(TAG, "addChannelRecentMsg: " + ApplicationClass.decryptMessage(lastMessage.message));
            dbhelper.addChannelRecentMsgs(lastMessage.channelId, lastMessage.messageId, lastMessage.chatTime, "" + unseenCount);
        } else {
            dbhelper.addChannelRecentMsgs(channelMessage.channelId, channelMessage.messageId, channelMessage.chatTime, "" + unseenCount);
        }
//        dbhelper.addChannelRecentMsgs(channelMessage.channelId, channelMessage.messageId, channelMessage.chatTime, "" + unseenCount);
    }

    private void getChannelInfo(ChannelMessage channelMessage) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(channelMessage.channelId);
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<ChannelInfoResponse> call = apiInterface.getChannelInfo(GetSet.getToken(), jsonArray);
        call.enqueue(new Callback<ChannelInfoResponse>() {
            @Override
            public void onResponse(Call<ChannelInfoResponse> call, Response<ChannelInfoResponse> response) {
                if (response.isSuccessful() && response.body().status != null && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                    ChannelInfoResponse data = response.body();
                    for (ChannelResult.Result result : data.result) {
                        dbhelper.addChannel(result.channelId, result.channelName, result.channelDes, result.channelImage,
                                result.channelType, result.channelAdminId, result.channelAdminName, result.totalSubscribers, result.createdAt, Constants.TAG_USER_CHANNEL,
                                "true", result.blockStatus, result.report);
                        addChannelMessages(channelMessage);
                        channelChatReceived(channelMessage);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChannelInfoResponse> call, Throwable t) {
                Log.e(TAG, "getChannelInfo: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getAdminChannels() {
        Call<AdminChannel> call3 = apiInterface.getAdminChannels(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<AdminChannel>() {
            @Override
            public void onResponse(Call<AdminChannel> call, Response<AdminChannel> response) {
                if (response.isSuccessful() && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                    /*Get Channels from Admin*/
                    for (AdminChannel.Result result : response.body().result) {
                        dbhelper.addChannel(result.channelId, result.channelName, result.channelDes,
                                result.channelImage, Constants.TAG_PUBLIC, "", "", "",
                                result.createdAt, Constants.TAG_ADMIN_CHANNEL, "", "", "0");
                        if (!dbhelper.isChannelIdExistInMessages(result.channelId)) {
                            String currentUTCTime = DateUtils.getInstance(context).getCurrentUTCTime();
                            RandomString randomString = new RandomString(10);
                            String messageId = result.channelId + randomString.nextString();
                            dbhelper.addChannelMessages(result.channelId, Constants.TAG_ADMIN_CHANNEL, messageId, "create_channel",
                                    "", "", "", "", "", "", "",
                                    currentUTCTime, "", "");

                            int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                            dbhelper.addChannelRecentMsgs(result.channelId, messageId, currentUTCTime, "" + unseenCount);
                        }
                    }

                    /*Get the last recent message form db*/
                    HashMap<String, String> hashMap = dbhelper.getRecentChannelMsg();
                    if (hashMap.containsKey(Constants.TAG_CHANNEL_ID) && hashMap.get(Constants.TAG_CHANNEL_ID) != null) {
                        getMsgFromAdminChannels(hashMap.get(Constants.TAG_CHAT_TIME));
                    } else {
                        getMsgFromAdminChannels(DateUtils.getInstance(context).getCurrentUTCTime());
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<AdminChannel> call, Throwable t) {
                Log.e(TAG, "getAdminChannels: " + t.getMessage());
                call.cancel();
                stopService();
            }
        });
    }

    private void getMsgFromAdminChannels(String timeStamp) {
        Call<AdminChannelMsg> call3 = apiInterface.getMsgFromAdminChannels(GetSet.getToken(), timeStamp);
        call3.enqueue(new Callback<AdminChannelMsg>() {
            @Override
            public void onResponse(Call<AdminChannelMsg> call, Response<AdminChannelMsg> response) {
                if (response.body() != null && response.body().status.equalsIgnoreCase(Constants.TAG_TRUE) && response.body().result != null) {
                    for (AdminChannelMsg.Result result : response.body().result) {
                        if (dbhelper.isChannelExist(result.channelId)) {
                            if (!dbhelper.isChannelMessageIdExist(result.messageId)) {
                                dbhelper.addChannelMessages(result.channelId, Constants.TAG_ADMIN_CHANNEL, result.messageId, result.messageType,
                                        result.message, result.attachment, "", "",
                                        "", "", "",
                                        result.messageDate, result.thumbnail, "");

                                int unseenCount = dbhelper.getUnseenChannelMessagesCount(result.channelId);
                                dbhelper.addChannelRecentMsgs(result.channelId, result.messageId, result.messageDate, "" + unseenCount);
                            }
                        }
                    }
                    if (socketConnection != null)
                        socketConnection.setRecentChannelChatListener();
                }
            }

            @Override
            public void onFailure(Call<AdminChannelMsg> call, Throwable t) {
//                Log.e(TAG, "getMsgFromAdminChannels: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getUserData(String memberKey, String groupId, String memberId, String
            memberRole) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE),
                                userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(TAG_CONTACT_STATUS));
                        dbhelper.createGroupMembers(memberKey, groupId, memberId, memberRole);
                    }
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.v(TAG, "getUserData Failed" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getUserInfo(String memberId) {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.getUserProfile(GetSet.getToken(), GetSet.getphonenumber(), memberId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                try {
//                    Log.v(TAG, "getUserInfo: " + new Gson().toJson(response.body()));
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String name = "";
                        HashMap<String, String> map = ApplicationClass.getContactOrNot(getApplicationContext(), userdata.get(Constants.TAG_PHONE_NUMBER));
                        if (map.get("isAlready").equals("true")) {
                            name = map.get(Constants.TAG_USER_NAME);
                        }
                        dbhelper.addContactDetails(name, userdata.get(Constants.TAG_ID), userdata.get(Constants.TAG_USER_NAME), userdata.get(Constants.TAG_PHONE_NUMBER), userdata.get(Constants.TAG_COUNTRY_CODE), userdata.get(Constants.TAG_USER_IMAGE),
                                userdata.get(Constants.TAG_PRIVACY_ABOUT), userdata.get(Constants.TAG_PRIVACY_LAST_SEEN), userdata.get(Constants.TAG_PRIVACY_PROFILE), userdata.get(Constants.TAG_ABOUT), userdata.get(Constants.TAG_CONTACT_STATUS));

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                Log.v("Contacts Failed", "TEST" + t.getMessage());
                call.cancel();
            }
        });
    }

    private void getOfflineStories() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<StatusResult> call3 = apiInterface.getOfflineStories(GetSet.getToken(), GetSet.getUserId());
        call3.enqueue(new Callback<StatusResult>() {
            @Override
            public void onResponse(Call<StatusResult> call, Response<StatusResult> response) {
                if (response.isSuccessful()) {
                    StatusResult statusResult = response.body();
                    if (statusResult.status.equals("true")) {
                        Set<Map.Entry<String, StatusResult.Result>> resultData = statusResult.result.entrySet();
                        for (Map.Entry<String, StatusResult.Result> resultEntry : resultData) {
                            StatusResult.Result result = resultEntry.getValue();
                            if (dbhelper.isUserExist(result.senderId) && !dbhelper.isStoryExists(result.storyId)) {
                                dbhelper.createStatus(result.storyId, result.storyTime, result.storyType, result.senderId,
                                        result.attachment, result.message, "0", result.thumbnail, result.expiryTime,
                                        TextUtils.join(",", result.storyMembers));
                                storyReceived(result);
                                if (socketConnection != null)
                                    socketConnection.onStoryReceived();
                            }
                        }
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<StatusResult> call, Throwable t) {
                t.printStackTrace();
                call.cancel();
                stopService();
            }
        });
    }

    private void storyReceived(StatusResult.Result statusResult) {
        OneTimeWorkRequest chatReceivedRequest =
                new OneTimeWorkRequest.Builder(StoryReceivedWorker.class)
                        .setInputData(createStoryData(statusResult))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(chatReceivedRequest);
    }

    private Data createStoryData(StatusResult.Result statusResult) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_STORY_ID, statusResult.storyId);
        return builder.build();
    }

    private void getRecentViewedStories() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<StatusResult> call = apiInterface.getRecentViewedStories(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<StatusResult>() {
            @Override
            public void onResponse(Call<StatusResult> call, Response<StatusResult> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equals(Constants.TAG_TRUE)) {
                        HashMap<String, StatusResult.Result> resultData = response.body().result;
                        for (Map.Entry<String, StatusResult.Result> resultEntry : resultData.entrySet()) {
                            StatusResult.Result result = resultEntry.getValue();
                            if (dbhelper.isStoryExists(result.storyId)) {
                                dbhelper.createStatusView(result.storyId, result.senderId);
                                if (socketConnection != null)
                                    socketConnection.onStoryViewed(result.storyId);
                            }
                            storyViewed(result);
                        }
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<StatusResult> call, Throwable t) {
                t.printStackTrace();
                call.cancel();
                stopService();
            }
        });
    }

    private void storyViewed(StatusResult.Result statusResult) {
        OneTimeWorkRequest storyViewedRequest =
                new OneTimeWorkRequest.Builder(StoryViewedWorker.class)
                        .setInputData(createStoryViewedData(statusResult))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(storyViewedRequest);
    }

    private Data createStoryViewedData(StatusResult.Result statusResult) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_STORY_ID, statusResult.storyId);
        return builder.build();
    }

    private void offlineDeletedStories() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<OfflineStoryDeleteResponse> call = apiInterface.offlineDeletedStories(GetSet.getToken(), GetSet.getUserId());
        call.enqueue(new Callback<OfflineStoryDeleteResponse>() {
            @Override
            public void onResponse(Call<OfflineStoryDeleteResponse> call, Response<OfflineStoryDeleteResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().status.equals(Constants.TAG_TRUE)) {
                        HashMap<String, OfflineStoryDeleteResponse.Result> result = response.body().result;
                        for (Map.Entry<String, OfflineStoryDeleteResponse.Result> storyEntry : result.entrySet()) {
                            OfflineStoryDeleteResponse.Result story = storyEntry.getValue();
                            dbhelper.deleteStatus(story.storyId);
                            if (socketConnection != null) {
                                socketConnection.refreshStoryListener(story.storyId);
                            }
                            clearDeletedStories(story);
                        }
                    }
                }
                stopService();
            }

            @Override
            public void onFailure(Call<OfflineStoryDeleteResponse> call, Throwable t) {
                t.printStackTrace();
                call.cancel();
                stopService();
            }
        });
    }

    private void clearDeletedStories(OfflineStoryDeleteResponse.Result result) {
        OneTimeWorkRequest deleteStoryRequest =
                new OneTimeWorkRequest.Builder(StoryDeletedWorker.class)
                        .setInputData(createStoryDeletedData(result))
                        .setConstraints(new Constraints.Builder()
                                .setRequiredNetworkType(NetworkType.CONNECTED)
                                .build())
                        .build();
        WorkManager.getInstance(this).enqueue(deleteStoryRequest);
    }

    private Data createStoryDeletedData(OfflineStoryDeleteResponse.Result statusResult) {
        Data.Builder builder = new Data.Builder();
        builder.putString(Constants.TAG_USER_ID, GetSet.getUserId());
        builder.putString(Constants.TAG_STORY_ID, statusResult.storyId);
        return builder.build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        socketConnection = null;
        if (mNotifyManager != null) {
            mNotifyManager.cancel(1);
        }
        Log.v(TAG, "In onDestroy");
    }

    @Override
    public IBinder onBind(Intent intent) {
        // Used only in case if services are bound (Bound Services).
        return null;
    }

    private boolean checkCallPermission() {
        int permissionContacts = ContextCompat.checkSelfPermission(context,
                READ_CONTACTS);
        return permissionContacts == PackageManager.PERMISSION_GRANTED;
    }
}
