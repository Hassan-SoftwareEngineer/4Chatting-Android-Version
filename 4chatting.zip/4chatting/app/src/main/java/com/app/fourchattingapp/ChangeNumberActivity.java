package com.app.fourchattingapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.app.model.GroupData;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.app.external.RandomString;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.SocketConnection;
import com.app.helper.Utils;
import com.app.fourchattingapp.R;
import com.app.model.ChangeNumberResult;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangeNumberActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    private static final int APP_REQUEST_CODE = 9002;
    static ApiInterface apiInterface;
    ProgressDialog progressDialog;
    DatabaseHandler dbhelper;
    EditText edtCountryCode, edtPhoneNumber;
    LinearLayout btnNext;
    TextView txtTitle;
    ImageView btnBack;
    String newCountryCode, newPhoneNumber;
    private SocketConnection socketConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_number);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        socketConnection = SocketConnection.getInstance(this);
        dbhelper = DatabaseHandler.getInstance(this);
        btnBack = findViewById(R.id.backbtn);
        txtTitle = findViewById(R.id.title);
        btnNext = findViewById(R.id.btnNext);
        edtCountryCode = findViewById(R.id.edtCountryCode);
        edtPhoneNumber = findViewById(R.id.edtPhoneNumber);

        if (ApplicationClass.isRTL()) {
            btnBack.setRotation(180);
        } else {
            btnBack.setRotation(0);
        }

        txtTitle.setText(getString(R.string.change_number));
        btnBack.setOnClickListener(this);
        btnNext.setOnClickListener(this);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.btnNext:
                if (TextUtils.isEmpty("" + edtCountryCode.getText())) {
                    makeToast(getString(R.string.enter_country_code));
                } else if (TextUtils.isEmpty("" + edtPhoneNumber.getText())) {
                    makeToast(getString(R.string.enter_phone_number));
                } else {
                    Utils utils = new Utils(this);
                    if (utils.isValidPhoneNumber("" + edtCountryCode.getText(), "" + edtPhoneNumber.getText())) {
                        String countryCode = "" + edtCountryCode.getText();
                        if (countryCode.contains("+")) {
                            countryCode = countryCode.replaceAll("\\+", "");
                        }
                        checkAvailability(countryCode, "" + edtPhoneNumber.getText());
                    } else {
                        makeToast(getString(R.string.invalid_phone_number));
                    }
                }
//                checkValidNumber();
                break;
        }
    }

    public void checkAvailability(String countryCode, String phoneNumber) {
        Call<Map<String, String>> call = apiInterface.verifyNewNumber(GetSet.getToken(), GetSet.getUserId(), phoneNumber);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
//                Log.i(TAG, "checkAvailability: " + response.body());
                Map<String, String> map = response.body();
                if (map.get(Constants.TAG_STATUS).equalsIgnoreCase(Constants.TAG_TRUE)) {
                    newCountryCode = countryCode;
                    newPhoneNumber = phoneNumber;
                    final Dialog dialog = new Dialog(ChangeNumberActivity.this);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.setContentView(R.layout.default_popup);
                    dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(true);
                    dialog.setCanceledOnTouchOutside(true);

                    TextView title = dialog.findViewById(R.id.title);
                    TextView yes = dialog.findViewById(R.id.yes);
                    TextView no = dialog.findViewById(R.id.no);
                    yes.setText(getString(R.string.im_sure));
                    no.setText(getString(R.string.nope));
                    title.setText(R.string.verify_old_number);
                    no.setVisibility(View.VISIBLE);

                    yes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            verifyNumber(countryCode, phoneNumber);
                        }
                    });

                    no.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();
                } else {
                    makeToast(getString(R.string.account_already_exists_with_this_number));
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
//                Log.e(TAG, "checkAvailability: " + t.getMessage());
                call.cancel();
            }
        });
    }

    public void verifyNumber(String countryCode, String phoneNumber) {
        String phone = "+" + countryCode + phoneNumber;
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(phone, null);
            String regionCode = phoneUtil.getRegionCodeForNumber(numberProto);
            if (regionCode != null) {
                // Choose authentication providers
                List<AuthUI.IdpConfig> providers = Arrays.asList(
                        new AuthUI.IdpConfig.PhoneBuilder().setDefaultNumber(regionCode, phoneNumber).build());
                // Create and launch sign-in intent
                startActivityForResult(
                        AuthUI.getInstance()
                                .createSignInIntentBuilder()
                                .setAvailableProviders(providers)
                                .setTheme(R.style.OTPTheme)
                                .build(),
                        APP_REQUEST_CODE);
            } else {
                makeToast(getString(R.string.invalid_country_code));
            }
        } catch (NumberParseException e) {
            Log.d(TAG, "verifyNumber: " + e.getMessage());
            Log.d(TAG, "verifyNumber: " + e.getErrorType());
            if (e.getMessage().equals("INVALID_COUNTRY_CODE") ||
                    e.getErrorType().equals("INVALID_COUNTRY_CODE")) {
                makeToast(getString(R.string.invalid_country_code));
            } else {
                makeToast(getString(R.string.something_wrong));
                e.printStackTrace();
            }
        } catch (Exception e) {
            Log.d(TAG, "verifyNumber: " + e.getMessage());
            makeToast(getString(R.string.something_wrong));
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == APP_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // Successfully signed in
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null && user.getPhoneNumber() != null) {
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                    Log.d(TAG, "onActivityResult: " + user.getPhoneNumber());
                    try {
                        Phonenumber.PhoneNumber numberProto = phoneUtil.parse(user.getPhoneNumber(), null);
//                                String regionCode = phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(phNumber.getCountryCode()));
                        String regionCode = phoneUtil.getRegionCodeForNumber(numberProto);

                        changeMyNumber(GetSet.getUserId(), "" + numberProto.getNationalNumber(), "" + numberProto.getCountryCode());
                    } catch (NumberParseException e) {
                        Log.d(TAG, "NumberParseException: " + e.getMessage());
                        makeToast(getString(R.string.something_wrong));
                        finish();
                    }
                }
                AuthUI.getInstance()
                        .signOut(this)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            public void onComplete(@NonNull Task<Void> task) {

                            }
                        });
                // ...
            }
        }
    }

    private void changeMyNumber(String userId, String phoneNumber, String countryCode) {
        Call<ChangeNumberResult> call = apiInterface.changeMyNumber(GetSet.getToken(), GetSet.getUserId(), phoneNumber, countryCode);
        call.enqueue(new Callback<ChangeNumberResult>() {
            @Override
            public void onResponse(Call<ChangeNumberResult> call, Response<ChangeNumberResult> response) {
                if (response.isSuccessful()) {
                    ChangeNumberResult result = response.body();
                    if (result.status.equalsIgnoreCase(Constants.TAG_TRUE)) {
                        sendMessageToGroup(result);
                    } else {
                        makeToast("" + result.message);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChangeNumberResult> call, Throwable t) {
//                Log.e(TAG, "changeMyNumber: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void sendMessageToGroup(ChangeNumberResult result) {
        if (progressDialog != null && !progressDialog.isShowing())
            progressDialog.show();
        List<GroupData> groupData = dbhelper.getGroups();

        for (GroupData groupDatum : groupData) {
            try {
                String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
                RandomString randomString = new RandomString(10);
                String messageId = groupDatum.groupId + randomString.nextString();

                JSONObject message = new JSONObject();
                message.put(Constants.TAG_GROUP_ID, groupDatum.groupId);
                message.put(Constants.TAG_GROUP_NAME, groupDatum.groupName);
                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                message.put(Constants.TAG_MESSAGE_ID, messageId);
                message.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                message.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                message.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                message.put(Constants.TAG_MESSAGE_TYPE, "change_number");
                String tempMsg = getString(R.string.changed_therir_number);
                message.put(Constants.TAG_MESSAGE, tempMsg);
                message.put(Constants.TAG_ATTACHMENT, GetSet.getphonenumber());
                message.put(Constants.TAG_CONTACT_COUNTRY_CODE, result.changeNumber.countryCode);
                message.put(Constants.TAG_CONTACT_PHONE_NO, result.changeNumber.phoneNo);
                message.put(Constants.TAG_CONTACT_NAME, result.changeNumber.userName);
                message.put(Constants.TAG_GROUP_ADMIN_ID, groupDatum.groupAdminId);
                socketConnection.messageToGroup(message);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        updateMyNumber(result);
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    private void updateMyNumber(ChangeNumberResult result) {
        GetSet.setphonenumber(result.changeNumber.phoneNo);
        GetSet.setcountrycode(result.changeNumber.countryCode);
        finish();
    }

    private void checkValidNumber() {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber numberProto = null;
        String numberToParse = "(040)250-3851";
        try {
            numberProto = phoneUtil.parse(numberToParse, null);
            String phoneNo = "" + numberProto.getNationalNumber();
            Log.d(TAG, "checkValidNumber: " + phoneNo);
        } catch (NumberParseException e) {
//            Log.e(TAG, "checkValidNumber: " + e.getMessage());
            Utils utils = new Utils(this);
            String formattedPhone = utils.getFormattedPhoneNumber(numberToParse);
            Log.e(TAG, "checkValidNumber: " + formattedPhone);
        }
    }

}
