package com.app.addons.livebroadcast.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.addons.livebroadcast.external.avloading.AVLoadingIndicatorView;
import com.app.addons.livebroadcast.helper.Utils;
import com.app.addons.livebroadcast.helper.VideoCache;
import com.app.addons.livebroadcast.model.StreamDetails;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.helper.StorageManager;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.hls.DefaultHlsDataSourceFactory;
import com.google.android.exoplayer2.source.hls.HlsDataSourceFactory;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.PlayerControlView;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.cache.CacheDataSource;
import com.google.android.exoplayer2.util.EventLogger;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.app.fourchattingapp.R;
import com.makeramen.roundedimageview.RoundedImageView;

import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PlayerActivity extends BaseActivity implements PlayerControlView.VisibilityListener, View.OnClickListener {
    final private static String TAG = PlayerActivity.class.getSimpleName();
    private StyledPlayerView playerView;
    private View dividerView;
    private RelativeLayout timeLay;
    private AppCompatTextView txtTime;
    private RoundedImageView btnComments;
    private RelativeLayout playLay;
    private CheckBox btnPlay;
    private ImageView btnRefresh;
    private RoundedImageView btnDetail;
    private View view;
    private ImageView btnClose;
    private RelativeLayout loadingLay;
    private ImageView loadingImage;
    private AppCompatTextView loadingTitle;
    private LinearLayout loadingUserLay;
    private AppCompatTextView loadingPublisherName;
    private RoundedImageView loadingPublisherImage;
    private RoundedImageView loadingPublisherColor;
    private AVLoadingIndicatorView avBallIndicator;
    AppCompatTextView txtBottomDuration;
    AppCompatTextView bottomStreamTitle;
    RoundedImageView publisherImage;
    RoundedImageView publisherColorImage;
    AppCompatTextView txtPublisherName;
    private RelativeLayout liveStatusLay;
    LinearLayout bottomFirstLay, bottomDeleteLay, bottomReportLay, chatHideLay, bottomDetailsLay,
            bottomUserLay, bottomViewersLay;
    AppCompatTextView bottomViewerCount, txtTotalLikes, txtReport;
    RecyclerView bottomRecyclerView, bottomCommentsView;
    RelativeLayout bottomDurationLay, bottomLikesLay;
    private BottomSheetDialog bottomDialog, bottomViewersDialog, bottomCommentsDialog;
    private String streamName, streamUrl, publisherId, totalTime = "00:00", from = null, userAgent;
    private int selectedPosition;
    Handler handler = new Handler();
    ApiInterface apiInterface;
    private ExoPlayer player;
    private boolean durationSet = false;
    public static boolean isStreamDeleted = false;
    private CommentsAdapter commentsAdapter;
    ArrayList<StreamDetails.Comments> commentList = new ArrayList<>();
    private BottomSheetDialog reportDialog;
    private RecyclerView reportsView;
    private ReportAdapter reportAdapter;
    Utils appUtils;
    private Handler mainHandler;
    private EventLogger eventLogger;
    private static DefaultBandwidthMeter BANDWIDTH_METER;
    private static final CookieManager DEFAULT_COOKIE_MANAGER;
    private Context context;

    static {
        DEFAULT_COOKIE_MANAGER = new CookieManager();
        DEFAULT_COOKIE_MANAGER.setCookiePolicy(CookiePolicy.ACCEPT_ORIGINAL_SERVER);
    }

    private Runnable timerUpdate = new Runnable() {
        @Override
        public void run() {
            if (player != null) {
                long currentMilliSeconds = player.getCurrentPosition();
                String duration;
                duration = appUtils.getFormattedDuration(currentMilliSeconds);
                txtTime.setText(duration + " / " + totalTime);
                handler.postDelayed(timerUpdate, 1000);
            }
        }
    };
    private StreamDetails streamDetails;
    private StreamDetails apiStreamData;
    private boolean playReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        context = this;
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        appUtils = new Utils(this);
        userAgent = Util.getUserAgent(this, "ExoPlayerDemo");
        BANDWIDTH_METER = new DefaultBandwidthMeter.Builder(this).build();
        mainHandler = new Handler();

        findViews();
        getFromIntent();
        initView();
        if (streamUrl != null) {
            setUpExoPlayer(streamUrl);
        }
        getStreamDetails(streamName);
    }

    private void findViews() {
        playerView = findViewById(R.id.playerView);
        dividerView = (View) findViewById(R.id.dividerView);
        timeLay = (RelativeLayout) findViewById(R.id.timeLay);
        txtTime = (AppCompatTextView) findViewById(R.id.txtTime);
        btnComments = (RoundedImageView) findViewById(R.id.btnComments);
        playLay = (RelativeLayout) findViewById(R.id.playLay);
        btnPlay = (CheckBox) findViewById(R.id.btnPlay);
        btnRefresh = (ImageView) findViewById(R.id.btnRefresh);
        btnDetail = (RoundedImageView) findViewById(R.id.btnDetail);
        view = (View) findViewById(R.id.view);
        btnClose = (ImageView) findViewById(R.id.btnClose);
        loadingLay = (RelativeLayout) findViewById(R.id.loadingLay);
        loadingImage = (ImageView) findViewById(R.id.loadingImage);
        loadingTitle = (AppCompatTextView) findViewById(R.id.loadingTitle);
        loadingUserLay = (LinearLayout) findViewById(R.id.loadingUserLay);
        loadingPublisherName = (AppCompatTextView) findViewById(R.id.loadingPublisherName);
        loadingPublisherImage = (RoundedImageView) findViewById(R.id.loadingPublisherImage);
        loadingPublisherColor = (RoundedImageView) findViewById(R.id.loadingPublisherColor);
        avBallIndicator = findViewById(R.id.avBallIndicator);

        btnDetail.setOnClickListener(this);
        playLay.setOnClickListener(this);
        btnRefresh.setOnClickListener(this);
        btnComments.setOnClickListener(this);
        btnClose.setOnClickListener(this);
    }

    private void getFromIntent() {
        SharedPreferences pref = getSharedPreferences(Constants.SHARED_PREFERENCE, MODE_PRIVATE);
        Intent intent = getIntent();
        from = intent.getStringExtra(StreamConstants.TAG_FROM);
        streamDetails = (StreamDetails) intent.getSerializableExtra(StreamConstants.TAG_STREAM_DATA);
        streamName = streamDetails.getName();
//        streamUrl = pref.getString(StreamConstants.TAG_VOD_URL, "") + streamName + ".mp4";
        streamUrl = streamDetails.playBackUrl;
        publisherId = streamDetails.getPublisherId();
        if (intent.hasExtra(Constants.TAG_POSITION)) {
            selectedPosition = intent.getIntExtra(Constants.TAG_POSITION, 0);
        }
    }

    private void initView() {
        initBottomDetailsDialog();
        initBottomViewersDialog();
        initBottomCommentsDialog();
        initBottomReportDialog();
        avBallIndicator.setVisibility(View.VISIBLE);
        loadingTitle.setText(streamDetails.getTitle());
        loadingPublisherName.setText(streamDetails.postedBy);

        Glide.with(this)
                .load(StreamConstants.STREAM_IMG_PATH + streamDetails.getStreamThumbnail())
                .error(R.drawable.profile_square)
                .placeholder(R.drawable.profile_square)
                .into(loadingImage);

        Glide.with(this)
                .load(Constants.USER_IMG_PATH + streamDetails.getPublisherImage())
                .placeholder(R.drawable.profile_square)
                .into(loadingPublisherImage);
        Random rnd = new Random();
        int color = Color.argb(60, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));
        loadingPublisherColor.setBackgroundColor(color);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        btnPlay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    startPlayer();
                } else {
                    pausePlayer();
                }
            }
        });
//        getStreamDetails(streamName);
    }

    private void setUpExoPlayer(String streamUrl) {
//        playerView.setControllerVisibilityListener(null);
        playerView.setControllerAutoShow(false);
        playerView.requestFocus();
        // Produces DataSource instances through which media data is loaded.
        Uri uri = Uri.parse("" + streamUrl);
        // This is the MediaSource representing the media to be played.
        MediaSource mediaSource = buildMediaSource(uri, StorageManager.getInstance(this).getMimeType("" + uri));
        // Prepare the player with the source.
        player = new ExoPlayer.Builder(this).build();
        player.addListener(new PlayerEventListener());
        player.setPlayWhenReady(true);
        playerView.setPlayer(player);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        player.setMediaSource(mediaSource);
        player.prepare();
    }

    private MediaSource buildMediaSource(Uri uri, String overrideExtension) {
        int type = TextUtils.isEmpty(overrideExtension) ? Util.inferContentType(uri)
                : Util.inferContentType("." + overrideExtension);
        Log.i(TAG, "buildMediaSource: " + type);
        if (type == C.TYPE_HLS) {
            HlsDataSourceFactory hlsDataSourceFactory = new DefaultHlsDataSourceFactory(buildDataSourceFactory(true));
            MediaItem.Builder builder = new MediaItem.Builder();
            builder.setUri(uri);
            return new HlsMediaSource.Factory(hlsDataSourceFactory).createMediaSource(builder.build());
        } else if (type == C.TYPE_OTHER) {
            if (!uri.getScheme().equals("rtmp")) {
                MediaItem.Builder builder = new MediaItem.Builder();
                builder.setUri(uri);
                return new ProgressiveMediaSource.Factory(buildDataSourceFactory(true))
                        .createMediaSource(builder.build());
            }
            throw new IllegalStateException("Unsupported type: " + type);
        }
        throw new IllegalStateException("Unsupported type: " + type);
    }

    private class PlayerEventListener implements Player.Listener {

        @Override
        public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
            playReady = playWhenReady;
        }

        @Override
        public void onPlaybackStateChanged(int playbackState) {
            if (playbackState == Player.STATE_ENDED) {
                btnRefresh.setVisibility(View.VISIBLE);
                btnPlay.setVisibility(View.GONE);
                handler.removeCallbacks(timerUpdate);
                durationSet = false;
            } else if (playReady && playbackState == Player.STATE_READY) {
                if (!durationSet) {
                    durationSet = true;
                    long duration = player.getDuration();
                    if (TimeUnit.MILLISECONDS.toHours(player.getDuration()) != 0)
                        totalTime = String.format(Locale.ENGLISH, "%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(duration),
                                TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1),
                                TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1));
                    else
                        totalTime = String.format(Locale.ENGLISH, "%02d:%02d",
                                TimeUnit.MILLISECONDS.toMinutes(duration) % TimeUnit.HOURS.toMinutes(1),
                                TimeUnit.MILLISECONDS.toSeconds(duration) % TimeUnit.MINUTES.toSeconds(1));
                    txtBottomDuration.setText(totalTime);
                }
                loadingLay.setVisibility(View.GONE);
                avBallIndicator.setVisibility(View.GONE);
            } else if (playbackState == Player.STATE_BUFFERING) {
                avBallIndicator.setVisibility(View.VISIBLE);
                handler.removeCallbacks(timerUpdate);
            }
        }

        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            if (isPlaying) {
                handler.post(timerUpdate);
            } else {
                handler.removeCallbacks(timerUpdate);
            }
        }

        @Override
        public void onPlayerError(PlaybackException e) {
            Log.e(TAG, "onPlayerError: " + e.getMessage());
        }
    }

    /**
     * Returns a new DataSource factory.
     *
     * @param useBandwidthMeter Whether to set {@link #BANDWIDTH_METER} as a listener to the new
     *                          DataSource factory.
     * @return A new DataSource factory.
     */
    private DataSource.Factory buildDataSourceFactory(boolean useBandwidthMeter) {
        return buildDataSourceFactory(useBandwidthMeter ? BANDWIDTH_METER : null);
    }

    public DataSource.Factory buildDataSourceFactory(DefaultBandwidthMeter bandwidthMeter) {
        CacheDataSource.Factory dataSourceFactory = new CacheDataSource.Factory();
        dataSourceFactory.setCache(VideoCache.getInstance(context));
        dataSourceFactory.setUpstreamDataSourceFactory(new DefaultDataSource.Factory(this,
                buildHttpDataSourceFactory()));
        return dataSourceFactory;
    }

    public HttpDataSource.Factory buildHttpDataSourceFactory() {
        DefaultHttpDataSource.Factory factory = new DefaultHttpDataSource.Factory();
        factory.setUserAgent(userAgent);
        return factory;
    }

    private void initBottomDetailsDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_details, null);
        bottomDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomDialog.setContentView(bottomSheet);

        bottomSheet.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
        bottomFirstLay = bottomSheet.findViewById(R.id.bottomFirstLay);
        bottomDeleteLay = bottomSheet.findViewById(R.id.bottomDeleteLay);
        liveStatusLay = bottomSheet.findViewById(R.id.liveStatusLay);
        bottomStreamTitle = bottomSheet.findViewById(R.id.bottomStreamTitle);
        bottomUserLay = bottomSheet.findViewById(R.id.bottomUserLay);
        publisherImage = bottomSheet.findViewById(R.id.publisherImage);
        publisherColorImage = bottomSheet.findViewById(R.id.publisherColorImage);
        txtPublisherName = bottomSheet.findViewById(R.id.txtPublisherName);
        bottomDetailsLay = bottomSheet.findViewById(R.id.bottomDetailsLay);
        chatHideLay = bottomSheet.findViewById(R.id.chatHideLay);
        bottomReportLay = bottomSheet.findViewById(R.id.bottomReportLay);
        txtReport = bottomSheet.findViewById(R.id.txtReport);

        bottomStreamTitle.setText(streamDetails.getTitle() != null ? streamDetails.getTitle() : "");
        bottomUserLay.setVisibility(View.GONE);
        chatHideLay.setVisibility(View.GONE);
        liveStatusLay.setVisibility(View.GONE);
        if (("" + streamDetails.getPublisherId()).equals(GetSet.getUserId())) {
            bottomDeleteLay.setVisibility(View.VISIBLE);
            bottomReportLay.setVisibility(View.GONE);
        } else {
            bottomReportLay.setVisibility(View.VISIBLE);
            bottomDeleteLay.setVisibility(View.GONE);
        }
        bottomDetailsLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (bottomViewersDialog != null && !bottomViewersDialog.isShowing()) {
                    bottomViewersDialog.show();
                }
            }
        });

        bottomDeleteLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDeleteDialog(getString(R.string.really_delete_video));
            }
        });

        bottomReportLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (streamDetails == null) {
                    openReportDialog();
                } else if (streamDetails.getReported() != null && streamDetails.getReported().equals(Constants.TAG_FALSE)) {
                    openReportDialog();
                } else if (apiStreamData.getReported() != null && apiStreamData.getReported().equals(Constants.TAG_FALSE)) {
                    openReportDialog();
                } else {
                    if (bottomDialog != null && bottomDialog.isShowing()) {
                        bottomDialog.dismiss();
                    }
                    sendReport("", false);
                }
            }
        });

        bottomDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initBottomViewersDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_viewers, null);
        bottomViewersDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomViewersDialog.setContentView(bottomSheet);

        bottomViewersLay = bottomSheet.findViewById(R.id.bottomViewersLay);
        bottomViewerCount = bottomSheet.findViewById(R.id.bottomViewerCount);
        bottomRecyclerView = bottomSheet.findViewById(R.id.bottomRecyclerView);
        txtBottomDuration = bottomSheet.findViewById(R.id.txtBottomDuration);
        bottomDurationLay = bottomSheet.findViewById(R.id.bottomDurationLay);
        bottomLikesLay = bottomSheet.findViewById(R.id.bottomLikesLay);
        txtTotalLikes = bottomSheet.findViewById(R.id.txtTotalLikes);

        bottomLikesLay.setVisibility(View.VISIBLE);
        bottomViewersLay.setVisibility(View.GONE);

        txtTotalLikes.setText(streamDetails.getLikes() != null ? streamDetails.getLikes() : "0");
        bottomViewersDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomViewersDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initBottomCommentsDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_comments, null);
        bottomCommentsDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomCommentsDialog.setContentView(bottomSheet);
        bottomSheet.setBackgroundColor(context.getResources().getColor(R.color.transparentBlack));
        bottomCommentsView = bottomSheet.findViewById(R.id.bottomCommentsView);
        bottomSheet.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;

        commentsAdapter = new CommentsAdapter(this, commentList);
        bottomCommentsView.setLayoutManager(new LinearLayoutManager(this));
        bottomCommentsView.setAdapter(commentsAdapter);
        bottomCommentsView.setHasFixedSize(true);
        commentsAdapter.notifyDataSetChanged();

        bottomCommentsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomCommentsDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initBottomReportDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.bottom_sheet_report, null);
        reportDialog = new BottomSheetDialog(PlayerActivity.this, R.style.Bottom_ReportDialog); // Style here
        reportDialog.setContentView(bottomSheet);
        ((View) bottomSheet.getParent()).setBackgroundColor(ContextCompat.getColor(this, R.color.colorBlack));
        bottomSheet.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
        WindowManager.LayoutParams params = reportDialog.getWindow().getAttributes();
        params.x = 0;
        reportDialog.getWindow().setAttributes(params);
        bottomSheet.requestLayout();
        reportsView = bottomSheet.findViewById(R.id.reportView);
        reportDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        reportDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        loadReports();
    }

    private void loadReports() {
        reportAdapter = new ReportAdapter(this, appUtils.getReportList());
        reportsView.setLayoutManager(new LinearLayoutManager(this));
        reportsView.setAdapter(reportAdapter);
        reportAdapter.notifyDataSetChanged();
    }

    private void openReportDialog() {
        if (reportDialog != null && !reportDialog.isShowing()) {
            reportDialog.show();
        }
    }

    public void getStreamDetails(String streamName) {
        if (NetworkStatus.isConnected()) {
            Call<StreamDetails> call = apiInterface.getStreamDetails(GetSet.getToken(), GetSet.getUserId(), streamName);
            call.enqueue(new Callback<StreamDetails>() {
                @Override
                public void onResponse(Call<StreamDetails> call, Response<StreamDetails> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals(Constants.TAG_TRUE)) {
                            apiStreamData = response.body();
                            streamDetails = response.body();
                            if (apiStreamData.getStreamBlocked() == 1) {
                                makeToast(getString(R.string.broadcast_deactivated_by_admin));
                                Intent intent = new Intent();
                                setResult(RESULT_OK, intent);
                                finish();
                            }
                            txtTotalLikes.setText(apiStreamData.getLikes());
                            bottomStreamTitle.setText(apiStreamData.getTitle());
                            bottomViewerCount.setText(apiStreamData.getWatchCount());
                            if (!("" + apiStreamData.getPublisherId()).equals(GetSet.getUserId())) {
                                bottomUserLay.setVisibility(View.VISIBLE);
                                txtPublisherName.setText(apiStreamData.getPostedBy());
                                Glide.with(getApplicationContext())
                                        .load(Constants.USER_IMG_PATH + apiStreamData.getPublisherImage())
                                        .error(R.drawable.profile_square)
                                        .into(publisherImage);
                                txtReport.setText(apiStreamData.getReported().equals(Constants.TAG_FALSE) ? getString(R.string.report_broadcast) :
                                        getString(R.string.undo_report_broadcast));
                            }
                            commentList.clear();
                            List<StreamDetails.Comments> tempCommentList = new ArrayList<>(apiStreamData.getCommentsList());
                            for (StreamDetails.Comments comment : tempCommentList) {
                                if (!comment.getType().equals(StreamConstants.TAG_LIKED) &&
                                        !comment.getType().equals(StreamConstants.TAG_STREAM_JOINED)) {
                                    commentList.add(comment);
                                }
                            }
                            commentsAdapter.notifyDataSetChanged();
                        } else {
                            if (response.body().getMessage() != null && response.body().getMessage().equals("No Stream found")) {
                                makeToast(getString(R.string.no_stream_found));
                                finish();
                            } else {
                                makeToast(getString(R.string.something_wrong));
                                finish();
                            }
                        }
                    } else {
                        finish();
                        makeToast(getString(R.string.something_wrong));
                    }
                }

                @Override
                public void onFailure(Call<StreamDetails> call, Throwable t) {
                    call.cancel();
                    Log.e(TAG, "getStreamDetailsFailure: " + t.getMessage());
                }
            });
        } else {
            makeToast(getString(R.string.no_internet_connection));
            finish();
        }
    }

    public void deleteVideo() {
        Call<Map<String, String>> call = apiInterface.deleteVideo(GetSet.getToken(), GetSet.getUserId(), streamDetails.getName());
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    if (response.body().get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                        isStreamDeleted = true;
                        Intent intent = new Intent();
                        setResult(RESULT_OK, intent);
                        makeToast(getString(R.string.video_deleted_successfully));
                        finish();
                    }
                } else {
                    makeToast(getString(R.string.something_wrong));
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
            }
        });
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        ApplicationClass.showSnack(this, findViewById(R.id.parentLay), isConnected);
        if (!isConnected) {
            btnPlay.setChecked(false);
        }
    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnDetail:
                if (bottomDialog != null && !bottomDialog.isShowing())
                    bottomDialog.show();
                break;
            case R.id.playLay:
                btnPlay.setChecked(!btnPlay.isChecked());
                break;
            case R.id.btnRefresh:
                btnRefresh.setVisibility(View.GONE);
                btnPlay.setVisibility(View.VISIBLE);
                if (player != null) {
                    player.seekTo(0);
                }
                btnPlay.setChecked(true);
                break;
            case R.id.btnComments:
                if (bottomCommentsDialog != null && !bottomCommentsDialog.isShowing()) {
                    bottomCommentsDialog.show();
                }
                break;
            case R.id.btnClose:
                finish();
                break;
            default:
                break;
        }
    }

    private void openDeleteDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(PlayerActivity.this);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                deleteVideo();
            }
        });
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        Typeface typeface = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            typeface = getResources().getFont(R.font.font_regular);
        } else {
            typeface = ResourcesCompat.getFont(this, R.font.font_regular);
        }
        TextView textView = dialog.findViewById(android.R.id.message);
        textView.setTypeface(typeface);

        Button btn1 = dialog.findViewById(android.R.id.button1);
        btn1.setTypeface(typeface);

        Button btn2 = dialog.findViewById(android.R.id.button2);
        btn2.setTypeface(typeface);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ApplicationClass.pauseExternalAudio(this);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(timerUpdate);
        releasePlayer();
        btnPlay.setChecked(false);
        ApplicationClass.resumeExternalAudio(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void releasePlayer() {
        pausePlayer();
        if (Util.SDK_INT <= 23) {
            if (playerView != null) {
                playerView.onPause();
            }
            if (player != null) {
                player.release();
                player = null;
            }
        }
    }

    private void pausePlayer() {
        if (player != null) {
            player.setPlayWhenReady(false);
            player.getPlaybackState();
        }
    }

    private void startPlayer() {
        if (player != null) {
            player.setPlayWhenReady(true);
            player.getPlaybackState();
        }
    }

    @Override
    public void onVisibilityChange(int visibility) {

    }

    public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        ArrayList<StreamDetails.Comments> commentList;
        Context context;
        Random rnd;
        public final int VIEW_TYPE_JOIN = 0;
        public final int VIEW_TYPE_TEXT = 1;

        public CommentsAdapter(Context context, ArrayList<StreamDetails.Comments> commentList) {
            this.commentList = commentList;
            this.context = context;
            rnd = new Random();
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == VIEW_TYPE_JOIN) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_join, parent, false);
                return new JoiningViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_TEXT) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
                return new MyViewHolder(view);
            }

            return null;
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int position) {
            if (viewHolder instanceof MyViewHolder) {
                final MyViewHolder holder = (MyViewHolder) viewHolder;
                StreamDetails.Comments comments = commentList.get(position);
                holder.txtMessage.setText(comments.getMessage());
                holder.txtUserName.setText("@" + comments.getUserName());

            } else if (viewHolder instanceof JoiningViewHolder) {
                final JoiningViewHolder joinViewHolder = (JoiningViewHolder) viewHolder;
                joinViewHolder.itemLay.setVisibility(View.GONE);
                StreamDetails.Comments comments = commentList.get(position);
                joinViewHolder.txtJoined.setText("@" + comments.getUserName() + " Joined");
            }
        }

        @Override
        public int getItemCount() {
            return commentList.size();
        }

        @Override
        public int getItemViewType(int position) {
            if (commentList.get(position) != null) {
                String type = "" + commentList.get(position).getType();
                switch (type) {
                    case Constants.TAG_TEXT:
                        return VIEW_TYPE_TEXT;
                    case StreamConstants.TAG_STREAM_JOINED:
                        return VIEW_TYPE_JOIN;
                }
            }
            return VIEW_TYPE_TEXT;
        }

        public class JoiningViewHolder extends RecyclerView.ViewHolder {
            RelativeLayout itemLay;
            TextView txtJoined;

            public JoiningViewHolder(View view) {
                super(view);
                itemLay = view.findViewById(R.id.itemLay);
                txtJoined = view.findViewById(R.id.txtJoined);
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            RelativeLayout itemLay;
            TextView txtUserName;
            TextView txtMessage;

            public MyViewHolder(View view) {
                super(view);
                itemLay = view.findViewById(R.id.itemLay);
                txtUserName = view.findViewById(R.id.txtUserName);
                txtMessage = view.findViewById(R.id.txtMessage);
            }
        }
    }

    public class ReportAdapter extends RecyclerView.Adapter {
        private final Context context;
        private List<String> reportList = new ArrayList<>();
        private RecyclerView.ViewHolder viewHolder;

        public ReportAdapter(Context context, List<String> reportList) {
            this.context = context;
            this.reportList = reportList;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(context)
                    .inflate(R.layout.item_report, parent, false);
            viewHolder = new MyViewHolder(itemView);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ((MyViewHolder) holder).txtReport.setText(reportList.get(position));
        }

        @Override
        public int getItemCount() {
            return reportList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            LinearLayout itemReportLay;
            TextView txtReport;

            public MyViewHolder(View view) {
                super(view);
                itemReportLay = view.findViewById(R.id.itemReportLay);
                txtReport = view.findViewById(R.id.txtReport);

                itemReportLay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ApplicationClass.preventMultiClick(itemReportLay);
                        reportDialog.dismiss();
                        if (bottomDialog != null && bottomDialog.isShowing()) {
                            bottomDialog.dismiss();
                        }
                        sendReport(reportList.get(getAbsoluteAdapterPosition()), true);
                    }
                });
            }
        }

    }

    private void sendReport(String title, boolean report) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_NAME, streamName);
        if (report) {
            map.put(Constants.TAG_REPORT, title);
        }
        Call<Map<String, String>> call = apiInterface.reportStream(GetSet.getToken(), map);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> reportResponse = response.body();
                    if (reportResponse.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                        if (report) {
                            makeToast(getString(R.string.reported_successfully));
                            if (streamDetails != null) {
                                streamDetails.setReported(Constants.TAG_TRUE);
                            }
                            txtReport.setText(getString(R.string.undo_report_broadcast));
                        } else {
                            makeToast(getString(R.string.undo_report_successfully));
                            if (streamDetails != null) {
                                streamDetails.setReported(Constants.TAG_FALSE);
                            }
                            txtReport.setText(getString(R.string.report_broadcast));
                        }
                    } else
                        makeToast(getString(R.string.something_wrong));
                } else {
                    makeToast(getString(R.string.something_wrong));
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
                makeToast(getString(R.string.something_wrong));
            }
        });
    }
}
