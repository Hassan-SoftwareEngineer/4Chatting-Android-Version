package com.app.helper.connectivity.base;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;


import static android.content.Context.CONNECTIVITY_SERVICE;
import static android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET;

import com.app.helper.connectivity.ConnectivityProviderImpl;
import com.app.helper.connectivity.ConnectivityProviderLegacyImpl;

public interface ConnectivityProvider {
    static final String TAG = ConnectivityProvider.class.getSimpleName();

    static ConnectivityProvider createProvider(Context mContext) {
        ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return new ConnectivityProviderImpl(cm);
        } else {
            return new ConnectivityProviderLegacyImpl(mContext, cm);
        }
    }

    interface ConnectivityStateListener {
        void onStateChange(NetworkState state);
    }

    void addListener(ConnectivityStateListener listener);

    void removeListener(ConnectivityStateListener listener);

    public NetworkState getNetworkState();

    abstract class NetworkState {
        public static NetworkState NotConnectedState;
        public boolean hasInternet;

        public static class ConnectedState extends NetworkState {

            public ConnectedState(boolean hasCapability) {
                hasInternet = hasCapability;
            }

            public static ConnectedState Connected(NetworkCapabilities capabilities) {
                return new ConnectedState(capabilities.hasCapability(NET_CAPABILITY_INTERNET));
            }

            public static ConnectedState ConnectedLegacy(NetworkInfo networkInfo) {
                return new ConnectedState(networkInfo.isConnectedOrConnecting());
            }
        }
    }
}
