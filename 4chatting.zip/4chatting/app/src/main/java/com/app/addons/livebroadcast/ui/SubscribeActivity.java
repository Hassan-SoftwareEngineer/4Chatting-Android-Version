package com.app.addons.livebroadcast.ui;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.MODIFY_AUDIO_SETTINGS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.telephony.TelephonyManager.NETWORK_TYPE_1xRTT;
import static android.telephony.TelephonyManager.NETWORK_TYPE_CDMA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EDGE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EHRPD;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_0;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_A;
import static android.telephony.TelephonyManager.NETWORK_TYPE_EVDO_B;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GPRS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSDPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSPAP;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSUPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_IDEN;
import static android.telephony.TelephonyManager.NETWORK_TYPE_LTE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UMTS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UNKNOWN;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.external.keyboard.HeightProvider;
import com.app.helper.LocaleManager;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.app.addons.livebroadcast.external.CustomLayoutManager;
import com.app.addons.livebroadcast.external.avloading.AVLoadingIndicatorView;
import com.app.addons.livebroadcast.external.avloading.BallBeatIndicator;
import com.app.addons.livebroadcast.external.heartlayout.HeartLayout;
import com.app.addons.livebroadcast.helper.SocketIO;
import com.app.addons.livebroadcast.helper.Utils;
import com.app.addons.livebroadcast.model.StreamDetails;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.DataChannel;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import de.tavendo.autobahn.WebSocket;
import io.antmedia.webrtcandroidframework.IDataChannelObserver;
import io.antmedia.webrtcandroidframework.IWebRTCClient;
import io.antmedia.webrtcandroidframework.IWebRTCListener;
import io.antmedia.webrtcandroidframework.StreamInfo;
import io.antmedia.webrtcandroidframework.WebRTCClient;
import io.antmedia.webrtcandroidframework.apprtc.CallActivity;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubscribeActivity extends BaseActivity implements SocketIO.SocketEvents,
        GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, View.OnClickListener,
        IWebRTCListener, IDataChannelObserver {
    final private static String TAG = SubscribeActivity.class.getSimpleName();

    private FrameLayout contentLay;
    private ImageView btnClose;
    private ImageView btnInfo;
    private RelativeLayout bottomLay;
    private RelativeLayout commentsLay;
    private RecyclerView rvComments;
    private HeartLayout heartLay;
    private LinearLayout viewersLay;
    private RelativeLayout viewLay;
    private ImageView iconView;
    private AppCompatTextView txtViewCount, txtLiveCount;
    private RecyclerView rvViewers;
    private RelativeLayout chatLay;
    private RelativeLayout messageLay, liveCountLay, liveStatusLay;
    private EditText edtMessage;
    private ImageView btnSend;
    private FrameLayout loadingLay, liveTxtLay;
    private ImageView loadingImage;
    private AppCompatTextView txtLoadingTitle;
    private AppCompatTextView loadingViewCount;
    private RoundedImageView loadingUserImage;
    private AppCompatTextView loadingUserName;
    private LinearLayout initializeLay;
    private AVLoadingIndicatorView initialIndicator;
    AppCompatTextView bottomTxtLiveCount, txtBottomDuration;
    RelativeLayout bottomDurationLay;
    AppCompatTextView bottomStreamTitle;
    RoundedImageView publisherImage;
    RoundedImageView publisherColorImage;
    AppCompatTextView txtPublisherName;
    AVLoadingIndicatorView avBallIndicator;

    private RelativeLayout bottomLiveCountLay;
    private FrameLayout bottomLiveTxtLay;
    LinearLayout bottomFirstLay, bottomDeleteLay, bottomReportLay, chatHideLay, bottomDetailsLay,
            bottomUserLay, bottomTopLay, bottomViewersLay;
    AppCompatTextView bottomViewerCount, txtReport;
    RecyclerView bottomRecyclerView, bottomGiftView;
    private BottomSheetDialog bottomDialog, bottomCommentsDialog, reportDialog;
    private RecyclerView reportsView;

    private ApiInterface apiInterface;
    private Animation slideIn;
    private Animation slideOut;
    private boolean isAnimated = false, isUnsubscribed = false, isKeyPadVisible = false, mPermissionsGranted = false;
    int displayHeight, displayWidth;
    private String from, streamName, streamImage;
    private SocketIO socketIO;
    private Socket mSocket;
    ArrayList<StreamDetails.LiveViewers> viewersList = new ArrayList<>();
    ArrayList<HashMap<String, String>> commentList = new ArrayList<HashMap<String, String>>();
    private int publisherColor;
    private ViewerListViewAdapter viewerListAdapter;
    private BottomListAdapter bottomListAdapter;
    private CommentsAdapter commentsAdapter;
    private CustomLayoutManager commentLayoutManager;
    private String userLikeColor, publisherId;
    private ReportAdapter reportAdapter;
    private StreamDetails streamInfo;
    private StreamDetails streamData;
    private GestureDetector gestureScanner;
    Utils appUtils;
    private String[] mRequiredPermissions = new String[]{
            CAMERA,
            RECORD_AUDIO,
            MODIFY_AUDIO_SETTINGS
    };
    private static final int PERMISSIONS_REQUEST_CODE = 0x1;
    private boolean isUserJoined = false;
    public static final String PREFER_EXTENSION_DECODERS = "prefer_extension_decoders";
    private Timer netWorkTimer = new Timer();
    private CountDownTimer publishTimer;

    /**
     * Mode can Publish, Play or P2P
     */

    private String webRTCMode = IWebRTCClient.MODE_PLAY;
    Intent intent;
    private WebRTCClient webRTCClient;
    private boolean enableDataChannel = true;
    private SurfaceViewRenderer cameraViewRenderer;
    private SurfaceViewRenderer pipViewRenderer;
    final int RECONNECTION_PERIOD_MLS = 100;
    Handler reconnectionHandler = new Handler();
    Runnable reconnectionRunnable = new Runnable() {
        @Override
        public void run() {
            if (!webRTCClient.isStreaming()) {
                attempt2Reconnect();
                // call the handler again in case startStreaming is not successful
                reconnectionHandler.postDelayed(this, RECONNECTION_PERIOD_MLS);
            }
        }
    };

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getStreamInfo(streamName);
                }
            });
        }
    };

    private Emitter.Listener _msgReceived = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    Log.e(TAG, "_msgReceived: " + data);
                    String type = data.optString(Constants.TAG_TYPE);
                    switch (type) {
                        case StreamConstants.TAG_STREAM_JOINED:
                            if (data.optString(StreamConstants.TAG_STREAM_NAME).equals(streamName)) {
                                getStreamInfo(streamName);
                                HashMap<String, String> map = new HashMap<>();
                                map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                                map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                                map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                                map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                                map.put(Constants.TAG_TYPE, data.optString(Constants.TAG_TYPE));
                                addComment(map);
                            }
                            break;
                        case Constants.TAG_TEXT: {
                            HashMap<String, String> map = new HashMap<>();
                            map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                            map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                            map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                            map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                            map.put(Constants.TAG_TYPE, Constants.TAG_TEXT);
                            map.put(Constants.TAG_VISIBILITY, Constants.TAG_TRUE);
                            addComment(map);
                            break;
                        }
                        case StreamConstants.TAG_LIKED: {
                            HashMap<String, String> map = new HashMap<>();
                            map.put(Constants.TAG_USER_ID, data.optString(Constants.TAG_USER_ID));
                            map.put(Constants.TAG_USER_NAME, data.optString(Constants.TAG_USER_NAME));
                            map.put(Constants.TAG_USER_IMAGE, data.optString(Constants.TAG_USER_IMAGE));
                            map.put(Constants.TAG_MESSAGE, data.optString(Constants.TAG_MESSAGE));
                            map.put(Constants.TAG_TYPE, Constants.TAG_MESSAGE);
                            try {
                                String userId = data.optString(Constants.TAG_USER_ID);
                                String likeColor = data.optString(StreamConstants.TAG_LIKE_COLOR);
                                heartLay.addHeart(Color.parseColor(likeColor));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;
                        }
                    }
                }
            });
        }
    };

    private Emitter.Listener _subscriberLeft = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    Log.i(TAG, "_subscriberLeft: " + data);
                    getStreamInfo(data.optString(StreamConstants.TAG_STREAM_NAME));
                }
            });
        }
    };

    private Emitter.Listener _streamInfo = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "_streamInfo: " + data);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Gson gson = new Gson();
                    StreamDetails tempDetails = gson.fromJson("" + data, StreamDetails.class);
                    streamInfo = tempDetails;
                    txtViewCount.setText(tempDetails.getWatchCount() != null ? tempDetails.getWatchCount() : "");
                    publisherId = tempDetails.getPublisherId();
                    viewersList.clear();
                    viewersList.addAll(tempDetails.getLiveViewers());
                    viewerListAdapter.notifyDataSetChanged();
                    setBottomDialogUI(tempDetails);
                }
            });
        }
    };

    private Emitter.Listener _streamBlocked = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            JSONObject data = (JSONObject) args[0];
            Log.i(TAG, "_streamBlocked: " + data);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    makeToast(getString(R.string.broadcast_deactivated_by_admin));
                    unSubscribeStream();
                }
            });
        }
    };
    private SubscribeActivity context;
    private boolean isStarted = false;
    private boolean updateCount = false;
    private SharedPreferences pref;

    private void setBottomDialogUI(StreamDetails details) {
        bottomListAdapter.notifyDataSetChanged();
        bottomStreamTitle.setText(details.getTitle());
        bottomViewerCount.setText(details.getWatchCount());
        bottomTxtLiveCount.setText(details.getWatchCount());
        txtPublisherName.setText(details.getPostedBy());
        Glide.with(getApplicationContext())
                .load(details.getPublisherImage())
                .error(R.drawable.profile_square)
                .into(publisherImage);

        Glide.with(getApplicationContext())
                .load(details.getPublisherImage())
                .error(R.drawable.profile_square)
                .into(loadingUserImage);
        publisherColorImage.setBackgroundColor(publisherColor);
        txtReport.setText(details.getReported().equals(Constants.TAG_FALSE) ? getString(R.string.report_broadcast) :
                getString(R.string.undo_report_broadcast));
    }

    private void addComment(HashMap<String, String> map) {
        commentList.add(map);
        commentsAdapter.notifyItemInserted(commentList.size() - 1);
        rvComments.scrollToPosition(commentList.size() - 1);
    }

    private void subscribeStream() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            jsonObject.put(Constants.TAG_USER_IMAGE, GetSet.getImageUrl());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket.connected()) {
                Log.i(TAG, "subscribeStream: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_SUBSCRIBE_STREAM, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "subscribeStream: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendUserJoined() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_TYPE, StreamConstants.TAG_STREAM_JOINED);
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            jsonObject.put(Constants.TAG_USER_IMAGE, GetSet.getImageUrl());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket.connected()) {
                Log.i(TAG, "sendUserJoined: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_SEND_MESSAGE, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "sendUserJoined: " + e.getMessage());
            e.printStackTrace();
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getStreamInfo(streamName);
            }
        }, 1000);
    }

    private void unSubscribeStream() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket != null && mSocket.connected() && !isUnsubscribed) {
                isUnsubscribed = true;
                Log.i(TAG, "unSubscribeStream: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_UNSUBSCRIBE_STREAM, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "unSubscribeStream: " + e.getMessage());
            e.printStackTrace();
        }
        finish();
    }

    private void sendChat() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_TYPE, Constants.TAG_TEXT);
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            jsonObject.put(Constants.TAG_USER_IMAGE, GetSet.getImageUrl());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            jsonObject.put(Constants.TAG_MESSAGE, "" + edtMessage.getText());
            HashMap<String, String> map = new HashMap<>();
            map.put(Constants.TAG_USER_ID, GetSet.getUserId());
            map.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            map.put(Constants.TAG_USER_IMAGE, GetSet.getImageUrl());
            map.put(StreamConstants.TAG_STREAM_NAME, streamName);
            map.put(Constants.TAG_MESSAGE, "" + edtMessage.getText());
            map.put(Constants.TAG_TYPE, Constants.TAG_TEXT);
            addComment(map);
            edtMessage.getText().clear();
            if (mSocket.connected()) {
                Log.i(TAG, "sendChat: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_SEND_MESSAGE, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "sendChat: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendLike() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_TYPE, StreamConstants.TAG_LIKED);
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            jsonObject.put(Constants.TAG_USER_IMAGE, GetSet.getImageUrl());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            jsonObject.put(StreamConstants.TAG_LIKE_COLOR, userLikeColor);
            heartLay.addHeart(Color.parseColor(userLikeColor));
            if (mSocket.connected()) {
                Log.i(TAG, "sendLike: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_SEND_MESSAGE, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "sendChat: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void getStreamInfo(String streamName) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(StreamConstants.TAG_STREAM_NAME, streamName);
            if (mSocket.connected()) {
                Log.i(TAG, "getStreamInfo: " + jsonObject);
                mSocket.emit(StreamConstants.TAG_GET_STREAM_INFO, jsonObject);
            }
        } catch (JSONException e) {
            Log.e(TAG, "getStreamInfo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        setContentView(R.layout.activity_subscribe);
        context = this;
        pref = getSharedPreferences("SavedPref", MODE_PRIVATE);

        findViews();
        Constants.isInStream = true;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancelAll();
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        appUtils = new Utils(this);
        slideIn = AnimationUtils.loadAnimation(this, R.anim.anim_slide_left_in);
        slideOut = AnimationUtils.loadAnimation(this, R.anim.anim_slide_right_out);
        intent = getIntent();
        Bundle bundle = intent.getExtras();
        streamData = (StreamDetails) bundle.getSerializable(StreamConstants.TAG_STREAM_DATA);
        from = intent.getStringExtra(Constants.TAG_FROM);
        streamName = streamData.getName();
        streamImage = streamData.getStreamThumbnail();
        intent.putExtra(CallActivity.EXTRA_CAPTURETOTEXTURE_ENABLED, true);
        intent.putExtra(CallActivity.EXTRA_VIDEO_FPS, 30);
        intent.putExtra(CallActivity.EXTRA_VIDEO_BITRATE, 1500);
        intent.putExtra(CallActivity.EXTRA_CAPTURETOTEXTURE_ENABLED, true);
        intent.putExtra(CallActivity.EXTRA_DATA_CHANNEL_ENABLED, enableDataChannel);

        if (LocaleManager.isRTL()) {
            viewLay.setBackground(getResources().getDrawable(R.drawable.rounded_curve_rtl_bg));
            liveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg_rtl));
            liveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg_rtl));
        } else {
            viewLay.setBackground(getResources().getDrawable(R.drawable.rounded_curve_bg));
            liveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg));
            liveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg));
        }
        setInitializingLay();
        // If running on Android 6 (Marshmallow) and later, check to see if the necessary permissions
        // have been granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mPermissionsGranted = hasPermissions(this, mRequiredPermissions);
            if (!mPermissionsGranted)
                ActivityCompat.requestPermissions(this, mRequiredPermissions, PERMISSIONS_REQUEST_CODE);
        } else
            mPermissionsGranted = true;

        // return if the user hasn't granted the app the necessary permissions
        if (!mPermissionsGranted) return;

        initView();
        initSocket();
        initWebRTCClient(streamName);
        backgroundInNetWorkSpeed();
    }

    public void findViews() {
        contentLay = findViewById(R.id.contentLay);
        cameraViewRenderer = findViewById(R.id.camera_view_renderer);
        pipViewRenderer = findViewById(R.id.pip_view_renderer);
        btnClose = findViewById(R.id.btnClose);
        btnInfo = findViewById(R.id.btnInfo);
        bottomLay = findViewById(R.id.bottomLay);
        commentsLay = findViewById(R.id.commentsLay);
        rvComments = findViewById(R.id.rv_comments);
        heartLay = findViewById(R.id.heartLay);
        viewersLay = findViewById(R.id.viewersLay);
        viewLay = findViewById(R.id.viewLay);
        iconView = findViewById(R.id.iconView);
        loadingViewCount = findViewById(R.id.txtViewCount);
        rvViewers = findViewById(R.id.rv_viewers);
        chatLay = findViewById(R.id.chatLay);
        messageLay = findViewById(R.id.messageLay);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);
        loadingLay = findViewById(R.id.loadingLay);
        loadingImage = findViewById(R.id.loadingImage);
        txtLoadingTitle = findViewById(R.id.txtLoadingTitle);
        loadingUserImage = findViewById(R.id.loadingUserImage);
        loadingUserName = findViewById(R.id.loadingUserName);
        initializeLay = findViewById(R.id.initializeLay);
        initialIndicator = findViewById(R.id.initialIndicator);
        liveStatusLay = findViewById(R.id.liveStatusLay);
        liveTxtLay = findViewById(R.id.liveTxtLay);
        liveCountLay = findViewById(R.id.liveCountLay);
        txtLiveCount = findViewById(R.id.txtLiveCount);
        txtViewCount = findViewById(R.id.txtViewCount);
        avBallIndicator = findViewById(R.id.avBallIndicator);

        btnSend.setOnClickListener(this);
        btnClose.setOnClickListener(this);
        btnInfo.setOnClickListener(this);
        viewLay.setOnClickListener(this);
    }

    private void initView() {
        gestureScanner = new GestureDetector(this, this);
        Random random = new Random();
        int i1 = random.nextInt(StreamConstants.LIKE_COLOR.length);
        publisherColor = Color.argb(60, random.nextInt(255), random.nextInt(255), random.nextInt(255));
        userLikeColor = StreamConstants.LIKE_COLOR[i1].trim();

        new HeightProvider(this).init().setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                if (height > 0) {
                    findViewById(R.id.bottomLay).setTranslationY(-height);
                } else {
                    findViewById(R.id.bottomLay).setTranslationY(0);
                }
            }
        });

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        displayHeight = displayMetrics.heightPixels;
        displayWidth = displayMetrics.widthPixels;

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ABOVE, R.id.viewersLay);
        params.height = (int) (displayHeight * 0.4);
        commentsLay.setLayoutParams(params);

        edtMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!isAnimated) {
                    isAnimated = true;
                    slideOutAnim();
                } else if (charSequence.length() == 0) {
                    slideInAnim();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        View view = findViewById(R.id.parentLay);
        findViewById(R.id.parentLay).getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int heightDiff = view.getRootView().getHeight() - view.getHeight();
                isKeyPadVisible = heightDiff > ApplicationClass.dpToPx(getApplicationContext(), 200);
            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rvViewers.setLayoutManager(linearLayoutManager);
        viewerListAdapter = new ViewerListViewAdapter(this, viewersList);
        rvViewers.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        rvViewers.setAdapter(viewerListAdapter);
        rvViewers.setHasFixedSize(true);
        viewerListAdapter.notifyDataSetChanged();

        commentsAdapter = new CommentsAdapter(this, commentList);
        commentLayoutManager = new CustomLayoutManager(this);
        commentLayoutManager.setScrollEnabled(false);
        rvComments.setLayoutManager(commentLayoutManager);
        rvComments.setAdapter(commentsAdapter);
        commentsAdapter.notifyDataSetChanged();
        setContentLayTouchListener();

        initBottomDetailsDialog();
        initBottomViewersDialog();
        getStreamDetails();
    }

    private void initSocket() {
        socketIO = new SocketIO(SubscribeActivity.this);
        mSocket = socketIO.getInstance();
        socketIO.setSocketEvents(SubscribeActivity.this);

        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(StreamConstants.TAG_MESSAGE_RECEIVED, _msgReceived);
        mSocket.on(StreamConstants.TAG_STREAM_INFO, _streamInfo);
        mSocket.on(StreamConstants.TAG_SUBSCRIBER_LEFT, _subscriberLeft);
        mSocket.on(StreamConstants.TAG_STREAM_BLOCKED, _streamBlocked);
        mSocket.connect();

    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        if (!isConnected) {
            if (isStarted) {
                unSubscribeStream();
                showToastAlert(getString(R.string.stream_end_description));
            } else {
                showToastAlert(getString(R.string.something_wrong));
            }
            finish();
        }
    }

    @Override
    public void backPressed() {
        if (bottomDialog != null && bottomDialog.isShowing()) {
            if (bottomViewersLay.getVisibility() == VISIBLE) {
                bottomViewersLay.setVisibility(GONE);
                bottomFirstLay.setVisibility(VISIBLE);
            } else {
                bottomDialog.dismiss();
            }
        } else {
            closeConfirmDialog(getString(R.string.really_want_exit));
        }
    }

    public void backgroundInNetWorkSpeed() {
        netWorkTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                // this code will be executed after 2 seconds
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        backgroundInNetWorkSpeed();
                        checkNetworkType();
                    }
                });

            }
        }, 10000);

    }


    private boolean isConnectedFast(Context context) {
        NetworkInfo info = getNetworkInfo(context);
        return (info != null && info.isConnected() && isConnectionFast(info.getType(), info.getSubtype(), context));
    }

    private boolean isConnectionFast(int type, int subType, Context context) {
        if (type == ConnectivityManager.TYPE_WIFI) {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            int speedMbps = wifiInfo.getLinkSpeed();

            Log.e("NetSpeed", "-" + speedMbps);
            switch (speedMbps) {
                case NETWORK_TYPE_1xRTT:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_CDMA:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 14-64 kbps
                case NETWORK_TYPE_EDGE:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_EVDO_0:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return true; // ~ 400-1000 kbps
                case NETWORK_TYPE_EVDO_A:
                    //Toast.makeText(getApplicationContext(),"High Network connection",Toast.LENGTH_SHORT).show();
                    return true; // ~ 600-1400 kbps
                case NETWORK_TYPE_GPRS:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 100 kbps
                case NETWORK_TYPE_HSDPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 2-14 Mbps
                case NETWORK_TYPE_HSPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 700-1700 kbps
                case NETWORK_TYPE_HSUPA:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 1-23 Mbps
                case NETWORK_TYPE_UMTS:
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 400-7000 kbps

                // Above API level 7, make sure to set android:targetSdkVersion to appropriate level to use these

                case NETWORK_TYPE_EHRPD: // API level 11
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 1-2 Mbps
                case NETWORK_TYPE_EVDO_B: // API level 9
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 5 Mbps
                case NETWORK_TYPE_HSPAP: // API level 13
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 10-20 Mbps
                case NETWORK_TYPE_IDEN: // API level 8
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return false; // ~25 kbps
                case NETWORK_TYPE_LTE: // API level 11
                    //Toast.makeText(getApplicationContext(),"High Network connection"+speedMbps,Toast.LENGTH_SHORT).show();
                    return true; // ~ 10+ Mbps
                // Unknown
                case NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
            //return true;
        } else if (type == ConnectivityManager.TYPE_MOBILE) {

            switch (subType) {
                case NETWORK_TYPE_1xRTT:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_CDMA:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 14-64 kbps
                case NETWORK_TYPE_EDGE:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 50-100 kbps
                case NETWORK_TYPE_EVDO_0:
                    return true; // ~ 400-1000 kbps
                case NETWORK_TYPE_EVDO_A:
                    return true; // ~ 600-1400 kbps
                case NETWORK_TYPE_GPRS:
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~ 100 kbps
                case NETWORK_TYPE_HSDPA:
                    return true; // ~ 2-14 Mbps
                case NETWORK_TYPE_HSPA:
                    return true; // ~ 700-1700 kbps
                case NETWORK_TYPE_HSUPA:
                    return true; // ~ 1-23 Mbps
                case NETWORK_TYPE_UMTS:
                    return true; // ~ 400-7000 kbps

                // Above API level 7, make sure to set android:targetSdkVersion to appropriate level to use these

                case NETWORK_TYPE_EHRPD: // API level 11
                    return true; // ~ 1-2 Mbps
                case NETWORK_TYPE_EVDO_B: // API level 9
                    return true; // ~ 5 Mbps
                case NETWORK_TYPE_HSPAP: // API level 13
                    return true; // ~ 10-20 Mbps
                case NETWORK_TYPE_IDEN: // API level 8
                    Toast.makeText(getApplicationContext(), context.getString(R.string.poor_network_connection), Toast.LENGTH_SHORT).show();
                    return false; // ~25 kbps
                case NETWORK_TYPE_LTE: // API level 11
                    return true; // ~ 10+ Mbps
                // Unknown
                case NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
        } else {
            return false;
        }
    }

    private void checkNetworkType() {
        boolean connectionStatus = isConnectedFast(getApplicationContext());
        if (!connectionStatus) {
            // connection is slow
            //   Toast.makeText(getApplicationContext(),"poorband",Toast.LENGTH_LONG).show();

        } else {
            // connection is fast
        }
    }

    private NetworkInfo getNetworkInfo(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo();
    }

    private void initWebRTCClient(String streamName) {
        webRTCClient = new WebRTCClient(this, this);
        webRTCClient.setVideoRenderers(pipViewRenderer, cameraViewRenderer);
        webRTCClient.setOpenFrontCamera(false);
        String SERVER_URL = pref.getString(StreamConstants.TAG_STREAM_BASE_URL, StreamConstants.STREAM_BASE_URL);
        // intent.putExtra(CallActivity.EXTRA_VIDEO_FPS, 24);
        webRTCClient.init(SERVER_URL, streamName, webRTCMode, "tokenId", intent);
        webRTCClient.setDataChannelObserver(this);
        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                attempt2Reconnect();
            }
        }, 500);
    }

    @Override
    public void onPlayStarted(String streamId) {
        Log.w(getClass().getSimpleName(), "onPlayStarted");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webRTCClient.switchVideoScaling(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
                webRTCClient.getStreamInfoList();
                setBuffering(GONE);
                loadingLay.setVisibility(GONE);
                initialIndicator.hide();
                initializeLay.setVisibility(GONE);
                isStarted = true;
                subscribeStream();
                sendUserJoined();
                setBuffering(GONE);
            }
        });
    }

    @Override
    public void onPublishStarted(String streamId) {

    }

    @Override
    public void onDisconnected(String streamId) {
        Log.e(TAG, "onDisconnected: " + streamId);
    }

    @Override
    public void onPublishFinished(String streamId) {

    }

    @Override
    public void onPlayFinished(String streamId) {
        unSubscribeStream();
        showToastAlert(getString(R.string.stream_end_description));
    }

    @Override
    public void noStreamExistsToPlay(String streamId) {
        Log.w(getClass().getSimpleName(), "noStreamExistsToPlay");
        unSubscribeStream();
        showToastAlert(getString(R.string.stream_end_description));
    }

    @Override
    public void streamIdInUse(String streamId) {
        Log.w(getClass().getSimpleName(), "streamIdInUse");
    }

    @Override
    public void onIceConnected(String streamId) {
        // remove scheduled reconnection attempts
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (reconnectionHandler.hasCallbacks(reconnectionRunnable)) {
                reconnectionHandler.removeCallbacks(reconnectionRunnable, null);
            }
        } else {
            reconnectionHandler.removeCallbacks(reconnectionRunnable, null);
        }
    }

    @Override
    public void onIceDisconnected(String streamId) {

    }

    @Override
    public void onPeerConnectionClosed(String streamId) {
        showToastAlert(getString(R.string.stream_end_description));
        unSubscribeStream();
    }

    @Override
    public void onTrackList(String[] tracks) {

    }

    @Override
    public void onBitrateMeasurement(String streamId, int targetBitrate, int videoBitrate, int audioBitrate) {

    }

    @Override
    public void onStreamInfoList(String streamId, ArrayList<StreamInfo> streamInfoList) {

    }

    @Override
    public void onError(String description, String streamId) {
        Log.e(TAG, "onError: " + description);
    }

    @Override
    public void onSignalChannelClosed(WebSocket.WebSocketConnectionObserver.WebSocketCloseNotification code, String streamId) {

    }

    @Override
    public void onBufferedAmountChange(long previousAmount, String dataChannelLabel) {

    }

    @Override
    public void onStateChange(DataChannel.State state, String dataChannelLabel) {

    }

    @Override
    public void onMessage(DataChannel.Buffer buffer, String dataChannelLabel) {

    }

    @Override
    public void onMessageSent(DataChannel.Buffer buffer, boolean successful) {

    }

    private void attempt2Reconnect() {
        Log.w(getClass().getSimpleName(), "Attempt2Reconnect called");
        if (!webRTCClient.isStreaming()) {
            webRTCClient.startStream();
            if (webRTCMode.equals(IWebRTCClient.MODE_JOIN)) {
                pipViewRenderer.setZOrderOnTop(true);
            }
        }
    }

    private void showToastAlert(String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                makeToast(message);
            }
        });
    }

    private void setInitializingLay() {
        loadingLay.setVisibility(VISIBLE);
        Glide.with(this)
                .load(Constants.USER_IMG_PATH + streamData.getStreamThumbnail())
                .placeholder(R.drawable.profile_square)
                .error(R.drawable.profile_square)
                .into(loadingImage);

        Glide.with(this)
                .load(Constants.USER_IMG_PATH + streamData.getPublisherImage())
                .error(R.drawable.profile_square)
                .placeholder(R.drawable.profile_square)
                .into(loadingUserImage);
        setBuffering(GONE);
        txtLoadingTitle.setText(streamData.getTitle());
        loadingUserName.setText(streamData.getPostedBy());
        initialIndicator.setIndicator(new BallBeatIndicator());
        initialIndicator.show();
        initializeLay.setVisibility(VISIBLE);
    }

    private void slideInAnim() {
        isAnimated = false;
        TranslateAnimation animate = new TranslateAnimation(
                0,
                -50,
                0,
                0);
        animate.setDuration(200);
        animate.setFillAfter(false);
        animate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                btnSend.setVisibility(GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        btnSend.startAnimation(animate);
    }

    private void slideOutAnim() {
        btnSend.setVisibility(VISIBLE);
        if (LocaleManager.isRTL()) {
            btnSend.setRotation(180);
            TranslateAnimation animate = new TranslateAnimation(
                    -50,
                    0,
                    0,
                    0);
            animate.setDuration(500);
            animate.setFillAfter(true);
            btnSend.startAnimation(animate);
        } else {
            btnSend.setRotation(0);
            btnSend.setVisibility(VISIBLE);
            TranslateAnimation animate = new TranslateAnimation(
                    -50,
                    0,
                    0,
                    0);
            animate.setDuration(500);
            animate.setFillAfter(true);
            btnSend.startAnimation(animate);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE: {
                mPermissionsGranted = true;
                // Check the result of each permission granted
                for (int grantResult : grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        mPermissionsGranted = false;
                        break;
                    }
                }
                if (mPermissionsGranted) {
                    initView();
                    initSocket();
                    initWebRTCClient(streamName);
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(CAMERA) &&
                                shouldShowRequestPermissionRationale(RECORD_AUDIO) &&
                                shouldShowRequestPermissionRationale(READ_EXTERNAL_STORAGE)) {
                            requestPermissions(permissions, PERMISSIONS_REQUEST_CODE);
                        } else {
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            makeToast(getString(R.string.camera_microphone_storage_permission_error));
                            finish();
                        }
                    }
                }
                break;
            }
        }
    }

    /**
     * Android Activity class methods
     */

    @Override
    protected void onResume() {
        super.onResume();
        if (socketIO != null)
            socketIO.setSocketEvents(SubscribeActivity.this);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        unSubscribeStream();
        if (socketIO != null)
            socketIO.setSocketEvents(null);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (netWorkTimer != null) {
            netWorkTimer.cancel();
            netWorkTimer = null;
        }
        unSubscribeStream();
        if (mSocket != null && mSocket.connected()) {
            mSocket.disconnect();
            mSocket.off(Socket.EVENT_CONNECT, onConnect);
            mSocket.off(StreamConstants.TAG_MESSAGE_RECEIVED, _msgReceived);
            mSocket.off(StreamConstants.TAG_STREAM_INFO, _streamInfo);
            mSocket.off(StreamConstants.TAG_SUBSCRIBER_LEFT, _subscriberLeft);
            mSocket.off(StreamConstants.TAG_STREAM_BLOCKED, _streamBlocked);
        }
        Constants.isInStream = false;
    }

    private void setBuffering(int visibility) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (visibility == VISIBLE) {
                    if (loadingLay.getVisibility() != VISIBLE) {
                        avBallIndicator.setVisibility(visibility);
                        contentLay.setOnTouchListener(null);
                        edtMessage.setEnabled(false);
                    }
                } else {
                    avBallIndicator.setVisibility(visibility);
                    setContentLayTouchListener();
                }
            }
        });
    }

    private void setContentLayTouchListener() {
        contentLay.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureScanner.onTouchEvent(event);
            }
        });
        edtMessage.setEnabled(true);
    }

    private void initBottomDetailsDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_details, null);
        bottomDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomDialog.setContentView(bottomSheet);

        bottomSheet.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
        bottomFirstLay = bottomSheet.findViewById(R.id.bottomFirstLay);
        bottomDeleteLay = bottomSheet.findViewById(R.id.bottomDeleteLay);
        bottomTxtLiveCount = bottomSheet.findViewById(R.id.txtLiveCount);
        bottomLiveTxtLay = bottomSheet.findViewById(R.id.liveTxtLay);
        bottomLiveCountLay = bottomSheet.findViewById(R.id.liveCountLay);
        bottomStreamTitle = bottomSheet.findViewById(R.id.bottomStreamTitle);
        bottomUserLay = bottomSheet.findViewById(R.id.bottomUserLay);
        publisherImage = bottomSheet.findViewById(R.id.publisherImage);
        publisherColorImage = bottomSheet.findViewById(R.id.publisherColorImage);
        txtPublisherName = bottomSheet.findViewById(R.id.txtPublisherName);
        bottomDetailsLay = bottomSheet.findViewById(R.id.bottomDetailsLay);
        chatHideLay = bottomSheet.findViewById(R.id.chatHideLay);
        bottomReportLay = bottomSheet.findViewById(R.id.bottomReportLay);
        txtReport = bottomSheet.findViewById(R.id.txtReport);

        if (LocaleManager.isRTL()) {
            bottomLiveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg_rtl));
            bottomLiveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg_rtl));
        } else {
            bottomLiveTxtLay.setBackground(getResources().getDrawable(R.drawable.live_status_bg));
            bottomLiveCountLay.setBackground(getResources().getDrawable(R.drawable.live_count_bg));
        }

        bottomStreamTitle.setText(streamData.getTitle());
        bottomReportLay.setVisibility(VISIBLE);
        bottomUserLay.setVisibility(VISIBLE);
        bottomDeleteLay.setVisibility(GONE);
        chatHideLay.setVisibility(VISIBLE);

        bottomDetailsLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (bottomCommentsDialog != null && !bottomCommentsDialog.isShowing()) {
                    bottomCommentsDialog.show();
                }
            }
        });

        bottomReportLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (streamInfo == null) {
                    openReportDialog();
                } else if (streamInfo.getReported().equals(Constants.TAG_FALSE)) {
                    openReportDialog();
                } else {
                    sendReport("", false);
                }
            }
        });

        chatHideLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomDialog.dismiss();
                if (bottomLay.getVisibility() == VISIBLE)
                    slideDownAnim();
            }
        });

        bottomDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void initBottomViewersDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.dialog_bottom_viewers, null);
        bottomCommentsDialog = new BottomSheetDialog(this, R.style.Bottom_StreamDialog); // Style here
        bottomCommentsDialog.setContentView(bottomSheet);

        bottomViewersLay = bottomSheet.findViewById(R.id.bottomViewersLay);
        bottomViewerCount = bottomSheet.findViewById(R.id.bottomViewerCount);
        bottomRecyclerView = bottomSheet.findViewById(R.id.bottomRecyclerView);
        bottomTopLay = bottomSheet.findViewById(R.id.bottomTopLay);
        txtBottomDuration = bottomSheet.findViewById(R.id.txtBottomDuration);
        bottomDurationLay = bottomSheet.findViewById(R.id.bottomDurationLay);

        bottomDurationLay.setVisibility(GONE);

        bottomListAdapter = new BottomListAdapter(this, viewersList);
        bottomRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        bottomRecyclerView.setAdapter(bottomListAdapter);
        bottomRecyclerView.setHasFixedSize(true);
        bottomListAdapter.notifyDataSetChanged();

        bottomCommentsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        bottomCommentsDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
    }

    private void openReportDialog() {
        View bottomSheet = getLayoutInflater().inflate(R.layout.bottom_sheet_report, null);
        reportDialog = new BottomSheetDialog(SubscribeActivity.this, R.style.Bottom_StreamDialog); // Style here
        reportDialog.setContentView(bottomSheet);
        ((View) bottomSheet.getParent()).setBackgroundColor(ContextCompat.getColor(this, R.color.colorBlack));
        bottomSheet.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
        WindowManager.LayoutParams params = reportDialog.getWindow().getAttributes();
        params.x = 0;
        reportDialog.getWindow().setAttributes(params);
        bottomSheet.requestLayout();
        reportsView = bottomSheet.findViewById(R.id.reportView);

        reportDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });

        reportDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                BottomSheetDialog dialog = (BottomSheetDialog) dialogInterface;
                View bottomSheet = dialog.findViewById(R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                BottomSheetBehavior.from(bottomSheet).setSkipCollapsed(true);
                BottomSheetBehavior.from(bottomSheet).setHideable(true);
            }
        });
        loadReports();
    }

    private void loadReports() {
        reportAdapter = new ReportAdapter(this, appUtils.getReportList());
        reportsView.setLayoutManager(new LinearLayoutManager(this));
        reportsView.setAdapter(reportAdapter);
        reportAdapter.notifyDataSetChanged();
        reportDialog.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnClose:
                closeConfirmDialog(getString(R.string.really_want_exit));
                break;
            case R.id.btnSend:
                if (TextUtils.isEmpty(edtMessage.getText())) {
                    makeToast(getString(R.string.enter_comments));
                } else {
                    sendChat();
                }
                break;
            case R.id.btnInfo:
                if (bottomDialog != null && !bottomDialog.isShowing())
                    bottomDialog.show();
                break;
            case R.id.viewLay:
                if (bottomCommentsDialog != null && !bottomCommentsDialog.isShowing())
                    bottomCommentsDialog.show();
                break;
        }
    }

    public void getStreamDetails() {
        if (NetworkStatus.isConnected()) {
            Call<StreamDetails> call3 = apiInterface.getStreamDetails(GetSet.getToken(), GetSet.getUserId(), streamName);
            call3.enqueue(new Callback<StreamDetails>() {
                @Override
                public void onResponse(Call<StreamDetails> call, Response<StreamDetails> response) {
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals(Constants.TAG_TRUE)) {
                            streamData = response.body();
                            if (!streamData.getType().equals(StreamConstants.TAG_LIVE)) {
                                finish();
                            } else {
                                publishTimer = new CountDownTimer(20000, 1000) {
                                    @Override
                                    public void onTick(long l) {

                                    }

                                    @Override
                                    public void onFinish() {
                                        if (!isStarted) {
                                            showToastAlert(getString(R.string.something_wrong));
                                            finish();
                                        }
                                    }
                                }.start();
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<StreamDetails> call, Throwable t) {
                    call.cancel();
                    Log.e(TAG, "onFailure: " + t.getMessage());
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void closeConfirmDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(SubscribeActivity.this);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.okay), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                unSubscribeStream();
                showToastAlert(getString(R.string.stream_end_description));
                dialog.cancel();
            }
        });
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        Typeface typeface = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            typeface = getResources().getFont(R.font.font_regular);
        } else {
            typeface = ResourcesCompat.getFont(this, R.font.font_regular);
        }
        TextView textView = dialog.findViewById(android.R.id.message);
        textView.setTypeface(typeface);

        Button btn1 = dialog.findViewById(android.R.id.button1);
        btn1.setTypeface(typeface);

        Button btn2 = dialog.findViewById(android.R.id.button2);
        btn2.setTypeface(typeface);

    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float v, float v1) {
        // TODO Auto-generated method stub
        float sensitivity = 50;
        // Get swipe delta value in x axis.
        float deltaX = e1.getX() - e2.getX();

        // Get swipe delta value in y axis.
        float deltaY = e1.getY() - e2.getY();
        // Get absolute value.
        float deltaXAbs = Math.abs(deltaX);
        float deltaYAbs = Math.abs(deltaY);
        // Minimal x and y axis swipe distance.
        int MIN_SWIPE_DISTANCE_X = 100;
        int MIN_SWIPE_DISTANCE_Y = 100;

        // Maximal x and y axis swipe distance.
        int MAX_SWIPE_DISTANCE_X = 1000;
        int MAX_SWIPE_DISTANCE_Y = 1000;

        Log.i(TAG, "onFling: ");
        if ((deltaYAbs >= MIN_SWIPE_DISTANCE_Y) && (deltaYAbs <= MAX_SWIPE_DISTANCE_Y)) {
            if (deltaY > 0) {
                if (bottomLay.getVisibility() != VISIBLE)
                    slideUpAnim();
            } else {
                if (bottomLay.getVisibility() == VISIBLE)
                    slideDownAnim();
            }
        }

        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        if (isKeyPadVisible) {
            ApplicationClass.hideSoftKeyboard(SubscribeActivity.this);
        } else {
            sendLike();
        }
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN && bottomLay.getVisibility() == VISIBLE) {
            sendLike();
        }
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }

    private void slideUpAnim() {
        bottomLay.setVisibility(VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0,
                0,
                bottomLay.getHeight(),
                0);
        animate.setDuration(500);
        animate.setFillAfter(true);
        bottomLay.startAnimation(animate);
    }

    private void slideDownAnim() {
        TranslateAnimation animate = new TranslateAnimation(
                0,
                0,
                0,
                bottomLay.getHeight());
        animate.setDuration(500);
        animate.setFillAfter(false);
        animate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                bottomLay.setVisibility(GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        bottomLay.startAnimation(animate);
    }

    public class ReportAdapter extends RecyclerView.Adapter {
        private final Context context;
        private List<String> reportList = new ArrayList<>();
        private RecyclerView.ViewHolder viewHolder;

        public ReportAdapter(Context context, List<String> reportList) {
            this.context = context;
            this.reportList = reportList;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(context)
                    .inflate(R.layout.item_report, parent, false);
            viewHolder = new MyViewHolder(itemView);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            ((MyViewHolder) holder).txtReport.setText(reportList.get(position));
        }

        @Override
        public int getItemCount() {
            return reportList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView txtReport;
            LinearLayout itemReportLay;

            public MyViewHolder(View view) {
                super(view);
                txtReport = view.findViewById(R.id.txtReport);
                itemReportLay = view.findViewById(R.id.itemReportLay);

                itemReportLay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ApplicationClass.preventMultiClick(itemReportLay);
                        reportDialog.dismiss();
                        if (bottomDialog != null && !bottomDialog.isShowing()) {
                            bottomDialog.dismiss();
                        }
                        sendReport(reportList.get(getAdapterPosition()), true);
                    }
                });
            }
        }
    }

    private void sendReport(String title, boolean report) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_ID, GetSet.getUserId());
        map.put(Constants.TAG_NAME, streamName);
        if (report) {
            map.put(Constants.TAG_REPORT, title);
        }

        Call<Map<String, String>> call = apiInterface.reportStream(GetSet.getToken(), map);
        call.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> reportResponse = response.body();
                    if (reportResponse.get(Constants.TAG_STATUS).equals(Constants.TAG_TRUE)) {
                        if (report) {
                            makeToast(getString(R.string.reported_successfully));
                            if (streamInfo != null) {
                                streamInfo.setReported(Constants.TAG_TRUE);
                            }
                            txtReport.setText(getString(R.string.undo_report_broadcast));
                        } else {
                            makeToast(getString(R.string.undo_report_successfully));
                            if (streamInfo != null) {
                                streamInfo.setReported(Constants.TAG_FALSE);
                            }
                            txtReport.setText(getString(R.string.report_broadcast));
                        }
                        if (bottomDialog != null && bottomDialog.isShowing()) {
                            bottomDialog.dismiss();
                        }
                    } else
                        makeToast(getString(R.string.something_wrong));
                } else {
                    makeToast(getString(R.string.something_wrong));
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
                makeToast(getString(R.string.something_wrong));
            }
        });
    }

    public class ViewerListViewAdapter extends RecyclerView.Adapter<ViewerListViewAdapter.MyViewHolder> {

        ArrayList<StreamDetails.LiveViewers> viewersList;
        Context context;
        Random rnd;

        public ViewerListViewAdapter(Context context, ArrayList<StreamDetails.LiveViewers> viewersList) {
            this.viewersList = viewersList;
            this.context = context;
            rnd = new Random();
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_viewers, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            final StreamDetails.LiveViewers viewer = viewersList.get(position);
            int color = Color.argb(60, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));
            Glide.with(context).load(Constants.USER_IMG_PATH + viewer.getUserImage())
                    .apply(RequestOptions.circleCropTransform())
                    .thumbnail(0.5f)
                    .error(R.drawable.profile_square)
                    .transition(new DrawableTransitionOptions().crossFade())
                    .into(holder.userImage);
            holder.colorImage.setBackgroundColor(color);

            holder.itemLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return viewersList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView userImage;
            ImageView colorImage;
            RelativeLayout itemLay;

            public MyViewHolder(View view) {
                super(view);
                userImage = view.findViewById(R.id.userImage);
                colorImage = view.findViewById(R.id.colorImage);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }
    }

    public class BottomListAdapter extends RecyclerView.Adapter<BottomListAdapter.MyViewHolder> {

        ArrayList<StreamDetails.LiveViewers> viewerList;
        Context context;
        Random rnd;

        public BottomListAdapter(Context context, ArrayList<StreamDetails.LiveViewers> viewerList) {
            this.viewerList = viewerList;
            this.context = context;
            rnd = new Random();
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_viewer, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            final StreamDetails.LiveViewers viewer = viewerList.get(position);

            int color = Color.argb(60, rnd.nextInt(255), rnd.nextInt(255), rnd.nextInt(255));
            Glide.with(context).load("" + viewer.getUserImage())
                    .apply(RequestOptions.circleCropTransform())
                    .thumbnail(0.5f)
                    .error(R.drawable.profile_square)
                    .transition(new DrawableTransitionOptions().crossFade())
                    .into(holder.userImage);
            holder.colorImage.setBackgroundColor(color);
            holder.txtUserName.setText(viewer.getUserName());
            holder.mainLay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return viewerList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            RoundedImageView userImage;
            RoundedImageView colorImage;
            TextView txtUserName;
            RelativeLayout mainLay;

            public MyViewHolder(View view) {
                super(view);
                userImage = view.findViewById(R.id.userImage);
                colorImage = view.findViewById(R.id.colorImage);
                txtUserName = view.findViewById(R.id.txtUserName);
                mainLay = view.findViewById(R.id.mainLay);
            }
        }
    }

    public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        public final int VIEW_TYPE_JOIN = 0;
        public final int VIEW_TYPE_TEXT = 1;
        public final int VIEW_TYPE_GIFT = 2;
        ArrayList<HashMap<String, String>> commentList;
        Context context;

        public CommentsAdapter(Context context, ArrayList<HashMap<String, String>> commentList) {
            this.commentList = commentList;
            this.context = context;
        }

        @Override
        public int getItemCount() {
            return commentList.size();
        }

        @Override
        public int getItemViewType(int position) {
            if (commentList.get(position) != null) {
                String type = "" + commentList.get(position).get(Constants.TAG_TYPE);
                switch (type) {
                    case Constants.TAG_TEXT:
                        return VIEW_TYPE_TEXT;
                    case StreamConstants.TAG_STREAM_JOINED:
                        return VIEW_TYPE_JOIN;
                }
            }
            return VIEW_TYPE_TEXT;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == VIEW_TYPE_JOIN) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_join, parent, false);
                return new JoiningViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_TEXT) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
                return new MyViewHolder(view);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, int position) {

            if (viewHolder instanceof MyViewHolder) {
                final MyViewHolder holder = (MyViewHolder) viewHolder;
                final HashMap<String, String> map = commentList.get(position);
                holder.txtMessage.setText(map.get(Constants.TAG_MESSAGE));
                holder.txtUserName.setText("@" + map.get(Constants.TAG_USER_NAME));
                new CountDownTimer(5000, 1000) { //(timer_duration, timer_interval)
                    @Override
                    public void onTick(long millisUntilFinished) {
                        holder.itemLay.setVisibility(VISIBLE);
                        //runs every second (1000 ms)
                    }

                    @Override
                    public void onFinish() {
                        //Do your operations when timer is finised
                        setFadeAnimation(holder.itemLay, holder.getAdapterPosition());
                        holder.itemLay.setVisibility(GONE);

                    }
                }.start();

            } else if (viewHolder instanceof JoiningViewHolder) {
                final JoiningViewHolder joinViewHolder = (JoiningViewHolder) viewHolder;
                final HashMap<String, String> map = commentList.get(position);

                joinViewHolder.txtJoined.setText("@" + map.get(Constants.TAG_USER_NAME) + " Joined");
                new CountDownTimer(5000, 1000) { //(timer_duration, timer_interval)
                    @Override
                    public void onTick(long millisUntilFinished) {
                        joinViewHolder.itemLay.setVisibility(VISIBLE);
                        //runs every second (1000 ms)
                    }

                    @Override
                    public void onFinish() {
                        //Do your operations when timer is finised
                        setFadeAnimation(joinViewHolder.itemLay, joinViewHolder.getAdapterPosition());
                        joinViewHolder.itemLay.setVisibility(GONE);

                    }
                }.start();
            }
        }

        public class JoiningViewHolder extends RecyclerView.ViewHolder {
            TextView txtJoined;
            RelativeLayout itemLay;

            public JoiningViewHolder(View view) {
                super(view);
                txtJoined = view.findViewById(R.id.txtJoined);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView txtUserName;
            TextView txtMessage;
            RelativeLayout itemLay;

            public MyViewHolder(View view) {
                super(view);
                txtUserName = view.findViewById(R.id.txtUserName);
                txtMessage = view.findViewById(R.id.txtMessage);
                itemLay = view.findViewById(R.id.itemLay);
            }
        }
    }


    private void setFadeAnimation(final View view, final int position) {
        /*sets animation from complete opaque state(1.0f) to complete transparent state(0.0f)*/

        AlphaAnimation anim = new AlphaAnimation(1.0f, 0.0f);
        anim.setDuration(StreamConstants.FADE_DURATION);
        view.startAnimation(anim);
    }

    //    Utility method to check the status of a permissions request for an array of permission identifiers
    private static boolean hasPermissions(Context context, String[] permissions) {
        for (String permission : permissions)
            if (context.checkCallingOrSelfPermission(permission) != PackageManager.PERMISSION_GRANTED)
                return false;

        return true;
    }
}
