package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class GroupInvite {
    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public Map<String,GroupData> result;
}
