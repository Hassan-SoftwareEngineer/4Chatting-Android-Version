package com.app.helper;

import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.app.fourchattingapp.ApplicationClass;
import com.app.model.ChannelMessage;
import com.app.model.MessagesData;
import com.app.fourchattingapp.R;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by hitasoft on 14/7/18.
 */

public class FileUploadService extends IntentService implements ProgressRequestBody.UploadCallbacks {

    private static final String TAG = FileUploadService.class.getSimpleName();
    public static boolean IS_FILE_UPLOADING = false;
    NotificationManager mNotifyManager;
    NotificationCompat.Builder mBuilder;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    StorageManager storageManager;
    MessagesData mdata;
    GroupMessage gdata;
    ChannelMessage chdata;
    String uploadFilePath, chatType, thumbnail = null;
    String savedPath;
    public static int NOTIFICATION_ID = 2;
    private Context mContext;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public FileUploadService() {
        super(TAG);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.v(TAG, "onCreate");
        mContext = this;
    }

    @Override
    protected void onHandleIntent(Intent intent) {
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {

        Log.d(TAG, "onStartCommand: " + flags + ", " + startId);
        IS_FILE_UPLOADING = true;
        dbhelper = DatabaseHandler.getInstance(this);
        socketConnection = SocketConnection.getInstance(this);
        storageManager = StorageManager.getInstance(this);

        Bundle bundle = intent.getExtras();
        uploadFilePath = bundle.getString("filepath");
        if (bundle.containsKey("savedPath")) {
            savedPath = bundle.getString("savedPath");
        }
        chatType = bundle.getString("chatType");
        if (bundle.containsKey(Constants.TAG_THUMBNAIL)) {
            thumbnail = bundle.getString(Constants.TAG_THUMBNAIL);
        }
        Log.d(TAG, "onHandleIntent: " + uploadFilePath + ", " + chatType + ", " + thumbnail);
        
        switch (chatType) {
            case "chat": {
                mdata = (MessagesData) bundle.getSerializable("mdata");
                boolean blockedMe = bundle.getBoolean(Constants.TAG_BLOCKED_ME);
                ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
                MultipartBody.Part filePart = MultipartBody.Part.createFormData("attachment", new File(uploadFilePath).getName(), fileBody);

                ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
                RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
                Call<Map<String, String>> call3 = apiInterface.upchat(GetSet.getToken(), filePart, userid);
                Log.d(TAG, "upChat: "+ call3.request().url());
                call3.enqueue(new Callback<Map<String, String>>() {
                    @Override
                    public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                        if (response.isSuccessful()) {
                            try {
                                Map<String, String> userdata = response.body();
                                if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                                    Log.d(TAG, "onResponse: " + userdata);
                                    String newFileName = userdata.get(Constants.TAG_USER_IMAGE);
                                    try {
                                        boolean fileStatus;
                                        switch (mdata.message_type) {
                                            case Constants.TAG_AUDIO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_AUDIO);
                                                break;
                                            case Constants.TAG_VIDEO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_VIDEO);
                                                break;
                                            case Constants.TAG_DOCUMENT:
                                            default:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_DOCUMENT);
                                                break;
                                        }
                                        if (fileStatus) {
                                            Log.d(TAG, "onResponse: " + blockedMe);
//                                            if (!blockedMe) {
                                            JSONObject jobj = new JSONObject();
                                            JSONObject message = new JSONObject();
                                            message.put(Constants.TAG_USER_ID, mdata.user_id);
                                            message.put(Constants.TAG_USER_NAME, mdata.user_name);
                                            message.put(Constants.TAG_MESSAGE_TYPE, mdata.message_type);
                                            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
                                            message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(thumbnail) : "");
                                            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
                                            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
                                            message.put(Constants.TAG_CHAT_ID, mdata.chat_id);
                                            message.put(Constants.TAG_MESSAGE_ID, mdata.message_id);
                                            message.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
                                            message.put(Constants.TAG_SENDER_ID, mdata.user_id);
                                            message.put(Constants.TAG_BLOCK_STATUS, "" + blockedMe);
                                            message.put(Constants.TAG_BLOCKED_BY, blockedMe ? mdata.receiver_id : "");
                                            message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
                                            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                                            jobj.put(Constants.TAG_SENDER_ID, mdata.user_id);
                                            jobj.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
                                            jobj.put("message_data", message);
                                            socketConnection.startChat(jobj);
//                                            }

                                            dbhelper.updateMessageData(mdata.message_id, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
                                            dbhelper.updateMessageData(mdata.message_id, Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(thumbnail));
                                            dbhelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "completed");

                                            mBuilder.setProgress(0, 0, false);
                                            mBuilder.setContentText(getString(R.string.file_uploaded));
                                            mNotifyManager.cancel("progress", 2);
                                            mNotifyManager.notify(2, mBuilder.build());

                                            socketConnection.setUploadingListen(chatType, mdata.message_id, newFileName, "completed", null);
                                            stopSelf();
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        setErrorUpload();
                                    }
                                } else {
                                    setErrorUpload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                setErrorUpload();
                            }
                        } else {
                            setErrorUpload();
                        }
                    }

                    @Override
                    public void onFailure(Call<Map<String, String>> call, Throwable t) {
                        Log.e(TAG, "onFailure: " + t.getMessage());
                        call.cancel();
                        setErrorUpload();
                    }
                });
                break;
            }
            case "group": {
                gdata = (GroupMessage) bundle.getSerializable("mdata");
                ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
                MultipartBody.Part filePart = MultipartBody.Part.createFormData("group_attachment", new File(uploadFilePath).getName(), fileBody);

                ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
                RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
                Call<HashMap<String, String>> call = apiInterface.upMyGroupChat(GetSet.getToken(), filePart, userid);
                call.enqueue(new Callback<HashMap<String, String>>() {
                    @Override
                    public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                        if (response.isSuccessful()) {
                            try {
                                HashMap<String, String> userdata = response.body();
                                if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                                    String apiFileName = userdata.get(Constants.TAG_USER_IMAGE);
                                    try {
                                        boolean fileStatus;
                                        switch (gdata.messageType) {
                                            case Constants.TAG_AUDIO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_AUDIO);
                                                break;
                                            case Constants.TAG_VIDEO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_VIDEO);
                                                break;
                                            case Constants.TAG_DOCUMENT:
                                            default:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_DOCUMENT);
                                                break;
                                        }

                                        if (fileStatus) {
                                            JSONObject message = new JSONObject();
                                            message.put(Constants.TAG_GROUP_ID, gdata.groupId);
                                            message.put(Constants.TAG_GROUP_NAME, gdata.groupName);
                                            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                                            message.put(Constants.TAG_MESSAGE_TYPE, gdata.messageType);
                                            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                                            message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(thumbnail) : "");
                                            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(gdata.message));
                                            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
                                            message.put(Constants.TAG_MESSAGE_ID, gdata.messageId);
                                            message.put(Constants.TAG_MEMBER_ID, gdata.memberId);
                                            message.put(Constants.TAG_MEMBER_NAME, gdata.memberName);
                                            message.put(Constants.TAG_MEMBER_NO, gdata.memberNo);
                                            message.put(Constants.TAG_DELIVERY_STATUS, "read");
                                            Log.v(TAG, "messageToGroup: " + message);
                                            socketConnection.messageToGroup(message);

                                            dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                                            dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(thumbnail));
                                            dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_PROGRESS, "completed");

                                            socketConnection.setUploadingListen(chatType, gdata.messageId, apiFileName, "completed", null);
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        setGroupErrorUpload();
                                    }
                                } else {
                                    setGroupErrorUpload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                setGroupErrorUpload();
                            }
                        } else {
                            setGroupErrorUpload();
                        }
                    }

                    @Override
                    public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                        Log.e(TAG, "onFailure: " + t.getMessage());
                        setGroupErrorUpload();
                    }
                });
                break;
            }
            case Constants.TAG_CHANNEL: {
                chdata = (ChannelMessage) bundle.getSerializable("mdata");

                ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
                MultipartBody.Part filePart = MultipartBody.Part.createFormData("channel_attachment", new File(uploadFilePath).getName(), fileBody);

                RequestBody channelid = RequestBody.create(chdata.channelId, MediaType.parse("multipart/form-data"));
                ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
                RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
                Call<Map<String, String>> call = apiInterface.upChannelChat(GetSet.getToken(), filePart, channelid, userid);
                call.enqueue(new Callback<Map<String, String>>() {
                    @Override
                    public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                        if (response.isSuccessful()) {
                            try {
//                            Log.v(TAG, "upChannelChat " + new Gson().toJson(response.body()));
                                Map<String, String> userdata = response.body();
                                if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                                    String apiFileName = userdata.get(Constants.TAG_USER_IMAGE);
                                    try {
                                        boolean fileStatus;
                                        switch (chdata.messageType) {
                                            case Constants.TAG_AUDIO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_AUDIO);
                                                break;
                                            case Constants.TAG_VIDEO:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_VIDEO);
                                                break;
                                            case Constants.TAG_DOCUMENT:
                                            default:
                                                fileStatus = storageManager.renameFile(null, uploadFilePath, apiFileName, StorageManager.TAG_DOCUMENT);
                                                break;
                                        }

                                        if (fileStatus) {
                                            JSONObject message = new JSONObject();
                                            message.put(Constants.TAG_CHANNEL_ID, chdata.channelId);
                                            message.put(Constants.TAG_ADMIN_ID, chdata.channelAdminId);
                                            message.put(Constants.TAG_CHANNEL_NAME, chdata.channelName);
                                            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_CHANNEL);
                                            message.put(Constants.TAG_MESSAGE_TYPE, chdata.messageType);
                                            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                                            message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(thumbnail) : "");
                                            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(chdata.message));
                                            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
                                            message.put(Constants.TAG_MESSAGE_ID, chdata.messageId);
                                            socketConnection.messageToChannel(message);

                                            dbhelper.updateChannelMessageData(chdata.messageId, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                                            dbhelper.updateChannelMessageData(chdata.messageId, Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(thumbnail));
                                            dbhelper.updateChannelMessageData(chdata.messageId, Constants.TAG_PROGRESS, "completed");

                                            mBuilder.setProgress(0, 0, false);
                                            mBuilder.setContentText(getString(R.string.file_uploaded));
                                            mNotifyManager.cancel("progress", 2);
                                            mNotifyManager.notify(2, mBuilder.build());

                                            socketConnection.setUploadingListen(chatType, chdata.messageId, apiFileName, "completed", null);
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        setChannelErrorUpload();
                                    }
                                } else {
                                    setChannelErrorUpload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                setChannelErrorUpload();
                            }
                        } else {
                            setChannelErrorUpload();
                        }
                    }

                    @Override
                    public void onFailure(Call<Map<String, String>> call, Throwable t) {
                        Log.e(TAG, "onFailure: " + t.getMessage());
                        call.cancel();
                        setChannelErrorUpload();
                    }
                });
                break;
            }
            case StorageManager.TAG_STATUS: {
                mdata = (MessagesData) bundle.getSerializable("mdata");

                ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
                MultipartBody.Part filePart = MultipartBody.Part.createFormData("attachment", new File(uploadFilePath).getName(), fileBody);

                ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
                RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
                Call<Map<String, String>> call3 = apiInterface.upchat(GetSet.getToken(), filePart, userid);
                call3.enqueue(new Callback<Map<String, String>>() {
                    @Override
                    public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                        if (response.isSuccessful()) {
                            try {
                                Log.v(TAG, "uploadStatusResponse= " + response.body());
                                Log.v(TAG, "filepath= " + uploadFilePath);
                                Map<String, String> userdata = response.body();
                                if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                                    String apiFileName = userdata.get(Constants.TAG_USER_IMAGE);
                                    storageManager.saveStatusFile(null, new File(uploadFilePath), apiFileName, Constants.TAG_SENT);
//                                boolean fileStatus = storageManager.moveFilesToSentPath(FileUploadService.this, StorageManager.TAG_VIDEO_SENT, uploadFilePath, apiFileName);
                                    mBuilder.setProgress(0, 0, false);
                                    mBuilder.setContentText(getString(R.string.file_uploaded));
                                    mNotifyManager.cancel("progress", 2);
                                    mNotifyManager.notify(2, mBuilder.build());

                                    socketConnection.setUploadingListen(chatType, "", apiFileName, "completed", apiFileName);
                                } else {
                                    setStatusErrorUpload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                setStatusErrorUpload();
                            }
                        } else {
                            setStatusErrorUpload();
                        }
                    }

                    @Override
                    public void onFailure(Call<Map<String, String>> call, Throwable t) {
                        Log.e(TAG, "onFailure: " + t.getMessage());
                        call.cancel();
                        setStatusErrorUpload();
                    }
                });
                break;
            }
        }
        Log.v(TAG, "onStartCommand END");
        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Log.d(TAG, "onTaskRemoved: ");
        if (chatType == null) {
        } else if (chatType.equals("chat")) {
            if (mdata.message_id != null)
                setErrorUpload();
        } else if (chatType.equals("group")) {
            if (gdata.groupId != null)
                setGroupErrorUpload();
        } else if (chatType.equalsIgnoreCase("channel")) {
            if (chdata.messageId != null)
                setChannelErrorUpload();
        }
        Log.v(TAG, "nos " + "task removed");
    }


    private void setErrorUpload() {
        dbhelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
        socketConnection.setUploadingListen(chatType, mdata.message_id, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(getString(R.string.file_upload_error));
        mNotifyManager.cancel("progress", 2);
        mNotifyManager.notify(2, mBuilder.build());
    }

    private void setGroupErrorUpload() {
        dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_PROGRESS, "error");
        socketConnection.setUploadingListen(chatType, gdata.messageId, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(getString(R.string.file_upload_error));
        mNotifyManager.cancel(2);
        mNotifyManager.notify(2, mBuilder.build());
    }

    private void setChannelErrorUpload() {
        dbhelper.updateChannelMessageData(chdata.messageId, Constants.TAG_PROGRESS, "error");
        socketConnection.setUploadingListen(chatType, chdata.messageId, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(getString(R.string.file_upload_error));
        mNotifyManager.cancel("progress", 2);
        mNotifyManager.notify(2, mBuilder.build());
    }

    private void setStatusErrorUpload() {
        socketConnection.setUploadingListen(chatType, mdata.message_id, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(getString(R.string.file_upload_error));
        mNotifyManager.cancel("progress", 2);
        mNotifyManager.notify(2, mBuilder.build());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
        IS_FILE_UPLOADING = false;
        /*if (ApplicationClass.getCurrentActivity() == null) {
            if (socketConnection != null) {
                socketConnection.goAway(ApplicationClass.groupList);
                socketConnection.disconnect();
            }
        }*/
    }

    @Override
    public void onProgressUpdate(final int percentage) {
        Log.d(TAG, "onProgressUpdate: " + percentage);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (percentage != 100) {
                    mBuilder.setProgress(100, percentage, false)
                            .setContentText(mContext.getString(R.string.uploading));
                    mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
                }
            }
        });
    }

    @Override
    public void onError() {
        Log.v(TAG, "onError");
        if (chatType.equals("chat")) {
            setErrorUpload();
        } else if (chatType.equals("group")) {
            setGroupErrorUpload();
        }
    }

    @Override
    public void onFinish() {
        mBuilder.setProgress(100, 100, false)
                .setContentText(getString(R.string.file_uploaded));
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mNotifyManager.cancel(NOTIFICATION_ID);
            }
        }, 1000);
    }

    @Override
    public void uploadStart() {
        createNotification();
    }

    private void createNotification() {
        Log.d(TAG, "createNotification: " + NOTIFICATION_ID);
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = getString(R.string.notification_channel_foreground_service);
        CharSequence channelName = getString(R.string.app_name);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        mBuilder = new NotificationCompat.Builder(this, channelId);
        mBuilder.setContentTitle(getString(R.string.app_name))
                .setContentText(mContext.getString(R.string.uploading))
                .setSmallIcon(R.drawable.notification)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true);
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

}
