package com.app.helper;

import android.os.Handler;
import android.os.Looper;

import com.app.helper.connectivity.NetworkStatus;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

/**
 * Created by hitasoft on 14/7/18.
 */

public class ProgressRequestBody extends RequestBody {

    private static final String TAG = ProgressRequestBody.class.getSimpleName();
    private static final int TIME_REFRESH_MS = 50;
    private File mFile;
    private long mUploadedSize;
    private long mTotalSize;
    private UploadCallbacks mListener;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final ProgressUpdater mProgressUpdater = new ProgressUpdater();

    private static final int DEFAULT_BUFFER_SIZE = 2048;

    public ProgressRequestBody(final File file, final UploadCallbacks listener) {
        mFile = file;
        mListener = listener;
        mListener.uploadStart();
    }

    @Override
    public MediaType contentType() {
        // i want to upload only images
        return MediaType.parse("*/*");
    }

    @Override
    public long contentLength() throws IOException {
        if (mFile != null) {
            return mFile.length();
        }
        return 0;
    }

    @Override
    public void writeTo(BufferedSink sink) throws IOException {
        mTotalSize = mFile.length();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        FileInputStream in = new FileInputStream(mFile);
        mUploadedSize = 0;
        if (mListener != null) {
            mHandler.postDelayed(mProgressUpdater, TIME_REFRESH_MS);
        }
        try {
            int read;
            Handler handler = new Handler(Looper.getMainLooper());
            while ((read = in.read(buffer)) != -1) {
                mUploadedSize += read;
                sink.write(buffer, 0, read);
            }
        } finally {
            in.close();
            //  mListener.onError();
        }
    }


    public interface UploadCallbacks {
        void onProgressUpdate(int percentage);

        void onError();

        void onFinish();

        void uploadStart();
    }

    private class ProgressUpdater implements Runnable {

        public ProgressUpdater() {
        }

        @Override
        public void run() {
            if (mListener != null && mTotalSize > 0) {
                int progress = (int) (100 * mUploadedSize / mTotalSize);
                if (progress != 100) {
                    if (NetworkStatus.isConnected()) {
                        mListener.onProgressUpdate(progress);
                        mHandler.postDelayed(mProgressUpdater, TIME_REFRESH_MS);
                    } else {
                        mHandler.removeCallbacks(mProgressUpdater);
                        mListener.onError();
                    }
                } else {
                    mHandler.removeCallbacks(mProgressUpdater);
                    mListener.onFinish();
                }
            }
        }
    }
}