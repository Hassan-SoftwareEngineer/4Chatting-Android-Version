package com.app.helper.event;

import com.app.model.GroupMessage;

public class NewGroupMessageEvent {
    private GroupMessage groupMessage;

    public NewGroupMessageEvent(GroupMessage groupMessage) {
        this.groupMessage = groupMessage;
    }

    public GroupMessage getGroupMessage() {
        return groupMessage;
    }

    public void setGroupMessage(GroupMessage groupMessage) {
        this.groupMessage = groupMessage;
    }
}
