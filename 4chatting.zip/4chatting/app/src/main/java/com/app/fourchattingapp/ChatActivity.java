package com.app.fourchattingapp;

import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.helper.StorageManager.TAG_AUDIO;
import static com.app.helper.StorageManager.TAG_AUDIO_SENT;
import static com.app.helper.StorageManager.TAG_DOCUMENT;
import static com.app.helper.StorageManager.TAG_DOCUMENT_SENT;
import static com.app.helper.StorageManager.TAG_THUMB;
import static com.app.helper.StorageManager.TAG_VIDEO;
import static com.app.helper.StorageManager.TAG_VIDEO_SENT;
import static com.app.fourchattingapp.ChatActivity.MessageListAdapter.VIEW_TYPE_DATE;
import static com.app.utils.Constants.TAG_IMAGE;
import static com.app.utils.Constants.TAG_MY_CONTACTS;
import static com.app.utils.Constants.TAG_NOBODY;
import static com.app.utils.Constants.TAG_TRUE;
import static com.app.utils.Constants.TAG_USER_ID;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.transition.TransitionManager;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.app.fourchattingapp.status.SingleStoryActivity;
import com.app.model.MessagesData;
import com.app.model.StatusDatas;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.GranularRoundedCorners;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.devlomi.record_view.OnRecordListener;
import com.devlomi.record_view.RecordButton;
import com.devlomi.record_view.RecordView;
import com.giphy.sdk.core.models.Media;
import com.giphy.sdk.ui.GPHContentType;
import com.giphy.sdk.ui.GPHSettings;
import com.giphy.sdk.ui.Giphy;
import com.giphy.sdk.ui.themes.GPHTheme;
import com.giphy.sdk.ui.themes.GridType;
import com.giphy.sdk.ui.views.GiphyDialogFragment;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.mlkit.nl.smartreply.SmartReplySuggestion;
import com.app.addons.smartreply.GenerateSmartReplyWorker;
import com.app.addons.smartreply.ReplyChipAdapter;
import com.app.apprtc.util.AppRTCUtils;
import com.app.external.EndlessRecyclerOnScrollListener;
import com.app.external.ImagePicker;
import com.app.external.MediaPlayerUtils;
import com.app.external.ProgressWheel;
import com.app.external.RandomString;
import com.app.external.RecyclerItemClickListener;
import com.app.external.keyboard.HeightProvider;
import com.app.helper.BitmapCompression;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.DownloadFiles;
import com.app.helper.DownloadFilesTask;
import com.app.helper.FileUploadService;
import com.app.helper.ImageDownloader;
import com.app.helper.NetworkUtil;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.helper.Utils;
import com.app.helper.WrapContentLinearLayoutManager;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.connectivity.NetworkStatus;
import com.app.helper.event.NewMessageEvent;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.makeramen.roundedimageview.RoundedImageView;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;
import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.models.sort.SortingTypes;
import droidninja.filepicker.utils.ContentUriUtils;
import jp.wasabeef.glide.transformations.BlurTransformation;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ChatActivity extends BaseActivity implements View.OnClickListener,
        SocketConnection.ChatCallbackListener, TextWatcher, DeleteAdapter.deleteListener, MediaPlayerUtils.Listener, GiphyDialogFragment.GifSelectionListener, RecognitionListener {
    private static final String TAG = ChatActivity.class.getSimpleName();
    public static String tempUserId = "";
    EditText editText;
    String userId, chatId;
    List<MessagesData> messagesList = new ArrayList<>();
    RecyclerView recyclerView;
    TextView username, online, txtBlocked;
    private CoordinatorLayout parentLay;
    RelativeLayout chatUserLay, mainLay, attachmentsLay, imageViewLay, bottomLay, forwordLay;

    Intent intent;
    SpeechRecognizer recognizer;
    TextView txt_recording;
    private ImageView attachbtn, optionbtn, backbtn, send, audioCallBtn, videoCallBtn, cameraBtn,
            galleryBtn, fileBtn, audioBtn, locationBtn, contactBtn, imageView, closeBtn,
            forwordBtn, copyBtn, deleteBtn, ivEmoji, btnGif, btnLanguage;
    LinearLayout toolBarBtnLay;
    CircleImageView userimage;
    FrameLayout newMessageLay;
    ImageView iconNewMessage;
    Display display;
    TextToSpeech t1;
    private Context mContext;
    SocketConnection socketConnection;
    LinearLayoutManager linearLayoutManager;
    MessageListAdapter messageListAdapter;
    DatabaseHandler dbHelper;
    StorageManager storageManager;
    ApiInterface apiInterface;
    ArrayList<Uri> pathsAry = new ArrayList<>();
    Handler handler = new Handler(Looper.getMainLooper());
    Runnable runnable;
    private Utils utils;
    ContactsData.Result results;
    EndlessRecyclerOnScrollListener endlessRecyclerOnScrollListener;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    ArrayList<MessagesData> selectedChatPos = new ArrayList<>();
    String recordVoicePath = null;
    Uri recordVoiceUri = null;
    MediaRecorder mediaRecorder;
    RecordView recordView;
    RecordButton recordButton;
    LinearLayout editLay, excryptText;
    boolean isRecording = false;
    private List<String> tempMessageIdList = new ArrayList<>();
    private String currentMessageId = null;
    private boolean isFromNotification = false;
    private Dialog permissionDialog;
    private Parcelable state;
    boolean isScroll = true, visible, stopLoading = false, meTyping, chatLongPressed = false;
    int totalMsg;

    private int keyBoardHeight = 0, bottomNavHeight = 0, bottomMargin = 0, scrollPosition = 0;
    private boolean isKeyBoardOpen = false;
    private boolean isMoveToStart = true, isLoadedAllItems = false, isApiCall = false;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private ActivityResultLauncher<String[]> callPermissionResult;
    private ActivityResultLauncher<Intent> contactResultLauncher;
    private ActivityResultLauncher<Intent> galleryResultLauncher;
    private ActivityResultLauncher<Intent> audioResultLauncher;
    private ActivityResultLauncher<Intent> documentResultLauncher;
    private ActivityResultLauncher<Intent> addContactResultLauncher;
    private ActivityResultLauncher<Intent> forwardResultLauncher;
    private ActivityResultLauncher<Intent> locationResultLauncher;
    private boolean isGalleryClicked = false, isCameraClicked = false, isFileClicked = false,
            isAudioClicked = false, isDownloadClicked = false;
    // The minimum amount of items to have below your current scroll position before loading more.
    private boolean isLoading;
    private DateUtils dateUtils;
    private boolean isDeletedAccount = false;
    private Uri photoURI;
    private HeightProvider heightProvider;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler onlineHandler = new Handler(Looper.myLooper());
    Runnable onlineRunnable = new Runnable() {
        @Override
        public void run() {
            if (NetworkStatus.isConnected()) {
                if (results != null && !results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                    checkOnlineStatus();
                }
            }
            onlineHandler.postDelayed(onlineRunnable, Constants.ONLINE_CHECK_TIMER);
        }
    };

    private void checkOnlineStatus() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_USER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_CONTACT_ID, userId);
            Log.v(TAG, "checkOnlineStatus: " + jsonObject);
            socketConnection.online(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Addon Gif
    GiphyDialogFragment giphyDialogFragment;
    //Addon Smart Reply
    ReplyChipAdapter mChipAdapter;
    private RecyclerView mSmartRepliesRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initValues();

        initBackground();
        initActivityResult();
        setContentView(R.layout.activity_main_chat);
        isRecording = false;


        if (getIntent().getStringExtra("notification") != null) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.cancelAll();
            }
        }

        if (Constants.chatContext != null && Constants.isChatOpened) {
            ((Activity) Constants.chatContext).finish();
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Constants.chatContext = this;

        parentLay = findViewById(R.id.parentLay);
        txt_recording = findViewById(R.id.txt_recording);
        recyclerView = findViewById(R.id.recyclerView);
        send = findViewById(R.id.send);
        editText = findViewById(R.id.editText);
        chatUserLay = findViewById(R.id.chatUserLay);
        toolBarBtnLay = findViewById(R.id.buttonLayout);
        userimage = findViewById(R.id.userImg);
        username = findViewById(R.id.userName);
        online = findViewById(R.id.online);
        txtBlocked = findViewById(R.id.txtBlocked);
        attachbtn = findViewById(R.id.attachbtn);
        audioCallBtn = findViewById(R.id.audioCallBtn);
        videoCallBtn = findViewById(R.id.videoCallBtn);
        optionbtn = findViewById(R.id.optionbtn);
        backbtn = findViewById(R.id.backbtn);
        bottomLay = findViewById(R.id.bottom);
        mainLay = findViewById(R.id.mainLay);
        attachmentsLay = findViewById(R.id.attachmentsLay);
        cameraBtn = findViewById(R.id.cameraBtn);
        galleryBtn = findViewById(R.id.galleryBtn);
        fileBtn = findViewById(R.id.fileBtn);
        audioBtn = findViewById(R.id.audioBtn);
        locationBtn = findViewById(R.id.locationBtn);
        contactBtn = findViewById(R.id.contactBtn);
        newMessageLay = findViewById(R.id.newMessageLay);
        iconNewMessage = findViewById(R.id.iconNewMessage);
        imageViewLay = findViewById(R.id.imageViewLay);
        imageView = findViewById(R.id.imageView);
        closeBtn = findViewById(R.id.closeBtn);
        forwordLay = findViewById(R.id.forwordLay);
        forwordBtn = findViewById(R.id.forwordBtn);
        copyBtn = findViewById(R.id.copyBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        editLay = findViewById(R.id.editLay);
        recordView = findViewById(R.id.record_view);
        recordButton = findViewById(R.id.record_button);
        excryptText = findViewById(R.id.excryptText);
        ivEmoji = findViewById(R.id.iv_emoji);
        btnLanguage = findViewById(R.id.btnLanguage);
        mSmartRepliesRecycler = findViewById(R.id.smartRepliesRecycler);
        btnGif = findViewById(R.id.btnGif);

        if (recyclerView.getItemAnimator() != null) {
            ((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
        }

        tempMessageIdList = new ArrayList<>();
        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        // set visibility status
        chatUserLay.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        audioCallBtn.setVisibility(View.VISIBLE);
        videoCallBtn.setVisibility(View.VISIBLE);
        optionbtn.setVisibility(View.VISIBLE);

        initPermission();
        //checkUserIsActive();
        checkUserExist();
        setVoiceRecorder();
        setKeyBoardListener();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(results.user_name, 0);
        }
        username.setText(results.user_name);
        setBlockStatus(results);
        totalMsg = dbHelper.getMessagesCount(chatId);

        try {
            List<MessagesData> tempMsgList = dbHelper.getMessages(chatId, "0", "" + Constants.CHAT_PAGINATION_LIMIT);
            messagesList.addAll(getMessagesAry(tempMsgList, null));
        } catch (Exception e) {
            e.printStackTrace();
        }
        showEncryptionText();
        linearLayoutManager = new WrapContentLinearLayoutManager(this, RecyclerView.VERTICAL, false);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        messageListAdapter = new MessageListAdapter(this, messagesList);
        recyclerView.setAdapter(messageListAdapter);
        DividerItemDecoration divider = new DividerItemDecoration(recyclerView.getContext(),
                linearLayoutManager.getOrientation());
        divider.setDrawable(ContextCompat.getDrawable(mContext, R.drawable.emptychat_divider));
        recyclerView.addItemDecoration(divider);
        recyclerView.post(new Runnable() {
            @Override
            public void run() {
                recyclerView.scrollToPosition(0);
            }
        });

        initAdOns();

        send.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        attachbtn.setOnClickListener(this);
        optionbtn.setOnClickListener(this);
        userimage.setOnClickListener(this);
        audioCallBtn.setOnClickListener(this);
        videoCallBtn.setOnClickListener(this);
        cameraBtn.setOnClickListener(this);
        galleryBtn.setOnClickListener(this);
        fileBtn.setOnClickListener(this);
        audioBtn.setOnClickListener(this);
        locationBtn.setOnClickListener(this);
        contactBtn.setOnClickListener(this);
        editText.addTextChangedListener(this);
        chatUserLay.setOnClickListener(this);
        closeBtn.setOnClickListener(this);
        copyBtn.setOnClickListener(this);
        forwordBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);

        newMessageLay.setOnClickListener(this);

        txt_recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkAudioPermission()) {
                    if (recognizer!=null){
                        recognizer.stopListening();
                    }

                    recognizer = SpeechRecognizer.createSpeechRecognizer(ChatActivity.this);
                    if (txt_recording.getText().toString().equals("Stop Recording")){
                        recognizer.stopListening();
                        txt_recording.setText("Start Recording");

                    }else{
                        txt_recording.setText("Stop Recording");
                        final Intent speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").isEmpty()){
                            speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                        }else{
                            if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")!=null){
                                speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""));

                            }else{
                                speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                            }

                        }

                        recognizer.setRecognitionListener(ChatActivity.this);
                        recognizer.startListening(speechRecognizerIntent);


//                        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
//                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
//                        if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").isEmpty()){
//                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
//                        }else{
//                            if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")!=null){
//                                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""));
//
//                            }else{
//                                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
//
//                            }
//
//                        }
//
//                        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true);


                    }


                } else {

                    requestAudioPermission();
                }
            }
        });

        endlessRecyclerOnScrollListener = new EndlessRecyclerOnScrollListener(linearLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                final List<MessagesData> tmpList = new ArrayList<>();
                try {
                    tmpList.addAll(dbHelper.getMessages(GetSet.getUserId() + userId, String.valueOf(page * 20), "20"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (tmpList.size() == 0 && !stopLoading) {
                    stopLoading = true;
                    messagesList.addAll(getMessagesAry(tmpList, messagesList.get(messagesList.size() - 1)));
                } else {
                    messagesList.addAll(getMessagesAry(tmpList, null));
                }
                showEncryptionText();
                recyclerView.post(new Runnable() {
                    public void run() {
//                        Log.v(TAG, "onLoadMore: " + messagesList.size());
                        messageListAdapter.notifyDataSetChanged();
                    }
                });
            }
        };
        recyclerView.addOnScrollListener(endlessRecyclerOnScrollListener);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) isScroll = true;
                scrollPosition = dy;
                isMoveToStart = linearLayoutManager.findFirstCompletelyVisibleItemPosition() == 0;
                new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setNewMessageLay();
                    }
                }, 100);
            }
        });

        if (SocketConnection.onUpdateTabIndication != null) {
            SocketConnection.onUpdateTabIndication.updateIndication();
        }
        recyclerView.addOnItemTouchListener(chatItemClick(this, recyclerView));
        requestStoragePermissions();
    }

    private void initValues() {
        mContext = this;
        pref = ChatActivity.this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        utils = new Utils(this);
        socketConnection = SocketConnection.getInstance(this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        dbHelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        display = getWindowManager().getDefaultDisplay();
        userId = getIntent().getExtras().getString("user_id");
        tempUserId = userId;
        results = dbHelper.getContactDetail(userId);
        dbHelper.updateContactInfo(userId, Constants.TAG_UNKNOWN_CONTACT, "" + 0);
        chatId = GetSet.getUserId() + userId;
        dateUtils = DateUtils.getInstance(this);
        if (getIntent().getStringExtra("notification") != null) {
            Constants.isChatOpened = true;
            isFromNotification = true;
            overridePendingTransition(0, 0);
        }


    }

    public void checkUserExist() {
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Map<String, String>> call3 = apiInterface.checkUserExists(GetSet.getToken(), userId);
        call3.enqueue(new Callback<Map<String, String>>() {
            @Override
            public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                if (response.isSuccessful()) {
                    Map<String, String> data = response.body();
                    Log.e(TAG, "checkUserExist: " + new Gson().toJson(response.body()));
                    if (data.get(Constants.TAG_STATUS).equals(TAG_TRUE)) {
                        dbHelper.updateContactInfo(userId, Constants.TAG_DELETED_ACCOUNT, "0");
                    } else {
                        dbHelper.updateContactInfo(userId, Constants.TAG_DELETED_ACCOUNT, "1");
                    }
                    results = dbHelper.getContactDetail(userId);
                    checkUserIsActive();
                }
            }

            @Override
            public void onFailure(Call<Map<String, String>> call, Throwable t) {
                call.cancel();
            }
        });
    }

    private void checkUserIsActive() {
        isDeletedAccount = results.isDeletedAccount.equals("1");
        setDeletedAccountUI(isDeletedAccount);
    }

    private void setDeletedAccountUI(boolean isDeletedAccount) {
        if (isDeletedAccount) {
            txtBlocked.setText(R.string.the_account_has_been_deleted);
            username.setText(R.string.deleted_account);
            txtBlocked.setVisibility(View.VISIBLE);
            bottomLay.setVisibility(View.GONE);
            chatUserLay.setEnabled(false);
            audioCallBtn.setEnabled(false);
            videoCallBtn.setEnabled(false);
            optionbtn.setEnabled(false);
            deleteBtn.setVisibility(View.GONE);
        }
    }

    private void setNewMessageLay() {
        if (isFirstItemVisible() || messagesList.size() == 0) {
            iconNewMessage.setVisibility(View.GONE);
            newMessageLay.setVisibility(View.GONE);
        } else {
            newMessageLay.setVisibility(View.VISIBLE);
        }
    }

    private void setNewMessageParams(int visibility) {
        if (visibility == View.VISIBLE) {
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.addRule(RelativeLayout.ABOVE, R.id.bottom);
            params.addRule(RelativeLayout.ALIGN_PARENT_END);
            params.bottomMargin = ApplicationClass.dpToPx(this, 15);
            params.rightMargin = ApplicationClass.dpToPx(this, 15);
            newMessageLay.setLayoutParams(params);
        } else {
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            params.addRule(RelativeLayout.ALIGN_PARENT_END);
            params.bottomMargin = ApplicationClass.dpToPx(this, 15);
            params.rightMargin = ApplicationClass.dpToPx(this, 15);
            newMessageLay.setLayoutParams(params);
        }
    }

    private void setKeyBoardListener() {
        heightProvider = new HeightProvider(this);
        parentLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + bottomMargin;
                if (parentLay != null) {
//                    setBottomMargin(bottomNavHeight + bottomMargin);
                }
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        heightProvider.init().setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                Log.d(TAG, "onHeightChanged: " + height);
                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                if (height > 0) {
                    params.bottomMargin = height;
                    bottomLay.setLayoutParams(params);
                    if (isMoveToStart) {
                        recyclerView.scrollToPosition(0);
                    }
                    keyBoardHeight = height;
                    isKeyBoardOpen = true;
                } else {
                    params.bottomMargin = 0;
                    bottomLay.setLayoutParams(params);
                    isKeyBoardOpen = false;
                    keyBoardHeight = 0;
                }
            }
        });
    }

    private void initAdOns() {
        if (Constants.ADDON_EMOJI_GIF) {
            initGif();
        }
        if (Constants.ADDON_SMART_REPLY) {
            setSmartReplyRecyclerView();
        }

        if (Constants.ADDON_CHAT_TRANSLATE) {
            btnLanguage.setVisibility(View.VISIBLE);
            btnLanguage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isRecording) return;
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        makeToast(getString(R.string.network_failure));
                        return;
                    }
                    Intent language = new Intent(getApplicationContext(), LanguageActivity.class);
                    language.putExtra(Constants.TAG_FROM, Constants.TAG_CHAT);
                    language.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(language);
                }
            });
        } else {
            btnLanguage.setVisibility(View.GONE);
        }
    }

    //Addon Gif
    private void initGif() {
        btnGif.setVisibility(View.VISIBLE);
        Giphy.INSTANCE.configure(this, Constants.GIPHY_KEY, false);
        GPHSettings settings = new GPHSettings();
        settings.setGridType(GridType.waterfall);
        settings.setTheme(GPHTheme.Light);
        settings.setShowCheckeredBackground(true);
        settings.setMediaTypeConfig(new GPHContentType[]{GPHContentType.sticker, GPHContentType.emoji, GPHContentType.gif, GPHContentType.text});
        giphyDialogFragment = GiphyDialogFragment.Companion.newInstance(settings);
        giphyDialogFragment.setGifSelectionListener(this);
        btnGif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else if (results.blockedbyme.equals("block")) {
                    blockChatConfirmDialog("unblock", "sent");
                } else {
                    //Addon Gif
                    giphyDialogFragment.show(getSupportFragmentManager(), "giphy_dialog");
                }
            }
        });
    }

    //Addon SmartReply
    private void setSmartReplyRecyclerView() {
        // Set up recycler view for smart replies
        mSmartRepliesRecycler.setVisibility(View.VISIBLE);
        LinearLayoutManager chipManager = new LinearLayoutManager(this);
        chipManager.setOrientation(RecyclerView.HORIZONTAL);
        mChipAdapter = new ReplyChipAdapter(new ReplyChipAdapter.ClickListener() {
            @Override
            public void onChipClick(@NonNull String chipText) {
                sendTextMessage(chipText);
            }
        });
        mSmartRepliesRecycler.setLayoutManager(chipManager);
        mSmartRepliesRecycler.setAdapter(mChipAdapter);
        mChipAdapter.notifyDataSetChanged();

        if (messagesList.size() > 0) {
            for (MessagesData messagesData : messagesList) {
                if (!messagesData.message_type.equals(Constants.TAG_DATE)) {
                    if (messagesData.message_type.equals(Constants.TAG_TEXT) || messagesData.message_type.equals(Constants.TAG_STORY)) {
                        if (messagesData.sender_id != null && !messagesData.sender_id.equals(GetSet.getUserId())) {
                            generateReplies(messagesData.message);
                        }
                    } else {
                        mSmartRepliesRecycler.setVisibility(View.GONE);
                    }
                    break;
                }
            }
        }
    }

    private void showEncryptionText() {
        if (messagesList.isEmpty()) {
            excryptText.setVisibility(View.VISIBLE);
        } else {
            excryptText.setVisibility(View.GONE);
        }
    }

    private void setVoiceRecorder() {
        setClickEvent(false, false, false, false, false, false);
//        recordView.setCounterTimeColor(Color.parseColor("#a3a3a3"));
        recordView.setCounterTimeColor(getResources().getColor(R.color.recieveLastSeen));
        recordView.setSmallMicColor(ContextCompat.getColor(ChatActivity.this, R.color.colorAccent));
//        recordView.setSlideToCancelTextColor(Color.parseColor("#a3a3a3"));
        recordView.setSlideToCancelTextColor(getResources().getColor(R.color.recieveLastSeen));
        recordView.setLessThanSecondAllowed(false);
        recordView.setSlideToCancelText(getString(R.string.slide_to_cancel));
        //set Custom sounds onRecord
        //you can pass 0 if you don't want to play sound in certain state
        recordView.setCustomSounds(R.raw.record_start, R.raw.record_finished, R.raw.record_error);

        recordButton.setRecordView(recordView);

        /*if(ApplicationClass.isRTL()){
            float cancelBound = ApplicationClass.pxToDp(getApplicationContext(),ApplicationClass.getWidth(getApplicationContext())) -
                    ApplicationClass.dpToPx(getApplicationContext(), (int) recordView.getCancelBounds());
            recordView.setCancelBounds(cancelBound);
        }

        Log.d(TAG, "setVoiceRecorder: " + recordView.getCancelBounds() + "\n"+ApplicationClass.dpToPx(getApplicationContext(),8)
                + "\n" );*/

        if (isNetworkConnected().equals(NOT_CONNECT)) {
            networkSnack();
        } else if (results.blockedbyme.equals("block")) {
            blockChatConfirmDialog("unblock", "sent");
        } else {
            recordView.setOnRecordListener(new OnRecordListener() {
                @Override
                public void onStart() {
                    if (checkAudioPermission()) {
                        isRecording = true;
                        startVoice();
                        Log.e("checkAudiois", "audioRecord");
                    } else {
                        recordVoicePath = null;
                        recordVoiceUri = null;
                        recordView.setOnRecordListener(null);
                        requestAudioPermission();
                    }
                }

                @Override
                public void onCancel() {
                    Log.e("checkAudiois", "cancel");
                    isRecording = false;
                    sendTypingStatus("untyping");
                    editText.requestFocus();
                    playSound(R.raw.record_error, false);
//                Toast.makeText(ChatActivity.this, "onCancel"+time, Toast.LENGTH_SHORT).show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ApplicationClass.hideSoftKeyboard(ChatActivity.this, recordView);
                            editLay.setVisibility(View.VISIBLE);
                            recordView.setVisibility(View.GONE);
                            if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                                runnable = new Runnable() {
                                    public void run() {
                                        meTyping = false;
                                        sendTypingStatus("untyping");
                                    }
                                };
                                handler.postDelayed(runnable, 1000);
                            }
                        }
                    }, 1000);

                }

                @Override
                public void onFinish(long recordTime, boolean limitReached) {

                    if (recordTime > 1500 && (recordVoicePath != null || recordVoiceUri != null)) {
                        editText.requestFocus();
                        isRecording = false;
                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                            networkSnack();
                        } else if (results.blockedbyme.equals("block")) {
                            blockChatConfirmDialog("unblock", "sent");
                        } else {
                            if (null != mediaRecorder) {
                                try {
                                    mediaRecorder.stop();
                                } catch (RuntimeException ignored) {
                                }
                            }

                            if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                                runnable = new Runnable() {
                                    public void run() {
                                        meTyping = false;
                                        sendTypingStatus("untyping");
                                    }
                                };
                                handler.postDelayed(runnable, 1000);
                            }

                            editLay.setVisibility(View.VISIBLE);
                            recordView.setVisibility(View.GONE);

                            MessagesData mdata = updateDBList(Constants.TAG_AUDIO, null, null, recordVoicePath, "");
                            Intent service = new Intent(mContext, FileUploadService.class);
                            Bundle b = new Bundle();
                            b.putSerializable("mdata", mdata);
                            b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                            b.putString("filepath", recordVoicePath);
                            b.putString("chatType", "chat");
                            service.putExtras(b);
                            startService(service);
                        }
                    } else if (!checkAudioPermission()) {
                        stopAudioViewHolder();
                        makeToast(getString(R.string.audio_record_permission_error));
                    } else {
                        sendTypingStatus("untyping");
                        stopAudioViewHolder();
                        editLay.setVisibility(View.VISIBLE);
                        recordView.setVisibility(View.GONE);
                        ApplicationClass.hideSoftKeyboard(ChatActivity.this, recordView);
                        Toast.makeText(ChatActivity.this, getString(R.string.less_than_second), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onLessThanSecond() {
                    stopAudioViewHolder();
                    sendTypingStatus("untyping");
                    editLay.setVisibility(View.VISIBLE);
                    recordView.setVisibility(View.GONE);
                    ApplicationClass.hideSoftKeyboard(ChatActivity.this, recordView);
                    if (!checkAudioPermission()) {
                        makeToast(getString(R.string.audio_record_permission_error));
                    } else {
                        Toast.makeText(ChatActivity.this, getString(R.string.less_than_second), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

    public boolean checkAudioPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return ContextCompat.checkSelfPermission(ChatActivity.this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;

        } else
            return ContextCompat.checkSelfPermission(ChatActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(ChatActivity.this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    public void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(this, PermissionsUtils.AUDIO_RECORD_V11_PERMISSION, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(this, PermissionsUtils.AUDIO_RECORD_PERMISSION, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
        }
    }

    private void sendTypingStatus(String typingStatus) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
            jsonObject.put(Constants.TAG_CHAT_ID, userId + GetSet.getUserId());
            jsonObject.put("type", typingStatus);
            socketConnection.typing(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void playSound(int soundRes, boolean isRecord) {
        try {
            MediaPlayer player = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(soundRes);
            if (afd == null) return;
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.prepare();
            player.start();
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    if (isRecord) {
                        try {
                            MediaRecorderReady();
                            mediaRecorder.prepare();
                            mediaRecorder.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            player.setLooping(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startVoice() {
        if (visible) {
            TransitionManager.beginDelayedTransition(bottomLay);
            visible = !visible;
            attachmentsLay.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
        stopAudioViewHolder();
        editLay.setVisibility(View.GONE);
        recordView.setVisibility(View.VISIBLE);

        boolean permissionGranted = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissionGranted = ContextCompat.checkSelfPermission(ChatActivity.this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        } else {
            permissionGranted = ContextCompat.checkSelfPermission(ChatActivity.this, RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(ChatActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        if (permissionGranted) {
            if (isNetworkConnected().equals(NOT_CONNECT)) {
                networkSnack();
            } else if (results.blockedbyme.equals("block")) {
                blockChatConfirmDialog("unblock", "sent");
            } else {
                if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                    if (runnable != null)
                        handler.removeCallbacks(runnable);
                    if (!meTyping) {
                        meTyping = true;
                    }
                    sendTypingStatus(Constants.TAG_RECORDING);
                }
                playSound(R.raw.record_start, true);
            }
        } else {
            requestAudioPermission();
        }
    }

    public void MediaRecorderReady() {
        if (mediaRecorder != null) {
            mediaRecorder.release();
            mediaRecorder = null;
        }

        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        String fileName = (getString(R.string.app_name) + "_" + System.currentTimeMillis() + ".mp3").replaceAll(" ", "");
        File destDir = storageManager.createDirectory(StorageManager.TAG_AUDIO_SENT);
        recordVoicePath = new File(destDir, fileName).getAbsolutePath();
        mediaRecorder.setOutputFile(recordVoicePath);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {
        Log.d(TAG, "onNetworkChange: " + isConnected);
        if (online != null) {
            if (isConnected) {
                online.setVisibility(View.VISIBLE);
            } else {
                online.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void backPressed() {
        if (selectedChatPos.size() > 0) {
            selectedChatPos.clear();
            messageListAdapter.notifyDataSetChanged();
            chatUserLay.setVisibility(View.VISIBLE);
            forwordLay.setVisibility(View.GONE);
            chatLongPressed = false;
        } else {
            if (isFromNotification) {
                if (isTaskRoot()) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    finish();
                }
            } else {
                finish();
            }
        }
    }

    private List<MessagesData> getMessagesAry(List<MessagesData> tmpList, MessagesData lastData) {

        List<MessagesData> msgList = new ArrayList<>();
        if (tmpList.size() == 0 && lastData != null) {
            MessagesData mdata = new MessagesData();
            mdata.message_type = "date";
            mdata.chat_time = lastData.chat_time;
            mdata.message = dateUtils.getChatDateFromUTC(lastData.chat_time);
            msgList.add(mdata);
            Log.v(TAG, "getMessagesAryLastData: " + lastData.message);
        } else {
            for (int i = 0; i < tmpList.size(); i++) {
                Calendar cal1 = Calendar.getInstance();
                cal1.setTimeInMillis(dateUtils.getTimeInMillisFromUTC(tmpList.get(i).chat_time));

                if (i + 1 < tmpList.size()) {
                    Calendar cal2 = Calendar.getInstance();
                    cal2.setTimeInMillis(dateUtils.getTimeInMillisFromUTC(tmpList.get(i + 1).chat_time));

                    boolean sameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                            cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
                    msgList.add(tmpList.get(i));

                    if (sameDay) {
//                        Log.v(TAG, "getMessagesAry: SameDay " + i + ", &msg: " + tmpList.get(i).message);
                    } else {
                        MessagesData mdata = new MessagesData();
                        mdata.message_type = "date";
                        if (tmpList.get(i) != null) {
                            mdata.chat_time = tmpList.get(i).chat_time;
                            mdata.message = dateUtils.getChatDateFromUTC(tmpList.get(i).chat_time);
                        }
                        msgList.add(mdata);
//                        Log.v(TAG, "getMessagesAry: " + i + ", &msg: " + tmpList.get(i).message);
                    }
                } else {
                    msgList.add(tmpList.get(i));
                }
            }
        }
        return msgList;
    }

    @Override
    public void onChatBoxJoined() {
        checkOnlineStatus();
        whileViewChat();
    }

    @SuppressLint("StaticFieldLeak")
    @Override
    public void onReceiveChat(final MessagesData mdata) {
        runOnUiThread(() -> {
//            Log.v(TAG, "onReceiveChat" + new Gson().toJson(mdata));
            mSmartRepliesRecycler.setVisibility(View.GONE);
            mdata.message = ApplicationClass.decryptMessage(mdata.message);
            Log.v(TAG, "onReceiveChat" + mdata.message);
            switch (mdata.message_type) {
                case Constants.TAG_IMAGE:
                case Constants.TAG_AUDIO:
                case Constants.TAG_DOCUMENT:
                case Constants.TAG_GIF:
                    mdata.attachment = ApplicationClass.decryptMessage(mdata.attachment);
                    break;
                case Constants.TAG_VIDEO:
                    mdata.attachment = ApplicationClass.decryptMessage(mdata.attachment);
                    mdata.thumbnail = ApplicationClass.decryptMessage(mdata.thumbnail);
                    break;
                case Constants.TAG_LOCATION:
                    mdata.lat = ApplicationClass.decryptMessage(mdata.lat);
                    mdata.lon = ApplicationClass.decryptMessage(mdata.lon);
                    break;
                case Constants.TAG_CONTACT:
                    mdata.contact_name = ApplicationClass.decryptMessage(mdata.contact_name);
                    mdata.contact_phone_no = ApplicationClass.decryptMessage(mdata.contact_phone_no);
                    mdata.contact_country_code = ApplicationClass.decryptMessage(mdata.contact_country_code);
                    break;
                case Constants.TAG_STORY:
                    mdata.statusData = ApplicationClass.decryptMessage(mdata.statusData);
                    break;
                default:
                    break;
            }

            if (mdata.user_id.equals(userId) || mdata.receiver_id.equals(userId)) {
                if (!mdata.message_type.equals(Constants.TAG_ISDELETE)) {
                    if (Constants.ADDON_CHAT_TRANSLATE && mdata.message_type.equals(Constants.TAG_TEXT)) {
                        //Addon Chat Translate
                        if (!TextUtils.isEmpty(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")) &&
                                !pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equalsIgnoreCase(mContext.getString(R.string.none))) {
                            chatTranslate(mdata);
                            /*Data.Builder builder = new Data.Builder();
                            builder.putString(Constants.TAG_MESSAGE, mdata.message);
                            final OneTimeWorkRequest translateWorkRequest = new OneTimeWorkRequest.Builder(ChatTranslateWorker.class)
                                    .setConstraints(new Constraints.Builder()
                                            .setRequiredNetworkType(NetworkType.CONNECTED)
                                            .build())
                                    .setInputData(builder.build())
                                    .build();
                            final WorkManager workManager = WorkManager.getInstance(ChatActivity.this);
                            workManager.enqueue(translateWorkRequest);
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    workManager.getWorkInfoByIdLiveData(translateWorkRequest.getId()).observe(ChatActivity.this, workInfo -> {
                                        if (workInfo.getState().isFinished()) {
                                            if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                                                String translatedMsg = workInfo.getOutputData().getString(Constants.TAG_DATA);
                                                mdata.message = translatedMsg;
                                                if (mdata.message_id != null && !tempMessageIdList.contains(mdata.message_id)) {
                                                    tempMessageIdList.add(mdata.message_id);
                                                    insertNewMessage(mdata);
                                                }
                                            }
                                        }
                                    });
                                }
                            });*/
                        } else {
                            if (mdata.message_id != null && !tempMessageIdList.contains(mdata.message_id)) {
                                String checkswitch=pref.getString("listencheck", "userPhone");
                                if (checkswitch.equals("yes")){
                                    if (mdata.message!=null){
                                        t1.speak(mdata.message, TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }
                                tempMessageIdList.add(mdata.message_id);
                                insertNewMessage(mdata);
                            }
                        }
                        if (Constants.ADDON_SMART_REPLY) {
                            setSmartReply(mdata, mdata.message);
                        }
                    } else {
                        if (mdata.message_id != null && !tempMessageIdList.contains(mdata.message_id)) {
                            tempMessageIdList.add(mdata.message_id);
                            insertNewMessage(mdata);
                        }
                    }
                } else {
                    int index = 0;
                    for (MessagesData data : messagesList) {
                        if (ApplicationClass.isStringNotNull(mdata.message_id) && ApplicationClass.isStringNotNull(data.message_id) && data.message_id.equals(mdata.message_id)) {
                            data.message_type = mdata.message_type;
                            messageListAdapter.notifyItemChanged(index);
                            dbHelper.updateMessageReadStatus(chatId, GetSet.getUserId());
                            break;
                        }
                        index++;
                    }
                }
            }
        });
    }

    ExecutorService executorchat = Executors.newSingleThreadExecutor();
    Handler mainHandler = HandlerCompat.createAsync(Looper.getMainLooper());

    public void chatTranslate(MessagesData mdata) {
        Log.e("chattranslEx", "-before call " + mdata.message);
        final String message = mdata.message;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                executorchat.execute(new Runnable() {
                    @Override
                    public void run() {
                        String url = "https://translation.googleapis.com/language/translate/v2?target=" +
                                pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "") +
                                "&key=" + "AIzaSyBSC5IB7c_0CcSC-hTNSlfeudjY9tGbJHE" + "&q=" + message;
                        Log.i(TAG, "startWork: " + url);
                        BufferedReader reader = null;
                        try {
                            URL urlObj = new URL(url);
                            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                            conn.setDoOutput(true);
                            conn.setRequestMethod("GET");
                            conn.setRequestProperty("Accept-Charset", "UTF-8");

                            StringBuilder sb = new StringBuilder();
                            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                            String line;
                            while ((line = reader.readLine()) != null) {
                                sb.append(line + "\n");
                            }
                            String translatedMsg = parseTranslatedMsg(sb.toString());
                            if (!TextUtils.isEmpty(translatedMsg)) {
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Log.e("chattranslEx", "-result success" + translatedMsg);
                                        String replace= translatedMsg.replace("&#39;","'");
                                        String checkswitch=pref.getString("listencheck", "userPhone");
                                        if (checkswitch.equals("yes")){
                                            if (replace!=null){
                                                t1.speak(replace, TextToSpeech.QUEUE_FLUSH, null);
                                            }

                                        }
                                        mdata.message = replace;
                                        if (mdata.message_id != null && !tempMessageIdList.contains(mdata.message_id)) {
                                            tempMessageIdList.add(mdata.message_id);
                                            insertNewMessage(mdata);
                                        }
                                    }
                                });
                            } else {
                                Log.e("chattranslEx", "-empty str");
                            }
                        } catch (IOException e) {
                            Log.e("chattranslEx", "exceptionworker-" + e.toString());
                            runOnUiThread(() -> {
                                if (mdata.message_id != null && !tempMessageIdList.contains(mdata.message_id)) {
                                    tempMessageIdList.add(mdata.message_id);
                                    insertNewMessage(mdata);
                                }

                            });

                            e.printStackTrace();
                        }
                    }
                });
            }
        });

    }

    private static String parseTranslatedMsg(String translatedMsg) {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(translatedMsg);
            JSONObject dataObject = jsonObject.getJSONObject("data");
            JSONArray translationArray = dataObject.getJSONArray("translations");
            if (translationArray.length() > 0) {
                JSONObject translatedText = translationArray.getJSONObject(0);
                translatedMsg = translatedText.optString("translatedText");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return translatedMsg;
    }

    private boolean containsIllegalCharacters(String displayName) {
        final int nameLength = displayName.length();

        for (int i = 0; i < nameLength; i++) {
            final char hs = displayName.charAt(i);

            if (0xd800 <= hs && hs <= 0xdbff) {
                final char ls = displayName.charAt(i + 1);
                final int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;

                if (0x1d000 <= uc && uc <= 0x1f77f) {
                    return true;
                }
            } else if (Character.isHighSurrogate(hs)) {
                final char ls = displayName.charAt(i + 1);

                if (ls == 0x20e3) {
                    return true;
                }
            } else {
                // non surrogate
                if (0x2100 <= hs && hs <= 0x27ff) {
                    return true;
                } else if (0x2B05 <= hs && hs <= 0x2b07) {
                    return true;
                } else if (0x2934 <= hs && hs <= 0x2935) {
                    return true;
                } else if (0x3297 <= hs && hs <= 0x3299) {
                    return true;
                } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                    return true;
                }
            }
        }

        return false;
    }

    private void insertNewMessage(MessagesData mdata) {
        whileViewChat();
        if (isFirstItemVisible()) {
            messagesList.add(0, mdata);
            isScroll = false;
            messageListAdapter.notifyItemInserted(0);
            recyclerView.smoothScrollToPosition(0);
            iconNewMessage.setVisibility(View.GONE);
        } else {
            messagesList.add(0, mdata);
            messageListAdapter.notifyItemInserted(0);
            iconNewMessage.setVisibility(View.VISIBLE);
        }
        showEncryptionText();
    }

    private boolean isFirstItemVisible() {
        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        int position = linearLayoutManager.findFirstVisibleItemPosition();
        return position == 0;
    }

    private void setSmartReply(MessagesData mdata, String oldMessage) {
        if (mdata.message_type.equals(Constants.TAG_TEXT)
                || mdata.message_type.equals(Constants.TAG_STORY)) {
            if (mdata.sender_id != null && !mdata.sender_id.equals(GetSet.getUserId())) {
                generateReplies(oldMessage);
            }
        } else {
            mSmartRepliesRecycler.setVisibility(View.GONE);
        }
    }

    //Addon SmartReply
    private void generateReplies(String message) {
        // If the last message in the chat thread is not sent by the "other" user, don't generate
        // smart replies.
        if (!TextUtils.isEmpty(message)) {

            Data.Builder builder = new Data.Builder();
            builder.putString(Constants.TAG_MESSAGE, message);
            OneTimeWorkRequest locationWorkRequest = new OneTimeWorkRequest.Builder(GenerateSmartReplyWorker.class)
                    .setConstraints(new Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.CONNECTED)
                            .build())
                    .setInputData(builder.build())
                    .build();
            WorkManager workManager = WorkManager.getInstance(this);
            workManager.enqueue(locationWorkRequest);
            workManager.getWorkInfoByIdLiveData(locationWorkRequest.getId()).observe(this, workInfo -> {
                if (workInfo.getState().isFinished()) {
                    if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                        final List<SmartReplySuggestion> suggestion = new ArrayList<>();
                        String suggestionJson = workInfo.getOutputData().getString(Constants.TAG_DATA);
                        Log.d(TAG, "GenerateSmartReplyWorker: " + suggestionJson);
                        if (!TextUtils.isEmpty(suggestionJson)) {
                            Type userListType = new TypeToken<List<SmartReplySuggestion>>() {
                            }.getType();
                            suggestion.addAll(new Gson().fromJson(suggestionJson, userListType));
                            mChipAdapter.setSuggestions(suggestion);
                            mSmartRepliesRecycler.setVisibility(View.VISIBLE);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    recyclerView.scrollToPosition(0);
                                }
                            }, 100);
                        }
                    } else {
                        mSmartRepliesRecycler.setVisibility(View.GONE);
                    }
                }
            });
        } else {
            mSmartRepliesRecycler.setVisibility(View.GONE);
        }
    }

    @Override
    public void onAudioUpdate(int currentPosition) {
        if (currentMessageId != null) {
            MessagesData tempMsgData = dbHelper.getSingleMessage(currentMessageId);
            int tempPosition = -1;

            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(currentPosition);
                    holder.duration.setText(milliSecondsToTimer(currentPosition));
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.play_icon_white));
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(currentPosition);
                    holder.duration.setText(milliSecondsToTimer(currentPosition));
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.play_icon_white));
                }
            }
        }
    }

    @Override
    public void onAudioComplete() {
        state = recyclerView.getLayoutManager().onSaveInstanceState();
        // Main position of RecyclerView when loaded again
        if (state != null) {
            recyclerView.getLayoutManager().onRestoreInstanceState(state);
        }
        if (currentMessageId != null) {
            MessagesData tempMsgData = dbHelper.getSingleMessage(currentMessageId);
            int tempPosition = -1;
            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                    if (file != null) {
                        holder.duration.setVisibility(View.VISIBLE);
                        holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                    } else {
                        holder.duration.setVisibility(View.INVISIBLE);
                    }
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), TAG_AUDIO);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        if (file != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    }
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                }
            }
        }
        ApplicationClass.resumeExternalAudio(mContext);
    }

    @Override
    public void receivedStatus(final String message_id, final String sender_id, final String receiverId) {
        runOnUiThread(() -> {
            for (int i = 0; i < messagesList.size(); i++) {
                if (messagesList.get(i).message_id != null &&
                        messagesList.get(i).message_id.equals(message_id) &&
                        !("" + messagesList.get(i).delivery_status).equals("read")) {
                    messagesList.get(i).delivery_status = "sent";
                    /*if (messagesList.get(i).message_type.equals(Constants.TAG_AUDIO)) {
                        updateAudioRead(i, "sent");
                    } else {
                        messageListAdapter.notifyItemChanged(i);
                    }*/
                    messageListAdapter.notifyItemChanged(i);
                    break;
                }
            }
        });
    }

    private void whileViewChat() {
        dbHelper.updateMessageReadStatus(chatId, GetSet.getUserId());
        dbHelper.resetUnseenMessagesCount(userId);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, userId);
                    jsonObject.put(Constants.TAG_RECEIVER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_CHAT_ID, userId + GetSet.getUserId());
                    socketConnection.chatViewed(jsonObject);
                    socketConnection.clearReadMessages(GetSet.getUserId(), userId + GetSet.getUserId());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, 1000);
    }

    @Override
    public void onViewChat(final String chat_id, final String sender_id, final String receiverId) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (chat_id.equals(chatId)) {
                    for (MessagesData messagesData : messagesList) {
                        if (!TextUtils.isEmpty(messagesData.user_id) && messagesData.user_id.equals(GetSet.getUserId())) {
                            if (!TextUtils.isEmpty(messagesData.delivery_status) && messagesData.delivery_status.equals("sent"))
                                messagesData.delivery_status = "read";
                        }
                    }
                    messageListAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void updateAudioRead(int position, String readStatus) {
        ImageView tickimage = null;
        if (position != -1) {
            RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(position);
            if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                tickimage = holder.tickimage;
            } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                tickimage = holder.tickimage;
            }
        }
        switch (readStatus) {
            case "read":
                if (tickimage != null) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.double_tick);
                }
                break;
            case "sent":
                if (tickimage != null) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.double_tick_unseen);
                }
                break;
            default:
                if (tickimage != null) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.single_tick);
                }
                break;
        }
    }

    @Override
    public void onlineStatus(final JSONObject data) {
        runOnUiThread(new Runnable() {
            public void run() {
//                Log.v(TAG, "onlineStatus: " + data);
                try {
                    String contactId = data.getString(Constants.TAG_CONTACT_ID);
                    if (contactId.equals(userId)) {
                        if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                            online.setVisibility(View.VISIBLE);
                            if (data.get("livestatus").equals("online")) {
                                if (!online.getText().equals(getString(R.string.recording))) {
                                    setOnlineStatus(getString(R.string.online), false);
                                }
                            } else if (data.get("livestatus").equals("offline")) {
                                ContactsData.Result result = dbHelper.getContactDetail(contactId);
                                if (result.privacy_last_seen.equalsIgnoreCase(TAG_MY_CONTACTS)) {
                                    if (result.contactstatus.equalsIgnoreCase(TAG_TRUE)) {
                                        String lastSeen = dateUtils.getLastSeenFromUTC(data.optString("lastseen", ""));
                                        if (TextUtils.isEmpty(lastSeen)) {
                                            setOnlineStatus("", false);
                                        } else {
                                            setOnlineStatus(getString(R.string.last_seen) + " " + lastSeen, true);
                                        }
                                    } else {
                                        setOnlineStatus("", false);
                                    }
                                } else if (result.privacy_last_seen.equalsIgnoreCase(TAG_NOBODY)) {
                                    setOnlineStatus("", false);
                                } else {
                                    String lastSeen = dateUtils.getLastSeenFromUTC(data.optString("lastseen", ""));
                                    if (TextUtils.isEmpty(lastSeen)) {
                                        setOnlineStatus("", false);
                                    } else {
                                        setOnlineStatus(getString(R.string.last_seen) + " " + lastSeen, true);
                                    }
                                }
                            }
                        } else {
                            online.setVisibility(View.GONE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setOnlineStatus(String onlineStatus, boolean isSelected) {
        if (TextUtils.isEmpty(onlineStatus)) {
            online.setVisibility(View.GONE);
        } else {
            online.setVisibility(View.VISIBLE);
        }
        online.setText(onlineStatus);
        online.setSelected(isSelected);
    }

    @Override
    public void onListenTyping(final JSONObject data) {
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    String chatId = data.getString(Constants.TAG_CHAT_ID);
                    if (chatId.equals(chatId)) {
                        if (data.get("type").equals("typing")) {
                            online.setText(getString(R.string.typing));
                        } else if (data.get("type").equals(Constants.TAG_RECORDING)) {
                            online.setText(getString(R.string.recording));
                        } else if (data.get("type").equals("untyping")) {
                            online.setText(getString(R.string.online));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onBlockStatus(final JSONObject data) {
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    String senderId = data.getString(Constants.TAG_SENDER_ID);
                    String receiverId = data.getString(Constants.TAG_RECEIVER_ID);
                    String type = data.getString(Constants.TAG_TYPE);
                    if (senderId.equals(userId)) {
                        results = dbHelper.getContactDetail(userId);
                        Log.d(TAG, "onBlockStatus: " + results.blockedme);
                        if (!results.blockedme.equals("block")) {
                            DialogActivity.setProfileImage(dbHelper.getContactDetail(userId), userimage, ChatActivity.this);
                            online.setVisibility(View.VISIBLE);
                            checkOnlineStatus();
                        } else {
                            Glide.with(ChatActivity.this).load(R.drawable.temp)
                                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(ChatActivity.this, 70)))
                                    .into(userimage);
                            online.setVisibility(View.GONE);
                        }
                        if (results.blockedbyme.equals("block")) {
                            online.setVisibility(View.GONE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onUserImageChange(final String user_id, final String user_image) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (user_id.equals(userId)) {
                    ContactsData.Result results = dbHelper.getContactDetail(userId);
                    if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
                        DialogActivity.setProfileImage(dbHelper.getContactDetail(results.user_id), userimage, ChatActivity.this);
                    }
                }
            }
        });
    }

    @Override
    public void onGetUpdateFromDB(boolean isRefresh) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "onGetUpdateFromDB:isRefresh " + isRefresh);
                if (isRefresh) {
                    updateMessagesFromDB();
                }
            }
        });
    }

    private void updateMessagesFromDB() {
        int currentCount = dbHelper.getMessagesCount(chatId);
        if (totalMsg != currentCount) {
            messagesList.clear();
            resetEndlessScroll();
            try {
                List<MessagesData> tempMessageList = dbHelper.getMessages(chatId, "0", "" + Constants.CHAT_PAGINATION_LIMIT);
                if (messagesList.size() > 0) {
                    messagesList.addAll(getMessagesAry(tempMessageList, messagesList.get(0)));
                } else {
                    messagesList.addAll(getMessagesAry(tempMessageList, null));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            totalMsg = currentCount;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showEncryptionText();
                    recyclerView.post(new Runnable() {
                        @Override
                        public void run() {
                            messageListAdapter.notifyDataSetChanged();
                        }
                    });
                    setNewMessageLay();
                    whileViewChat();
                }
            });
        } else if (isFromNotification) {
            messagesList.clear();
            resetEndlessScroll();
            try {
                List<MessagesData> tempMessageList = dbHelper.getMessages(chatId, "0", "" + Constants.CHAT_PAGINATION_LIMIT);
                messagesList.addAll(getMessagesAry(tempMessageList, null));
            } catch (Exception e) {
                e.printStackTrace();
            }
            runOnUiThread(new Runnable() {
                public void run() {
                    showEncryptionText();
                    messageListAdapter.notifyDataSetChanged();
                    recyclerView.post(new Runnable() {
                        @Override
                        public void run() {
                            recyclerView.scrollToPosition(0);
                        }
                    });
                    whileViewChat();
                }
            });
        }
    }

    private void resetEndlessScroll() {
        if (endlessRecyclerOnScrollListener != null) {
            endlessRecyclerOnScrollListener.resetState();
        }
    }

    @Override
    public void onUploadListen(final String message_id, final String attachment, final String progress) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < messagesList.size(); i++) {
                    if (message_id.equals(messagesList.get(i).message_id)) {
                        messagesList.get(i).attachment = attachment;
                        messagesList.get(i).progress = progress;
                        messageListAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
    }

    @Override
    public void onPrivacyChanged(final JSONObject jsonObject) {
//        Log.i(TAG, "onPrivacyChanged: " + jsonObject);
        try {
            if (jsonObject.getString(TAG_USER_ID).equalsIgnoreCase(userId)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            DialogActivity.setProfileImage(dbHelper.getContactDetail(jsonObject.getString(TAG_USER_ID)), userimage, ChatActivity.this);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onPrivateChatReceived(String userId, final String senderId) {
        runOnUiThread(() -> {
            for (int i = 0; i < messagesList.size(); i++) {
                if (messagesList.get(i).message_id != null &&
                        messagesList.get(i).sender_id.equals(senderId) &&
                        TextUtils.isEmpty(messagesList.get(i).delivery_status)) {
                    messagesList.get(i).delivery_status = "sent";
                    messageListAdapter.notifyItemChanged(i);
                }
            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length() > 0) {
            send.setVisibility(View.VISIBLE);
            recordButton.setVisibility(View.GONE);
        } else {
            send.setVisibility(View.GONE);
            recordButton.setVisibility(View.VISIBLE);
        }
        if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
            if (runnable != null)
                handler.removeCallbacks(runnable);
            if (!meTyping) {
                meTyping = true;
            }
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                jsonObject.put(Constants.TAG_CHAT_ID, userId + GetSet.getUserId());
                jsonObject.put("type", "typing");
                socketConnection.typing(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {
        if (!results.blockedme.equals("block") && !results.blockedbyme.equals("block")) {
            runnable = new Runnable() {
                public void run() {
                    meTyping = false;
                    sendTypingStatus("untyping");
                }
            };
            handler.postDelayed(runnable, 1000);
        }
    }

    @Override
    public void deleteType(String type) {
        String chatId = this.chatId;
        for (int i = 0; i < selectedChatPos.size(); i++) {
            MessagesData mData = selectedChatPos.get(i);
            try {
                JSONObject jobj = new JSONObject();
                JSONObject message = new JSONObject();
                message.put(Constants.TAG_USER_ID, GetSet.getUserId());
                message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
                message.put(Constants.TAG_PHONE, GetSet.getphonenumber());
                message.put(Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(getString(R.string.message_deleted)));
                message.put(Constants.TAG_ATTACHMENT, mData.attachment);
                message.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(mData.thumbnail));
                message.put(Constants.TAG_CHAT_TIME, mData.chat_time);
                message.put(Constants.TAG_CHAT_ID, chatId);
                message.put(Constants.TAG_MESSAGE_ID, mData.message_id);
                message.put(Constants.TAG_RECEIVER_ID, userId);
                message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                message.put(Constants.TAG_BLOCK_STATUS, "" + results.blockedme.equals("block"));
                message.put(Constants.TAG_BLOCKED_BY, results.blockedme.equals("block") ? userId : "");
                if (type.equals("me")) {
                    message.put(Constants.TAG_DELETE_FOR_ME, GetSet.getUserId());
                }
                message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + type.equals("everyone"));
                jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                jobj.put(Constants.TAG_RECEIVER_ID, userId);
                jobj.put("message_data", message);
//                    Log.v(TAG, "deleteType: " + jobj);
                socketConnection.startChat(jobj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            mData.message_type = Constants.TAG_ISDELETE;
            if (type.equals("me")) {
                currentMessageId = null;
                dbHelper.deleteMessageFromId(mData.message_id);
                messageListAdapter.notifyItemRemoved(messagesList.indexOf(mData));
                messagesList.remove(mData);
            } else {
                messageListAdapter.notifyItemChanged(messagesList.indexOf(mData));
                dbHelper.updateMessageData(mData.message_id, Constants.TAG_MESSAGE_TYPE, Constants.TAG_ISDELETE);
                dbHelper.updateMessageData(mData.message_id, Constants.TAG_ATTACHMENT, "");
                dbHelper.updateMessageData(mData.message_id, Constants.TAG_THUMBNAIL, "");
                whileViewChat();
            }
        }
        if (type.equals("me")) {
            if (messagesList.isEmpty()) {
                dbHelper.deleteRecentChat(chatId);
            } else {
                MessagesData data = messagesList.get(0);
                dbHelper.addRecentMessages(chatId, userId, data.message_id, data.chat_time, "0");
            }
        }
        showEncryptionText();
        selectedChatPos.clear();
        chatUserLay.setVisibility(View.VISIBLE);
        forwordLay.setVisibility(View.GONE);
        chatLongPressed = false;
    }

    public RecyclerItemClickListener chatItemClick(Context mContext, final RecyclerView recyclerView) {
        return new RecyclerItemClickListener(mContext, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if (chatLongPressed) {
                    int chatType = recyclerView.getAdapter().getItemViewType(position);
                    if (chatType != VIEW_TYPE_DATE /*&& !messagesList.get(position).message_type.equals(Constants.TAG_ISDELETE)*/) {
                        if (selectedChatPos.contains(messagesList.get(position))) {
                            selectedChatPos.remove(messagesList.get(position));
                        } else {
                            selectedChatPos.add(messagesList.get(position));
                        }
                        messageListAdapter.notifyItemChanged(position);
                    }

                    for (MessagesData messagesData : selectedChatPos) {
                        if (!isForwardable(messagesData)) {
                            forwordBtn.setVisibility(View.GONE);
                            break;
                        } else {
                            forwordBtn.setVisibility(View.VISIBLE);
                        }
                    }

                    if (selectedChatPos.isEmpty()) {
                        chatLongPressed = false;
                        chatUserLay.setVisibility(View.VISIBLE);
                        forwordLay.setVisibility(View.GONE);
                        copyBtn.setVisibility(View.GONE);
                    } else {
                        setCopyBtnVisibility();
                    }
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {
                if (!chatLongPressed && !isRecording) {
                    if (currentMessageId != null && currentMessageId.equals(messagesList.get(position))) {
                        if (MediaPlayerUtils.isPlaying()) MediaPlayerUtils.pauseMediaPlayer();
                    }
                    if (recyclerView.getAdapter().getItemViewType(position) != VIEW_TYPE_DATE /*&&
                         !messagesList.get(position).message_type.equals(Constants.TAG_ISDELETE)*/) {
                        chatLongPressed = true;
                        selectedChatPos.add(messagesList.get(position));
                        chatUserLay.setVisibility(View.GONE);
                        forwordLay.setVisibility(View.VISIBLE);

                        if (isForwardable(messagesList.get(position))) {
                            forwordBtn.setVisibility(View.VISIBLE);
                        } else {
                            forwordBtn.setVisibility(View.GONE);
                        }
                        messageListAdapter.notifyItemChanged(position);
                        setCopyBtnVisibility();
                    }
                }
            }
        });
    }


    private boolean isForwardable(MessagesData mData) {
        switch (mData.message_type) {
            case Constants.TAG_ISDELETE:
                return false;
            case Constants.TAG_VIDEO:
            case Constants.TAG_DOCUMENT:
            case Constants.TAG_AUDIO:
            case Constants.TAG_IMAGE:
                if (mData.user_id.equals(GetSet.getUserId()) && !mData.progress.equals("completed")) {
                    return false;
                } else {
                    return mData.user_id.equals(GetSet.getUserId()) || storageManager.checkFileExists(mData.attachment, mData.message_type);
                }
            default:
                return true;
        }
    }

    private void setCopyBtnVisibility() {
        if (selectedChatPos.size() > 0) {
            for (MessagesData message : selectedChatPos) {
                if (!message.message_type.equals("text") && !message.message_type.equals("link")) {
                    copyBtn.setVisibility(View.GONE);
                    break;
                } else {
                    copyBtn.setVisibility(View.VISIBLE);
                }
            }
        } else {
            copyBtn.setVisibility(View.GONE);
        }
    }

    private void emitImage(MessagesData mdata, String imageUrl) {
        if (socketConnection.getMSocket().connected()) {
//        if (!results.blockedme.equals("block")) {
            try {
                JSONObject jobj = new JSONObject();
                JSONObject message = new JSONObject();
                message.put(Constants.TAG_USER_ID, GetSet.getUserId());
                message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
                message.put(Constants.TAG_PHONE, GetSet.getphonenumber());
                message.put(Constants.TAG_MESSAGE_TYPE, mdata.message_type);
                message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(imageUrl));
                message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
                message.put(Constants.TAG_CHAT_TIME, mdata.chat_time);
                message.put(Constants.TAG_CHAT_ID, mdata.chat_id);
                message.put(Constants.TAG_MESSAGE_ID, mdata.message_id);
                message.put(Constants.TAG_RECEIVER_ID, userId);
                message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                message.put(Constants.TAG_ISDELETE, "0");
                message.put(Constants.TAG_BLOCK_STATUS, "" + results.blockedme.equals("block"));
                message.put(Constants.TAG_BLOCKED_BY, results.blockedme.equals("block") ? userId : "");
                message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
                jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                jobj.put(Constants.TAG_RECEIVER_ID, userId);
                jobj.put("message_data", message);
                Log.v(TAG, "emitImage: " + jobj);
                socketConnection.startChat(jobj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            hideSmartReplyVisible();
//        }
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    private void hideSmartReplyVisible() {
        if (Constants.ADDON_SMART_REPLY) {
            mSmartRepliesRecycler.setVisibility(View.GONE);
        }
    }

    private MessagesData updateDBList(String type, Uri fileUri, Uri thumbUri, String filePath, String thumbPath) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        String chatId = this.chatId;
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();

        String msg = "";
        switch (type) {
            case Constants.TAG_IMAGE:
                msg = getString(R.string.image);
                break;
            case Constants.TAG_AUDIO:
//                msg = getFileName(filePath);
                msg = getString(R.string.audio);
                break;
            case Constants.TAG_VIDEO:
                msg = getString(R.string.video);
                break;
            case Constants.TAG_DOCUMENT:
//                msg = getFileName(filePath);
                msg = getString(R.string.document);
                break;
            case Constants.TAG_GIF:
                msg = getString(R.string.gif);
                break;
        }

        MessagesData data = new MessagesData();
        data.user_id = GetSet.getUserId();
        data.message_type = type;
        data.message = msg;
        data.message_id = messageId;
        data.chat_time = currentUTCTime;
        data.delivery_status = "";
        data.progress = "";
        data.receiver_id = userId;

        switch (type) {
            case Constants.TAG_VIDEO: {
                data.thumbnail = thumbUri != null ? "" + thumbUri.getLastPathSegment() : thumbPath;
                data.attachment = fileUri != null ? "" + fileUri.getLastPathSegment() : filePath;
                MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                        type, msg, data.attachment, "", "", "", "", "",
                        currentUTCTime, userId, GetSet.getUserId(),
                        "", data.thumbnail, "", data.progress);
                dbHelper.addMessageData(tempMessageData, true);
            }
            break;
            case Constants.TAG_IMAGE:
            case Constants.TAG_GIF: {
                data.thumbnail = "";
                data.attachment = fileUri != null ? fileUri.getLastPathSegment() : filePath;
                MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                        type, msg, data.attachment, "", "", "", "", "",
                        currentUTCTime, userId, GetSet.getUserId(), "", "", "", data.progress);
                dbHelper.addMessageData(tempMessageData, true);
            }
            break;
            default: {
                data.thumbnail = "";
                data.attachment = fileUri != null ? "" + fileUri.getLastPathSegment() : filePath;
                MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                        type, msg, data.attachment, "", "", "", "", "",
                        currentUTCTime, userId, GetSet.getUserId(), "", "", "",
                        data.progress);
                dbHelper.addMessageData(tempMessageData, true);
            }
            break;
        }
        dbHelper.addRecentMessages(chatId, userId, messageId, currentUTCTime, "0");

        messagesList.add(0, data);
        showEncryptionText();
        notifyItemInserted(0);

        return data;
    }

    private void notifyItemInserted(int position) {
        isScroll = false;
        messageListAdapter.notifyItemInserted(0);
        recyclerView.post(new Runnable() {
            @Override
            public void run() {
                recyclerView.smoothScrollToPosition(position);
            }
        });
    }

    private void emitLocation(String lat, String lon) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        String chatId = this.chatId;
        String msg = getString(R.string.location);
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
//            if (!results.blockedme.equals("block")) {
        try {
            JSONObject jobj = new JSONObject();
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_USER_ID, GetSet.getUserId());
            message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            message.put(Constants.TAG_PHONE, GetSet.getphonenumber());
            message.put(Constants.TAG_MESSAGE_TYPE, Constants.TAG_LOCATION);
            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(msg));
            message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
            message.put(Constants.TAG_CHAT_ID, chatId);
            message.put(Constants.TAG_LAT, ApplicationClass.encryptMessage(lat));
            message.put(Constants.TAG_LON, ApplicationClass.encryptMessage(lon));
            message.put(Constants.TAG_MESSAGE_ID, messageId);
            message.put(Constants.TAG_RECEIVER_ID, userId);
            message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
            message.put(Constants.TAG_BLOCK_STATUS, "" + results.blockedme.equals("block"));
            message.put(Constants.TAG_BLOCKED_BY, results.blockedme.equals("block") ? userId : "");
            message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
            jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            jobj.put(Constants.TAG_RECEIVER_ID, userId);
            jobj.put("message_data", message);
            Log.v(TAG, "emitLocation: " + jobj);
            socketConnection.startChat(jobj);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        hideSmartReplyVisible();

//            }

        MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                Constants.TAG_LOCATION, msg, "", lat, lon, "", "", "",
                currentUTCTime, userId, GetSet.getUserId(), "", "", "", "");
        dbHelper.addMessageData(tempMessageData, true);
        dbHelper.addRecentMessages(chatId, userId, messageId, currentUTCTime, "0");

        messagesList.add(0, tempMessageData);
        showEncryptionText();
        notifyItemInserted(0);
    }

    private void emitContact(String name, String phone, String countrycode) {
        if (socketConnection.getMSocket().connected()) {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            String chatId = this.chatId;
            RandomString randomString = new RandomString(10);
            String type = "contact";
            String msg = getString(R.string.contact);
            String messageId = GetSet.getUserId() + randomString.nextString();
            try {
                //            if (!results.blockedme.equals("block")) {
                JSONObject jobj = new JSONObject();
                JSONObject message = new JSONObject();
                message.put(Constants.TAG_USER_ID, GetSet.getUserId());
                message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
                message.put(Constants.TAG_MESSAGE_TYPE, type);
                message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(msg));
                message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                message.put(Constants.TAG_CHAT_ID, chatId);
                message.put(Constants.TAG_CONTACT_NAME, ApplicationClass.encryptMessage(name));
                message.put(Constants.TAG_CONTACT_PHONE_NO, ApplicationClass.encryptMessage(phone));
                message.put(Constants.TAG_CONTACT_COUNTRY_CODE, ApplicationClass.encryptMessage(countrycode));
                message.put(Constants.TAG_MESSAGE_ID, messageId);
                message.put(Constants.TAG_RECEIVER_ID, userId);
                message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                message.put(Constants.TAG_BLOCK_STATUS, "" + results.blockedme.equals("block"));
                message.put(Constants.TAG_BLOCKED_BY, results.blockedme.equals("block") ? userId : "");
                message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
                jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                jobj.put(Constants.TAG_RECEIVER_ID, userId);
                jobj.put("message_data", message);
                Log.v(TAG, "emitContact: " + jobj);
                socketConnection.startChat(jobj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            hideSmartReplyVisible();
//            }

            MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                    type, msg, "", "", "", name,
                    phone, countrycode, currentUTCTime, userId, GetSet.getUserId(), "", "", "", "");
            dbHelper.addMessageData(tempMessageData, true);

            dbHelper.addRecentMessages(chatId, userId, messageId, currentUTCTime, "0");

            messagesList.add(0, tempMessageData);
            showEncryptionText();
            notifyItemInserted(0);
        } else {
            makeToast(getString(R.string.poor_network_connection));
        }
    }

    private void openDeleteDialog() {
        boolean canEveryOneVisible = true;
        Dialog deleteDialog = new Dialog(ChatActivity.this);
        deleteDialog.setCancelable(true);
        if (deleteDialog.getWindow() != null) {
            deleteDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
            deleteDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        deleteDialog.setContentView(R.layout.dialog_report);

        RecyclerView deleteRecyclerView = deleteDialog.findViewById(R.id.reportRecyclerView);
        TextView title = deleteDialog.findViewById(R.id.title);

        title.setText(getString(R.string.really_delete_msg));

        List<String> deleteTexts = new ArrayList<>();

        for (MessagesData message : selectedChatPos) {
            if (dateUtils.isExceedsOneHour(message.chat_time) || !message.user_id.equalsIgnoreCase(GetSet.getUserId())
                    || message.message_type.equalsIgnoreCase(Constants.TAG_ISDELETE)) {
                canEveryOneVisible = false;
                break;
            }
        }

        deleteTexts.add(getString(R.string.delete_for_me));
        deleteTexts.add(getString(R.string.cancel));

        if (canEveryOneVisible) {
            deleteTexts.add(getString(R.string.delete_for_everyone));
            LinearLayoutManager layoutManager = new LinearLayoutManager(ChatActivity.this, RecyclerView.VERTICAL, false);
            deleteRecyclerView.setLayoutManager(layoutManager);
        } else {
            GridLayoutManager layoutManager = new GridLayoutManager(ChatActivity.this, 2);
            deleteRecyclerView.setLayoutManager(layoutManager);
        }
        DeleteAdapter adapter = new DeleteAdapter(deleteTexts, deleteDialog, ChatActivity.this);
        deleteRecyclerView.setAdapter(adapter);

        deleteDialog.show();
    }

    private void deleteChatConfirmDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_delete_chat_history);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkStatus.isConnected()) {
                    callClearChatApi();
                    dbHelper.deleteAllMessages(chatId);
                    showEncryptionText();
                    dialog.dismiss();
                    currentMessageId = null;
                    totalMsg = 0;
                    stopMediaPlayer();
                    messagesList.clear();
                    messageListAdapter.notifyDataSetChanged();
                    iconNewMessage.setVisibility(View.GONE);
                    newMessageLay.setVisibility(View.GONE);
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void callClearChatApi() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
        requestMap.put(Constants.TAG_RECEIVER_ID, userId);
        requestMap.put(Constants.TAG_TYPE, Constants.TAG_CLEAR);

        Call<HashMap<String, String>> call = apiInterface.callDeleteChatApi(GetSet.getToken(), requestMap);
        call.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                call.cancel();
            }
        });
    }

    private void deleteMessageConfirmDialog(MessagesData mData) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_delete_msg);
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                dbHelper.deleteMessageFromId(mData.message_id);
                messagesList.remove(mData);
                Toast.makeText(ChatActivity.this, getString(R.string.message_deleted), Toast.LENGTH_SHORT).show();
                selectedChatPos.clear();
                messageListAdapter.notifyDataSetChanged();
                chatUserLay.setVisibility(View.VISIBLE);
                forwordLay.setVisibility(View.GONE);
                chatLongPressed = false;
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void blockChatConfirmDialog(final String type, String from) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);

        if (from.equals("popup")) {
            yes.setText(getString(R.string.im_sure));
            no.setText(getString(R.string.nope));
            if (type.equals(Constants.TAG_BLOCK)) {
                title.setText(R.string.really_block_chat);
            } else {
                title.setText(R.string.really_unblock_chat);
            }
        } else {
            yes.setText(getString(R.string.unblock));
            no.setText(getString(R.string.cancel));
            title.setText(R.string.unblock_message);
        }

        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                    jsonObject.put(Constants.TAG_TYPE, type);
                    socketConnection.block(jsonObject);
                    dbHelper.updateBlockStatus(userId, Constants.TAG_BLOCKED_BYME, type);
                    results = dbHelper.getContactDetail(userId);
                    setBlockStatus(results);
                    if (!type.equals(Constants.TAG_BLOCK)) {
                        checkOnlineStatus();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void uploadImage(byte[] imageBytes, final Uri imageUri, final String imagePath, final MessagesData mdata) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("attachment", "openImage.jpg", requestFile);
        Log.d(TAG, "uploadImage: "+GetSet.getUserId());
        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call3 = apiInterface.upMyChat(GetSet.getToken(), body, userid);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                if (data.get(Constants.TAG_STATUS).equals(TAG_TRUE)) {
                    if (mdata.message_type.equals(Constants.TAG_IMAGE)) {
                        String apiFileName = data.get(Constants.TAG_USER_IMAGE);
                        boolean isFileMoved = storageManager.renameFile(imageUri, imagePath, apiFileName, Constants.TAG_IMAGE);
                        if (isFileMoved) {
                            dbHelper.updateMessageData(mdata.message_id, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(apiFileName));
                            dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "completed");
                        }
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                                    messagesList.get(i).progress = "completed";
                                    messagesList.get(i).attachment = apiFileName;
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }
                        emitImage(mdata, apiFileName);
                    }
                } else {
                    dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
                    if (messageListAdapter != null) {
                        for (int i = 0; i < messagesList.size(); i++) {
                            if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                                messagesList.get(i).progress = "error";
                                messageListAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "uploadImage: " + t.getMessage());
                call.cancel();
                dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
                if (messageListAdapter != null) {
                    for (int i = 0; i < messagesList.size(); i++) {
                        if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                            messagesList.get(i).progress = "error";
                            messageListAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    private void uploadVideoThumbnail(byte[] imageBytes, final Uri imageUri, final String imagePath,
                                      final MessagesData mdata, final Uri videoUri, final String videoPath) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("attachment", "openImage.jpg", requestFile);

        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<HashMap<String, String>> call3 = apiInterface.upMyChat(GetSet.getToken(), body, userid);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                if (response.isSuccessful()) {
                    if (data.get(Constants.TAG_STATUS).equals("true")) {
                        String apiFileName = data.get(Constants.TAG_USER_IMAGE);
                        boolean isFileMoved = storageManager.renameFile(null, imagePath, apiFileName, TAG_IMAGE);
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                                    messagesList.get(i).thumbnail = apiFileName;
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }
                        Intent service = new Intent(mContext, FileUploadService.class);
                        Bundle b = new Bundle();
                        b.putSerializable("mdata", mdata);
                        b.putString(Constants.TAG_THUMBNAIL, apiFileName);
                        b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                        b.putString("filepath", videoPath);
                        b.putString("chatType", "chat");
                        service.putExtras(b);
                        startService(service);
                    } else {
                        dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
                        if (messageListAdapter != null) {
                            for (int i = 0; i < messagesList.size(); i++) {
                                if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                                    messagesList.get(i).progress = "error";
                                    messageListAdapter.notifyItemChanged(i);
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
                    if (messageListAdapter != null) {
                        for (int i = 0; i < messagesList.size(); i++) {
                            if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                                messagesList.get(i).progress = "error";
                                messageListAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "uploadImage: " + t.getMessage());
                call.cancel();
                dbHelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
                if (messageListAdapter != null) {
                    for (int i = 0; i < messagesList.size(); i++) {
                        if (mdata.message_id.equals(messagesList.get(i).message_id)) {
                            messagesList.get(i).progress = "error";
                            messageListAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    private String getFileName(String url) {
        String imgSplit = url;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1);
        }
        return imgSplit;
    }

    public String firstThree(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        return str.length() < 3 ? str : str.substring(0, 3);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE) {
            int permissionContacts = ContextCompat.checkSelfPermission(ChatActivity.this,
                    READ_CONTACTS);
            if (permissionContacts == PackageManager.PERMISSION_GRANTED) {
                contactBtn.performClick();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
                        requestPermission(new String[]{READ_CONTACTS}, PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.contact_permission_error));
                    }
                } else {
                    makeToast(getString(R.string.contact_permission_error));
                }
            }
        } else if (requestCode == PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE) {
            int permissionAudio = ContextCompat.checkSelfPermission(ChatActivity.this,
                    RECORD_AUDIO);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (permissionAudio != PackageManager.PERMISSION_GRANTED) {
                    if (shouldShowRequestPermissionRationale(RECORD_AUDIO)) {
                        requestPermission(new String[]{RECORD_AUDIO}, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.audio_record_permission_error));
                    }
                }
            } else {
                int permissionStorage = ContextCompat.checkSelfPermission(ChatActivity.this,
                        WRITE_EXTERNAL_STORAGE);
                if (permissionAudio != PackageManager.PERMISSION_GRANTED ||
                        permissionStorage != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(ChatActivity.this, RECORD_AUDIO) ||
                            ActivityCompat.shouldShowRequestPermissionRationale(ChatActivity.this, WRITE_EXTERNAL_STORAGE)) {
                        requestPermission(new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, PermissionsUtils.RECORD_PERMISSION_REQUEST_CODE);
                    } else {
                        makeToast(getString(R.string.audio_record_permission_error));
                    }
                }
            }
            setVoiceRecorder();
        }
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == Constants.CAMERA_REQUEST_CODE) {
            String filePath = null;
            Uri fileUri = null;
            if (isNetworkConnected().equals(NOT_CONNECT)) {
                networkSnack();
            } else {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    fileUri = photoURI;
                } else {
                    filePath = ImagePicker.getImagePathFromResult(this, requestCode, resultCode, data);
                }
                BitmapCompression imageCompression = new BitmapCompression(mContext, fileUri, filePath) {
                    @Override
                    protected void onPostExecute(Bitmap compressedBitmap) {
                        String fileName = System.currentTimeMillis() + ".jpg";
                        String savedPath = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();
                        MessagesData mdata = updateDBList(Constants.TAG_IMAGE, null, null, savedPath, "");
                        byte[] bytes = StorageManager.bitmapToByteArray(compressedBitmap);
                        uploadImage(bytes, null, savedPath, mdata);
                        saveFileInGallery(new File(savedPath), StorageManager.TAG_IMAGE, StorageManager.TAG_IMAGE);
                    }
                };
                imageCompression.execute();
            }
        }
    }

    private void takeCameraPictures() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dispatchTakePictureIntent();
        } else {
            ImagePicker.pickImageCameraOnly(this, Constants.CAMERA_REQUEST_CODE);
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, Constants.CAMERA_REQUEST_CODE);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        // Save a file: path for use with ACTION_VIEW intents
        return image;
    }

    private void saveFileInGallery(File srcFile, String from, String fileType) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String fileName = mContext.getString(R.string.app_name) + "_" + (System.currentTimeMillis() / 1000) + "." + FilenameUtils.getExtension(srcFile.getName());
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    storageManager.saveFileInStorageV10(srcFile, fileName, from, fileType);
                } else {
                    storageManager.saveFileInGallery(srcFile, fileName, from);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getDisplayWidthHeight();
        socketConnection.setChatCallbackListener(this);
        ApplicationClass.onShareExternal = false;
        userId = getIntent().getExtras().getString("user_id");
        tempUserId = userId;
        results = dbHelper.getContactDetail(userId);
        username.setText(results.user_name);
        setBlockStatus(results);
        sendPing();
        getNewMessages();
        whileViewChat();
        if (!SingleStoryActivity.isMessageSent.equals("")) {
            messagesList.add(0, dbHelper.getSingleMessage(SingleStoryActivity.isMessageSent));
            showEncryptionText();
            isScroll = false;
            messageListAdapter.notifyItemInserted(0);
            recyclerView.post(new Runnable() {
                @Override
                public void run() {
                    recyclerView.smoothScrollToPosition(0);
                }
            });
            SingleStoryActivity.isMessageSent = "";
        }
        if (!pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none)) || !pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("")) {
            messageListAdapter.notifyDataSetChanged();
        }


        t1 = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result=0;
//                    Toast.makeText(mContext, pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""), Toast.LENGTH_SHORT).show();
                    if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").isEmpty()){
                        result = t1.setLanguage(Locale.getDefault());
                    }else{
                        if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")!=null){
                            result = t1.setLanguage(new Locale(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")));
                        }else{
                            result = t1.setLanguage(Locale.getDefault());
                        }

                    }
//
//                    if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("it")){
//                        result = t1.setLanguage(Locale.ITALIAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh") ||  pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh-CN")){
//                        result = t1.setLanguage(new Locale("zh-rCN"));
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("zh-TW")){
//                        result = t1.setLanguage(new Locale("zh-rTW"));
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("en")){
//                        result = t1.setLanguage(Locale.ENGLISH);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("fr")){
//                        result = t1.setLanguage(Locale.FRENCH);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("de")){
//                        result = t1.setLanguage(Locale.GERMAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("ja")){
//                        result = t1.setLanguage(Locale.JAPANESE);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("ko")){
//                        result = t1.setLanguage(Locale.KOREAN);
//                    }else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals("uk")){
//                        result = t1.setLanguage(Locale.UK);
//                    }else{
//                        result = t1.setLanguage(new Locale("ja"));
//                    }
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
//                        Toast.makeText(ChatActivity.this, "language not supported", Toast.LENGTH_SHORT).show();
                    } else {
//                        Toast.makeText(ChatActivity.this, "language  supported", Toast.LENGTH_SHORT).show();
                    }
                } else {
//                    Toast.makeText(ChatActivity.this, "Initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getNewMessages() {
        int currentCount = dbHelper.getMessagesCount(chatId);
        if (totalMsg != currentCount) {
            updateMessagesFromDB();
        }
    }

    private void setBlockStatus(ContactsData.Result results) {
        if (!results.blockedme.equals("block")) {
            DialogActivity.setProfileImage(dbHelper.getContactDetail(userId), userimage, this);
            online.setVisibility(View.VISIBLE);
        } else {
            Glide.with(ChatActivity.this).load(R.drawable.temp)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .into(userimage);
            online.setVisibility(View.GONE);
        }
        if (results.blockedbyme.equals("block")) {
            online.setVisibility(View.GONE);
        }
    }

    @Override
    public void onPause() {
        socketConnection.setChatCallbackListener(null);
        editText.setError(null);
        ApplicationClass.hideSoftKeyboard(this);
        stopAudioViewHolder();
        super.onPause();
        state = recyclerView.getLayoutManager().onSaveInstanceState();
        if (recordView != null && isRecording)
            recordView.cancelRecord();
    }

    @Override
    protected void onStop() {
        super.onStop();
        totalMsg = dbHelper.getMessagesCount(chatId);
        removePing();
    }

    @Override
    protected void onDestroy() {
        tempUserId = "";
        EventBus.getDefault().unregister(this);
        if (Constants.isChatOpened) {
            Constants.isChatOpened = false;
        }
        removePing();
        stopMediaPlayer();

        if (t1 != null) {
            t1.stop();
            t1.shutdown();
        }
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(NewMessageEvent event) {
        Log.d(TAG, "onMessageEvent: ");
        if (event != null && event.getMessageData() != null) {
            onReceiveChat(event.getMessageData());
        }
        totalMsg = dbHelper.getMessagesCount(chatId);
    }

    private void sendPing() {
        onlineHandler.post(onlineRunnable);
    }

    private void removePing() {
        onlineHandler.removeCallbacks(onlineRunnable);
    }

    private void stopMediaPlayer() {
        MediaPlayerUtils.releaseMediaPlayer();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.send:
                ApplicationClass.preventMultiClick(send);
                if (isNetworkConnected().equals(NOT_CONNECT) && !socketConnection.getMSocket().connected()) {
                    makeToast(getString(R.string.network_failure));
                } else if (results.blockedbyme.equals("block")) {
                    blockChatConfirmDialog("unblock", "sent");
                } else {
                    if (editText.getText().toString().trim().length() > 0) {
                        sendTextMessage(editText.getText().toString());
                        editText.setText("");
                    } else {
                        editText.setError(getString(R.string.please_enter_your_message));
                    }
                }
                break;
            case R.id.backbtn:
                if (isRecording) return;
                backPressed();
                break;
            case R.id.optionbtn:
                if (isRecording) return;
                ApplicationClass.preventMultiClick(optionbtn);
                results = dbHelper.getContactDetail(userId);
                final ArrayList<String> values = new ArrayList<>();
                if (results.mute_notification.equals("true")) {
                    values.add(getString(R.string.unmute_notification));
                } else {
                    values.add(getString(R.string.mute_notification));
                }
                if (results.blockedbyme.equals("block")) {
                    values.add(getString(R.string.unblock));
                } else {
                    values.add(getString(R.string.block));
                }
                values.add(getString(R.string.clear_chat));
                if (results.favourited.equals("true")) {
                    values.add(getString(R.string.remove_favourite));
                } else {
                    values.add(getString(R.string.mark_favourite));
                }
                if (!ApplicationClass.isStringNotNull(results.saved_name)) {
                    values.add(getString(R.string.add_contact));
                }

                final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                        R.layout.option_item, android.R.id.text1, values);
                LayoutInflater layoutInflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = layoutInflater.inflate(R.layout.option_layout, null);
                final PopupWindow popup = new PopupWindow(ChatActivity.this);
                popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                popup.setContentView(layout);
                popup.setWidth(displayWidth * 50 / 100);
                popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
                popup.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
                popup.setFocusable(true);

                ImageView pinImage = layout.findViewById(R.id.pinImage);
                if (ApplicationClass.isRTL()) {
                    layout.setAnimation(AnimationUtils.loadAnimation(this, R.anim.grow_from_topleft_to_bottomright));
                    pinImage.setRotation(180);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.START, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                } else {
                    layout.setAnimation(AnimationUtils.loadAnimation(this, R.anim.grow_from_topright_to_bottomleft));
                    pinImage.setRotation(0);
                    popup.showAtLocation(mainLay, Gravity.TOP | Gravity.END, ApplicationClass.dpToPx(this, 10), ApplicationClass.dpToPx(this, 63));
                }

                final ListView lv = layout.findViewById(R.id.listView);
                lv.setAdapter(adapter);
                popup.showAsDropDown(v);

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        popup.dismiss();
                        if (position == 0) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                if (values.get(position).equalsIgnoreCase(getString(R.string.mute_notification))) {
                                    dbHelper.updateMuteUser(userId, "true");
                                    values.set(position, getString(R.string.unmute_notification));
                                    socketConnection.muteChat(Constants.TAG_SINGLE, userId, true);
                                } else {
                                    dbHelper.updateMuteUser(userId, "");
                                    socketConnection.muteChat(Constants.TAG_SINGLE, userId, false);
                                    values.set(position, getString(R.string.mute_notification));
                                }
                                results = dbHelper.getContactDetail(userId);
                                adapter.notifyDataSetChanged();
                            }
                        } else if (position == 1) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                String type = "";
                                if (results.blockedbyme.equals("block")) {
                                    type = "unblock";
                                } else {
                                    type = "block";
                                }
                                blockChatConfirmDialog(type, "popup");
                            }
                        } else if (position == 2) {
                            deleteChatConfirmDialog();
                        } else if (position == 3) {
                            if (results.favourited.equals("true")) {
                                dbHelper.updateFavUser(userId, "false");
                                Toast.makeText(ChatActivity.this, getString(R.string.removed_favourites), Toast.LENGTH_SHORT).show();
                            } else {
                                dbHelper.updateFavUser(userId, "true");
                                Toast.makeText(ChatActivity.this, getString(R.string.marked_favourite), Toast.LENGTH_SHORT).show();
                            }
                        } else if (values.get(position).equals(mContext.getString(R.string.removed_favourites)) ||
                                values.get(position).equals(mContext.getString(R.string.marked_favourite))) {
                        } else if (values.get(position).equals(mContext.getString(R.string.add_contact))) {
                            Intent intent = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                            intent.putExtra("finishActivityOnSaveCompleted", true);
                            intent.putExtra(ContactsContract.Intents.Insert.PHONE, (!TextUtils.isEmpty(results.country_code) ? "+" + (results.country_code + " ") : "") + results.phone_no);
                            intent.putExtra(ContactsContract.Intents.Insert.NAME, "");
                            addContactResultLauncher.launch(intent);
                        }
                    }
                });
                break;
            case R.id.attachbtn:
                ApplicationClass.preventMultiClick(attachbtn);
                TransitionManager.beginDelayedTransition(bottomLay);
                visible = !visible;
                attachmentsLay.setVisibility(visible ? View.VISIBLE : View.GONE);
                break;
            case R.id.userImg:
                break;
            case R.id.cameraBtn:
                setClickEvent(false, true, false, false, false, false);
                ApplicationClass.preventMultiClick(cameraBtn);
                stopAudioViewHolder();
                if (PermissionsUtils.checkCameraPermission(mContext)) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                            networkSnack();
                        } else if (results.blockedbyme.equals("block")) {
                            blockChatConfirmDialog("unblock", "sent");
                        } else {
                            ApplicationClass.onShareExternal = true;
                            takeCameraPictures();
                        }
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    requestCameraPermissions();
                }
                break;
            case R.id.galleryBtn:
                setClickEvent(true, false, false, false, false, false);
                ApplicationClass.preventMultiClick(galleryBtn);
                stopAudioViewHolder();

                if (PermissionsUtils.checkStoragePermission(ChatActivity.this)) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        FilePickerBuilder.getInstance()
                                .setMaxCount(1)
                                .setActivityTheme(R.style.MainTheme)
                                .setActivityTitle(getString(R.string.please_select_media))
                                .enableVideoPicker(true)
                                .enableImagePicker(true)
                                .enableCameraSupport(false)
                                .showGifs(false)
                                .showFolderView(false)
                                .enableSelectAll(false)
                                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                                .pickPhoto(this, galleryResultLauncher);
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.fileBtn:
                setClickEvent(false, false, true, false, false, false);
                ApplicationClass.preventMultiClick(fileBtn);
                stopAudioViewHolder();
                if (PermissionsUtils.checkStoragePermission(this)) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Intent documentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                            documentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                            documentIntent.setType("application/*");
                            documentResultLauncher.launch(documentIntent);
                        } else {
                            FilePickerBuilder.getInstance()
                                    .setMaxCount(1)
                                    .enableDocSupport(true)
                                    .setActivityTitle(getString(R.string.please_select_document))
                                    .showTabLayout(true)
                                    .setActivityTheme(R.style.MainTheme)
                                    .pickFile(this, documentResultLauncher);
                        }
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.audioBtn:
                if (isRecording) return;
                setClickEvent(false, false, false, true, false, false);
                ApplicationClass.preventMultiClick(audioBtn);
                stopAudioViewHolder();
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    storagePermissionResult.launch(PermissionsUtils.AUDIO_STORAGE_PERMISSION13);
                }else if (PermissionsUtils.checkStoragePermission(this) || Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        FilePickerBuilder.getInstance()
                                .setMaxCount(1)
                                .setActivityTheme(R.style.MainTheme)
                                .setActivityTitle(getString(R.string.please_select_audio))
                                .addFileSupport("MP3", Utils.AUDIO_TYPES)
                                .enableDocSupport(false)
                                .enableImagePicker(false)
                                .enableVideoPicker(false)
                                .enableSelectAll(false)
                                .showTabLayout(false)
                                .sortDocumentsBy(SortingTypes.NAME)
                                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                                .pickFile(this, audioResultLauncher);
                    }
                } else {
                    requestStoragePermissions();
                }
                break;
            case R.id.locationBtn:
                ApplicationClass.preventMultiClick(locationBtn);
                stopAudioViewHolder();
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else if (results.blockedbyme.equals("block")) {
                    blockChatConfirmDialog("unblock", "sent");
                } else {
                    Intent location = new Intent(this, LocationActivity.class);
                    location.putExtra("from", "share");
                    locationResultLauncher.launch(location);
                }
                break;
            case R.id.contactBtn:
                ApplicationClass.preventMultiClick(contactBtn);
                stopAudioViewHolder();
                if (ContextCompat.checkSelfPermission(this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{READ_CONTACTS}, PermissionsUtils.CONTACT_PERMISSION_REQUEST_CODE);
                } else {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        ApplicationClass.onShareExternal = true;
                        Intent contactIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                        contactResultLauncher.launch(contactIntent);
                    }
                }
                break;
            case R.id.closeBtn:
                stopMediaPlayer();
                break;
            case R.id.audioCallBtn:
                if (isRecording) return;
                ApplicationClass.preventMultiClick(audioCallBtn);
                if (socketConnection.getMSocket().connected()) {
                    stopAudioViewHolder();
                    if (!PermissionsUtils.checkCallPermissions(mContext, Constants.TAG_AUDIO)) {
                        callPermissionResult.launch(AppRTCUtils.MANDATORY_AUDIO_PERMISSIONS);
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        if (NetworkStatus.isConnected()) {
                            ApplicationClass.preventMultiClick(audioCallBtn);
                            Utils.getInstance(mContext).makeCall(mContext, userId, Constants.TAG_SEND, Constants.TAG_AUDIO);
                        } else {
                            makeToast(getString(R.string.no_internet_connection));
                        }
                    }
                } else {
                    makeToast(getString(R.string.poor_network_connection));
                }
                break;
            case R.id.videoCallBtn:
                if (isRecording) return;
                ApplicationClass.preventMultiClick(videoCallBtn);
                if (socketConnection.getMSocket().connected()) {
                    stopAudioViewHolder();
                    if (!PermissionsUtils.checkCallPermissions(mContext, Constants.TAG_VIDEO)) {
                        callPermissionResult.launch(AppRTCUtils.MANDATORY_VIDEO_PERMISSIONS);
                    } else if (results.blockedbyme.equals("block")) {
                        blockChatConfirmDialog("unblock", "sent");
                    } else {
                        if (NetworkStatus.isConnected()) {
                            ApplicationClass.preventMultiClick(videoCallBtn);
                            utils.makeCall(mContext, userId, Constants.TAG_SEND, Constants.TAG_VIDEO);
                        } else {
                            makeToast(getString(R.string.no_internet_connection));
                        }
                    }
                } else {
                    makeToast(getString(R.string.poor_network_connection));
                }
                break;
            case R.id.chatUserLay:
                if (isRecording) return;
                ApplicationClass.preventMultiClick(chatUserLay);
                stopAudioViewHolder();
                Intent profile = new Intent(ChatActivity.this, ProfileActivity.class);
                profile.putExtra(Constants.TAG_USER_ID, userId);
                startActivity(profile);
                break;
            case R.id.forwordBtn:
                if (isRecording) return;
                ApplicationClass.preventMultiClick(forwordBtn);
                stopAudioViewHolder();
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    Intent f = new Intent(ChatActivity.this, ForwardActivity.class);
                    f.putExtra("from", "chat");
                    f.putExtra("id", userId);
                    f.putExtra("data", selectedChatPos);
                    forwardResultLauncher.launch(f);
                }
                break;
            case R.id.copyBtn:
                if (selectedChatPos.size() > 0) {
                    ArrayList<MessagesData> sortList = new ArrayList<>(selectedChatPos);
                    Collections.reverse(sortList);
                    StringBuilder builder = new StringBuilder();
                    for (MessagesData messageData : sortList) {
                        builder.append(messageData.message);
                        builder.append("\n");
                    }
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("Copied Message", builder.toString().trim());
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(this, getString(R.string.message_copied), Toast.LENGTH_SHORT).show();
                    selectedChatPos.clear();
                    messageListAdapter.notifyDataSetChanged();
                    chatUserLay.setVisibility(View.VISIBLE);
                    forwordLay.setVisibility(View.GONE);
                    chatLongPressed = false;
                }
                break;
            case R.id.deleteBtn:
                ApplicationClass.preventMultiClick(deleteBtn);
                stopAudioViewHolder();
                openDeleteDialog();
                //deleteMessageConfirmDialog(selectedChatPos.get(0));
                break;
            case R.id.newMessageLay:
                recyclerView.smoothScrollToPosition(0);
                iconNewMessage.setVisibility(View.GONE);
                newMessageLay.setVisibility(View.GONE);
                break;
        }
    }


    private void sendTextMessage(String textMsg) {
        String utcTime = DateUtils.getInstance(this).getCurrentUTCTime();
        String encryptedMsg = ApplicationClass.encryptMessage(textMsg);
        String chatId = this.chatId;
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
//            if (!results.blockedme.equals("block")) {
        try {
            JSONObject jobj = new JSONObject();
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_USER_ID, GetSet.getUserId());
            message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
            message.put(Constants.TAG_PHONE, GetSet.getphonenumber());
            message.put(Constants.TAG_MESSAGE_TYPE, "text");
            message.put(Constants.TAG_MESSAGE, encryptedMsg);
            message.put(Constants.TAG_CHAT_TIME, utcTime);
            message.put(Constants.TAG_CHAT_ID, chatId);
            message.put(Constants.TAG_MESSAGE_ID, messageId);
            message.put(Constants.TAG_RECEIVER_ID, userId);
            message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
            message.put(Constants.TAG_BLOCK_STATUS, "" + results.blockedme.equals("block"));
            message.put(Constants.TAG_BLOCKED_BY, results.blockedme.equals("block") ? userId : "");
            message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
            jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
            jobj.put(Constants.TAG_RECEIVER_ID, userId);
            jobj.put("message_data", message);
//            Log.v(TAG, "startChat: " + jobj);
            socketConnection.startChat(jobj);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        hideSmartReplyVisible();
//            }
        MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                Constants.TAG_TEXT, textMsg, "", "", "",
                "", "", "",
                utcTime, userId, GetSet.getUserId(), "", "", "", "");
        dbHelper.addMessageData(tempMessageData, true);
        dbHelper.addRecentMessages(chatId, userId, messageId, utcTime, "0");

        messagesList.add(0, tempMessageData);
        notifyItemInserted(0);
        showEncryptionText();
    }

    private void setClickEvent(boolean gallery, boolean camera, boolean file, boolean audio,
                               boolean download, boolean wallpaper) {
        isGalleryClicked = gallery;
        isCameraClicked = camera;
        isFileClicked = file;
        isAudioClicked = audio;
        isDownloadClicked = download;
    }

    private void requestPermission(String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(ChatActivity.this, permissions, requestCode);
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void requestCameraPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cameraPermissionResult.launch(PermissionsUtils.CAMERA_PERMISSION);
        } else {
            cameraPermissionResult.launch(PermissionsUtils.CAMERA_STORAGE_PERMISSION);
        }
    }

    private void initPermission() {
        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }
                if (granted) {
                    cameraBtn.performClick();
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ChatActivity.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                String errorString;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    errorString = mContext.getString(R.string.camera_error);
                                } else {
                                    errorString = mContext.getString(R.string.camera_storage_error);
                                }
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, errorString);
                            }
                            break;
                        }
                    }
                }
            }
        });

        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isGalleryClicked) galleryBtn.performClick();
                    else if (isFileClicked) fileBtn.performClick();
                    else if (isAudioClicked) audioBtn.performClick();
                    else if (isCameraClicked) cameraBtn.performClick();
                } else {
                    boolean neverAsked = false;
                    Log.d(TAG, "requestPermissions: ");
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ChatActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));

                            } else {
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, mContext.getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
        callPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) {
                        granted = false;
                        break;
                    }
                }

                if (granted) {

                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(ChatActivity.this, x.getKey())) {
                                callPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
//                                makeToast(getString(R.string.call_permission_error));
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, PermissionsUtils.getCallPermissionError(mContext));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void initActivityResult() {
        contactResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            // There are no request codes
                            Intent data = result.getData();
                            Uri uri = data.getData();
                            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                            if (cursor.moveToFirst()) {
                                int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                                int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                                String phoneNo = cursor.getString(phoneIndex);
                                String name = cursor.getString(nameIndex);

                                emitContact(name, phoneNo, "");
                            }
                            cursor.close();
                        }
                    }
                });

        audioResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                pathsAry = new ArrayList<>();
                                pathsAry.addAll(result.getData().getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                                if (pathsAry.size() > 0) {
                                    String savedPath = null;
                                    String filepath = null;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        String extension = storageManager.getExtension(pathsAry.get(0));
                                        File tempFile = new File(storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension));
                                        savedPath = storageManager.saveFileInStorage(tempFile, StorageManager.TAG_AUDIO_SENT);
                                    } else {
                                        try {
                                            filepath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                        } catch (URISyntaxException e) {
                                            e.printStackTrace();
                                        }
                                        savedPath = storageManager.saveFileInStorage(new File(filepath), StorageManager.TAG_AUDIO_SENT);
                                    }

                                    MessagesData mdata = updateDBList(Constants.TAG_AUDIO, null, null, savedPath, "");
                                    Intent service = new Intent(mContext, FileUploadService.class);
                                    Bundle b = new Bundle();
                                    b.putSerializable("mdata", mdata);
                                    b.putString("filepath", savedPath);
                                    b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                                    b.putString("chatType", "chat");
                                    service.putExtras(b);
                                    startService(service);

//                    WorkingManager
                    /*Data.Builder builder = new Data.Builder();
                    builder.putString(Constants.TAG_DATA, new Gson().toJson(mdata));
                    builder.putString("chatType", "chat");
                    builder.putString("filepath", savedPath);
                    builder.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                    OneTimeWorkRequest chatReceivedRequest =
                            new OneTimeWorkRequest.Builder(FileUploadWorker.class)
                                    .setInputData(builder.build())
                                    .setConstraints(new Constraints.Builder()
                                            .setRequiredNetworkType(NetworkType.CONNECTED)
                                            .build())
                                    .build();
                    WorkManager.getInstance(this).enqueue(chatReceivedRequest);*/

                                } else {
                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });

        galleryResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {

                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                pathsAry = new ArrayList<>();
                                pathsAry.addAll(result.getData().getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));

                                if (pathsAry.size() > 0) {
                                    boolean isVideo = false;
                                    if (storageManager.getMimeTypeOfUri(mContext, pathsAry.get(0)).startsWith("video/")) {
                                        isVideo = true;
                                    }

                                    if (isVideo) {
                                        String filePath = "";
                                        String savedVideoPath = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            String extension = storageManager.getExtension(pathsAry.get(0));
                                            String tempPath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                                            savedVideoPath = storageManager.saveFileInStorage(new File(tempPath), TAG_VIDEO_SENT);
                                        } else {
                                            try {
                                                filePath = ContentUriUtils.INSTANCE.getFilePath(getApplicationContext(), pathsAry.get(0));
                                                savedVideoPath = storageManager.saveFileInStorage(new File(filePath), TAG_VIDEO_SENT);
                                            } catch (URISyntaxException | NullPointerException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        Bitmap thumb = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            try {
                                                thumb = getContentResolver().loadThumbnail(pathsAry.get(0),
                                                        Utils.getBitmapSize(mContext), null);
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        } else {
                                            thumb = ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Video.Thumbnails.MINI_KIND);
                                        }
                                        if (thumb != null) {
                                            String fileName = System.currentTimeMillis() + ".jpg";
                                            String savedThumbPath = storageManager.saveImageInStorage(thumb, fileName, StorageManager.TAG_THUMB).getAbsolutePath();
                                            String finalSavedVideoPath = savedVideoPath;

                                            try {
                                                MessagesData mdata = updateDBList(Constants.TAG_VIDEO, null, null, finalSavedVideoPath, savedThumbPath);
                                                byte[] bytes = FileUtils.readFileToByteArray(new File(savedThumbPath));
                                                uploadVideoThumbnail(bytes, null, savedThumbPath, mdata, null, finalSavedVideoPath);
                                            } catch (IOException e) {
                                                makeToast(getString(R.string.something_wrong));
                                                e.printStackTrace();
                                            }
                                        }
                                    } else {
                                        String savedImagePath = null;
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            String extension = storageManager.getExtension(pathsAry.get(0));
                                            savedImagePath = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                                        } else {
                                            try {
                                                savedImagePath = ContentUriUtils.INSTANCE.getFilePath(mContext, pathsAry.get(0));
                                                Log.d(TAG, "onActivityResult: " + savedImagePath);
                                            } catch (URISyntaxException | NullPointerException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        String finalSavedImagePath = savedImagePath;
                                        BitmapCompression imageCompression = new BitmapCompression(mContext, null, finalSavedImagePath) {
                                            @Override
                                            protected void onPostExecute(Bitmap compressedBitmap) {
                                                String fileName = (System.currentTimeMillis()) + ".jpg";
                                                String savedPath = null;
                                                savedPath = storageManager.saveImageInStorage(compressedBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();

                                                MessagesData mdata = updateDBList(Constants.TAG_IMAGE, null, null, savedPath, "");
                                                byte[] bytes = StorageManager.bitmapToByteArray(compressedBitmap);
                                                uploadImage(bytes, null, savedPath, mdata);
                                            }
                                        };
                                        imageCompression.execute();
                                    }
                                } else {
                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });
        documentResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            sendDocument(result.getData());
                        }
                    }
                });
        addContactResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            username.setText(results.user_name);
                        }
                    }
                });

        locationResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            String lat = result.getData().getStringExtra("lat");
                            String lon = result.getData().getStringExtra("lon");
                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                networkSnack();
                            } else {
                                emitLocation(lat, lon);
                            }
                        }
                    }
                });

        forwardResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            selectedChatPos.clear();
                            messageListAdapter.notifyDataSetChanged();
                            chatUserLay.setVisibility(View.VISIBLE);
                            forwordLay.setVisibility(View.GONE);
                            chatLongPressed = false;
                        }
                    }
                });
    }

    private void initBackground() {
        getWindow().setBackgroundDrawableResource(R.drawable.chat_bg);
    }

    public void setLoading(boolean isLoading) {
        this.isLoading = isLoading;
    }

    private void sendDocument(Intent data) {
        if (isNetworkConnected().equals(NOT_CONNECT)) {
            networkSnack();
        } else {
            pathsAry = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Uri contentUri = data.getData();
                pathsAry.add(contentUri);
            } else {
                pathsAry.addAll(data.getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
            }
            String filePath = "";
            String savedFilePath = null;
            if (pathsAry.size() > 0) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String extension = storageManager.getExtension(pathsAry.get(0));
                    String tempFile = storageManager.fileFromContentUri(mContext, pathsAry.get(0), extension);
                    savedFilePath = storageManager.saveFileInStorage(new File(tempFile), TAG_DOCUMENT_SENT);
                } else {
                    try {
                        filePath = ContentUriUtils.INSTANCE.getFilePath(mContext, pathsAry.get(0));
                        savedFilePath = storageManager.saveFileInStorage(new File(filePath), TAG_DOCUMENT_SENT);
                    } catch (URISyntaxException | NullPointerException e) {
                        e.printStackTrace();
                    }
                }

                MessagesData mdata = updateDBList(Constants.TAG_DOCUMENT, null, null, savedFilePath, "");
                Intent service = new Intent(mContext, FileUploadService.class);
                Bundle b = new Bundle();
                b.putSerializable("mdata", mdata);
                b.putString("filepath", savedFilePath);
                b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                b.putString("chatType", "chat");
                service.putExtras(b);
                startService(service);
            } else {
                Toast.makeText(this, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openPermissionDialog(String permissionList) {
        permissionDialog = new Dialog(ChatActivity.this);
        permissionDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        permissionDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        permissionDialog.setContentView(R.layout.default_popup);
        permissionDialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 85 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        permissionDialog.setCancelable(false);
        permissionDialog.setCanceledOnTouchOutside(false);

        TextView title = permissionDialog.findViewById(R.id.title);
        TextView yes = permissionDialog.findViewById(R.id.yes);
        TextView no = permissionDialog.findViewById(R.id.no);
        title.setText("This app requires " + permissionList + " permissions to access the features. Please turn on");
        yes.setText(R.string.grant);
        no.setText(R.string.nope);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                permissionDialog.dismiss();
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivityForResult(intent, 100);
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (permissionDialog.isShowing())
                    permissionDialog.dismiss();
            }
        });
        permissionDialog.show();
    }

    private String milliSecondsToTimer(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        // Add hours if there
        if (hours > 0) {
            finalTimerString = hours + ":";
        }

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }

        finalTimerString = finalTimerString + minutes + ":" + secondsString;

        // return timer string
        return finalTimerString;
    }

    //Addon Gif
    @Override
    public void onGifSelected(@NonNull Media media, @Nullable String s, @NonNull GPHContentType gphContentType) {
        MessagesData messagesData = updateDBList(Constants.TAG_GIF, null, null, media.getImages().getFixedHeightDownsampled().getGifUrl(), "");
        if (!results.blockedme.equals("block")) {
            JSONObject jobj = new JSONObject();
            JSONObject message = new JSONObject();
            try {
                message.put(Constants.TAG_USER_ID, GetSet.getUserId());
                message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
                message.put(Constants.TAG_PHONE, GetSet.getphonenumber());
                message.put(Constants.TAG_MESSAGE_TYPE, messagesData.message_type);
                message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(messagesData.attachment));
                message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(messagesData.message));
                message.put(Constants.TAG_CHAT_TIME, messagesData.chat_time);
                message.put(Constants.TAG_CHAT_ID, messagesData.chat_id);
                message.put(Constants.TAG_MESSAGE_ID, messagesData.message_id);
                message.put(Constants.TAG_RECEIVER_ID, userId);
                message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                message.put(Constants.TAG_ISDELETE, "0");
                jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                jobj.put(Constants.TAG_RECEIVER_ID, userId);
                jobj.put("message_data", message);
                Log.v(TAG, "onGifSelected: " + jobj);
                socketConnection.startChat(jobj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            hideSmartReplyVisible();
        }
    }

    @Override
    public void didSearchTerm(@NotNull String s) {

    }

    @Override
    public void onDismissed(@NonNull GPHContentType gphContentType) {

    }

    public void stopAudioViewHolder() {
        MediaPlayerUtils.pauseMediaPlayer();
        if (currentMessageId != null) {
            MessagesData tempMsgData = dbHelper.getSingleMessage(currentMessageId);
            int tempPosition = -1;
            if (messagesList.contains(tempMsgData)) {
                tempPosition = messagesList.indexOf(tempMsgData);
            }
            if (tempPosition != -1) {
                messageListAdapter.notifyItemChanged(tempPosition);
                /*RecyclerView.ViewHolder tempViewHolder = recyclerView.findViewHolderForAdapterPosition(tempPosition);
                if (tempViewHolder instanceof MessageListAdapter.SentVoiceHolder) {
                    MessageListAdapter.SentVoiceHolder holder = (MessageListAdapter.SentVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, ApplicationClass.decryptMessage(tempMsgData.attachment), TAG_AUDIO);
                    if (file != null) {
                        holder.duration.setVisibility(View.VISIBLE);
                        holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(file)));
                    } else {
                        holder.duration.setVisibility(View.INVISIBLE);
                    }
                } else if (tempViewHolder instanceof MessageListAdapter.ReceiveVoiceHolder) {
                    MessageListAdapter.ReceiveVoiceHolder holder = (MessageListAdapter.ReceiveVoiceHolder) tempViewHolder;
                    holder.seekbar.setProgress(0);
                    holder.icon.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.pause_icon_white));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, ApplicationClass.decryptMessage(tempMsgData.attachment), StorageManager.TAG_AUDIO);
                        Uri fileUri = storageManager.getUriFromFile(file);
                        if (fileUri != null) {
                            holder.duration.setVisibility(View.VISIBLE);
                            holder.duration.setText(milliSecondsToTimer(storageManager.getMediaDuration(mContext, fileUri)));
                        } else {
                            holder.duration.setVisibility(View.INVISIBLE);
                        }
                    }
                }*/
            }
        }
    }

    private void addLoadingView() {
        //Add loading item
        handler.post(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "addLoadingView: " + messagesList.size());
                if (messagesList.size() > 0 && (messagesList.get(messagesList.size() - 1) == null ||
                        messagesList.get(messagesList.size() - 1).message_type.equals("loading"))) {

                } else {
                    if (messagesList.size() > 0) {
                        int position = messagesList.size();
//                    Log.d(TAG, "addLoadingView: " + position + ", " + messagesList.get(position - 1).message_type);
                        MessagesData mData = new MessagesData();
                        mData.message_type = "loading";
                        messagesList.add(mData);
                        isScroll = false;
                        messageListAdapter.notifyItemInserted(position);
                        Log.d(TAG, "addLoadingView: " + messagesList.size() + ", " + messagesList.get(messagesList.size() - 1).message_type);
                    }
                }
            }
        });
    }

    private void removeLoadingView() {
        isScroll = true;
        for (int i = messagesList.size() - 1; i > 0; i--) {
            if (messagesList.get(i) == null ||
                    messagesList.get(i).message_type.equals("loading")) {
                messagesList.remove(i);
                messageListAdapter.notifyItemRemoved(i);
                break;
            }
        }
        /*//Remove loading item
        if (messagesList.size() != 0 && messagesList.get(messagesList.size() - 1) == null ||
                messagesList.get(messagesList.size() - 1).message_type.equals("loading")) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "removeLoadingView: " + messagesList.get(messagesList.size() - 1).message_type);
//                    Log.d(TAG, "removeLoadingView: " + (messagesList.size() - 1) + ", " + messagesList.get(messagesList.size() - 1).message_type);
                    messagesList.remove(messagesList.size() - 1);
                    messageListAdapter.notifyItemRemoved(messagesList.size() - 1);
//                    messageListAdapter.notifyItemRangeChanged(position, messagesList.size());
                }
            });
        }*/
    }




    @Override
    public void onReadyForSpeech(Bundle params) {
        editText.setText("");
        editText.setText("Listening...");
    }

    @Override
    public void onBeginningOfSpeech() {

    }

    @Override
    public void onRmsChanged(float rmsdB) {

    }

    @Override
    public void onBufferReceived(byte[] buffer) {

    }

    @Override
    public void onEndOfSpeech() {

    }

    @Override
    public void onError(int error) {
        String message;
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
//                Toast.makeText(ChatActivity.this, "Audio error", Toast.LENGTH_SHORT).show();
//                message = "Audio error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
//                Toast.makeText(ChatActivity.this, "Client error", Toast.LENGTH_SHORT).show();

//                message = "Client error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
//                Toast.makeText(ChatActivity.this, "Insufficient permissions", Toast.LENGTH_SHORT).show();

//                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                Toast.makeText(ChatActivity.this, "Network error", Toast.LENGTH_SHORT).show();

//                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                Toast.makeText(ChatActivity.this, "Network timeout", Toast.LENGTH_SHORT).show();

//                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                Toast.makeText(ChatActivity.this, "No match", Toast.LENGTH_SHORT).show();

//                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
//                Toast.makeText(ChatActivity.this, "Speech Recognizer is busy", Toast.LENGTH_SHORT).show();

//                message = "Speech Recognizer is busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                Toast.makeText(ChatActivity.this, "Server error", Toast.LENGTH_SHORT).show();

//                message = "Server error";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
//                Toast.makeText(ChatActivity.this, "No speech input", Toast.LENGTH_SHORT).show();

//                message = "No speech input";
                break;
            default:
                Toast.makeText(ChatActivity.this, "Speech Recognizer cannot understand you", Toast.LENGTH_SHORT).show();

//                message = "Speech Recognizer cannot understand you";
                break;
        }

        editText.setText("");
        txt_recording.setText("Start Recording");
        //recognizer.stopListening();
        //recognizer.startListening(intent);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> words = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

        String text = "";

        for (String word : words) {
            text += word + " ";
        }

        editText.setText(text);
        txt_recording.setText("Start Recording");

        //recognizer.stopListening();
        //recognizer.startListening(intent);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {

    }

    @Override
    public void onEvent(int eventType, Bundle params) {

    }

    public class MessageListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        public static final int VIEW_TYPE_LOADING = 0;
        public static final int VIEW_TYPE_MESSAGE_SENT = 1;
        public static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
        public static final int VIEW_TYPE_IMAGE_SENT = 3;
        public static final int VIEW_TYPE_IMAGE_RECEIVED = 4;
        public static final int VIEW_TYPE_CONTACT_SENT = 5;
        public static final int VIEW_TYPE_CONTACT_RECEIVED = 6;
        public static final int VIEW_TYPE_FILE_SENT = 7;
        public static final int VIEW_TYPE_FILE_RECEIVED = 8;
        public static final int VIEW_TYPE_DATE = 9;
        public static final int VIEW_TYPE_VOICE_SENT = 10;
        public static final int VIEW_TYPE_VOICE_RECEIVE = 11;
        public static final int VIEW_TYPE_DELETE_SENT = 12;
        public static final int VIEW_TYPE_DELETE_RECEIVE = 13;
        public static final int VIEW_TYPE_STATUS_REPLY_SENT = 14;
        public static final int VIEW_TYPE_STATUS_REPLY_RECEIVE = 15;
        public static final int VIEW_TYPE_INVITE_LINK_SENT = 16;
        public static final int VIEW_TYPE_INVITE_LINK_RECEIVE = 17;

        private Context mContext = getApplicationContext();
        private List<MessagesData> messageList = new ArrayList<>();

        public MessageListAdapter(Context context, List<MessagesData> messageList) {
            //mContext = context;
            this.messageList = messageList;
        }

        @Override
        public int getItemCount() {
            return messageList.size();
        }

        // Determines the appropriate ViewType according to the sender of the message.
        @Override
        public int getItemViewType(int position) {
            if (messageList.get(position) == null || messageList.get(position).message_type.equals("loading")) {
                return VIEW_TYPE_LOADING;
            } else {
                MessagesData message = messageList.get(position);
                if (message.user_id != null && message.user_id.equals(GetSet.getUserId())) {
                    switch (message.message_type) {
                        case "text":
                            return VIEW_TYPE_MESSAGE_SENT;
                        case Constants.TAG_LINK:
                            return VIEW_TYPE_INVITE_LINK_SENT;
                        case Constants.TAG_IMAGE:
                        case Constants.TAG_VIDEO:
                        case Constants.TAG_LOCATION:
                        case Constants.TAG_GIF:
                            return VIEW_TYPE_IMAGE_SENT;
                        case "contact":
                            return VIEW_TYPE_CONTACT_SENT;
                        case "date":
                            return VIEW_TYPE_DATE;
                        case Constants.TAG_AUDIO:
                            return VIEW_TYPE_VOICE_SENT;
                        case "story":
                            return VIEW_TYPE_STATUS_REPLY_SENT;
                        case Constants.TAG_ISDELETE:
                            return VIEW_TYPE_DELETE_SENT;
                        default:
                            return VIEW_TYPE_FILE_SENT;
                    }
                } else {
                    switch (message.message_type) {
                        case "text":
                            return VIEW_TYPE_MESSAGE_RECEIVED;
                        case Constants.TAG_LINK:
                            return VIEW_TYPE_INVITE_LINK_RECEIVE;
                        case Constants.TAG_IMAGE:
                        case Constants.TAG_VIDEO:
                        case Constants.TAG_LOCATION:
                        case Constants.TAG_GIF:
                            return VIEW_TYPE_IMAGE_RECEIVED;
                        case "contact":
                            return VIEW_TYPE_CONTACT_RECEIVED;
                        case "date":
                            return VIEW_TYPE_DATE;
                        case Constants.TAG_AUDIO:
                            return VIEW_TYPE_VOICE_RECEIVE;
                        case "story":
                            return VIEW_TYPE_STATUS_REPLY_RECEIVE;
                        case Constants.TAG_ISDELETE:
                            return VIEW_TYPE_DELETE_RECEIVE;
                        default:
                            return VIEW_TYPE_FILE_RECEIVED;
                    }
                }
            }
        }

        // Inflates the appropriate layout according to the ViewType.
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;

            if (viewType == VIEW_TYPE_MESSAGE_SENT) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_text_bubble_sent, parent, false);
                return new SentMessageHolder(view);
            } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_text_bubble_receive, parent, false);
                return new ReceivedMessageHolder(view);
            } else if (viewType == VIEW_TYPE_INVITE_LINK_SENT) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_link_bubble_sent, parent, false);
                return new SentInviteLinkHolder(view);
            } else if (viewType == VIEW_TYPE_INVITE_LINK_RECEIVE) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_link_bubble_receive, parent, false);
                return new ReceivedInviteLinkHolder(view);
            } else if (viewType == VIEW_TYPE_IMAGE_SENT) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_image_bubble_sent, parent, false);
                return new SentImageHolder(view);
            } else if (viewType == VIEW_TYPE_IMAGE_RECEIVED) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_image_bubble_receive, parent, false);
                return new ReceivedImageHolder(view);
            } else if (viewType == VIEW_TYPE_CONTACT_SENT) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_contact_bubble_sent, parent, false);
                return new SentContactHolder(view);
            } else if (viewType == VIEW_TYPE_CONTACT_RECEIVED) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_contact_bubble_receive, parent, false);
                return new ReceivedContactHolder(view);
            } else if (viewType == VIEW_TYPE_FILE_SENT) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_file_bubble_sent, parent, false);
                return new SentFileHolder(view);
            } else if (viewType == VIEW_TYPE_FILE_RECEIVED) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_file_bubble_received, parent, false);
                return new ReceivedFileHolder(view);
            } else if (viewType == VIEW_TYPE_DATE) {
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.chat_date_layout, parent, false);
                return new DateHolder(view);
            } else if (viewType == VIEW_TYPE_VOICE_SENT) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_voice_sent, parent, false);
                return new SentVoiceHolder(view);
            } else if (viewType == VIEW_TYPE_VOICE_RECEIVE) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_voice_receive, parent, false);
                return new ReceiveVoiceHolder(view);
            } else if (viewType == VIEW_TYPE_DELETE_SENT) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_delete_bubble_sent, parent, false);
                return new DeleteMsgSent(view);
            } else if (viewType == VIEW_TYPE_DELETE_RECEIVE) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_delete_bubble_receive, parent, false);
                return new DeleteMsgReceived(view);
            } else if (viewType == VIEW_TYPE_STATUS_REPLY_SENT) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sent_status_reply, parent, false);
                return new SentStatusViewHolder(view);
            } else if (viewType == VIEW_TYPE_STATUS_REPLY_RECEIVE) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.received_status_reply, parent, false);
                return new ReceivedStatusViewHolder(view);
            } else if (viewType == VIEW_TYPE_LOADING) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_horizontal_loadmore, parent, false);
                return new LoadingMoreHolder(view);
            }

            return null;
        }

        // Passes the message object to a ViewHolder so that the contents can be bound to UI.
        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (messageList.size() > 0) {
                MessagesData message = messageList.get(position);
                switch (holder.getItemViewType()) {
                    case VIEW_TYPE_MESSAGE_SENT:
                        ((SentMessageHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_MESSAGE_RECEIVED:
                        ((ReceivedMessageHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_INVITE_LINK_SENT:
                        ((SentInviteLinkHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_INVITE_LINK_RECEIVE:
                        ((ReceivedInviteLinkHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_IMAGE_SENT:
                        ((SentImageHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_IMAGE_RECEIVED:
                        ((ReceivedImageHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_FILE_SENT:
                        ((SentFileHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_FILE_RECEIVED:
                        ((ReceivedFileHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_CONTACT_SENT:
                        ((SentContactHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_CONTACT_RECEIVED:
                        ((ReceivedContactHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_DATE:
                        ((DateHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_VOICE_SENT:
                        ((SentVoiceHolder) holder).bind(message, position);
                        break;
                    case VIEW_TYPE_VOICE_RECEIVE:
                        ((ReceiveVoiceHolder) holder).bind(message, position);
                        break;
                    case VIEW_TYPE_DELETE_SENT:
                        ((DeleteMsgSent) holder).bind(message);
                        break;
                    case VIEW_TYPE_DELETE_RECEIVE:
                        ((DeleteMsgReceived) holder).bind(message);
                        break;
                    case VIEW_TYPE_STATUS_REPLY_SENT:
                        ((SentStatusViewHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_STATUS_REPLY_RECEIVE:
                        ((ReceivedStatusViewHolder) holder).bind(message);
                        break;
                    case VIEW_TYPE_LOADING:
                        ((LoadingMoreHolder) holder).bind(message);
                        break;
                }
            }
        }

        private String checkJSONobject(JSONObject json, String key) {
            if (json.isNull(key))
                return "";
            else
                return json.optString(key, "").trim();
        }

        private class SentMessageHolder extends RecyclerView.ViewHolder {
            TextView messageText, timeText;
            ImageView tickimage,img_mike;

            SentMessageHolder(View itemView) {
                super(itemView);

                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                img_mike = itemView.findViewById(R.id.img_mike);


            }

            void bind(MessagesData message) {
//                Log.d(TAG, "SentMessageHolder: " + getAbsoluteAdapterPosition() + ", " + new Gson().toJson(message));
                String msg;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    msg = message.message + Html.fromHtml(
                            " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                } else {
                    msg = message.message + Html.fromHtml(
                            " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                }
//                setLinks(messageText, msg);
                messageText.setText(msg);
                img_mike.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String toSpeak = messageText.getText().toString();
                        t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                    }
                });
                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                if (message.delivery_status != null) {
                    switch (message.delivery_status) {
                        case "read":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            break;
                        case "sent":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            break;
                        default:
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.single_tick);
                            break;
                    }
                } else {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.single_tick);
                }

                itemView.setSelected(selectedChatPos.contains(message));
            }
        }

        private void setLinks(TextView messageText, String msg) {
        }

        private class ReceivedMessageHolder extends RecyclerView.ViewHolder {
            TextView messageText, timeText;
            TextView btnTranslate;
            ImageView img_mike;

            ReceivedMessageHolder(View itemView) {
                super(itemView);

                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                btnTranslate = itemView.findViewById(R.id.btnTranslate);
                img_mike = itemView.findViewById(R.id.img_mike);


            }

            void bind(MessagesData message) {
                Log.d(TAG, "ReceivedMessageHolder: " + Constants.ADDON_CHAT_TRANSLATE + " " + pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, ""));
                String msg;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    msg = message.message + Html.fromHtml(
                            " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                } else {
                    msg = message.message + Html.fromHtml(
                            " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                }
                messageText.setText(msg);

                img_mike.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String toSpeak = messageText.getText().toString();
                        t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                    }
                });

                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                itemView.setSelected(selectedChatPos.contains(message));

                if (Constants.ADDON_CHAT_TRANSLATE) {
                    if (containsIllegalCharacters(msg))
                        btnTranslate.setVisibility(View.GONE);
                    else if (pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none)) || pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(""))
                        btnTranslate.setVisibility(View.GONE);
                    else btnTranslate.setVisibility(View.VISIBLE);
                } else {
                    btnTranslate.setVisibility(View.GONE);
                }

                btnTranslate.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("StaticFieldLeak")
                    @Override
                    public void onClick(View view) {
                        //Addon Chat Translate
                        if (!TextUtils.isEmpty(pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "")) && !pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "").equals(mContext.getString(R.string.none))) {
                            /*Data.Builder builder = new Data.Builder();
                            builder.putString(Constants.TAG_MESSAGE, message.message);
                            OneTimeWorkRequest translateWorkRequest = new OneTimeWorkRequest.Builder(ChatTranslateWorker.class)
                                    .setConstraints(new Constraints.Builder()
                                            .setRequiredNetworkType(NetworkType.CONNECTED)
                                            .build())
                                    .setInputData(builder.build())
                                    .build();
                            WorkManager workManager = WorkManager.getInstance(mContext);
                            workManager.enqueue(translateWorkRequest);
                            workManager.getWorkInfoByIdLiveData(translateWorkRequest.getId()).observe(ChatActivity.this, workInfo -> {
                                if (workInfo.getState().isFinished()) {
                                    if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                                        String translatedMsg = workInfo.getOutputData().getString(Constants.TAG_DATA);
                                        message.message = translatedMsg;
                                        notifyItemChanged(getAbsoluteAdapterPosition());
                                    }
                                }
                            });*/


                            Log.e("chattranslEx", "-before call " + message.message);
                            final String msgStr = message.message;
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    executorchat.execute(new Runnable() {
                                        @Override
                                        public void run() {
                                            String url = "https://translation.googleapis.com/language/translate/v2?target=" +
                                                    pref.getString(Constants.TAG_TRANSLATE_LANGUAGE_CODE, "") +
                                                    "&key=" + "AIzaSyBSC5IB7c_0CcSC-hTNSlfeudjY9tGbJHE" + "&q=" + msgStr;
                                            Log.i(TAG, "startWork: " + url);
                                            BufferedReader reader = null;
                                            try {
                                                URL urlObj = new URL(url);
                                                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                                                conn.setDoOutput(true);
                                                conn.setRequestMethod("GET");
                                                conn.setRequestProperty("Accept-Charset", "UTF-8");

                                                StringBuilder sb = new StringBuilder();
                                                reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                                                String line;
                                                while ((line = reader.readLine()) != null) {
                                                    sb.append(line + "\n");
                                                }
                                                String translatedMsg = parseTranslatedMsg(sb.toString());

                                                if (!TextUtils.isEmpty(translatedMsg)) {
                                                    mainHandler.post(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Log.e("chattranslEx", "-result success" + translatedMsg);
                                                            String replace= translatedMsg.replace("&#39;","'");
                                                            message.message = replace;
                                                            notifyItemChanged(getAbsoluteAdapterPosition());
                                                        }
                                                    });
                                                } else {
                                                    Log.e("chattranslEx", "-empty str");
                                                }
                                            } catch (IOException e) {
                                                Log.e("chattranslEx", "exceptionworker-" + e.toString());
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                }
                            });


                        } else {
                            Toast.makeText(mContext, mContext.getString(R.string.select_language), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        }

        private class SentInviteLinkHolder extends RecyclerView.ViewHolder {
            private ConstraintLayout headerLay;
            private TextView messageText, timeText, txtName, txtDescription, btnView;
            private CircleImageView ivProfile;
            private ImageView tickimage,img_mike;

            SentInviteLinkHolder(View itemView) {
                super(itemView);

                headerLay = itemView.findViewById(R.id.headerLay);
                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                img_mike = itemView.findViewById(R.id.img_mike);
                txtName = itemView.findViewById(R.id.txtName);
                txtDescription = itemView.findViewById(R.id.txtDescription);
                btnView = itemView.findViewById(R.id.btnView);
                ivProfile = itemView.findViewById(R.id.ivProfile);

            }

            void bind(MessagesData message) {

                Log.d(TAG, "SentInviteLinkHolder: " + new Gson().toJson(message));
                try {
                    JSONObject messageObject = new JSONObject(message.message);
                    txtName.setText(messageObject.optString(Constants.TAG_NAME));
                    txtDescription.setText(messageObject.optString(Constants.TAG_DESCRIPTION));
                    if (messageObject.optString(Constants.TAG_TYPE).equals(Constants.TAG_GROUP)) {
                        btnView.setText(mContext.getString(R.string.view_grouop));
                    } else {
                        btnView.setText(mContext.getString(R.string.view_channel));
                    }
//                    Log.d(TAG, "ReceivedInviteLinkHolder: "+messageObject.optString(Constants.TAG_MESSAGE));
                    String msg = messageObject.optString(Constants.TAG_LINK);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                    } else {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                    }
                    // set up spanned string with url
                    SpannableString spannableString = new SpannableString(msg);
                    String url = messageObject.optString(Constants.TAG_LINK);
                    int startIndex = msg.indexOf(url);
                    int lastIndex = startIndex + url.length();
                    spannableString.setSpan(new UnderlineSpan(), startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannableString.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(@NonNull View widget) {
                            btnView.performClick();
                        }
                    }, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    // set to textview
                    messageText.setText(spannableString);
                    img_mike.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String toSpeak = messageText.getText().toString();
                            t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    });
                    messageText.setMovementMethod(LinkMovementMethod.getInstance()); // enable clicking on url span
//                    messageText.setText(msg);
                    headerLay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btnView.performClick();
                        }
                    });
                    btnView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            intent.putExtra(Constants.TAG_FROM, Constants.TAG_CHAT);
                            intent.setData(Uri.parse(url));
                            startActivity(intent);
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                if (message.delivery_status != null) {
                    switch (message.delivery_status) {
                        case "read":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            break;
                        case "sent":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            break;
                        default:
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.single_tick);
                            break;
                    }
                } else {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.single_tick);
                }

                itemView.setSelected(selectedChatPos.contains(message));
            }
        }

        private class ReceivedInviteLinkHolder extends RecyclerView.ViewHolder {
            private ConstraintLayout headerLay;
            private TextView messageText, timeText, btnTranslate, txtName, txtDescription, btnView;
            private CircleImageView ivProfile;
            ImageView img_mike;

            ReceivedInviteLinkHolder(View itemView) {
                super(itemView);

                headerLay = itemView.findViewById(R.id.headerLay);
                messageText = itemView.findViewById(R.id.text_message_body);
                timeText = itemView.findViewById(R.id.text_message_time);
                btnTranslate = itemView.findViewById(R.id.btnTranslate);
                txtName = itemView.findViewById(R.id.txtName);
                txtDescription = itemView.findViewById(R.id.txtDescription);
                btnView = itemView.findViewById(R.id.btnView);
                ivProfile = itemView.findViewById(R.id.ivProfile);
                img_mike = itemView.findViewById(R.id.img_mike);


            }

            void bind(MessagesData message) {
                Log.d(TAG, "ReceivedInviteLinkHolder: " + new Gson().toJson(message));
                btnTranslate.setVisibility(View.GONE);
                try {
                    JSONObject messageObject = new JSONObject(message.message);
                    txtName.setText(messageObject.optString(Constants.TAG_NAME));
                    txtDescription.setText(messageObject.optString(Constants.TAG_DESCRIPTION));
                    if (messageObject.optString(Constants.TAG_TYPE).equals(Constants.TAG_GROUP)) {
                        btnView.setText(mContext.getString(R.string.view_grouop));
                    } else {
                        btnView.setText(mContext.getString(R.string.view_channel));
                    }
//                    Log.d(TAG, "ReceivedInviteLinkHolder: "+messageObject.optString(Constants.TAG_MESSAGE));
                    String msg = messageObject.optString(Constants.TAG_LINK);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;", Html.FROM_HTML_MODE_LEGACY);
                    } else {
                        msg = msg + Html.fromHtml(
                                " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;");
                    }
                    // set up spanned string with url
                    SpannableString spannableString = new SpannableString(msg);
                    String url = messageObject.optString(Constants.TAG_LINK);
                    int startIndex = msg.indexOf(url);
                    int lastIndex = startIndex + url.length();
                    spannableString.setSpan(new UnderlineSpan(), startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannableString.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(@NonNull View widget) {
                            btnView.performClick();
                        }
                    }, startIndex, lastIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    // set to textview
                    messageText.setText(spannableString);
                    img_mike.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String toSpeak = messageText.getText().toString();
                            t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    });
                    messageText.setMovementMethod(LinkMovementMethod.getInstance()); // enable clicking on url span
//                    messageText.setText(msg);
                    headerLay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btnView.performClick();
                        }
                    });
                    btnView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            intent.putExtra(Constants.TAG_FROM, Constants.TAG_CHAT);
                            intent.setData(Uri.parse(url));
                            startActivity(intent);
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                Linkify.addLinks(messageText, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                itemView.setSelected(selectedChatPos.contains(message));
            }
        }

        private class SentImageHolder extends RecyclerView.ViewHolder {
            TextView timeText;
            ImageView tickimage, uploadimage, downloadicon;
            ShapeableImageView gifImage;
            RelativeLayout progresslay;
            ProgressWheel progressbar;

            SentImageHolder(View itemView) {
                super(itemView);

                uploadimage = itemView.findViewById(R.id.uploadimage);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                progresslay = itemView.findViewById(R.id.progresslay);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                gifImage = itemView.findViewById(R.id.gifImage);
            }

            void bind(final MessagesData message) {
                Log.i(TAG, "SentImageHolder: " + new Gson().toJson(message));
                gifImage.setVisibility(View.GONE);
                uploadimage.setVisibility(View.VISIBLE);
                String attachmentPath = message.attachment;
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }

                switch (message.message_type) {
                    case Constants.TAG_IMAGE: {
                        downloadicon.setImageResource(R.drawable.upload);
                        if (message.delivery_status.equals("read")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.colorAccent));
                        } else if (message.delivery_status.equals("sent")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                        } else if (message.progress.equals("completed")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.single_tick);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                        } else {
                            tickimage.setVisibility(View.GONE);
                        }

                        switch (message.progress) {
                            case "": {
                                progresslay.setVisibility(View.VISIBLE);
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.spin();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                                break;
                            }
                            case "completed": {
                                progresslay.setVisibility(View.GONE);
                                progressbar.setVisibility(View.GONE);
                                progressbar.stopSpinning();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    progresslay.setVisibility(View.VISIBLE);
                                    progressbar.setVisibility(View.VISIBLE);
                                    downloadicon.setImageResource(R.drawable.download);
                                    setErrorImage(mContext, Constants.CHAT_IMG_PATH + getFileName(attachmentPath), uploadimage);
                                }
                                break;
                            }
                            case "error": {
                                progresslay.setVisibility(View.VISIBLE);
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.stopSpinning();
                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                if (file != null) {
                                    setMediaImage(mContext, null, file, uploadimage);
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                                break;
                            }
                        }

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                if (isRecording) return;

                                ApplicationClass.preventMultiClick(view);
                                if (!chatLongPressed) {
                                    if (message.progress.equals("error")) {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            try {
                                                progressbar.setVisibility(View.VISIBLE);
                                                progressbar.spin();
                                                dbHelper.updateMessageData(message.message_id, Constants.TAG_PROGRESS, "");
                                                message.progress = "";
                                                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                                if (file != null) {
                                                    setMediaImage(mContext, null, file, uploadimage);
                                                    byte[] bytes = FileUtils.readFileToByteArray(file);
                                                    uploadImage(bytes, null, attachmentPath, message);
                                                } else {
                                                    setErrorImage(mContext, "", uploadimage);
                                                }
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                            }
                                        }
                                    } else if (message.progress.equals("completed")) {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, getFileName(attachmentPath), Constants.TAG_IMAGE);
                                        Uri fileuri;
                                        fileuri = storageManager.getUriFromFile(file);
                                        if (fileuri != null) {
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, fileuri, Constants.TAG_MESSAGE, imageView);
                                        } else {
                                            stopAudioViewHolder();
                                            downloadImage(Constants.CHAT_IMG_PATH + getFileName(attachmentPath), getFileName(attachmentPath), uploadimage, progresslay, progressbar);
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_LOCATION: {
                        switch (message.delivery_status) {
                            case "read":
                                tickimage.setVisibility(View.VISIBLE);
                                tickimage.setImageResource(R.drawable.double_tick);
                                tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.colorAccent));
                                break;
                            case "sent":
                                tickimage.setVisibility(View.VISIBLE);
                                tickimage.setImageResource(R.drawable.double_tick_unseen);
                                tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                                break;
                            default:
                                tickimage.setVisibility(View.VISIBLE);
                                tickimage.setImageResource(R.drawable.single_tick);
                                tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                                break;
                        }
                        progresslay.setVisibility(View.GONE);
                        String lat = message.lat;
                        String lng = message.lon;
                        String mapUrl = ApplicationClass.getMapUrl(lat, lng, mContext);
                        Glide.with(mContext).load(mapUrl).thumbnail(0.5f)
                                .into(uploadimage);

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                ApplicationClass.preventMultiClick(view);
                                if (!chatLongPressed && !isRecording) {
                                    stopAudioViewHolder();
                                    Intent i = new Intent(ChatActivity.this, LocationActivity.class);
                                    i.putExtra("from", "view");
                                    i.putExtra("lat", lat);
                                    i.putExtra("lon", lng);
                                    startActivity(i);
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_VIDEO: {
                        if (message.delivery_status.equals("read")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.colorAccent));
                        } else if (message.delivery_status.equals("sent")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                        } else if (message.progress.equals("completed")) {
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.single_tick);
                            tickimage.setColorFilter(ContextCompat.getColor(mContext, R.color.white));
                        } else {
                            tickimage.setVisibility(View.GONE);
                        }

                        progresslay.setVisibility(View.VISIBLE);
                        String thumbnail = message.thumbnail;
                        switch (message.progress) {
                            case "": {
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.spin();
                                downloadicon.setImageResource(R.drawable.upload);

                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                if (fileUri != null) {
                                    if (thumb != null && thumb.exists()) {
                                        setMediaImage(mContext, null, thumb, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                            }
                            break;
                            case "completed": {
                                progressbar.setVisibility(View.GONE);
                                progressbar.stopSpinning();
                                downloadicon.setImageResource(R.drawable.play);
                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                if (thumb != null) {
                                    Log.d(TAG, "bind: " + thumb.getName() + ", " + thumb.exists());
                                }
                                if (fileUri != null) {
                                    if (thumb != null && thumb.exists()) {
                                        setMediaImage(mContext, null, thumb, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    progressbar.setVisibility(View.VISIBLE);
                                    downloadicon.setImageResource(R.drawable.download);
                                    setErrorImage(mContext, Constants.CHAT_IMG_PATH + thumbnail, uploadimage);
                                }
                            }
                            break;
                            case "error": {
                                progressbar.setVisibility(View.VISIBLE);
                                progressbar.stopSpinning();
                                downloadicon.setImageResource(R.drawable.upload);
                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(attachmentPath), Constants.TAG_VIDEO);
                                File thumb = storageManager.getSrcFile(TAG_THUMB, getFileName(thumbnail), Constants.TAG_IMAGE);
                                Uri fileUri = storageManager.getUriFromFile(file);
                                if (fileUri != null) {
                                    if (thumb != null && thumb.exists()) {
                                        setMediaImage(mContext, null, thumb, uploadimage);
                                    } else {
                                        setMediaImage(mContext, fileUri, null, uploadimage);
                                    }
                                } else {
                                    setErrorImage(mContext, "", uploadimage);
                                }
                            }
                            break;
                            default:
                                break;
                        }

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                ApplicationClass.preventMultiClick(view);
                                ApplicationClass.preventMultiClick(view);
                                if (!chatLongPressed && !isRecording) {
                                    if (message.progress.equals("error")) {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            try {
                                                Bitmap thumb = null;
                                                File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                                if (file != null) {
                                                    String filePath = file.getAbsolutePath();
                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                        CancellationSignal ca = new CancellationSignal();
                                                        thumb = ThumbnailUtils.createVideoThumbnail(file, Utils.getBitmapSize(mContext), ca);
                                                    } else {
                                                        thumb = ThumbnailUtils.createVideoThumbnail(message.attachment, MediaStore.Video.Thumbnails.MINI_KIND);
                                                    }
                                                    if (thumb != null) {
                                                        progressbar.setVisibility(View.VISIBLE);
                                                        progressbar.spin();
                                                        dbHelper.updateMessageData(message.message_id, Constants.TAG_PROGRESS, "");
                                                        message.progress = "";
                                                        String thumbName = System.currentTimeMillis() + ".jpg";
                                                        String savedThumbPath = storageManager.saveImageInStorage(thumb, thumbName, TAG_THUMB).getAbsolutePath();
                                                        byte[] bytes = FileUtils.readFileToByteArray(new File(savedThumbPath));
                                                        uploadVideoThumbnail(bytes, null, savedThumbPath, message, null, filePath);
                                                    }
                                                } else {
                                                    Toast.makeText(mContext, getString(R.string.no_media_found), Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    } else if (message.progress.equals("completed")) {
                                        File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                        Uri fileUri = storageManager.getUriFromFile(file);
                                        if (file != null) {
                                            openUri(fileUri);
                                        } else {
                                            downloadVideo(Constants.CHAT_IMG_PATH + message.thumbnail, Constants.CHAT_IMG_PATH + message.attachment,
                                                    uploadimage, downloadicon, progresslay, progressbar);
                                        }
                                    } else if (message.progress.equalsIgnoreCase("")) {
                                        File file = storageManager.getSrcFile(TAG_VIDEO_SENT, getFileName(message.attachment), Constants.TAG_VIDEO);
                                        Uri fileUri = storageManager.getUriFromFile(file);
                                        if (fileUri != null) {
//                                            dbhelper.updateGroupMessageData(message.message_id, Constants.TAG_PROGRESS, "completed");
//                                            messagesList.get(getAbsoluteAdapterPosition()).progress = "completed";
//                                            progressbar.setVisibility(View.GONE);
//                                            progressbar.stopSpinning();
//                                            downloadicon.setImageResource(R.drawable.play);
//                                            uploadimage.performClick();
//                                            messageListAdapter.notifyDataSetChanged();
                                            openUri(fileUri);
                                        }

                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_GIF:
                        progresslay.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadimage.setVisibility(View.GONE);
                        gifImage.setVisibility(View.VISIBLE);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                        setGifImage(mContext, message.attachment, gifImage);
                        break;
                }
            }
        }

        private void downloadImage(String url, String fileName, ImageView uploadimage, RelativeLayout progresslay, ProgressWheel progressbar) {
            ImageDownloader imageDownloader = new ImageDownloader(ChatActivity.this) {
                @Override
                protected void onPostExecute(Bitmap imgBitmap) {
                    if (imgBitmap == null) {
                        Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                    } else {
                        Uri savedUri = null;
                        String savedPath = null;
                        savedPath = storageManager.saveImageInStorage(imgBitmap, fileName, StorageManager.TAG_IMAGE_SENT).getAbsolutePath();
                        if (!TextUtils.isEmpty(savedPath)) {
                            setMediaImage(mContext, null, new File(savedPath), uploadimage);
                            progresslay.setVisibility(View.GONE);
                            progressbar.stopSpinning();
                        } else {
                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                protected void onProgressUpdate(String... progress) {
                    //progressbar.setProgress(Integer.parseInt(progress[0]));
                }
            };
            imageDownloader.execute(url, Constants.TAG_IMAGE);
            progressbar.setVisibility(View.VISIBLE);
            progressbar.spin();
        }

        private void downloadVideo(String thumbUrl, String videoUrl, ImageView uploadImage, ImageView downloadIcon, RelativeLayout videoprogresslay, ProgressWheel videoprogressbar) {
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                ImageDownloader imageDownloader = new ImageDownloader(ChatActivity.this) {
                    @Override
                    protected void onPostExecute(Bitmap downloadedBitmap) {
                        if (downloadedBitmap == null) {
                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                            videoprogresslay.setVisibility(View.GONE);
                            videoprogressbar.setVisibility(View.GONE);
                            videoprogressbar.stopSpinning();
                        } else {
                            try {
                                File thumbFile = storageManager.saveImageInStorage(downloadedBitmap, getFileName(thumbUrl), TAG_THUMB);
                                if (thumbFile != null) {
                                    DownloadFiles downloadFiles = new DownloadFiles(mContext) {
                                        @Override
                                        protected void onPostExecute(String downPath) {
                                            videoprogresslay.setVisibility(View.VISIBLE);
                                            videoprogressbar.setVisibility(View.GONE);
                                            videoprogressbar.stopSpinning();
                                            downloadIcon.setImageResource(R.drawable.play);
                                            if (downPath == null) {
                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                            } else {
                                                setMediaImage(mContext, null, thumbFile, uploadImage);
                                            }
                                        }
                                    };
                                    downloadFiles.execute(videoUrl, TAG_VIDEO_SENT);
                                }
                            } catch (NullPointerException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    protected void onProgressUpdate(String... progress) {
                        // progressbar.setProgress(Integer.parseInt(progress[0]));
                    }
                };
                imageDownloader.execute(thumbUrl, StorageManager.TAG_THUMB);
                videoprogresslay.setVisibility(View.VISIBLE);
                videoprogressbar.setVisibility(View.VISIBLE);
                videoprogressbar.spin();
            } else {
                requestStoragePermissions();
            }
        }

        private void downloadFile(String fileUrl, String from, RelativeLayout progressLay, ProgressWheel progressWheel) {
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                try {
                    DownloadFiles downloadFiles = new DownloadFiles(mContext) {
                        @Override
                        protected void onPostExecute(String downPath) {
                            progressLay.setVisibility(View.GONE);
                            progressWheel.stopSpinning();
                            if (downPath == null) {
                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                            }
                        }
                    };
                    downloadFiles.execute(fileUrl, from);
                    progressLay.setVisibility(View.VISIBLE);
                    progressWheel.spin();
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            } else {
                requestStoragePermissions();
            }
        }

        private void openUri(Uri fileUri) {
            if (fileUri != null) {
                try {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    MimeTypeMap mime = MimeTypeMap.getSingleton();
                    String ext = storageManager.getExtension(fileUri);
                    String type = mime.getMimeTypeFromExtension(ext);
                    intent.setDataAndType(fileUri, type);
                    stopAudioViewHolder();
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(mContext, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(mContext, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
            }
        }

        private void setMediaImage(Context mContext, Uri imageUri, File imageFile, ImageView uploadImage) {
            Glide.with(mContext)
                    .asBitmap()
                    .load(imageUri != null ? imageUri : imageFile)
                    .error(R.drawable.chat_media_placeholder)
                    .thumbnail(0.5f)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(uploadImage);
        }

        private void setErrorImage(Context mContext, String imageUrl, ImageView uploadImage) {
            if (TextUtils.isEmpty(imageUrl)) {
                Glide.with(mContext).load(R.drawable.chat_media_placeholder).thumbnail(0.5f)
                        .into(uploadImage);
            } else {
                Glide.with(mContext).load(imageUrl).error(R.drawable.chat_media_placeholder).thumbnail(0.5f)
                        .transform(new BlurTransformation(Constants.BLUR_RADIUS))
                        .into(uploadImage);
            }
        }

        private void setGifImage(Context mContext, String attachment, ShapeableImageView gifImage) {
            Glide
                    .with(mContext)
                    .asGif()
                    .transform(new GranularRoundedCorners(20, 20, 20, 20))
                    .load(attachment)
                    .into(gifImage);
        }

        private class ReceivedImageHolder extends RecyclerView.ViewHolder {
            TextView timeText;
            ImageView uploadimage, downloadicon;
            ShapeableImageView gifImage;
            RelativeLayout progresslay, videoprogresslay;
            ProgressWheel progressbar, videoprogressbar;

            ReceivedImageHolder(View itemView) {
                super(itemView);

                uploadimage = itemView.findViewById(R.id.uploadimage);
                gifImage = itemView.findViewById(R.id.gifImage);
                progresslay = itemView.findViewById(R.id.progresslay);
                timeText = itemView.findViewById(R.id.text_message_time);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                videoprogresslay = itemView.findViewById(R.id.videoprogresslay);
                videoprogressbar = itemView.findViewById(R.id.videoprogressbar);
            }

            void bind(final MessagesData message) {
                Log.i(TAG, "ReceivedImageHolder: " + new Gson().toJson(message));
                if (selectedChatPos.contains(message)) {
                    itemView.setSelected(true);
                } else {
                    itemView.setSelected(false);
                }
                uploadimage.setVisibility(View.VISIBLE);
                gifImage.setVisibility(View.GONE);
                switch (message.message_type) {
                    case Constants.TAG_IMAGE: {
                        videoprogresslay.setVisibility(View.GONE);
                        downloadicon.setImageResource(R.drawable.download);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            Uri fileUri = storageManager.getFileUri(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                            if (fileUri != null) {
                                progresslay.setVisibility(View.GONE);
                                setMediaImage(mContext, fileUri, null, uploadimage);
                            } else {
                                loadBlurImage(message);
                            }
                        } else {
                            File file = storageManager.getSrcFile(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                            if (file != null && !TextUtils.isEmpty(file.getAbsolutePath())) {
                                progresslay.setVisibility(View.GONE);
                                setMediaImage(mContext, null, file, uploadimage);
                            } else {
                                loadBlurImage(message);
                            }
                        }

                        timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (isRecording) return;
                                ApplicationClass.preventMultiClick(view);
                                setClickEvent(false, false, false, false, false, false);
                                if (!chatLongPressed) {
                                    boolean validFile = false;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        Uri fileUri = storageManager.getFileUri(Constants.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                                        if (fileUri != null) {
                                            validFile = true;
                                            videoprogresslay.setVisibility(View.GONE);
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, fileUri, Constants.TAG_MESSAGE, imageView);
                                        }
                                    } else {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, getFileName(message.attachment), Constants.TAG_IMAGE);
                                        if (file != null) {
                                            validFile = true;
                                            videoprogresslay.setVisibility(View.GONE);
                                            stopAudioViewHolder();
                                            ApplicationClass.openImage(mContext, file.getAbsolutePath(), Constants.TAG_MESSAGE, imageView);
                                        }
                                    }
                                    if (!validFile) {
                                        if (PermissionsUtils.checkStoragePermission(mContext)) {
                                            if (isNetworkConnected().equals(NOT_CONNECT)) {
                                                networkSnack();
                                            } else {
                                                ImageDownloader imageDownloader = new ImageDownloader(ChatActivity.this) {
                                                    @Override
                                                    protected void onPostExecute(Bitmap imgBitmap) {
                                                        if (imgBitmap == null) {
                                                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                        } else {
                                                            Uri savedUri = null;
                                                            String savedPath = null;
                                                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                                savedUri = storageManager.saveImageInStorageV10(imgBitmap, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                                                            } else {
                                                                savedPath = storageManager.saveImageInStorage(imgBitmap, getFileName(message.attachment), StorageManager.TAG_IMAGE).getAbsolutePath();
                                                            }
                                                            if (savedUri != null || savedPath != null) {
                                                                setMediaImage(mContext, savedUri, savedPath != null ? new File(savedPath) : null, uploadimage);
                                                                progresslay.setVisibility(View.GONE);
                                                                progressbar.stopSpinning();
                                                                videoprogresslay.setVisibility(View.GONE);
                                                            } else {
                                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    protected void onProgressUpdate(String... progress) {
                                                        //progressbar.setProgress(Integer.parseInt(progress[0]));
                                                    }
                                                };
                                                imageDownloader.execute(Constants.CHAT_IMG_PATH + message.attachment, Constants.TAG_IMAGE);
                                                progressbar.setVisibility(View.VISIBLE);
                                                progressbar.spin();
                                            }
                                        } else {
                                            requestStoragePermissions();
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_LOCATION: {
                        progresslay.setVisibility(View.GONE);
                        videoprogresslay.setVisibility(View.GONE);
                        String mapUrl = ApplicationClass.getMapUrl(message.lat, message.lon, mContext);
                        Glide.with(mContext).load(mapUrl).thumbnail(0.5f)
                                .into(uploadimage);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (isRecording) return;
                                ApplicationClass.preventMultiClick(view);
                                if (!chatLongPressed) {
                                    stopAudioViewHolder();
                                    Intent i = new Intent(ChatActivity.this, LocationActivity.class);
                                    i.putExtra("from", "view");
                                    i.putExtra("lat", message.lat);
                                    i.putExtra("lon", message.lon);
                                    startActivity(i);
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_VIDEO: {
                        progresslay.setVisibility(View.VISIBLE);
                        progressbar.setVisibility(View.GONE);
                        downloadicon.setImageResource(R.drawable.play);
                        timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                        Uri videoUri;
                        Uri thumbUri = null;
                        File thumbFile = storageManager.getSrcFile(TAG_THUMB, getFileName(message.attachment), StorageManager.TAG_IMAGE);
                        if (thumbFile != null) {
                            thumbUri = storageManager.getUriFromFile(thumbFile);
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            videoUri = storageManager.getFileUri(TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                        } else {
                            File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                            videoUri = storageManager.getUriFromFile(file);
                        }
                        if (videoUri != null) {
                            if (thumbUri != null) {
                                setMediaImage(mContext, thumbUri, null, uploadimage);
                                videoprogresslay.setVisibility(View.GONE);
                            } else {
                                setMediaImage(mContext, videoUri, null, uploadimage);
                                videoprogresslay.setVisibility(View.GONE);
                            }
                        } else {
                            setErrorImage(mContext, Constants.CHAT_IMG_PATH + message.thumbnail, uploadimage);
                            videoprogresslay.setVisibility(View.VISIBLE);
                            videoprogressbar.setVisibility(View.VISIBLE);
                            videoprogressbar.stopSpinning();
                        }

                        uploadimage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setClickEvent(false, false, false, false, false, false);
                                ApplicationClass.preventMultiClick(view);
                                if (!chatLongPressed && !isRecording) {
                                    Uri videoUri;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        videoUri = storageManager.getFileUri(TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                                    } else {
                                        File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, getFileName(message.attachment), StorageManager.TAG_VIDEO);
                                        videoUri = storageManager.getUriFromFile(file);
                                    }
                                    if (videoUri != null) {
                                        stopAudioViewHolder();
                                        try {
                                            Intent intent = new Intent();
                                            intent.setAction(Intent.ACTION_VIEW);
                                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                            MimeTypeMap mime = MimeTypeMap.getSingleton();
                                            String ext = storageManager.getExtension(videoUri);
                                            String type = mime.getMimeTypeFromExtension(ext);
                                            intent.setDataAndType(videoUri, type);
                                            startActivity(intent);
                                        } catch (ActivityNotFoundException e) {
                                            Toast.makeText(ChatActivity.this, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                            e.printStackTrace();
                                        }
                                    } else {
                                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                                            networkSnack();
                                        } else {
                                            if (PermissionsUtils.checkStoragePermission(mContext)) {
                                                ImageDownloader imageDownloader = new ImageDownloader(ChatActivity.this) {
                                                    @Override
                                                    protected void onPostExecute(Bitmap downloadedBitmap) {
                                                        if (downloadedBitmap == null) {
                                                            Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                            videoprogresslay.setVisibility(View.GONE);
                                                            videoprogressbar.setVisibility(View.GONE);
                                                            videoprogressbar.stopSpinning();
                                                        } else {
                                                            try {
                                                                File thumbFile = storageManager.saveImageInStorage(downloadedBitmap, getFileName(message.thumbnail), TAG_THUMB);
                                                                if (thumbFile != null) {
                                                                    DownloadFilesTask downloadFilesTask = new DownloadFilesTask(mContext) {
                                                                        @Override
                                                                        protected void onPostExecute(String downPath) {
                                                                            videoprogresslay.setVisibility(View.GONE);
                                                                            videoprogressbar.setVisibility(View.GONE);
                                                                            videoprogressbar.stopSpinning();
                                                                            if (downPath == null) {
                                                                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                                            } else {
                                                                                setMediaImage(mContext, null, thumbFile, uploadimage);
                                                                            }
                                                                        }
                                                                    };
                                                                    downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.message_type);
                                                                }
                                                            } catch (NullPointerException e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    protected void onProgressUpdate(String... progress) {
                                                        // progressbar.setProgress(Integer.parseInt(progress[0]));
                                                    }
                                                };
                                                imageDownloader.execute(Constants.CHAT_IMG_PATH + message.thumbnail, StorageManager.TAG_THUMB);
                                                videoprogresslay.setVisibility(View.VISIBLE);
                                                videoprogressbar.setVisibility(View.VISIBLE);
                                                videoprogressbar.spin();
                                            } else {
                                                requestStoragePermissions();
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                    break;
                    case Constants.TAG_GIF: {
                        progresslay.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadimage.setVisibility(View.GONE);
                        videoprogresslay.setVisibility(View.GONE);
                        gifImage.setVisibility(View.VISIBLE);
                        setGifImage(mContext, message.attachment, gifImage);
                    }
                    break;
                }
            }

            private void loadBlurImage(MessagesData message) {
                progresslay.setVisibility(View.VISIBLE);
                progressbar.setVisibility(View.VISIBLE);
                progressbar.stopSpinning();
                Glide.with(mContext).load(Constants.CHAT_IMG_PATH + message.attachment).thumbnail(0.5f)
                        .transform(new BlurTransformation(Constants.BLUR_RADIUS))
                        .into(uploadimage);
            }
        }

        private class SentFileHolder extends RecyclerView.ViewHolder {
            TextView filename, timeText, file_type_tv;
            ImageView tickimage, icon, uploadicon;
            RelativeLayout file_body_lay, progressLay;
            ProgressWheel progressbar;

            SentFileHolder(View itemView) {
                super(itemView);

                file_body_lay = itemView.findViewById(R.id.file_body_lay);
                progressLay = itemView.findViewById(R.id.progressLay);
                filename = itemView.findViewById(R.id.filename);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                icon = itemView.findViewById(R.id.icon);
                progressbar = itemView.findViewById(R.id.progressbar);
                uploadicon = itemView.findViewById(R.id.uploadicon);
                file_type_tv = itemView.findViewById(R.id.file_type_tv);
            }

            void bind(final MessagesData message) {
                Log.d(TAG, "SentFileHolder: " + new Gson().toJson(message));
                itemView.setSelected(selectedChatPos.contains(message));
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                if (message.delivery_status.equals("read")) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.double_tick);
                } else if (message.delivery_status.equals("sent")) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.double_tick_unseen);
                } else if (message.progress.equals("completed")) {
                    tickimage.setVisibility(View.VISIBLE);
                    tickimage.setImageResource(R.drawable.single_tick);
                } else {
                    tickimage.setVisibility(View.GONE);
                }

                if (message.message_type.equals(TAG_DOCUMENT)) {
                    icon.setImageResource(R.drawable.icon_file_unknown);
                    file_type_tv.setVisibility(View.VISIBLE);
                    file_type_tv.setText(firstThree(FilenameUtils.getExtension(message.attachment)));
                } else if (message.message_type.equals(StorageManager.TAG_AUDIO)) {
                    icon.setImageResource(R.drawable.mp3);
                    file_type_tv.setVisibility(View.GONE);
                }

                uploadicon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.upload));
                switch (message.progress) {
                    case "":
                        progressLay.setVisibility(View.VISIBLE);
                        progressbar.spin();
                        filename.setText(R.string.uploading);
                        break;
                    case "completed":
                        progressLay.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        filename.setText(message.message);
                        File tempFile = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT_SENT, getFileName(message.attachment), StorageManager.TAG_DOCUMENT);
                        if (tempFile == null || !tempFile.exists()) {
                            uploadicon.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.download));
                            progressLay.setVisibility(View.VISIBLE);
                            progressbar.setVisibility(View.VISIBLE);
                            progressbar.stopSpinning();
                        }
                        break;
                    case "error":
                        progressLay.setVisibility(View.VISIBLE);
                        progressbar.stopSpinning();
                        filename.setText(R.string.retry);
                        break;
                }

                file_body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ApplicationClass.preventMultiClick(view);
                        if (!chatLongPressed && !isRecording) {
                            if (message.progress.equals("error")) {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    try {
                                        progressLay.setVisibility(View.VISIBLE);
                                        progressbar.spin();
                                        filename.setText(getString(R.string.uploading));
                                        dbHelper.updateMessageData(message.message_id, Constants.TAG_PROGRESS, "");
                                        message.progress = "";
                                        File savedFile = storageManager.getSrcFile(TAG_DOCUMENT_SENT, getFileName(message.attachment), TAG_DOCUMENT);
                                        String savedPath = savedFile.getAbsolutePath();
                                        if (!TextUtils.isEmpty(savedPath)) {
                                            Intent service = new Intent(mContext, FileUploadService.class);
                                            Bundle b = new Bundle();
                                            b.putSerializable("mdata", message);
                                            b.putString("filepath", savedPath);
                                            b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                                            b.putString("chatType", "chat");
                                            service.putExtras(b);
                                            startService(service);
                                        } else {
                                            Toast.makeText(mContext, mContext.getString(R.string.no_media_found), Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }
                            } else if (message.progress.equals("completed")) {
                                File savedFile = storageManager.getSrcFile(TAG_DOCUMENT_SENT, getFileName(message.attachment), TAG_DOCUMENT);
                                Uri fileUri = storageManager.getUriFromFile(savedFile);
                                if (fileUri != null) {
                                    stopAudioViewHolder();
                                    try {
                                        Intent intent = new Intent();
                                        intent.setAction(Intent.ACTION_VIEW);
                                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                        intent.setDataAndType(fileUri, storageManager.getMimeTypeOfUri(mContext, fileUri));
                                        startActivity(intent);
                                    } catch (ActivityNotFoundException e) {
                                        Toast.makeText(mContext, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                        e.printStackTrace();
                                    }
                                } else {
                                    downloadFile(Constants.CHAT_IMG_PATH + message.attachment,
                                            TAG_DOCUMENT_SENT, progressLay, progressbar);
                                }
                            }
                        }
                    }
                });
            }
        }

        private class ReceivedFileHolder extends RecyclerView.ViewHolder {
            TextView filename, timeText, file_type_tv;
            ImageView icon, downloadicon;
            RelativeLayout file_body_lay;
            ProgressWheel progressbar;

            ReceivedFileHolder(View itemView) {
                super(itemView);

                filename = itemView.findViewById(R.id.filename);
                timeText = itemView.findViewById(R.id.text_message_time);
                icon = itemView.findViewById(R.id.icon);
                file_body_lay = itemView.findViewById(R.id.file_body_lay);
                downloadicon = itemView.findViewById(R.id.downloadicon);
                progressbar = itemView.findViewById(R.id.progressbar);
                file_type_tv = itemView.findViewById(R.id.file_type_tv);
            }

            void bind(final MessagesData message) {
                Log.d(TAG, "ReceivedFileHolder: " + new Gson().toJson(message));
                filename.setText(message.message);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                itemView.setSelected(selectedChatPos.contains(message));
                if (message.message_type.equals(TAG_DOCUMENT)) {
                    icon.setImageResource(R.drawable.icon_file_unknown);
                    file_type_tv.setVisibility(View.VISIBLE);
                    file_type_tv.setText(firstThree(FilenameUtils.getExtension(message.attachment)));
                } else if (message.message_type.equals(TAG_AUDIO)) {
                    file_type_tv.setVisibility(View.GONE);
                    icon.setImageResource(R.drawable.mp3);
                }

                Uri documentUri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    documentUri = storageManager.getFileUri(TAG_DOCUMENT, getFileName(message.attachment), TAG_DOCUMENT);
                } else {
                    File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, getFileName(message.attachment), StorageManager.TAG_DOCUMENT);
                    documentUri = storageManager.getUriFromFile(file);
                }

                if (documentUri != null) {
                    downloadicon.setVisibility(View.GONE);
                    progressbar.setVisibility(View.GONE);
                } else {
                    downloadicon.setVisibility(View.VISIBLE);
                    progressbar.setVisibility(View.VISIBLE);
                    progressbar.stopSpinning();
                }

                file_body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setClickEvent(false, false, false, false, false, false);
                        if (!chatLongPressed && !isRecording) {
                            Uri documentUri;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                documentUri = storageManager.getFileUri(TAG_DOCUMENT, getFileName(message.attachment), TAG_DOCUMENT);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_DOCUMENT, getFileName(message.attachment), StorageManager.TAG_DOCUMENT);
                                documentUri = storageManager.getUriFromFile(file);
                            }
                            if (documentUri != null) {
                                try {
                                    stopAudioViewHolder();
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_VIEW);
                                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                    String mimeType = storageManager.getMimeTypeOfUri(mContext, documentUri);
                                    intent.setDataAndType(documentUri, mimeType);
                                    startActivity(intent);
                                } catch (ActivityNotFoundException e) {
                                    Toast.makeText(mContext, getString(R.string.no_application), Toast.LENGTH_SHORT).show();
                                    e.printStackTrace();
                                }
                            } else {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                                        DownloadFilesTask downloadFilesTask = new DownloadFilesTask(mContext) {
                                            @Override
                                            protected void onPostExecute(String downPath) {
                                                progressbar.setVisibility(View.GONE);
                                                progressbar.stopSpinning();
                                                downloadicon.setVisibility(View.GONE);
                                                if (downPath == null) {
                                                    Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                                } else {
                                                    //Toast.makeText(mContext, getString(R.string.downloaded), Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        };
                                        downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.message_type);
                                        progressbar.setVisibility(View.VISIBLE);
                                        progressbar.spin();
                                        downloadicon.setVisibility(View.VISIBLE);
                                    } else {
                                        requestStoragePermissions();
                                    }
                                }
                            }
                        }
                    }
                });
            }
        }

        private class SentContactHolder extends RecyclerView.ViewHolder {
            TextView username, phoneno, timeText;
            ImageView tickimage;

            SentContactHolder(View itemView) {
                super(itemView);
                username = itemView.findViewById(R.id.username);
                phoneno = itemView.findViewById(R.id.phoneno);
                tickimage = itemView.findViewById(R.id.tickimage);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(MessagesData message) {
                username.setText(message.contact_name);
                phoneno.setText(message.contact_phone_no);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                itemView.setSelected(selectedChatPos.contains(message));

                switch (message.delivery_status) {
                    case "read":
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.double_tick);
                        break;
                    case "sent":
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.double_tick_unseen);
                        break;
                    default:
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.single_tick);
                        break;
                }
            }
        }

        private class ReceivedContactHolder extends RecyclerView.ViewHolder {
            TextView username, phoneno, timeText, addcontact;

            ReceivedContactHolder(View itemView) {
                super(itemView);
                username = itemView.findViewById(R.id.username);
                phoneno = itemView.findViewById(R.id.phoneno);
                timeText = itemView.findViewById(R.id.text_message_time);
                addcontact = itemView.findViewById(R.id.addcontact);
            }

            void bind(final MessagesData message) {
                username.setText(message.contact_name);
                phoneno.setText(message.contact_phone_no);
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
                itemView.setSelected(selectedChatPos.contains(message));
                addcontact.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!chatLongPressed && !isRecording) {
                            stopAudioViewHolder();
                            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                            intent.putExtra(ContactsContract.Intents.Insert.PHONE, message.contact_phone_no); //  message.contact_phone_no
                            intent.putExtra(ContactsContract.Intents.Insert.NAME, message.contact_name);
                            startActivity(intent);
                        }
                    }
                });
            }
        }

        private class DateHolder extends RecyclerView.ViewHolder {
            TextView timeText;

            DateHolder(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(final MessagesData message) {
                timeText.setText(message.message);
            }
        }

        private class DeleteMsgSent extends RecyclerView.ViewHolder {
            TextView timeText;

            DeleteMsgSent(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(final MessagesData message) {
                itemView.setSelected(selectedChatPos.contains(message));
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
            }
        }

        private class DeleteMsgReceived extends RecyclerView.ViewHolder {
            TextView timeText;

            DeleteMsgReceived(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
            }

            void bind(final MessagesData message) {
                itemView.setSelected(selectedChatPos.contains(message));
                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));
            }
        }

        private class SentVoiceHolder extends RecyclerView.ViewHolder {

            RelativeLayout downloadLay;
            ImageView icon, tickimage, uploadicon;
            TextView duration, msg_time, filename;
            SeekBar seekbar;
            ConstraintLayout body_lay;
            ProgressWheel progressbar;
            Context context;

            SentVoiceHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                downloadLay = itemView.findViewById(R.id.downloadLay);
                icon = itemView.findViewById(R.id.icon);
                tickimage = itemView.findViewById(R.id.tickimage);
                duration = itemView.findViewById(R.id.duration);
                msg_time = itemView.findViewById(R.id.text_message_time);
                body_lay = itemView.findViewById(R.id.body_lay);
                progressbar = itemView.findViewById(R.id.progressbar);
                uploadicon = itemView.findViewById(R.id.uploadicon);
                filename = itemView.findViewById(R.id.filename);
                seekbar = itemView.findViewById(R.id.song_seekbar);

            }

            void bind(final MessagesData message, int position) {
//                Log.i(TAG, "SentVoiceHolder: " + new Gson().toJson(message));
                /*Check message id equals to already playing message id*/
                if (currentMessageId != null && currentMessageId.equals(message.message_id)) {
                    if (MediaPlayerUtils.isPlaying()) {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.play_icon_white));
                        seekbar.setMax(MediaPlayerUtils.getTotalDuration());
                        seekbar.setProgress(MediaPlayerUtils.getCurrentDuration());
                    } else {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        if (file != null) {
                            long totalDuration = storageManager.getMediaDuration(file);
                            duration.setText(milliSecondsToTimer(totalDuration));
                        }
                    }
                    seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            if (fromUser && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                MediaPlayerUtils.applySeekBarValue(progress);
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                            }
                        }
                    });
                } else {
                    icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                    seekbar.setProgress(0);
                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                    if (file != null) {
                        long totalDuration = storageManager.getMediaDuration(file);
                        seekbar.setMax((int) totalDuration);
                        duration.setText(milliSecondsToTimer(totalDuration));
                        duration.setVisibility(View.VISIBLE);
                        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                            @Override
                            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                if (fromUser && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                    MediaPlayerUtils.applySeekBarValue(progress);
                                }
                            }

                            @Override
                            public void onStartTrackingTouch(SeekBar seekBar) {

                            }

                            @Override
                            public void onStopTrackingTouch(SeekBar seekBar) {
                                if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                }
                            }
                        });
                    } else {
                        seekbar.setMax(0);
                        duration.setVisibility(View.GONE);
                    }
                }
                msg_time.setText(dateUtils.getTimeFromUTC(message.chat_time));

                itemView.setSelected(selectedChatPos.contains(message));
                uploadicon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.upload));

                switch (message.progress) {
                    case "":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.spin();
                        uploadicon.setVisibility(View.VISIBLE);
                        seekbar.setVisibility(View.INVISIBLE);
                        filename.setText(R.string.uploading);
                        filename.setVisibility(View.VISIBLE);
                        break;
                    case "completed":
                        progressbar.setVisibility(View.GONE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.GONE);
                        seekbar.setVisibility(View.VISIBLE);
                        icon.setVisibility(View.VISIBLE);
                        filename.setVisibility(View.GONE);
                        duration.setVisibility(View.VISIBLE);
                        File tempFile = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName((message.attachment)), TAG_AUDIO);
                        if (tempFile == null || !tempFile.exists()) {
                            progressbar.setVisibility(View.VISIBLE);
                            progressbar.stopSpinning();
                            uploadicon.setVisibility(View.VISIBLE);
                            uploadicon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.download));
                        }
                        break;
                    case "error":
                        progressbar.setVisibility(View.VISIBLE);
                        progressbar.stopSpinning();
                        uploadicon.setVisibility(View.VISIBLE);
                        seekbar.setVisibility(View.INVISIBLE);
                        icon.setVisibility(View.GONE);
                        filename.setText(R.string.retry);
                        filename.setVisibility(View.VISIBLE);
                        break;
                }

                if (message.delivery_status != null) {
                    switch (message.delivery_status) {
                        case "read":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick);
                            break;
                        case "sent":
                            tickimage.setVisibility(View.VISIBLE);
                            tickimage.setImageResource(R.drawable.double_tick_unseen);
                            break;
                        default:
                            if (message.progress.equals("") || message.progress.equals("error")) {
                                tickimage.setVisibility(View.GONE);
                            } else {
                                tickimage.setVisibility(View.VISIBLE);
                            }
                            tickimage.setImageResource(R.drawable.single_tick);
                            break;
                    }
                }

                body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ApplicationClass.preventMultiClick(view);
                        if (!chatLongPressed && !isRecording) {
                            if (message.progress.equals("error")) {
                                if (isNetworkConnected().equals(NOT_CONNECT)) {
                                    networkSnack();
                                } else {
                                    progressbar.setVisibility(View.VISIBLE);
                                    progressbar.spin();
                                    uploadicon.setVisibility(View.VISIBLE);
                                    duration.setVisibility(View.VISIBLE);
                                    filename.setText(getString(R.string.uploading));
                                    dbHelper.updateMessageData(message.message_id, Constants.TAG_PROGRESS, "");
                                    message.progress = "";
                                    String savedPath = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName((message.attachment)), TAG_AUDIO).getAbsolutePath();
                                    if (!TextUtils.isEmpty(savedPath)) {
                                        Intent service = new Intent(mContext, FileUploadService.class);
                                        Bundle b = new Bundle();
                                        b.putSerializable("mdata", message);
                                        b.putString("filepath", savedPath);
                                        b.putBoolean(Constants.TAG_BLOCKED_ME, results.blockedme.equals("block"));
                                        b.putString("chatType", "chat");
                                        service.putExtras(b);
                                        startService(service);
                                    }
                                }
                            }
                        }

                    }
                });

                icon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!chatLongPressed && !isRecording) {
                            File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO_SENT, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            Uri voiceURI = storageManager.getUriFromFile(file);
                            if (file != null) {
                                duration.setVisibility(View.VISIBLE);
                                if (currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                    if (MediaPlayerUtils.isPlaying()) {
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                        MediaPlayerUtils.pauseMediaPlayer();
                                    } else {
                                        seekbar.setMax(storageManager.getMediaDuration(file));
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                        startPlayer(voiceURI, seekbar.getProgress(), context);
                                    }
                                } else {
                                    stopAudioViewHolder();
                                    currentMessageId = message.message_id;
                                    seekbar.setMax(storageManager.getMediaDuration(file));
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                    startPlayer(voiceURI, seekbar.getProgress(), context);
                                }
                            } else {
                                downloadFile(Constants.CHAT_IMG_PATH + message.attachment,
                                        TAG_AUDIO_SENT, downloadLay, progressbar);
//                                Toast.makeText(context, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });

                seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if (fromUser && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                            MediaPlayerUtils.applySeekBarValue(progress);
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                        }
                    }
                });

            }
        }

        private class ReceiveVoiceHolder extends RecyclerView.ViewHolder {

            ImageView icon, tickimage, downloadIcon;
            TextView duration, msg_time, file_name;
            SeekBar seekbar;
            ConstraintLayout body_lay;
            ProgressWheel progressbar;
            Context context;

            ReceiveVoiceHolder(View itemView) {
                super(itemView);
                context = itemView.getContext();
                icon = itemView.findViewById(R.id.icon);
                duration = itemView.findViewById(R.id.duration);
                msg_time = itemView.findViewById(R.id.text_message_time);
                seekbar = itemView.findViewById(R.id.song_seekbar);
                progressbar = itemView.findViewById(R.id.progressbar);
                downloadIcon = itemView.findViewById(R.id.downloadicon);
                file_name = itemView.findViewById(R.id.filename);
                body_lay = itemView.findViewById(R.id.body_lay);
            }

            void bind(final MessagesData message, int position) {
                Log.i(TAG, "ReceiveVoiceHolder: " + new Gson().toJson(message));
                /*Check message id equals to already playing message id*/
                if (currentMessageId != null && currentMessageId.equals(message.message_id)) {
                    if (MediaPlayerUtils.isPlaying()) {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.play_icon_white));
                        seekbar.setMax(MediaPlayerUtils.getTotalDuration());
                        seekbar.setProgress(MediaPlayerUtils.getCurrentDuration());
                    } else {
                        icon.setImageDrawable(context.getResources().getDrawable(R.drawable.pause_icon_white));
                        Uri voiceURI = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        } else {
                            File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            voiceURI = storageManager.getUriFromFile(file);
                        }
                        if (voiceURI != null) {
                            setAudioUri(message, voiceURI);
                        }
                    }
                    seekbar.setEnabled(true);
                    seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            if (fromUser && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                MediaPlayerUtils.applySeekBarValue(progress);
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                            }
                        }
                    });
                } else {
                    icon.setImageResource(R.drawable.pause_icon_white);
                    seekbar.getProgressDrawable().setColorFilter(ContextCompat.getColor(context, R.color.white), PorterDuff.Mode.MULTIPLY);
                    Uri voiceURI = null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                    } else {
                        File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                        voiceURI = storageManager.getUriFromFile(file);
                    }
                    if (voiceURI != null) {
                        setAudioUri(message, voiceURI);
                    } else {
                        setError();
                    }
                    seekbar.setProgress(0);
                }
                msg_time.setText(dateUtils.getTimeFromUTC(message.chat_time));

                itemView.setSelected(selectedChatPos.contains(message));

                body_lay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setClickEvent(false, false, false, false, false, false);
                        if (!chatLongPressed && !isRecording) {
                            Uri voiceURI = null;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                                voiceURI = storageManager.getUriFromFile(file);
                            }
                            if (voiceURI != null) {
                                body_lay.setEnabled(false);
                            } else {
                                downloadFile(message);
                            }
                        }
                    }
                });

                icon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!chatLongPressed && !isRecording) {
                            Uri voiceURI = null;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                voiceURI = storageManager.getFileUri(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                            } else {
                                File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(message.attachment), StorageManager.TAG_AUDIO);
                                voiceURI = storageManager.getUriFromFile(file);
                            }
                            if (voiceURI != null) {
                                duration.setVisibility(View.VISIBLE);
                                if (currentMessageId != null && currentMessageId.equals(message.message_id)) {
                                    if (MediaPlayerUtils.isPlaying()) {
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                                        MediaPlayerUtils.pauseMediaPlayer();
                                    } else {
                                        seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                        icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                        startPlayer(voiceURI, seekbar.getProgress(), context);
                                    }
                                } else {
                                    stopAudioViewHolder();
                                    currentMessageId = message.message_id;
                                    seekbar.setMax(storageManager.getMediaDuration(context, voiceURI));
                                    icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                                    startPlayer(voiceURI, seekbar.getProgress(), context);
                                }
                            } else {
                                Toast.makeText(context, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
            }

            private void downloadFile(MessagesData message) {
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else if (PermissionsUtils.checkStoragePermission(mContext)) {
                    DownloadFilesTask downloadFilesTask = new DownloadFilesTask(ChatActivity.this) {
                        @Override
                        protected void onPostExecute(String downPath) {
                            if (TextUtils.isEmpty(downPath)) {
                                Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                            } else {
                                Uri voiceURI = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    voiceURI = Uri.parse(downPath);
                                } else {
                                    File file = storageManager.getSrcFile(StorageManager.TAG_AUDIO, getFileName(downPath), StorageManager.TAG_AUDIO);
                                    voiceURI = storageManager.getUriFromFile(file);
                                }
                                if (voiceURI != null) {
                                    setAudioUri(message, voiceURI);
                                }
                                //Toast.makeText(mContext, getString(R.string.downloaded), Toast.LENGTH_SHORT).show();
                            }
                        }
                    };
                    downloadFilesTask.execute(Constants.CHAT_IMG_PATH + message.attachment, message.message_type);
                    progressbar.setVisibility(View.VISIBLE);
                    progressbar.spin();
                    downloadIcon.setVisibility(View.VISIBLE);
                    icon.setEnabled(true);
                    duration.setEnabled(true);
                    seekbar.setEnabled(true);
                } else {
                    requestStoragePermissions();
                }
            }

            private void setAudioUri(MessagesData message, Uri voiceURI) {
                downloadIcon.setVisibility(View.GONE);
                progressbar.setVisibility(View.GONE);
                duration.setVisibility(View.VISIBLE);
                long totalDuration = storageManager.getAudioDuration(context, voiceURI, TAG_AUDIO);
                duration.setText(milliSecondsToTimer(totalDuration));
                seekbar.setProgress(0);
                seekbar.setMax((int) totalDuration);
                icon.setEnabled(true);
                seekbar.setEnabled(true);
                seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if (fromUser && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pause_icon_white));
                            MediaPlayerUtils.applySeekBarValue(progress);
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        if (MediaPlayerUtils.isPlaying() && currentMessageId != null && currentMessageId.equals(message.message_id)) {
                            icon.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.play_icon_white));
                        }
                    }
                });
            }

            public void setError() {
                downloadIcon.setVisibility(View.VISIBLE);
                progressbar.setVisibility(View.VISIBLE);
                duration.setVisibility(View.INVISIBLE);
                icon.setEnabled(false);
                seekbar.setEnabled(false);
                progressbar.stopSpinning();
            }
        }

        private void startPlayer(Uri voiceURI, int progress, Context context) {
            try {
                ApplicationClass.pauseExternalAudio(mContext);
                MediaPlayerUtils.startAndPlayMediaPlayer(context, voiceURI, ChatActivity.this, progress);
            } catch (IOException e) {
                Log.e(TAG, "startPlayer: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private String milliSecondsToTimer(long milliseconds) {
            String finalTimerString = "";
            String secondsString = "";

            // Convert total duration into time
            int hours = (int) (milliseconds / (1000 * 60 * 60));
            int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
            int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
            // Add hours if there
            if (hours > 0) {
                finalTimerString = hours + ":";
            }

            // Prepending 0 to seconds if it is one digit
            if (seconds < 10) {
                secondsString = "0" + seconds;
            } else {
                secondsString = "" + seconds;
            }

            finalTimerString = finalTimerString + minutes + ":" + secondsString;

            // return timer string
            return finalTimerString;
        }

        private class SentStatusViewHolder extends RecyclerView.ViewHolder {

            TextView timeText, statusName, statusTypeName, textMessageBody;
            ImageView tickimage, statusTypeImage;
            RoundedImageView statusImage;
            RelativeLayout parentLay;

            SentStatusViewHolder(View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
                tickimage = itemView.findViewById(R.id.tickimage);
                statusImage = itemView.findViewById(R.id.statusImage);
                statusName = itemView.findViewById(R.id.statusName);
                statusTypeImage = itemView.findViewById(R.id.statusTypeImage);
                statusTypeName = itemView.findViewById(R.id.statusTypeName);
                textMessageBody = itemView.findViewById(R.id.text_message_body);
                parentLay = itemView.findViewById(R.id.parentLay);


            }

            void bind(MessagesData message) {
                Log.i(TAG, "SentStatusViewHolder: " + new Gson().toJson(message));
                itemView.setSelected(selectedChatPos.contains(message));

                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));

                switch (message.delivery_status) {
                    case "read":
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.double_tick);
                        break;
                    case "sent":
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.double_tick_unseen);
                        break;
                    default:
                        tickimage.setVisibility(View.VISIBLE);
                        tickimage.setImageResource(R.drawable.single_tick);
                        break;
                }

                results = dbHelper.getContactDetail(userId);
                statusName.setText(results.user_name + " . " + getString(R.string.status));
                textMessageBody.setText(message.message + Html.fromHtml(
                        " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;"));
                Linkify.addLinks(textMessageBody, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);
                StatusDatas.Status data = getStatusData(message.statusData);

                if (data != null) {
                    if (data.storyType.equals(Constants.TAG_VIDEO)) {
                        statusTypeImage.setImageResource(R.drawable.video);
                        statusTypeName.setText(R.string.video);
                        setStatusThumb(data.mThumbnail, statusImage, TAG_THUMB);
                    } else {
                        statusTypeImage.setImageResource(R.drawable.camera_status);
                        statusTypeName.setText(R.string.image);
                        setStatusThumb(data.attachment, statusImage, StorageManager.TAG_SENT);
                    }
                }

                statusImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (isRecording) return;
                        ApplicationClass.preventMultiClick(view);
                        if (!chatLongPressed && data != null && data.storyId != null &&
                                !TextUtils.isEmpty(data.storyId) && dbHelper.isStoryExists(data.storyId)) {
                            stopAudioViewHolder();
                            StatusDatas datas = dbHelper.getSingleStatus(data.storyId);
                            Intent intent = new Intent(mContext, SingleStoryActivity.class);
                            intent.putExtra(Constants.TAG_DATA, datas);
                            startActivity(intent);
                        } else {
                            makeToast(getString(R.string.no_media_found));
                        }
                    }
                });

            }
        }

        private class ReceivedStatusViewHolder extends RecyclerView.ViewHolder {

            TextView timeText, statusName, statusTypeName, textMessageBody;
            ImageView statusTypeImage;
            RoundedImageView statusImage;
            RelativeLayout parentLay;

            ReceivedStatusViewHolder(@NonNull View itemView) {
                super(itemView);
                timeText = itemView.findViewById(R.id.text_message_time);
                statusImage = itemView.findViewById(R.id.statusImage);
                statusName = itemView.findViewById(R.id.statusName);
                statusTypeImage = itemView.findViewById(R.id.statusTypeImage);
                statusTypeName = itemView.findViewById(R.id.statusTypeName);
                textMessageBody = itemView.findViewById(R.id.text_message_body);
                parentLay = itemView.findViewById(R.id.parentLay);
            }

            void bind(MessagesData message) {
                Log.i(TAG, "ReceivedStatusViewHolder: " + new Gson().toJson(message));
                itemView.setSelected(selectedChatPos.contains(message));

                timeText.setText(dateUtils.getTimeFromUTC(message.chat_time));

                statusName.setText(getString(R.string.you) + " . " + getString(R.string.status));

                StatusDatas.Status data = getStatusData(message.statusData);

                textMessageBody.setText(message.message + Html.fromHtml(
                        " &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;"));
                Linkify.addLinks(textMessageBody, Linkify.EMAIL_ADDRESSES | Linkify.PHONE_NUMBERS | Linkify.WEB_URLS);

                if (data != null) {
                    if (data.storyType.equals(Constants.TAG_VIDEO)) {
                        statusTypeImage.setImageResource(R.drawable.video);
                        statusTypeName.setText(R.string.video);
                        setStatusThumb(data.mThumbnail, statusImage, StorageManager.TAG_THUMB);
                    } else {
                        statusTypeImage.setImageResource(R.drawable.camera_status);
                        setStatusThumb(data.attachment, statusImage, StorageManager.TAG_SENT);
                        statusTypeName.setText(R.string.image);
                    }
                }

                statusImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (isRecording) return;
                        ApplicationClass.preventMultiClick(view);
                        if (!chatLongPressed && data != null && data.storyId != null && dbHelper.isStoryExists(data.storyId)) {
                            stopAudioViewHolder();
                            StatusDatas datas = dbHelper.getSingleStatus(data.storyId);
                            Intent intent;
                            intent = new Intent(ChatActivity.this, SingleStoryActivity.class);
                            intent.putExtra(Constants.TAG_DATA, datas);
                            startActivity(intent);
                        } else {
                            makeToast(getString(R.string.no_media_found));
                        }
                    }
                });

            }
        }

        private StatusDatas.Status getStatusData(String data) {
            StatusDatas.Status model = null;
            try {
                if (data != null && !TextUtils.isEmpty(data)) {
                    Log.i(TAG, "getStatusData: " + data);
                    JSONObject object = new JSONObject(data);
                    model = new StatusDatas().new Status();
                    model.storyType = checkJSONobject(object, "story_type");
                    model.message = checkJSONobject(object, "message");
                    model.storyId = checkJSONobject(object, "story_id");
                    model.attachment = checkJSONobject(object, "attachment");
                    model.mThumbnail = checkJSONobject(object, "thumbnail");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return model;
        }

        private void setStatusThumb(final String fileName, final ImageView image, String from) {
            if (!TextUtils.isEmpty(fileName)) {
                File file = storageManager.getStatusFile(fileName, from);
                if (file != null) {
                    Glide.with(mContext).load(Uri.fromFile(file)).thumbnail(0.5f)
                            .transition(new DrawableTransitionOptions().crossFade())
                            .into(image);
                } else {
                    if (!ChatActivity.this.isDestroyed()) {
                        Glide.with(mContext).load(new ColorDrawable(ContextCompat.getColor(mContext, R.color.secondarybg))).thumbnail(0.5f)
                                .transition(new DrawableTransitionOptions().crossFade())
                                .into(image);
                    }
                    ImageDownloader imageDownloader = new ImageDownloader(mContext) {
                        @Override
                        protected void onPostExecute(Bitmap imgBitmap) {
                            if (imgBitmap == null) {
                            } else {
                                try {
                                    File thumbFile = storageManager.saveStatusFile(imgBitmap, null, fileName, from);
                                    Glide.with(mContext).load(Uri.fromFile(thumbFile)).thumbnail(0.5f)
                                            .into(image);
                                } catch (NullPointerException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        protected void onProgressUpdate(String... progress) {
                            //progressbar.setProgress(Integer.parseInt(progress[0]));
                        }
                    };
                    imageDownloader.execute(Constants.CHAT_IMG_PATH + fileName, StorageManager.TAG_THUMB);
                }
            } else {
                if (!ChatActivity.this.isDestroyed()) {
                    Glide.with(mContext).load(new ColorDrawable(ContextCompat.getColor(mContext, R.color.secondarybg))).thumbnail(0.5f)
                            .transition(new DrawableTransitionOptions().crossFade())
                            .into(image);
                }
            }
        }

        private class LoadingMoreHolder extends RecyclerView.ViewHolder {
            ConstraintLayout parentLay;
            ProgressBar progressBar;

            LoadingMoreHolder(View itemView) {
                super(itemView);
                parentLay = itemView.findViewById(R.id.parentLay);
                progressBar = itemView.findViewById(R.id.progressBar);
            }

            void bind(final MessagesData message) {
                parentLay.setVisibility(View.VISIBLE);
                progressBar.setIndeterminate(true);

            }
        }
    }


}
