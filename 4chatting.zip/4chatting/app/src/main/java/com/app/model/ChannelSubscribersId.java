package com.app.model;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class ChannelSubscribersId{

	@SerializedName("subscribers")
	private List<String> subscribers;

	@SerializedName("status")
	private String status;

	@SerializedName("message")
	private String message;

	public List<String> getSubscribers(){
		return subscribers;
	}

	public String getStatus(){
		return status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}