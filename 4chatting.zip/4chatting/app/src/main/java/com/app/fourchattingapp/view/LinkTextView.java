package com.app.fourchattingapp.view;

import android.content.Context;
import android.os.Handler;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.util.Pair;

import java.util.ArrayList;


@SuppressWarnings("LogNotTimber")
public class LinkTextView extends AppCompatTextView {
    public static final String TAG = LinkTextView.class.getSimpleName();

    public LinkTextView(Context context) {
        super(context);
    }

    public LinkTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public LinkTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void makeLinks(@NonNull ArrayList<Pair<String, OnClickListener>> links) {
        try {
            SpannableString spannableString = new SpannableString(this.getText());
            for (Pair<String, OnClickListener> it : links) {
                ClickableSpan clickableSpan = new ClickableSpan() {
                    @Override
                    public void onClick(@NonNull View view) {
                        Selection.setSelection(((Spannable) ((TextView) view).getText()), 0);
                        view.invalidate();
                        it.second.onClick(view);
                        view.setEnabled(false);
                        new Handler().postDelayed(() -> view.setEnabled(true), 1000L);
                    }

                    @Override
                    public void updateDrawState(@NonNull TextPaint ds) {
                        super.updateDrawState(ds);
                        ds.setUnderlineText(false);
                    }
                };
                final int startIndexOfLink = this.getText().toString().indexOf(it.first);
                spannableString.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), startIndexOfLink, startIndexOfLink + it.first.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//                spannableString.setSpan(new UnderlineSpan(), startIndexOfLink, startIndexOfLink + it.first.length(), 0);
                spannableString.setSpan(clickableSpan, startIndexOfLink, startIndexOfLink + it.first.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            this.setText(spannableString, BufferType.SPANNABLE);
            this.setMovementMethod(LinkMovementMethod.getInstance());
        } catch (IndexOutOfBoundsException | NullPointerException e) {
            Log.i(TAG, "Link: Cannot create link for %s: %s" + links + e.getMessage());
        }
    }
}

