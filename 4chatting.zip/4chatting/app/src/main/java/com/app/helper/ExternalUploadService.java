package com.app.helper;

import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.app.external.RandomString;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.ExternalShareActivity;
import com.app.fourchattingapp.ForwardActivity;
import com.app.model.ChannelMessage;
import com.app.model.MessagesData;
import com.app.model.SearchData;
import com.app.fourchattingapp.R;
import com.app.model.GroupMessage;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by hitasoft on 14/7/18.
 */

public class ExternalUploadService extends IntentService implements ProgressRequestBody.UploadCallbacks {

    private static final String TAG = ExternalUploadService.class.getSimpleName();
    public static boolean IS_FILE_UPLOADING = false;
    NotificationManager mNotifyManager;
    NotificationCompat.Builder mBuilder;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    StorageManager storageManager;
    String uploadFilePath, thumbnail = null;
    String fileType;
    long startTime;
    long elapsedTime = 0L;
    private Context mContext;
    ArrayList<Uri> externalImageUris = new ArrayList<>();
    ArrayList<Uri> uploadedUri = new ArrayList<>();
    List<SearchData> selectedList = new ArrayList<>();
    private int NOTIFICATION_ID = 0;

    public ExternalUploadService() {
        super(TAG);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
//        setNotification();
    }

    private void setNotification() {
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = getString(R.string.notification_channel_foreground_service);
        CharSequence channelName = getString(R.string.app_name);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        mBuilder = new NotificationCompat.Builder(this, channelId);
        mBuilder.setContentTitle(getString(R.string.app_name))
                .setContentText(mContext.getString(R.string.uploading))
                .setSmallIcon(R.drawable.notification)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true);
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        IS_FILE_UPLOADING = true;
        dbhelper = DatabaseHandler.getInstance(this);
        socketConnection = SocketConnection.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        Bundle bundle = intent.getExtras();
        selectedList = (ArrayList<SearchData>) bundle.getSerializable("selectedList");
        fileType = bundle.getString(Constants.TAG_TYPE);
        thumbnail = bundle.getString(Constants.TAG_THUMBNAIL);
        uploadFilePath = bundle.getString(Constants.TAG_ATTACHMENT);
        NOTIFICATION_ID = bundle.getInt(Constants.TAG_NOTIFICATION_ID);
        Log.d(TAG, "onHandleIntent: " + NOTIFICATION_ID);
        setNotification();
        uploadFile();
    }

    private void uploadFile() {
        ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
        MultipartBody.Part filePart = MultipartBody.Part.createFormData("attachment", new File(uploadFilePath).getName(), fileBody);
        ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<Map<String, String>> call3 = apiInterface.upchat(GetSet.getToken(), filePart, userid);
        try {
            Response<Map<String, String>> response = call3.execute();
            if (response.isSuccessful()) {
                try {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String newFileName = userdata.get(Constants.TAG_USER_IMAGE);
                        boolean fileStatus;
                        switch (fileType) {
                            case Constants.TAG_AUDIO:
                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_AUDIO);
                                break;
                            case Constants.TAG_VIDEO:
                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_VIDEO);
                                break;
                            case Constants.TAG_DOCUMENT:
                            default:
                                fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_DOCUMENT);
                                break;
                        }
                        if (fileStatus) {
                            for (SearchData selectedUser : selectedList) {
                                if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_CHATS ||
                                        selectedUser.viewType == ExternalShareActivity.RecyclerViewAdapter.VIEW_TYPE_CONTACTS) {
                                    emitMessage(selectedUser, newFileName);
                                } else if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_GROUPS) {
                                    emitGroupMessage(selectedUser, newFileName);
                                } else if (selectedUser.viewType == ForwardActivity.RecyclerViewAdapter.VIEW_TYPE_CHANNELS) {
                                    emitChannelMessage(selectedUser, newFileName);
                                }
                            }
                            mBuilder.setProgress(0, 0, false);
                            mBuilder.setContentText(getString(R.string.file_uploaded));
                            mNotifyManager.cancel("progress", NOTIFICATION_ID);
                            mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
                            socketConnection.setExternalUploadListener("completed");
                        }
                    } else {
                        setErrorUpload();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    setErrorUpload();
                }
            } else {
                setErrorUpload();
            }
        } catch (IOException e) {
            e.printStackTrace();
            setErrorUpload();
        }
    }

    public void emitMessage(SearchData selectedUser, String newFileName) {
//        if (!selectedUser.blockedme.equals("block")) {
        try {
            MessagesData mdata = getExternalData(Constants.TAG_VIDEO, newFileName, thumbnail, selectedUser);
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            dbhelper.addMessageData(mdata, true);
            dbhelper.addRecentMessages(mdata.chat_id, mdata.receiver_id, mdata.message_id, currentUTCTime, "0");

            JSONObject jobj = new JSONObject();
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_USER_ID, mdata.user_id);
            message.put(Constants.TAG_USER_NAME, mdata.user_name);
            message.put(Constants.TAG_MESSAGE_TYPE, mdata.message_type);
            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(mdata.attachment));
            message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(mdata.thumbnail) : "");
            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
            message.put(Constants.TAG_CHAT_ID, mdata.chat_id);
            message.put(Constants.TAG_MESSAGE_ID, mdata.message_id);
            message.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
            message.put(Constants.TAG_SENDER_ID, mdata.user_id);
            message.put(Constants.TAG_BLOCK_STATUS, selectedUser.blockedme.equals("block"));
            message.put(Constants.TAG_BLOCKED_BY, selectedUser.blockedme.equals("block") ? mdata.receiver_id : "");
            message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
            jobj.put(Constants.TAG_SENDER_ID, mdata.user_id);
            jobj.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
            jobj.put("message_data", message);
            socketConnection.startChat(jobj);

        } catch (JSONException e) {
            e.printStackTrace();
        }
//        }
    }

    private MessagesData getExternalData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        String chatId = GetSet.getUserId() + selectedUser.user_id;
        MessagesData data = new MessagesData();
        data.chat_id = chatId;

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                data.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                ;
                data.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                data.progress = "completed";
                break;
            case "document":
                data.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        data.user_id = GetSet.getUserId();
        data.message_type = type;
        data.message = msg;
        data.message_id = messageId;
        data.chat_time = currentUTCTime;
        data.delivery_status = "";
        data.receiver_id = selectedUser.user_id;
        data.sender_id = GetSet.getUserId();
        data.thumbnail = thumbPath;
        data.attachment = mediaPath;
        data.statusData = "";
        data.lat = "";
        data.lon = "";
        data.contact_name = "";
        data.contact_phone_no = "";
        data.contact_country_code = "";

        Log.d(TAG, "getExternalData: " + new Gson().toJson(data));
        return data;
    }

    private void emitGroupMessage(SearchData selectedUser, String newFileName) {
        try {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            GroupMessage gdata = getExternalGroupData(Constants.TAG_VIDEO, newFileName, thumbnail, selectedUser);
            JSONObject message = new JSONObject();
            message.put(Constants.TAG_GROUP_ID, gdata.groupId);
            message.put(Constants.TAG_GROUP_NAME, gdata.groupName);
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
            message.put(Constants.TAG_MESSAGE_TYPE, gdata.messageType);
            message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
            message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(thumbnail) : "");
            message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(gdata.message));
            message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
            message.put(Constants.TAG_MESSAGE_ID, gdata.messageId);
            message.put(Constants.TAG_MEMBER_ID, gdata.memberId);
            message.put(Constants.TAG_MEMBER_NAME, gdata.memberName);
            message.put(Constants.TAG_MEMBER_NO, gdata.memberNo);
            message.put(Constants.TAG_DELIVERY_STATUS, "read");
            Log.d(TAG, "emitGroupMessage: " + message);
            socketConnection.messageToGroup(message);

            dbhelper.addGroupMessages(gdata.messageId, gdata.groupId, GetSet.getUserId(), "", gdata.messageType,
                    ApplicationClass.encryptMessage(gdata.message), ApplicationClass.encryptMessage(newFileName), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""),
                    ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""), ApplicationClass.encryptMessage(""),
                    currentUTCTime, ApplicationClass.encryptMessage(thumbnail), "read");
            dbhelper.updateGroupMessageData(gdata.messageId, Constants.TAG_PROGRESS, "completed");
            dbhelper.addGroupRecentMsg(gdata.groupId, gdata.messageId, GetSet.getUserId(), currentUTCTime, "0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private GroupMessage getExternalGroupData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        GroupMessage groupMessage = new GroupMessage();

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                groupMessage.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                groupMessage.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                groupMessage.progress = "completed";
                break;
            case "document":
                groupMessage.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        groupMessage.groupId = selectedUser.groupId;
        groupMessage.groupName = selectedUser.groupName;
        groupMessage.memberId = GetSet.getUserId();
        groupMessage.memberName = GetSet.getUserName();
        groupMessage.memberNo = GetSet.getphonenumber();
        groupMessage.messageType = type;
        groupMessage.message = msg;
        groupMessage.messageId = messageId;
        groupMessage.chatTime = currentUTCTime;
        groupMessage.deliveryStatus = "";
        groupMessage.progress = "completed";
        groupMessage.thumbnail = thumbPath;
        groupMessage.attachment = mediaPath;

        Log.d(TAG, "getExternalGroupData: " + new Gson().toJson(groupMessage));
        return groupMessage;
    }

    private void emitChannelMessage(SearchData selectedUser, String newFileName) {
        try {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            ChannelMessage channelData = getExternalChannelData(Constants.TAG_VIDEO, newFileName, thumbnail, selectedUser);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(Constants.TAG_CHANNEL_ID, selectedUser.channelId);
            jsonObject.put(Constants.TAG_CHANNEL_NAME, selectedUser.channelName);
            jsonObject.put(Constants.TAG_CHAT_TYPE, channelData.chatType);
            jsonObject.put(Constants.TAG_MESSAGE_ID, channelData.messageId);
            jsonObject.put(Constants.TAG_MESSAGE_TYPE, channelData.messageType);
            jsonObject.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(channelData.message));
            jsonObject.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(channelData.attachment));
            jsonObject.put(Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(channelData.thumbnail));
            jsonObject.put(Constants.TAG_CHAT_TIME, channelData.chatTime);
            jsonObject.put(Constants.TAG_ADMIN_ID, channelData.channelAdminId);
            socketConnection.messageToChannel(jsonObject);

            dbhelper.addChannelMessages(channelData.channelId, Constants.TAG_CHANNEL, channelData.messageId, channelData.messageType,
                    ApplicationClass.encryptMessage(channelData.message), ApplicationClass.encryptMessage(channelData.attachment), "", "", "",
                    "", "", currentUTCTime, ApplicationClass.encryptMessage(channelData.thumbnail), "read");
            dbhelper.updateChannelMessageData(channelData.messageId, Constants.TAG_PROGRESS, "completed");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private ChannelMessage getExternalChannelData(String type, String mediaPath, String thumbPath, SearchData selectedUser) {
        String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        ChannelMessage channelMessage = new ChannelMessage();

        String msg = "";
        switch (type) {
            case "image":
                msg = getString(R.string.image);
                channelMessage.progress = "completed";
                break;
            case "audio":
                msg = getString(R.string.audio);
                channelMessage.progress = "completed";
                break;
            case "video":
                msg = getString(R.string.video);
                channelMessage.progress = "completed";
                break;
            case "document":
                channelMessage.progress = "completed";
                msg = getString(R.string.document);
                break;
        }

        channelMessage.channelId = selectedUser.channelId;
        channelMessage.channelName = selectedUser.channelName;
        channelMessage.channelAdminId = selectedUser.channelAdminId;
        channelMessage.chatType = Constants.TAG_CHANNEL;
        channelMessage.messageType = type;
        channelMessage.message = msg;
        channelMessage.messageId = messageId;
        channelMessage.chatTime = currentUTCTime;
        channelMessage.deliveryStatus = "";
        channelMessage.progress = "completed";
        channelMessage.thumbnail = thumbPath;
        channelMessage.attachment = mediaPath;

        Log.d(TAG, "getExternalChannelData: " + new Gson().toJson(channelMessage));
        return channelMessage;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
    }

    private void setSuccessUploaded() {
        mBuilder.setProgress(100, 100, false);
        mBuilder.setContentText(getString(R.string.file_uploaded));
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                mNotifyManager.cancel(NOTIFICATION_ID);
            }
        }, 1000);
    }

    private void setErrorUpload() {
        socketConnection.setExternalUploadListener("error");
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(getString(R.string.file_upload_error));
        mNotifyManager.cancel("progress", NOTIFICATION_ID);
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        IS_FILE_UPLOADING = false;
        /*if (ApplicationClass.getCurrentActivity() == null) {
            if (socketConnection != null) {
                socketConnection.goAway(ApplicationClass.groupList);
                socketConnection.disconnect();
            }
        }*/
    }

    @Override
    public void onProgressUpdate(final int percentage) {
        Log.d(TAG, "onProgressUpdate: " + percentage);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (percentage != 100) {
                    mBuilder.setProgress(100, percentage, false);
                    mBuilder.setContentText(mContext.getString(R.string.uploading));
                    mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
                    startTime = System.currentTimeMillis();
                    elapsedTime = 0;
                } else {
                    mBuilder.setProgress(100, 100, false);
                    mBuilder.setContentText(getString(R.string.file_uploaded));
                    mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
                }
            }
        });
    }

    @Override
    public void onError() {
        setErrorUpload();
    }

    @Override
    public void onFinish() {
        setSuccessUploaded();
    }

    @Override
    public void uploadStart() {

    }

}
