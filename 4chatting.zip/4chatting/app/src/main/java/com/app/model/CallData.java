package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by hitasoft on 29/7/18.
 */

public class CallData {

    public List<Result> result;
    public String status;

    public class Result {
        @SerializedName("call_id")
        public String callId;
        @SerializedName("user_id")
        public String userId;
        @SerializedName("type")
        public String type;
        @SerializedName("call_status")
        public String callStatus;
        @SerializedName("created_at")
        public String createdAt;
        @SerializedName("caller_id")
        public String callerId;
        @SerializedName("status")
        public String status;
        @SerializedName("message_data")
        public MessageData messageData;

        public class MessageData {
            @SerializedName("caller_id")
            public String callerId;
            @SerializedName("call_id")
            public String callId;
            @SerializedName("message")
            public String message;
            @SerializedName("created_at")
            public String createdAt;
            @SerializedName("chat_type")
            public String chatType;
            @SerializedName("type")
            public String type;
            @SerializedName("call_status")
            public String callStatus;
            @SerializedName("call_type")
            public String callType;

        }
    }

}
