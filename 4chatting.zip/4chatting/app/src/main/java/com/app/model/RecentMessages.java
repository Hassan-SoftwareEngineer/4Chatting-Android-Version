package com.app.model;

import com.google.gson.annotations.SerializedName;

public class RecentMessages {
    @SerializedName("chat_id")
    public String chatId;

    @SerializedName("chat_type")
    public String chatType;

    @SerializedName("message_id")
    public String messageId;

    @SerializedName("user_id")
    public String userId;

    @SerializedName("user_name")
    public String userName;

    @SerializedName("user_image")
    public String userImage;

    @SerializedName("phone")
    public String phone;

    @SerializedName("about")
    public String about;

    @SerializedName("message_type")
    public String messageType;

    @SerializedName("message")
    public String message;

    @SerializedName("attachment")
    public String attachment;

    @SerializedName("contact_name")
    public String contactName;

    @SerializedName("contact_phone_no")
    public String contactPhoneNo;

    @SerializedName("contact_country_code")
    public String contactCountryCode;

    @SerializedName("lat")
    public String lat;

    @SerializedName("lon")
    public String lon;

    @SerializedName("country_code")
    public String countryCode;

    @SerializedName("chat_time")
    public String chatTime;

    @SerializedName("receiver_id")
    public String receiverId;

    @SerializedName("sender_id")
    public String senderId;

    @SerializedName("delivery_status")
    public String deliveryStatus;

    @SerializedName("unread_count")
    public String unreadCount;

    @SerializedName("thumbnail")
    public String thumbnail;

    @SerializedName("progress")
    public String progress;

    @SerializedName("mute_notification")
    public String muteNotification;

    @SerializedName("delete_for_me")
    public String deleteForMe;

    @SerializedName("isDelete")
    public String isDelete;

    @SerializedName("statusData")
    public String statusData;

    @SerializedName("privacy_last_seen")
    public String privacyLastSeen;

    @SerializedName("privacy_profile_image")
    public String privacyProfileImage;

    @SerializedName("privacy_about")
    public String privacyAbout;

    @SerializedName("contactstatus")
    public String contactStatus;

    @SerializedName("blockedme")
    public String blockedMe;

    @SerializedName("blockedbyme")
    public String blockedByMe;

    @SerializedName("favourited")
    public String favouriteId;

    @SerializedName("deleted_account")
    public String deletedAccount;

    @SerializedName("get_from_api")
    public String getFromApi;

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getChatType() {
        return chatType;
    }

    public void setChatType(String chatType) {
        this.chatType = chatType;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getChatTime() {
        return chatTime;
    }

    public void setChatTime(String chatTime) {
        this.chatTime = chatTime;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public String getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(String unreadCount) {
        this.unreadCount = unreadCount;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getMuteNotification() {
        return muteNotification;
    }

    public void setMuteNotification(String muteNotification) {
        this.muteNotification = muteNotification;
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }

    public String getStatusData() {
        return statusData;
    }

    public void setStatusData(String statusData) {
        this.statusData = statusData;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPrivacyLastSeen() {
        return privacyLastSeen;
    }

    public void setPrivacyLastSeen(String privacyLastSeen) {
        this.privacyLastSeen = privacyLastSeen;
    }

    public String getPrivacyProfileImage() {
        return privacyProfileImage;
    }

    public void setPrivacyProfileImage(String privacyProfileImage) {
        this.privacyProfileImage = privacyProfileImage;
    }

    public String getPrivacyAbout() {
        return privacyAbout;
    }

    public void setPrivacyAbout(String privacyAbouot) {
        this.privacyAbout = privacyAbouot;
    }

    public String getContactStatus() {
        return contactStatus;
    }

    public void setContactStatus(String contactStatus) {
        this.contactStatus = contactStatus;
    }

    public String getBlockedMe() {
        return blockedMe;
    }

    public void setBlockedMe(String blockedMe) {
        this.blockedMe = blockedMe;
    }

    public String getBlockedByMe() {
        return blockedByMe;
    }

    public void setBlockedByMe(String blockedByMe) {
        this.blockedByMe = blockedByMe;
    }

    public String getFavouriteId() {
        return favouriteId;
    }

    public void setFavouriteId(String favouriteId) {
        this.favouriteId = favouriteId;
    }

    public String getDeletedAccount() {
        return deletedAccount;
    }

    public void setDeletedAccount(String deletedAccount) {
        this.deletedAccount = deletedAccount;
    }

    public String getGetFromApi() {
        return getFromApi;
    }

    public void setGetFromApi(String getFromApi) {
        this.getFromApi = getFromApi;
    }

    public String getDeleteForMe() {
        return deleteForMe;
    }

    public void setDeleteForMe(String deleteForMe) {
        this.deleteForMe = deleteForMe;
    }
}
