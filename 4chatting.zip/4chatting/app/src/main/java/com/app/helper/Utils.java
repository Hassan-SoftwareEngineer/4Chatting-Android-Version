package com.app.helper;

import static android.content.Context.MODE_PRIVATE;
import static com.app.utils.Constants.TAG_MY_CONTACTS;
import static com.app.utils.Constants.TAG_NOBODY;
import static com.app.utils.Constants.TAG_TRUE;

import android.app.Dialog;
import android.app.KeyguardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.text.Html;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.app.apprtc.util.AppRTCUtils;
import com.app.external.RandomString;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.CallActivity;
import com.app.model.ChannelResult;
import com.app.model.MessagesData;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import okhttp3.Request;

public class Utils {

    private static String TAG = Utils.class.getSimpleName();
    private final Context context;
    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;
    public static final String[] AUDIO_TYPES = {"mp3", "wav", "flac", "ogg"};
    private static Utils mInstance;

    public static Utils getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new Utils(context);
        }
        return mInstance;
    }

    public Utils(Context context) {
        this.context = context;
        pref = context.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
    }

    public static String getURLForResource(int resourceId) {
        return Uri.parse("android.resource://com.app.fourchattingapp/" + resourceId).toString();
    }

    public static String getApiRequestLog(Request request) {
        StringBuilder builder = new StringBuilder();
        builder.append(request.url());
        builder.append("\n");
        builder.append(new Gson().toJson(request.body()));
        return builder.toString();
    }

    public static String isNetworkConnected(Context context) {
        return NetworkUtil.getConnectivityStatusString(context);
    }

    public static void networkSnack(CoordinatorLayout mainLay, Context context) {
        Snackbar snackbar = Snackbar
                .make(mainLay, context.getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public static Spanned fromHtml(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT);
        } else {
            return Html.fromHtml(html);
        }
    }

    public static boolean isUserAdminInChannel(ChannelResult.Result channelData) {
        if (channelData.channelAdminId != null && channelData.channelAdminId.equalsIgnoreCase(GetSet.getUserId())) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isChannelAdmin(ChannelResult.Result channelData, String userId) {
        return channelData.channelAdminId != null && channelData.channelAdminId.equalsIgnoreCase(userId);
    }

    public static boolean isProfileEnabled(ContactsData.Result result) {
        if (result.privacy_profile_image.equalsIgnoreCase(TAG_MY_CONTACTS)) {
            return result.contactstatus != null && result.contactstatus.equalsIgnoreCase(TAG_TRUE);
        } else return !result.privacy_profile_image.equalsIgnoreCase(TAG_NOBODY);
    }

    public static boolean isLastSeenEnabled(ContactsData.Result result) {
        if (result.privacy_last_seen.equalsIgnoreCase(TAG_MY_CONTACTS)) {
            return result.contactstatus != null && result.contactstatus.equalsIgnoreCase(TAG_TRUE);
        } else return !result.privacy_last_seen.equalsIgnoreCase(TAG_NOBODY);
    }

    public static boolean isAboutEnabled(ContactsData.Result result) {
        if (result.privacy_about.equalsIgnoreCase(TAG_MY_CONTACTS)) {
            return result.contactstatus != null && result.contactstatus.equalsIgnoreCase(TAG_TRUE);
        } else return !result.privacy_about.equalsIgnoreCase(TAG_NOBODY);
    }

    static void refreshGallery(String TAG, Context context, File file) {

        try {
            final Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            final Uri contentUri = Uri.fromFile(file);
            scanIntent.setData(contentUri);
            context.sendBroadcast(scanIntent);
            MediaScannerConnection.scanFile(context, new String[]{file.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                @Override
                public void onScanCompleted(String path, Uri uri) {
                    Log.i(TAG, "Finished scanning " + file.getAbsolutePath());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Size getBitmapSize(Context mContext) {
        return new Size(150, 150);
    }

    public static void openDeletedAlertDialog(Context context, String isDeletedAccount, String phoneNo, String countryCode) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(context.getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(R.string.okay);
        no.setText(context.getString(R.string.nope));
        if (isDeletedAccount.equals("1")) {
            title.setText(context.getString(R.string.could_not_add) + " " + context.getString(R.string.deleted_account));
        } else {
            title.setText(context.getString(R.string.could_not_add) + " " + ApplicationClass.getContactName(context, phoneNo, countryCode));
        }
        no.setVisibility(View.GONE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public static MessagesData getMessageFromJson(JSONObject data) {
        MessagesData mdata = new MessagesData();
//        mdata = new Gson().fromJson(data.toString(), MessagesData.class);
        mdata.user_id = data.optString(Constants.TAG_SENDER_ID, "");
        mdata.message_type = data.optString(Constants.TAG_MESSAGE_TYPE, "");
        mdata.message = data.optString(Constants.TAG_MESSAGE, "");
        mdata.message_id = data.optString(Constants.TAG_MESSAGE_ID, "");
        mdata.attachment = data.optString(Constants.TAG_ATTACHMENT, "");
        mdata.chat_time = data.optString(Constants.TAG_CHAT_TIME, "");
        mdata.receiver_id = data.optString(Constants.TAG_RECEIVER_ID, "");
        mdata.sender_id = data.optString(Constants.TAG_SENDER_ID, "");
        mdata.lat = data.optString(Constants.TAG_LAT, "");
        mdata.lon = data.optString(Constants.TAG_LON, "");
        mdata.contact_name = data.optString(Constants.TAG_CONTACT_NAME, "");
        mdata.contact_phone_no = data.optString(Constants.TAG_CONTACT_PHONE_NO, "");
        mdata.contact_country_code = data.optString(Constants.TAG_CONTACT_COUNTRY_CODE, "");
        mdata.thumbnail = data.optString(Constants.TAG_THUMBNAIL, "");
        mdata.statusData = data.optString(Constants.TAG_STATUS_DATA, "");
        mdata.progress = data.optString(Constants.TAG_PROGRESS, "");
        return mdata;
    }

    public static MessagesData getMessageData(String chatId, String messageId, String userId, String userName, String messageType,
                                              String message, String attachment, String lat, String lon,
                                              String contact_name, String contact_phone_no, String contact_country_code, String chat_time,
                                              String receiver_id, String sender_id, String deliveryStatus, String thumbnail, String statusData,
                                              String progress) {
        MessagesData tempData = new MessagesData();
        tempData.chat_id = chatId;
        tempData.message_id = messageId;
        tempData.user_id = userId;
        tempData.user_name = userName;
        tempData.message_type = messageType;
        tempData.message = message;
        tempData.attachment = attachment;
        tempData.lat = lat;
        tempData.lon = lon;
        tempData.contact_name = contact_name;
        tempData.contact_phone_no = contact_phone_no;
        tempData.contact_country_code = contact_country_code;
        tempData.chat_time = chat_time;
        tempData.receiver_id = receiver_id;
        tempData.sender_id = sender_id;
        tempData.delivery_status = deliveryStatus;
        tempData.thumbnail = thumbnail;
        tempData.statusData = statusData;
        tempData.progress = progress;
        return tempData;
    }

    public MessagesData getDateModel(MessagesData messagesData) {
        RandomString randomString = new RandomString(10);
        String messageId = GetSet.getUserId() + randomString.nextString();
        MessagesData dateModel = new MessagesData();
        dateModel.chat_id = messagesData.chat_id;
        dateModel.message_id = messageId;
        dateModel.message_type = Constants.TAG_DATE;
        dateModel.message = DateUtils.getInstance(context).getChatDateFromUTC(messagesData.chat_time);
        dateModel.chat_time = messagesData.chat_time;
        dateModel.sender_id = ""/*messagesData.sender_id*/;
        dateModel.receiver_id = ""/*messagesData.receiver_id*/;
        dateModel.user_id = ""/*messagesData.user_id*/;
        dateModel.user_name = ""/*messagesData.user_name*/;
        dateModel.attachment = "";
        dateModel.lat = "";
        dateModel.lon = "";
        dateModel.contact_name = "";
        dateModel.contact_phone_no = "";
        dateModel.contact_country_code = "";
        dateModel.thumbnail = "";
        dateModel.statusData = "";
        dateModel.delivery_status = "";
        dateModel.progress = "";

        return dateModel;
    }

    public List<String> getMyContactList(Context mContext) {
        List<String> myContacts = new ArrayList<>();
        Uri uri = null;
        uri = ContactsContract.CommonDataKinds.Contactables.CONTENT_URI;
        ContentResolver cr = mContext.getContentResolver();
        Cursor cur = cr.query(uri, Constants.PROJECTION, Constants.SELECTION, Constants.SELECTION_ARGS, null);

        if (cur != null) {
            try {
                final int numberIndex = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                while (cur.moveToNext()) {
                    String phoneNo = cur.getString(numberIndex).replace(" ", "");
                    String formattedPhoneNumber = getFormattedPhoneNumber(phoneNo);
                    if (!TextUtils.isEmpty(formattedPhoneNumber)) {
                        myContacts.add(formattedPhoneNumber);
                    }
                }
            } finally {
                cur.close();
            }
        }
        return myContacts;
    }

    public String getFormattedPhoneNumber(String phone) {
        String phoneNo = phone.trim();
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber numberProto;
        if (TextUtils.isEmpty(phoneNo) || phoneNo.length() < 7 || phoneNo.length() > 15) {
            return "";
        } else {
            try {
                numberProto = phoneUtil.parse(phoneNo, null);
                phoneNo = "" + numberProto.getNationalNumber();
            } catch (NumberParseException e) {
//                Log.e(TAG, "getFormattedPhoneNumber: " + phoneNo);
                phoneNo = getOnlyStrings(phoneNo);
                if (!isValidPhoneNumber(phoneNo)) {
                    phoneNo = "";
                }
            }
        }

//        Log.d(TAG, "getFormattedPhoneNumber: " + phoneNo);
        return phoneNo;
    }

    public boolean isValidPhoneNumber(CharSequence target) {
        return !TextUtils.isEmpty(target) && target.length() >= 7 && target.length() <= 15;
    }

    public boolean isValidPhoneNumber(String countryCode, String phoneNumber) {
        if (phoneNumber.length() < 7 || phoneNumber.length() > 15) {
            return false;
        } else {
            if (!countryCode.startsWith("+")) {
                countryCode = "+" + countryCode;
            }
            //NOTE: This should probably be a member variable.
            PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
            try {
                Phonenumber.PhoneNumber parsedNumber = phoneUtil.parse(countryCode + phoneNumber, null);
                if (parsedNumber == null) return false;
                if (phoneUtil.isValidNumber(parsedNumber)) {
                    return true;
                } else {
                    if (isValidMobilePattern(phoneNumber)) {
                        return true;
                    } else {
                        String tempCountryCode = phoneUtil.getRegionCodeForCountryCode(parsedNumber.getCountryCode());
                        return phoneUtil.isPossibleNumber(phoneNumber, tempCountryCode);
                    }
                }
            } catch (NumberParseException e) {
                System.err.println("NumberParseException was thrown: " + e.toString());
            }
            return isValidMobilePattern(phoneNumber);
        }
        /*else {
            return android.util.Patterns.PHONE.matcher(target).matches();
        }*/
    }

    public boolean isValidMobilePattern(CharSequence target) {
        String patterns = "^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$";
        return Pattern.compile(patterns).matcher(target).matches();
    }

    public String getOnlyStrings(String phone) {
        String phoneNo = phone.trim();
        if (phoneNo.startsWith("+")) {
            phoneNo = phoneNo.replaceAll("\\+", "");
        }
        phoneNo = phoneNo.replaceAll("[\\D]", "").trim();
        phoneNo = phoneNo.replaceAll("[\\s\\-()]", "").trim();
        phoneNo = phoneNo.replaceAll("\\s", "").trim();
        phoneNo = phoneNo.replaceAll("[^0-9]", "").trim();
        phoneNo = phoneNo.replaceAll("^0+(?!$)", "").trim();
//        Log.d(TAG, "getOnlyStrings: " + phoneNo);
        return phoneNo;
    }

    public JSONObject generateGroupLink(Context mContext, String groupId, String groupName) {
        String inviteLink = Constants.INVITE_LINK_URL + "/groups/" + groupId.trim();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_ID, groupId);
            jsonObject.put(Constants.TAG_NAME, groupName);
            jsonObject.put(Constants.TAG_TYPE, Constants.TAG_GROUP);
            jsonObject.put(Constants.TAG_DESCRIPTION, mContext.getString(R.string.group_chat_invite));
            jsonObject.put(Constants.TAG_LINK, inviteLink);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "generateGroupLink: " + jsonObject);
        return jsonObject;
    }

    public JSONObject generateChannelLink(Context mContext, String channelId, String channelName) {
        String inviteLink = Constants.INVITE_LINK_URL + "/channels/" + channelId.trim();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(Constants.TAG_ID, channelId);
            jsonObject.put(Constants.TAG_NAME, channelName);
            jsonObject.put(Constants.TAG_TYPE, Constants.TAG_CHANNEL);
            jsonObject.put(Constants.TAG_DESCRIPTION, mContext.getString(R.string.channel_chat_invite));
            jsonObject.put(Constants.TAG_LINK, inviteLink);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "generateChannelLink: " + jsonObject);
        return jsonObject;
    }

    public static String encodeBase64URLSafeString(byte[] binaryData) {
        return android.util.Base64.encodeToString(binaryData, Base64.URL_SAFE);

    }

    public int getNavigationBarHeight() {
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            int height = resources.getDimensionPixelSize(resourceId);
            editor.putInt(Constants.TAG_NAV_HEIGHT, height);
            editor.commit();
            return height;
        }
        return 0;
    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        editor.putInt(Constants.TAG_STATUS_HEIGHT, result);
        editor.commit();
        return result;
    }

    public Drawable getChatWallpaper(Context mContext, String _id, String type) {
        String wallpaper = DatabaseHandler.getInstance(mContext).getWallpaper(_id, type);
        if (!TextUtils.isEmpty(wallpaper)) {
            File file = new File(wallpaper);
            if (file != null && file.exists()) {
                return Drawable.createFromPath(file.getAbsolutePath());
            } else {
                return getAlternateWallpaper(mContext);
            }
        } else {
            return getAlternateWallpaper(mContext);
        }
    }

    public Drawable getAlternateWallpaper(Context mContext) {
        String commonWallpaper = getCommonWallpaper(mContext);
        if (!TextUtils.isEmpty(commonWallpaper)) {
            Drawable d = Drawable.createFromPath(commonWallpaper);
            return (d != null) ? d : getDefaultWallpaperDrawable(mContext);
        } else {
            String defaultWallpaper = getDefaultChatWallpaper(mContext);
            if (!TextUtils.isEmpty(defaultWallpaper)) {
                Drawable d = Drawable.createFromPath(defaultWallpaper);
                return (d != null) ? d : getDefaultWallpaperDrawable(mContext);
            } else {
                return getDefaultWallpaperDrawable(mContext);
            }
        }
    }

    public String getDefaultWallpaperName(Context mContext) {
        return mContext.getString(R.string.app_name) + "_" + mContext.getString(R.string.wallpaper) + ".jpg";
    }

    public String getCommonWallpaper(Context mContext) {
        String commonWallpaper = pref.getString(Constants.TAG_COMMON_WALLPAPER, null);
        return commonWallpaper;
    }

    public String getDefaultChatWallpaper(Context mContext) {
        String defaultWallpaper = pref.getString(Constants.TAG_DEFAULT_WALLPAPER, null);
        return defaultWallpaper;
    }

    public Drawable getDefaultWallpaperDrawable(Context mContext) {
        Bitmap icon = BitmapFactory.decodeResource(mContext.getResources(),
                R.drawable.chat_bg);
        int dimension = Math.min(icon.getWidth(), icon.getHeight());
        Bitmap backgroundBitmap = ThumbnailUtils.extractThumbnail(icon, dimension, dimension);
        Drawable d = new BitmapDrawable(mContext.getResources(), backgroundBitmap);
        return d;
    }

    private boolean isKeyGuardSecured(KeyguardManager km) {
        if (!km.isKeyguardSecure()) {
            editor.putBoolean(Constants.IS_FINGERPRINT_LOCKED, false).apply();
        }
        return km.isKeyguardSecure();
    }

    public static void appendLog(Context context, String log, String fileName) {
        StorageManager storageManager = StorageManager.getInstance(context);
        File logFile = new File(storageManager.getExtCachesDir(), fileName);
        if (logFile.exists()) logFile.delete();
        if (!logFile.exists()) {
            try {
                logFile.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try {
            //BufferedWriter for performance, true to set append to file flag
            BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(log);
            buf.newLine();
            buf.close();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                storageManager.saveFileInStorageV10(logFile, fileName, StorageManager.TAG_DOCUMENT, StorageManager.TAG_DOCUMENT);
            } else {
                storageManager.saveFileInStorage(logFile, StorageManager.TAG_DOCUMENT);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void makeCall(Context mContext, String userId, String from, String type) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                if (!CallActivity.isInCall) {
                    AppRTCUtils appRTCUtils = new AppRTCUtils(mContext);
                    Intent video = appRTCUtils.connectToRoom(userId, from, type);
                    mContext.startActivity(video);
                } else {
                    ApplicationClass.showToast(context, context.getString(R.string.already_in_call), Toast.LENGTH_SHORT);
                }
            }
        }, Constants.CALL_TIME_DELAY);
    }
}
