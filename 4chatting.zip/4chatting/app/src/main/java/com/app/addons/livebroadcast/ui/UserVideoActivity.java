package com.app.addons.livebroadcast.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.app.addons.livebroadcast.external.avloading.AVLoadingIndicatorView;
import com.app.addons.livebroadcast.helper.Utils;
import com.app.addons.livebroadcast.model.LiveStreamRequest;
import com.app.addons.livebroadcast.model.LiveStreamResponse;
import com.app.addons.livebroadcast.model.StreamDetails;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.helper.LocaleManager;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserVideoActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = UserVideoActivity.class.getSimpleName();
    private ImageView userBackground;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerView;
    private LinearLayout nullLay;
    private AppCompatImageView nullImage;
    private TextView nullText;
    private ImageView backbtn;
    private TextView title;
    private TextView txtSubtitle;
    private LinearLayout buttonLayout;
    private ImageView optionbtn;

    private ArrayList<StreamDetails> streamLists = new ArrayList<>();
    private RecyclerViewAdapter itemAdapter;
    private LinearLayoutManager itemManager;
    private ApiInterface apiInterface;
    private Utils appUtils;
    private int currentPage = 0, visibleItemCount, totalItemCount, firstVisibleItem, previousTotal, visibleThreshold;
    private boolean isLoading = true;
    private String publisherId, publisherName, publisherImage, from;
    private Long selectedPosition;
    private List<Call<LiveStreamResponse>> liveStreamApiCall = new ArrayList<>();
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_video);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        appUtils = new Utils(this);
        context = this;
        findViews();
        getFromIntent();
        initView();
    }

    private void findViews() {
        backbtn = (ImageView) findViewById(R.id.backbtn);
        title = (TextView) findViewById(R.id.title);
        txtSubtitle = (TextView) findViewById(R.id.txtSubtitle);
        buttonLayout = (LinearLayout) findViewById(R.id.buttonLayout);
        optionbtn = (ImageView) findViewById(R.id.optionbtn);
        userBackground = findViewById(R.id.userBackground);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        recyclerView = findViewById(R.id.recyclerView);
        nullLay = findViewById(R.id.nullLay);
        nullImage = findViewById(R.id.nullImage);
        nullText = findViewById(R.id.nullText);

        backbtn.setOnClickListener(this);
    }

    private void getFromIntent() {
        publisherId = getIntent().getStringExtra(Constants.TAG_USER_ID);
        publisherName = getIntent().getStringExtra(Constants.TAG_USER_NAME);
        publisherImage = getIntent().getStringExtra(Constants.TAG_USER_IMAGE);
        from = getIntent().getStringExtra(Constants.TAG_FROM);
    }

    private void initView() {
        if (LocaleManager.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }
        backbtn.setVisibility(View.VISIBLE);
        title.setVisibility(View.VISIBLE);
        swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.colorPrimary), ContextCompat.getColor(this, R.color.colorPrimaryDark));

        Glide.with(this)
                .load(Constants.USER_IMG_PATH + GetSet.getImageUrl())
                .error(R.drawable.profile_square)
                .placeholder(R.drawable.profile_square)
                .into(userBackground);
        title.setText(getString(R.string.my_video));
        title.setTextColor(ContextCompat.getColor(this, R.color.primarytext));

        itemAdapter = new RecyclerViewAdapter(this, streamLists);
        itemManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(itemManager);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                itemAdapter.showLoading(false);
                streamLists.clear();
                for (Call<LiveStreamResponse> liveStreamResponseCall : liveStreamApiCall) {
                    liveStreamResponseCall.cancel();
                }
                liveStreamApiCall.clear();
                previousTotal = 0;
                currentPage = 0;
                totalItemCount = 0;
                visibleItemCount = 0;
                firstVisibleItem = 0;
                getLiveStreams(currentPage);
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                visibleItemCount = recyclerView.getChildCount();
                totalItemCount = itemManager.getItemCount();
                firstVisibleItem = itemManager.findFirstVisibleItemPosition();

                if (dy > 0) {//check for scroll down
                    if (isLoading) {
                        Log.i(TAG, "onScrolled: " + totalItemCount + ", " + previousTotal);
                        if (totalItemCount > previousTotal) {
                            isLoading = false;
                            previousTotal = totalItemCount;
                            currentPage++;
                        }
                    }

                    if (!isLoading && (totalItemCount - visibleItemCount)
                            <= (firstVisibleItem + visibleThreshold)) {
                        // End has been reached
                        isLoading = true;
                        getLiveStreams(currentPage);
                    }
                }
            }
        });

        streamLists.clear();
        swipeRefresh(true);
    }

    private void swipeRefresh(final boolean refresh) {
        swipeRefreshLayout.setRefreshing(refresh);
        if (refresh) {
            previousTotal = 0;
            currentPage = 0;
            totalItemCount = 0;
            visibleItemCount = 0;
            firstVisibleItem = 0;
            getLiveStreams(currentPage);
        }
    }

    public void getLiveStreams(final int offset) {
        if (NetworkStatus.isConnected()) {
            nullLay.setVisibility(View.GONE);
            if (!swipeRefreshLayout.isRefreshing()) {
                itemAdapter.showLoading(true);
            }

            Call<LiveStreamResponse> call = null;
            LiveStreamRequest request = new LiveStreamRequest();
            request.setUserId(GetSet.getUserId());
            request.setProfileId(GetSet.getUserId());
            request.setSortBy(StreamConstants.TAG_RECENT);
            request.setType(StreamConstants.TAG_USER);
            request.setLimit("" + StreamConstants.MAX_LIMIT);
            request.setOffset("" + (StreamConstants.MAX_LIMIT * offset));
            Log.d(TAG, "getLiveStreamsParams: " + new Gson().toJson(request));
            call = apiInterface.getCurrentStreams(GetSet.getToken(), request);
            liveStreamApiCall.add(call);
            call.enqueue(new Callback<LiveStreamResponse>() {
                @Override
                public void onResponse(Call<LiveStreamResponse> call, Response<LiveStreamResponse> response) {
                    try {
                        Log.d(TAG, "getLiveStreamsRes: " + new Gson().toJson(response.body()));
                        if (response.isSuccessful()) {
                            LiveStreamResponse data = response.body();
                            if (data.status.equals(Constants.TAG_TRUE)) {
                                streamLists.addAll(data.result);
                            }
                        }
                        if (streamLists.size() == 0) {
                            nullImage.setImageResource(R.drawable.no_video);
                            nullText.setText(getString(R.string.no_videos));
                            nullLay.setVisibility(View.VISIBLE);
                        } else {
                            nullLay.setVisibility(View.GONE);
                        }
                        if (swipeRefreshLayout.isRefreshing()) {
                            swipeRefresh(false);
                            isLoading = true;
                        }
                        itemAdapter.showLoading(false);
                        itemAdapter.notifyDataSetChanged();

                    } catch (Exception e) {
                        streamLists.clear();
                        itemAdapter.notifyDataSetChanged();
                        e.printStackTrace();
                    }

                }

                @Override
                public void onFailure(Call<LiveStreamResponse> call, Throwable t) {
                    Log.e(TAG, "getLiveStreams: " + t.getMessage());
                    if (currentPage != 0)
                        currentPage--;

                    if (!swipeRefreshLayout.isRefreshing()) {
                        itemAdapter.showLoading(false);
                    } else {
                        if (streamLists.size() == 0) {
                            nullText.setVisibility(View.VISIBLE);
                            nullText.setText(getString(R.string.something_wrong));
                        }
                        swipeRefresh(false);
                    }
                    call.cancel();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.backbtn) {
            backPressed();
        }
    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private final int VIEW_TYPE_ITEM = 0;
        private final int VIEW_TYPE_FOOTER = 1;
        List<StreamDetails> broadcastLists;
        private boolean showLoading = false;
        Context context;

        public RecyclerViewAdapter(Context context, List<StreamDetails> broadcastLists) {
            this.broadcastLists = broadcastLists;
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == VIEW_TYPE_ITEM) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_FOOTER) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.livza_progress, parent, false);
                return new LoadingViewHolder(view);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int position) {
            if (viewHolder instanceof MyViewHolder) {
                MyViewHolder holder = (MyViewHolder) viewHolder;
                final StreamDetails broadCast = broadcastLists.get(position);
                holder.txtUserName.setVisibility(View.VISIBLE);
                holder.txtUserName.setText(broadCast.getPostedBy());
                holder.txtUserName.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));

                if (broadCast.type.equals(StreamConstants.TAG_LIVE)) {
                    holder.liveStatusLay.setVisibility(View.VISIBLE);
                    holder.txtLiveCount.setText(broadCast.getWatchCount());
                } else {
                    holder.liveStatusLay.setVisibility(View.GONE);
                }
                holder.txtTitle.setText(broadCast.title);
                Glide.with(context).load(Constants.USER_IMG_PATH + broadCast.getPublisherImage())
                        .error(R.drawable.profile_square)
                        .placeholder(R.drawable.profile_square)
                        .centerCrop()
                        .into(holder.iconThumb);

                holder.txtUploadTime.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));
                holder.txtUploadTime.setText(appUtils.getRecentDate(appUtils.getTimeFromUTC(broadCast.getStreamedOn())));

                holder.parentLay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (broadCast.type.equals(StreamConstants.TAG_LIVE)) {
                            ApplicationClass.pauseExternalAudio(UserVideoActivity.this);
                            Intent i = new Intent(UserVideoActivity.this, SubscribeActivity.class);
                            Bundle arguments = new Bundle();
                            arguments.putSerializable(StreamConstants.TAG_STREAM_DATA, broadCast);
                            i.putExtra(Constants.TAG_FROM, StreamConstants.TAG_SUBSCRIBE);
                            i.putExtras(arguments);
                            startActivity(i);
                        } else {
                            ApplicationClass.pauseExternalAudio(UserVideoActivity.this);
                            selectedPosition = (long) position;
                            Intent intent = new Intent(UserVideoActivity.this, PlayerActivity.class);
                            intent.putExtra(StreamConstants.TAG_STREAM_DATA, broadCast);
                            intent.putExtra(Constants.TAG_FROM, from);
                            startActivityForResult(intent, StreamConstants.DELETE_REQUEST_CODE);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemViewType(int position) {
            if (showLoading && isPositionFooter(position))
                return VIEW_TYPE_FOOTER;
            return VIEW_TYPE_ITEM;
        }

        @Override
        public int getItemCount() {
            int itemCount = broadcastLists.size();
            if (showLoading)
                itemCount++;
            return itemCount;
        }


        public boolean isPositionFooter(int position) {
            return position == getItemCount() - 1 && showLoading;
        }

        public void showLoading(boolean value) {
            showLoading = value;
        }

        public class LoadingViewHolder extends RecyclerView.ViewHolder {
            AVLoadingIndicatorView progressBar;
            FrameLayout progressLay;

            public LoadingViewHolder(View view) {
                super(view);
                progressBar = view.findViewById(R.id.progress);
                progressLay = view.findViewById(R.id.progressLay);
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            RelativeLayout parentLay;
            RelativeLayout liveStatusLay;
            ImageView iconThumb;
            TextView txtLiveCount;
            TextView txtTitle;
            TextView txtUploadTime;
            TextView txtUserName;

            public MyViewHolder(View view) {
                super(view);
                parentLay = view.findViewById(R.id.parentLay);
                liveStatusLay = view.findViewById(R.id.liveStatusLay);
                iconThumb = view.findViewById(R.id.iconThumb);
                txtLiveCount = view.findViewById(R.id.txtLiveCount);
                txtTitle = view.findViewById(R.id.txtTitle);
                txtUploadTime = view.findViewById(R.id.txtUploadTime);
                txtUserName = view.findViewById(R.id.txtUserName);

                txtTitle.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));
                txtUploadTime.setTextColor(ContextCompat.getColor(context, R.color.secondarytext));
            }

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == StreamConstants.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (selectedPosition != null) {
                streamLists.remove(selectedPosition.intValue());
                itemAdapter.notifyItemRemoved(selectedPosition.intValue());
                itemAdapter.notifyItemRangeChanged(selectedPosition.intValue(), (itemAdapter.getItemCount() - selectedPosition.intValue()));
                selectedPosition = null;
            }
        }
    }
}
