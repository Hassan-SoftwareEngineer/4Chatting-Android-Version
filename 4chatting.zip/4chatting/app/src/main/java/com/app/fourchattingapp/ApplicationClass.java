package com.app.fourchattingapp;

import static android.Manifest.permission.READ_CONTACTS;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.multidex.MultiDex;

import com.facebook.stetho.Stetho;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseApp;
import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;
import com.app.external.FontsOverride;
import com.app.helper.CallNotificationService;
import com.app.helper.CryptLib;
import com.app.helper.DatabaseHandler;
import com.app.helper.ExampleNotificationOpenedHandler;
import com.app.helper.ExternalUploadService;
import com.app.helper.ForegroundService;
import com.app.helper.LocaleManager;
import com.app.helper.NetworkReceiver;
import com.app.helper.NetworkUtil;
import com.app.helper.SocketConnection;
import com.app.helper.ThemeHelper;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.R;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.instacart.library.truetime.TrueTime;
import com.onesignal.OSInAppMessage;
import com.onesignal.OSInAppMessageLifecycleHandler;
import com.onesignal.OneSignal;
import com.onesignal.shortcutbadger.ShortcutBadger;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by hitasoft on 24/1/18.
 */
public class ApplicationClass extends Application {

    private static final String TAG = ApplicationClass.class.getSimpleName();
    private static final String ONESIGNAL_APP_ID = Constants.ONESIGNAL_APP_ID;
    private static final String apikey= String.valueOf(R.string.google_api_key);
    public static SharedPreferences pref;
    public static SharedPreferences.Editor editor;
    public static boolean onShareExternal = false, onAppForegrounded = false,
            isAppOpened = false, isScreenLockOpened = false;
    private static Snackbar snackbar = null;
    private static ApplicationClass mInstance;
    private static Toast toast = null;
    private static SocketConnection socketConnection;
    private DatabaseHandler dbhelper;
    private Intent foregroundService;
    private Intent callNotificationService;
    private static AppCompatActivity mCurrentActivity = null;
    public static List<String> groupList = new ArrayList<>();
    public static List<String> channelList = new ArrayList<>();
    public static boolean IS_NETWORK_CHANGED = false;
    private Context mContext;

    public static synchronized ApplicationClass getInstance() {
        return mInstance;
    }

    public static void setCurrentActivity(AppCompatActivity activity) {
        mCurrentActivity = activity;
    }

    public static AppCompatActivity getCurrentActivity() {
        return mCurrentActivity;
    }

    private DefaultLifecycleObserver lifecycleObserver = new DefaultLifecycleObserver() {
        @Override
        public void onCreate(@NonNull LifecycleOwner owner) {
            DefaultLifecycleObserver.super.onCreate(owner);
        }

        @Override
        public void onStart(@NonNull LifecycleOwner owner) {
            DefaultLifecycleObserver.super.onStart(owner);
        }

        @Override
        public void onResume(@NonNull LifecycleOwner owner) {
            Log.d(TAG, "onAppForegrounded: ");
            onAppForegrounded = true;
            ShortcutBadger.applyCount(mContext, 0);
            dbhelper = DatabaseHandler.getInstance(mInstance);
            if (GetSet.isLogged() && NetworkStatus.isConnected() && !CallActivity.isInCall) {
                Log.e("checkBakup","1st");
                foregroundService = new Intent(ApplicationClass.this, ForegroundService.class);
                foregroundService.setAction("start");

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(foregroundService);
                } else {
                    startService(foregroundService);
                }
            } else if (GetSet.isLogged() && CallActivity.isInCall) {
                Log.e("checkBakup","second");
                /*if (callNotificationService != null) {
                    stopService(callNotificationService);
                    callNotificationService = null;
                }*/
            }

        }

        @Override
        public void onPause(@NonNull LifecycleOwner owner) {
            onAppForegrounded = false;
            Log.e("checkHiddy","onpause");
            DefaultLifecycleObserver.super.onPause(owner);
        }

        @Override
        public void onStop(@NonNull LifecycleOwner owner) {
            Log.d(TAG, "onAppBackgrounded: "+ CallActivity.isInCall);
            Log.e("checkHiddy","onstop");
            onAppForegrounded = false;
            if (!onShareExternal && !CallActivity.isInCall) {
                if (!ExternalUploadService.IS_FILE_UPLOADING) {
                    if (socketConnection != null) {
                        socketConnection.goAway(groupList);
                        socketConnection.disconnect();
                    }
                }
                if (foregroundService != null) {
                    stopService(foregroundService);
                    foregroundService = null;
                }

                if (dbhelper != null) {
                    dbhelper.close();
                }
            }
            if (CallActivity.isInCall) {
                Log.e("checkBakup","onStop"+"callnot");
                callNotificationService = new Intent(getBaseContext(), CallNotificationService.class);
                if(Build.VERSION.SDK_INT==Build.VERSION_CODES.S){
                    Log.e("checkBakup","onStop"+"workerstart");
                    /*OneTimeWorkRequest request = new OneTimeWorkRequest.Builder ( BackupWorker.class ).addTag ( "BACKUP_WORKER_TAG" ).build ();
                    WorkManager.getInstance ( mContext ).enqueue ( request );*/
                    startService(callNotificationService);
                }
                else  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(callNotificationService);
                } else {
                    startService(callNotificationService);
                }
            }
        }

        @Override
        public void onDestroy(@NonNull LifecycleOwner owner) {
            if (callNotificationService != null) {
                stopService(callNotificationService);
                callNotificationService = null;
            }
            DefaultLifecycleObserver.super.onDestroy(owner);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);
        FirebaseAppCheck firebaseAppCheck = FirebaseAppCheck.getInstance();
        firebaseAppCheck.installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance());
        mInstance = this;
        pref = this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        isAppOpened = false;
        mContext = this;
        editor.putBoolean(Constants.TAG_IS_APP_OPENED, false).apply();
        initOneSignal();
        ProcessLifecycleOwner.get().getLifecycle().addObserver(lifecycleObserver);
//        EmojiManager.install(new IosEmojiProvider());
        FontsOverride.setDefaultFont(this, "MONOSPACE", "font_regular.ttf");
        Stetho.initializeWithDefaults(this);
        dbhelper = DatabaseHandler.getInstance(this);
        // for dark theme addon
        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this);
        String themePref = sharedPreferences.getString("themePref", ThemeHelper.DEFAULT_MODE);
        ThemeHelper.applyTheme(themePref);
        setTimeZone();
        isAppOpened = false;

        if (pref.getBoolean("isLogged", false)) {
            GetSet.setLogged(true);
            GetSet.setUserId(pref.getString("userId", null));
            GetSet.setUserName(pref.getString("userName", null));
            GetSet.setphonenumber(pref.getString("phoneNumber", null));
            GetSet.setcountrycode(pref.getString("countryCode", null));
            GetSet.setImageUrl(pref.getString("userImage", null));
            GetSet.setToken(pref.getString("token", null));
            GetSet.setAbout(pref.getString("about", null));
            GetSet.setPrivacyprofileimage(pref.getString("privacyprofileimage", null));
            GetSet.setPrivacylastseen(pref.getString("privacylastseen", null));
            GetSet.setPrivacyabout(pref.getString("privacyabout", null));
            socketConnection = SocketConnection.getInstance(this);
            groupList = new ArrayList<>();
            groupList.addAll(dbhelper.getGroupIdList());
            channelList = new ArrayList<>();
            channelList.addAll(dbhelper.getChannelIdList());
        }
    }

    // Showing network status in Snackbar
    public static void showSnack(final Context context, View view, boolean isConnected) {
        if (snackbar == null) {
            snackbar = Snackbar
                    .make(view, context.getString(R.string.network_failure), Snackbar.LENGTH_INDEFINITE)
                    .setAction("SETTINGS", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                            context.startActivity(intent);
                        }
                    });
            View sbView = snackbar.getView();
            TextView textView = sbView.findViewById(R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
        }

        if (!isConnected && !snackbar.isShown()) {
            snackbar.show();
        } else {
            snackbar.dismiss();
            snackbar = null;
        }
    }

    public static void showToast(final Context context, String text, int duration) {
        if(context.getApplicationContext()==null)
            return;
        if (toast == null ) {
            toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            toast.cancel();
            toast=null;
            toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

    /**
     * To convert the given dp value to pixel
     **/
    public static int dpToPx(Context context, int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int px = Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return px;
    }

    public static void hideSoftKeyboard(Activity context, View view) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        try {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            //Find the currently focused view, so we can grab the correct window token from it.
            View view = activity.getCurrentFocus();
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (view == null) {
                view = new View(activity);
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showKeyboard(Activity context, View view) {
        view.requestFocus();
        InputMethodManager keyboard = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        keyboard.showSoftInput(view, 0);
    }

    public static float pxToDp(Context context, float px) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return dp;
    }

    public static int getStatusBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    /**
     * Returns {@code null} if this couldn't be determined.
     */
    @SuppressLint("PrivateApi")
    public static Boolean hasNavigationBar() {
        try {
            Class<?> serviceManager = Class.forName("android.os.ServiceManager");
            IBinder serviceBinder = (IBinder) serviceManager.getMethod("getService", String.class).invoke(serviceManager, "window");
            Class<?> stub = Class.forName("android.view.IWindowManager$Stub");
            Object windowManagerService = stub.getMethod("asInterface", IBinder.class).invoke(stub, serviceBinder);
            Method hasNavigationBar = windowManagerService.getClass().getMethod("hasNavigationBar");
            return (boolean) hasNavigationBar.invoke(windowManagerService);
        } catch (ClassNotFoundException | ClassCastException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            Log.w("YOUR_TAG_HERE", "Couldn't determine whether the device has a navigation bar", e);
            return false;
        }
    }

    public static String getContactName(Context context, String phoneNumber, String countryCode) {
        if (ContextCompat.checkSelfPermission(context, READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            ContentResolver cr = context.getContentResolver();
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
            Cursor cursor = null;
            String contactName = phoneNumber;
            if (!TextUtils.isEmpty(phoneNumber)) {
                cursor = cr.query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, ContactsContract.PhoneLookup._ID, null, null);
            }
            if (cursor == null) {
                return phoneNumber;
            }
//            else if(cursor.moveToFirst()) {
//                String id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
//            }
            if (cursor.moveToFirst()) {
                contactName = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME));
            }
            if (!cursor.isClosed()) {
                cursor.close();
            }
//            Log.d(TAG, "getContactName: " + contactName);
            return contactName;
        } else {
            if (countryCode != null && !countryCode.equals("")) {
                return "+" + countryCode + "-" + phoneNumber;
            } else {
                return phoneNumber;
            }
        }
    }

    public static HashMap<String, String> getContactOrNot(Context context, String phoneNumber) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_NAME, phoneNumber);
        map.put("isAlready", "false");
        if (ContextCompat.checkSelfPermission(context, READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            ContentResolver cr = context.getContentResolver();
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
            Cursor cursor = cr.query(uri, new String[]{ContactsContract.Contacts.DISPLAY_NAME}, null, null, null);
            if (cursor == null) {
                return map;
            }
            String contactName;
            if (cursor.moveToFirst()) {
                contactName = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Data.DISPLAY_NAME_PRIMARY));
                map.put(Constants.TAG_USER_NAME, contactName);
                /*if (!TextUtils.isEmpty(contactName)) {
                    map.put(Constants.TAG_USER_NAME, contactName);
                } else {
                    map.put(Constants.TAG_USER_NAME, phoneNumber);
                }*/
                map.put("isAlready", "true");
            }
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }
        return map;
    }

    /*public static HashMap<String, String> getContactOrNot(Context context, String phoneNumber, String countryCode) {
        String DISPLAY_NAME = ContactsContract.Contacts.DISPLAY_NAME_PRIMARY;
        String[] PROJECTION = {ContactsContract.Data.CONTACT_ID, ContactsContract.Contacts.HAS_PHONE_NUMBER,
                ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1};
        String SORT_ORDER = DISPLAY_NAME;
        String SELECTION = ContactsContract.CommonDataKinds.Phone.NUMBER + "=?" + " AND " +
                ContactsContract.Data.MIMETYPE + " != " + "'" + ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE + "'";
        String[] selectionArgs = {phoneNumber};

        HashMap<String, String> map = new HashMap<>();
        map.put(Constants.TAG_USER_NAME, phoneNumber);
        map.put("isAlready", "" + false);
        try {
            ContentResolver cr = context.getContentResolver();
//            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
//            Uri uri = Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, Uri.encode(phoneNumber));
            Uri uri = ContactsContract.Data.CONTENT_URI;
            Cursor cur = cr.query(uri, PROJECTION, SELECTION, selectionArgs, SORT_ORDER);
            if (cur.moveToFirst()) {
                do {
                    int hasPhone = cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                    int contactId = cur.getInt(cur.getColumnIndex(ContactsContract.Data.CONTACT_ID));
                    String name = cur.getString(cur.getColumnIndex(ContactsContract.Data.DISPLAY_NAME_PRIMARY));
                    String emailOrMobile = cur.getString(cur.getColumnIndex(ContactsContract.Data.DATA1));
                    PhoneNumberUtil phoneInstance = PhoneNumberUtil.getInstance();
                    Phonenumber.PhoneNumber phone;
                    String mobile = "";
                    if (emailOrMobile.startsWith("+")) {
                        try {
                            phone = phoneInstance.parse(emailOrMobile, null);
                            mobile = "" + phone.getNationalNumber();
                        } catch (Exception e) {
                            e.printStackTrace();
                            if (isValidPhoneNumber(emailOrMobile)) {
                                if (emailOrMobile.startsWith("0")) {
                                    mobile = emailOrMobile.replaceFirst("^0+(?!$)", "");
                                }
                                mobile = mobile.replaceAll("[^0-9]", "");
                            }
                        }
                    } else {
                        mobile = emailOrMobile.replaceAll("\\s", "").trim();
                    }
                    if (mobile.startsWith("0")) {
                        mobile = mobile.replaceFirst("^0+(?!$)", "");
                    }
                    mobile = mobile.replaceAll("[^0-9]", "");
                    Log.i(TAG, "getContactOrNot: " + emailOrMobile);
                    Log.e(TAG, "getContactOrNot: " + mobile);
                    Log.e(TAG, "getContactOrNot: " + name);
                    if (TextUtils.isEmpty(name))
                        name = cur.getString(cur.getColumnIndex(ContactsContract.Data.DISPLAY_NAME_ALTERNATIVE));
                    if (hasPhone > 0 && mobile.equals(phoneNumber)) {
                        map.put(Constants.TAG_USER_NAME, name);
                        map.put("isAlready", "" + true);
                        break;
                    }
                } while (cur.moveToNext());
            }
            if (cur != null) {
                cur.close();
            }
        } catch (Exception e) {
//            Log.e(TAG, "getContactOrNot: " + e.getMessage(), e);
        }
        return map;
    }*/

    public static boolean isValidPhoneNumber(String target) {
        if (target.length() < 7 || target.length() > 15) {
            return false;
        } else {
            return android.util.Patterns.PHONE.matcher(target).matches();
        }
    }

    public static String getStatusDate() {
        try {
            DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
            Date netDate = (new Date());
            return sdf.format(netDate);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "xx";
        }
    }

    public static void preventMultiClick(View view) {
        view.setEnabled(false);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                view.setEnabled(true);
            }
        }, 500);
    }

    public static boolean isRTL() {
        return Locale.getDefault().getLanguage().equals("ar");
    }

    public static String encryptMessage(String message) {
        String encryptedMsg = "";
        if (!TextUtils.isEmpty(message)) {
            try {
                CryptLib cryptLib = new CryptLib();
                encryptedMsg = cryptLib.encryptPlainTextWithRandomIV(message, Constants.MESSAGE_CRYPT_KEY);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return encryptedMsg;
    }

    public static String decryptMessage(String message) {
        if (!TextUtils.isEmpty(message)) {
            try {
                CryptLib cryptLib = new CryptLib();
                message = cryptLib.decryptCipherTextWithRandomIV(message, Constants.MESSAGE_CRYPT_KEY);
            } catch (Exception e) {
                Log.e(TAG, "decryptMessage: " + e.getMessage());
//                e.printStackTrace();
            }
            return message;
        }
        return "";
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        ShortcutBadger.removeCount(this);
    }

    public static void setTimeZone() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    TrueTime.build().initialize();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void initOneSignal() {
        OSInAppMessageLifecycleHandler handler = new OSInAppMessageLifecycleHandler() {
            @Override
            public void onWillDisplayInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onWillDisplayInAppMessage");
            }

            @Override
            public void onDidDisplayInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onDidDisplayInAppMessage");
            }

            @Override
            public void onWillDismissInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onWillDismissInAppMessage");
            }

            @Override
            public void onDidDismissInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onDidDismissInAppMessage");
            }
        };

        OneSignal.setInAppMessageLifecycleHandler(handler);
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        // OneSignal Initialization
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);

        OneSignal.setNotificationOpenedHandler((OneSignal.OSNotificationOpenedHandler)
                new ExampleNotificationOpenedHandler(this));
        OneSignal.unsubscribeWhenNotificationsAreDisabled(true);
    }

    public static InputStream getInputStream(String src) {
        InputStream inputStream = null;
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            inputStream = connection.getInputStream();
            return inputStream;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Bitmap getRotatedBitmap(ExifInterface exifInterface, Bitmap bitmap) {
        int rotation = 0;
        rotation = getRotation(exifInterface);
        Matrix matrix = new Matrix();
        if (rotation != 0) {
            matrix.postRotate(rotation);
        }
        Bitmap rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return rotatedBitmap;
    }

    public static int getRotation(ExifInterface exifInterface) {
        int rotation = 0;
        int orientation = exifInterface.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_UNDEFINED);
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                rotation = 90;
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                rotation = 180;
                break;
            case ExifInterface.ORIENTATION_ROTATE_270:
                rotation = 270;
                break;
        }
//        Log.d(TAG, "getRotation: " + orientation);
//        Log.d(TAG, "getRotation: " + rotation);
        return rotation;
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    @Override
    protected void attachBaseContext(Context context) {
        mContext = this;
        super.attachBaseContext(LocaleManager.setLocale(context));
        MultiDex.install(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LocaleManager.setLocale(this);
    }

    public void setConnectivityListener(NetworkReceiver.ConnectivityReceiverListener listener) {
        NetworkReceiver.connectivityReceiverListener = listener;
    }

    public static boolean checkEnglish(String text) {
        return isRTL() && new Locale(text).getLanguage().equals("en");
    }

    public static int getWidth(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        return displayMetrics.widthPixels;
    }

    public static String getMapUrl(String lat, String lng, Context context) {
        int size = dpToPx(context, 170);
        String mapUrl = "https://maps.googleapis.com/maps/api/staticmap?center=" + lat + "," + lng
                + "&zoom=14&size=" + size + "x" + size + "&maptype=roadmap&sensor=false&markers=" + lat + "," + lng +
                "&key=" + apikey;  //
        Log.d(TAG, "getMapUrl: " + mapUrl);
        return mapUrl;
    }

    public static void openImage(Context context, String url, String type, ImageView view) {
        preventMultiClick(view);
        Intent intent = new Intent(context, ImageOpenActivity.class);
        intent.putExtra(Constants.TAG_USER_IMAGE, url);
        intent.putExtra(Constants.TAG_FROM, type);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static void openImage(Context context, Uri uri, String type, ImageView view) {
        preventMultiClick(view);
        Intent intent = new Intent(context, ImageOpenActivity.class);
        intent.setData(uri);
        intent.putExtra(Constants.TAG_FROM, type);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static void pauseExternalAudio(Context context) {
        AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (manager.isMusicActive()) {
            Constants.isExternalPlay = true;
            Intent i = new Intent("com.android.music.musicservicecommand");
            i.putExtra("command", "pause");
            context.sendBroadcast(i);
        }
    }

    public static void resumeExternalAudio(Context context) {
        if (Constants.isExternalPlay) {
            Constants.isExternalPlay = false;
            Intent i = new Intent("com.android.music.musicservicecommand");
            i.putExtra("command", "play");
            context.sendBroadcast(i);
        }
    }

    public static boolean isStringNotNull(String value) {
        return value != null && !TextUtils.isEmpty(value);
    }

}
