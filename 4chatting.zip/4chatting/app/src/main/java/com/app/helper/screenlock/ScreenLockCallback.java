package com.app.helper.screenlock;

import android.content.Intent;

public interface ScreenLockCallback {
    void onUnableToVerify();

    void onError(Intent intent, String errorMessage);

    void onSuccess();
}
