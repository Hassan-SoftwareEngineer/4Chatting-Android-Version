package com.app.model;

import com.google.gson.annotations.SerializedName;

public class GroupMembersItem{

	@SerializedName("member_id")
	private String memberId;

	@SerializedName("member_role")
	private String memberRole;

	@SerializedName("member_no")
	private String memberNo;

	@SerializedName("member_picture")
	private String memberPicture;

	@SerializedName("member_name")
	private String memberName;

	@SerializedName("member_about")
	private String memberAbout;

	public String getMemberId(){
		return memberId;
	}

	public String getMemberRole(){
		return memberRole;
	}

	public String getMemberNo(){
		return memberNo;
	}

	public String getMemberPicture(){
		return memberPicture;
	}

	public String getMemberName(){
		return memberName;
	}

	public String getMemberAbout(){
		return memberAbout;
	}
}