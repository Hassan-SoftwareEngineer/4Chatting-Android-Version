package com.app.helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import androidx.exifinterface.media.ExifInterface;

import com.app.fourchattingapp.ApplicationClass;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by hitasoft on 27/6/18.
 */

public abstract class ImageDownloader extends AsyncTask<String, String, Bitmap> {
    private Context mContext;
    private static final String TAG = ImageDownloader.class.getSimpleName();
    private StorageManager storageManager;

    public ImageDownloader(Context mContext) {
        this.mContext = mContext;
        storageManager = StorageManager.getInstance(mContext);
    }

    @Override
    protected Bitmap doInBackground(String... strings) {
        if (strings.length == 0 || strings[0] == null) {
            return null;
        }
        Log.d(TAG, "doInBackground: " + strings[0]);
        InputStream inputStream = ApplicationClass.getInputStream(strings[0]);
        if(inputStream==null)return null;
        Bitmap bitmap = downloadImage(strings[0]);
        Bitmap rotatedBitmap = null;
        if (bitmap == null) {
            return null;
        } else {
            try {
                ExifInterface exif = new ExifInterface(inputStream);
                rotatedBitmap = ApplicationClass.getRotatedBitmap(exif, bitmap);
                return rotatedBitmap;
            } catch (NullPointerException e) {
                e.printStackTrace();
                Log.e(TAG, "doInBackground: " + e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public Bitmap downloadImage(String src) {
        try {
            InputStream inputStream = getInputStream(src);
            return BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public InputStream getInputStream(String src) {
        InputStream inputStream = null;
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            inputStream = connection.getInputStream();
            return inputStream;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected abstract void onPostExecute(Bitmap imgBitmap);

    protected abstract void onProgressUpdate(String... progress);
}
