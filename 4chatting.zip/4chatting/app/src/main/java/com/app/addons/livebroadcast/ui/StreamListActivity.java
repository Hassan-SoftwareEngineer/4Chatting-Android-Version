package com.app.addons.livebroadcast.ui;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.app.addons.livebroadcast.external.avloading.AVLoadingIndicatorView;
import com.app.addons.livebroadcast.helper.Utils;
import com.app.addons.livebroadcast.model.LiveStreamRequest;
import com.app.addons.livebroadcast.model.LiveStreamResponse;
import com.app.addons.livebroadcast.model.StreamDetails;
import com.app.addons.livebroadcast.utils.StreamConstants;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.app.fourchattingapp.R;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StreamListActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = StreamListActivity.class.getSimpleName();
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerView;
    private LinearLayout btnAddStream;
    private ImageView fab;
    private LinearLayout nullLay;
    private AppCompatImageView nullImage;
    private TextView nullText;
    private ImageView backbtn;
    private TextView title;
    private TextView txtSubtitle;
    private ImageView optionbtn;

    int currentPage = 0;
    private List<StreamDetails> streamLists = new ArrayList<>();
    private int visibleItemCount, totalItemCount, firstVisibleItem, previousTotal, visibleThreshold = 10;
    private GridLayoutManager mLayoutManager;
    private ApiInterface apiInterface;
    private Utils appUtils;
    private boolean isLoading = true;
    private String from;
    private Long selectedPosition;
    private List<Call<LiveStreamResponse>> liveStreamApiCall = new ArrayList<>();
    private Context context;
    private LiveStreamAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stream_list);
        context = this;
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        appUtils = new Utils(this);
        findViews();
        getFromIntent();
        initView();
    }

    private void findViews() {
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        recyclerView = findViewById(R.id.recyclerView);
        btnAddStream = findViewById(R.id.btnAddStream);
        fab = findViewById(R.id.fab);
        nullLay = findViewById(R.id.nullLay);
        nullImage = findViewById(R.id.nullImage);
        nullText = findViewById(R.id.nullText);
        backbtn = findViewById(R.id.backbtn);
        title = findViewById(R.id.title);
        txtSubtitle = findViewById(R.id.txtSubtitle);

        backbtn.setOnClickListener(this);
        btnAddStream.setOnClickListener(this);
    }

    private void getFromIntent() {
        from = getIntent().getStringExtra(Constants.TAG_FROM);
    }

    private void initView() {
        nullImage.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.no_video));
        swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.colorPrimary), ContextCompat.getColor(this, R.color.colorPrimaryDark));
        title.setText(getString(R.string.live_streams));
        title.setVisibility(View.VISIBLE);
        backbtn.setVisibility(View.VISIBLE);
        backbtn.setEnabled(true);
        adapter = new LiveStreamAdapter(context, streamLists);
        mLayoutManager = new GridLayoutManager(context, 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return adapter.isPositionFooter(position) ? mLayoutManager.getSpanCount() : 1;
            }
        });

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                adapter.showLoading(false);
                streamLists.clear();
                adapter.notifyDataSetChanged();
                for (Call<LiveStreamResponse> liveStreamResponseCall : liveStreamApiCall) {
                    liveStreamResponseCall.cancel();
                }
                liveStreamApiCall = new ArrayList<>();
                previousTotal = 0;
                currentPage = 0;
                totalItemCount = 0;
                visibleItemCount = 0;
                firstVisibleItem = 0;
                getLiveStreams(currentPage);
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(final RecyclerView recyclerView, final int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(final RecyclerView rv, final int dx, final int dy) {
                visibleItemCount = recyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (dy > 0) {//check for scroll down
                    if (isLoading) {
                        if (totalItemCount > previousTotal) {
                            isLoading = false;
                            previousTotal = totalItemCount;
                            currentPage++;
                        }
                    }

                    if (!isLoading && (totalItemCount - visibleItemCount)
                            <= (firstVisibleItem + visibleThreshold)) {
                        // End has been reached
                        isLoading = true;
                        Log.i(TAG, "onScrolled: " + currentPage);
                        getLiveStreams(currentPage);
                    }
                }
            }
        });

        //To load first ten items
        swipeRefresh(true);
    }

    private void swipeRefresh(final boolean refresh) {
        swipeRefreshLayout.setRefreshing(refresh);
        if (refresh) {
            previousTotal = 0;
            currentPage = 0;
            totalItemCount = 0;
            visibleItemCount = 0;
            firstVisibleItem = 0;
            getLiveStreams(currentPage);
        }
    }

    public void getLiveStreams(int offset) {
        if (NetworkStatus.isConnected()) {
            nullLay.setVisibility(View.GONE);
            if (!swipeRefreshLayout.isRefreshing()) {
                adapter.showLoading(true);
            }

            LiveStreamRequest request = new LiveStreamRequest();
            request.setUserId(GetSet.getUserId());
            request.setProfileId(GetSet.getUserId());
            request.setSortBy(StreamConstants.TAG_RECENT);
            request.setLimit("" + StreamConstants.MAX_LIMIT);
            request.setOffset("" + (StreamConstants.MAX_LIMIT * offset));
            request.setType(StreamConstants.TAG_LIVE);
            Log.d(TAG, "getLiveStreamsParams: " + new Gson().toJson(request));
            Call<LiveStreamResponse> call = apiInterface.getCurrentStreams(GetSet.getToken(), request);
            liveStreamApiCall.add(call);
            call.enqueue(new Callback<LiveStreamResponse>() {
                @Override
                public void onResponse(Call<LiveStreamResponse> call, Response<LiveStreamResponse> response) {
                    Log.d(TAG, "getLiveStreamsRes: " + new Gson().toJson(response.body()));
                    if (response.isSuccessful()) {
                        if (response.body().getStatus().equals(Constants.TAG_TRUE)) {
                            nullLay.setVisibility(View.GONE);
                            streamLists.addAll(response.body().getResult());
                        }
                    }
                    if (streamLists.size() == 0) {
                        nullImage.setImageResource(R.drawable.no_video);
                        nullText.setText(getString(R.string.no_videos));
                        nullLay.setVisibility(View.VISIBLE);
                    } else {
                        nullLay.setVisibility(View.GONE);
                    }

                    if (swipeRefreshLayout.isRefreshing()) {
                        swipeRefresh(false);
                        isLoading = true;
                    }
                    adapter.showLoading(false);
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onFailure(Call<LiveStreamResponse> call, Throwable t) {
                    call.cancel();
                    Log.e(TAG, "getLiveStreams: " + t.getMessage());
                    if (currentPage != 0)
                        currentPage--;
                }
            });
        } else {
            if (currentPage != 0)
                currentPage--;
            if (!swipeRefreshLayout.isRefreshing()) {
                adapter.showLoading(false);
            } else {
                if (streamLists.size() == 0) {
                    nullLay.setVisibility(View.VISIBLE);
                    nullText.setText(getString(R.string.no_internet_connection));
                }
                swipeRefresh(false);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    private void openDeleteDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(StreamListActivity.this);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                deleteWatchHistory();
            }
        });
        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        Typeface typeface = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            typeface = getResources().getFont(R.font.font_regular);
        } else {
            typeface = ResourcesCompat.getFont(this, R.font.font_regular);
        }
        TextView textView = dialog.findViewById(android.R.id.message);
        textView.setTypeface(typeface);

        Button btn1 = dialog.findViewById(android.R.id.button1);
        btn1.setTypeface(typeface);

        Button btn2 = dialog.findViewById(android.R.id.button2);
        btn2.setTypeface(typeface);
    }

    public void deleteWatchHistory() {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backbtn:
                backPressed();
                break;

            case R.id.cancelbtn:
                openDeleteDialog(getString(R.string.really_remove_from_list));
                break;

            case R.id.btnAddStream:
                Intent stream = new Intent(context, CameraActivity.class);
                stream.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(stream);
                break;
        }
    }

    public class LiveStreamAdapter extends RecyclerView.Adapter {

        private final int VIEW_TYPE_ITEM = 0;
        private final int VIEW_TYPE_FOOTER = 1;
        List<StreamDetails> streamLists = new ArrayList<>();
        private boolean showLoading = false;
        Context context;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();

        public LiveStreamAdapter(Context context, List<StreamDetails> streamLists) {
            this.streamLists = streamLists;
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == VIEW_TYPE_ITEM) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home, parent, false);
                return new MyViewHolder(itemView);
            } else if (viewType == VIEW_TYPE_FOOTER) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.livza_progress, parent, false);
                return new LoadingViewHolder(view);
            }
            return null;
        }

        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int position) {
            if (viewHolder instanceof MyViewHolder) {
                final StreamDetails stream = streamLists.get(position);
                MyViewHolder holder = (MyViewHolder) viewHolder;
                holder.txtTitle.setText(stream.title);
                Glide.with(context).load(Constants.USER_IMG_PATH + stream.getPublisherImage())
                        .apply(new RequestOptions().error(R.drawable.profile_banner).placeholder(R.drawable.profile_banner).centerCrop())
                        .into(holder.imageThumbnail);

                if (stream.type.equals("live")) {
                    holder.txtDuration.setVisibility(View.GONE);
                    holder.txtLive.setVisibility(View.VISIBLE);
                    // holder.statusLay.setVisibility(View.VISIBLE);
                } else {
                    //     holder.duration.setText(stream.duration);
                    holder.txtDuration.setVisibility(View.VISIBLE);
                    if (!TextUtils.isEmpty(stream.getPlayBackDuration())) {
                        holder.txtDuration.setText(stream.getPlayBackDuration());
                    } else {
                        holder.txtDuration.setText("");
                    }
                    /*if (stream.getPlayBackDuration() == null && stream.getPlayBackUrl() != null) {
                        retriever = new MediaMetadataRetriever();
                        retriever.setDataSource(stream.getPlayBackUrl(), new HashMap<String, String>());
                        String mVideoDuration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:MM:SS");
                        Date date = new Date();
                        date.setTime(Long.parseLong(mVideoDuration));
                        holder.txtDuration.setText(dateFormat.format(date));
                    }*/

                    holder.txtLive.setVisibility(View.GONE);
                    //  holder.statusLay.setVisibility(View.GONE);
                }

                holder.txtUserName.setText(stream.getPostedBy());
                holder.txtViewCount.setText(stream.getWatchCount());

                holder.parentLay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (stream.type.equals(StreamConstants.TAG_LIVE)) {
                            ApplicationClass.pauseExternalAudio(context);
                            Intent i = new Intent(context, SubscribeActivity.class);
                            Bundle arguments = new Bundle();
                            arguments.putSerializable(StreamConstants.TAG_STREAM_DATA, stream);
                            i.putExtra(Constants.TAG_FROM, StreamConstants.TAG_SUBSCRIBE);
                            i.putExtras(arguments);
                            startActivity(i);
                        } else {
                            ApplicationClass.pauseExternalAudio(context);
                            Intent intent = new Intent(context, PlayerActivity.class);
                            selectedPosition = (long) position;
                            intent.putExtra(StreamConstants.TAG_STREAM_DATA, stream);
                            intent.putExtra(Constants.TAG_FROM, StreamConstants.TAG_RECENT);
                            startActivityForResult(intent, StreamConstants.DELETE_REQUEST_CODE);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemViewType(int position) {
            if (showLoading && isPositionFooter(position))
                return VIEW_TYPE_FOOTER;
            return VIEW_TYPE_ITEM;
        }

        @Override
        public int getItemCount() {
            int itemCount = streamLists.size();
            if (showLoading)
                itemCount++;
            return itemCount;
        }

        public boolean isPositionFooter(int position) {
            return position == getItemCount() - 1 && showLoading;
        }

        public void showLoading(boolean value) {
            showLoading = value;
        }

        public class LoadingViewHolder extends RecyclerView.ViewHolder {
            AVLoadingIndicatorView progress;
            FrameLayout progressLay;

            public LoadingViewHolder(View view) {
                super(view);
                progress = view.findViewById(R.id.progress);
                progressLay = view.findViewById(R.id.progressLay);
            }
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView imageThumbnail, iconView;
            TextView txtViewCount, txtDuration, txtTitle, txtUserName, txtLive;
            RelativeLayout statusLay, parentLay;

            public MyViewHolder(View view) {
                super(view);
                imageThumbnail = view.findViewById(R.id.imageThumbnail);
                iconView = view.findViewById(R.id.iconView);
                txtViewCount = view.findViewById(R.id.txtViewCount);
                txtDuration = view.findViewById(R.id.txtDuration);
                txtTitle = view.findViewById(R.id.txtTitle);
                txtUserName = view.findViewById(R.id.txtUserName);
                statusLay = view.findViewById(R.id.statusLay);
                txtLive = view.findViewById(R.id.txtLive);
                parentLay = view.findViewById(R.id.parentLay);
            }

        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == StreamConstants.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (selectedPosition != null) {
                streamLists.remove(selectedPosition.intValue());
                adapter.notifyItemRemoved(selectedPosition.intValue());
                adapter.notifyItemRangeChanged(selectedPosition.intValue(), (adapter.getItemCount() - selectedPosition.intValue()));
                selectedPosition = null;
            }
        }
    }
}
