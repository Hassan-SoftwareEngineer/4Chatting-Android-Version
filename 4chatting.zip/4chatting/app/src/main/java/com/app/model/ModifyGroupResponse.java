package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModifyGroupResponse {

    @SerializedName("result")
    private Result result;

    @SerializedName("status")
    private String status;

    public Result getResult() {
        return result;
    }

    public String getStatus() {
        return status;
    }

    public class Result {

        @SerializedName("group_name")
        private String groupName;

        @SerializedName("group_members")
        private List<GroupMembersItem> groupMembers;

        @SerializedName("group_image")
        private String groupImage;

        @SerializedName("__v")
        private int V;

        @SerializedName("modified_by")
        private String modifiedBy;

        @SerializedName("created_at")
        private String createdAt;

        @SerializedName("_id")
        private String id;

        @SerializedName("modified_at")
        private String modifiedAt;

        @SerializedName("group_admin_id")
        private String groupAdminId;

        public String getGroupName() {
            return groupName;
        }

        public List<GroupMembersItem> getGroupMembers() {
            return groupMembers;
        }

        public String getGroupImage() {
            return groupImage;
        }

        public int getV() {
            return V;
        }

        public String getModifiedBy() {
            return modifiedBy;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public String getId() {
            return id;
        }

        public String getModifiedAt() {
            return modifiedAt;
        }

        public String getGroupAdminId() {
            return groupAdminId;
        }
    }
}