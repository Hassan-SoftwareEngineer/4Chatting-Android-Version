package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ChannelInfoResponse {
    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public List<ChannelResult.Result> result;
}
