package com.app.fourchattingapp;

import static android.Manifest.permission.READ_CONTACTS;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;

import com.app.fourchattingapp.legals.PermissionsDialog;
import com.app.model.CheckForUpdateResponse;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.app.helper.StorageManager;
import com.app.helper.ThemeHelper;
import com.app.helper.Utils;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;
import com.onesignal.OSSubscriptionObserver;
import com.onesignal.OSSubscriptionStateChanges;
import com.onesignal.OneSignal;

import java.io.File;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends BaseActivity implements OSSubscriptionObserver {
    private static final String TAG = SplashActivity.class.getSimpleName();
    private static final int SPLASH_TIME_OUT = 2000;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    private ApiInterface apiInterface;
    private boolean updateAvailable = false;
    String oneSignalId = null;
    private static String[] REQUIRED_PERMISSIONS = new String[]{READ_CONTACTS};
    private ActivityResultLauncher<Intent> screenLockResultLauncher;
    private StorageManager storageManager;
    private Utils utils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow(); // in Activity's onCreate() for instance
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        SharedPreferences sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this);
        String themePref = sharedPreferences.getString("themePref", ThemeHelper.DEFAULT_MODE);
        ThemeHelper.applyTheme(themePref);
        getDisplayWidthHeight();
        utils = new Utils(this);

        pref = getApplicationContext().getSharedPreferences(Constants.SHARED_PREFERENCE, MODE_PRIVATE);
        editor = pref.edit();
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        storageManager = StorageManager.getInstance(this);
        storageManager.deleteCacheDirs();
        OneSignal.addSubscriptionObserver(this);
        ApplicationClass.isAppOpened = false;
//        initActivityResultLauncher();
        setContentView(R.layout.activity_splash);
//        getDefaultChatWallpaper();
//        checkIsFromLink();
//        initBioMetric();
//        checkDeviceLockEnabled();
        goToHomePage();
    }

    private void initActivityResultLauncher() {
        screenLockResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            editor.putBoolean(Constants.TAG_IS_APP_OPENED, true).apply();
                            goToHomePage();
                        } else {
                            makeToast(getString(R.string.unable_to_verify));
                            finishAffinity();
                        }
                    }
                });
    }

    private void goToHomePage() {
        checkForUpdates();
        if (pref.getBoolean("isLogged", false)) {
            GetSet.setLogged(true);
            GetSet.setUserId(pref.getString("userId", null));
            GetSet.setUserName(pref.getString("userName", null));
            GetSet.setphonenumber(pref.getString("phoneNumber", null));
            GetSet.setcountrycode(pref.getString("countryCode", null));
            GetSet.setImageUrl(pref.getString("userImage", null));
            GetSet.setToken(pref.getString("token", null));
            GetSet.setAbout(pref.getString("about", null));
        }
        checkPermissions();
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {

    }

    public void onOSSubscriptionChanged(OSSubscriptionStateChanges stateChanges) {
        if (!stateChanges.getFrom().isSubscribed() &&
                stateChanges.getTo().isSubscribed()) {
            // get player ID
            if (stateChanges.getTo().getUserId() != null) {
                oneSignalId = stateChanges.getTo().getUserId();
            }
        }
        Log.i(TAG, "onOSSubscriptionChanged: " + stateChanges);
    }

    private void checkForUpdates() {
        Call<CheckForUpdateResponse> call3 = apiInterface.checkForUpdates();
        call3.enqueue(new Callback<CheckForUpdateResponse>() {
            @Override
            public void onResponse(Call<CheckForUpdateResponse> call, Response<CheckForUpdateResponse> response) {
                if (response.isSuccessful()) {
                    CheckForUpdateResponse data = response.body();
                    //Addon Live Stream
                    if (Constants.ADDON_LIVE_STREAM_ENABLED) {
                        if (data != null && data.getBaseUrl() != null) {
                            /*editor.putString(StreamConstants.TAG_STREAM_BASE_URL, data.getBaseUrl());
                            editor.putString(StreamConstants.TAG_API_URL, data.getApiUrl());
                            editor.putString(StreamConstants.TAG_VOD_URL, data.getVodUrl());
                            editor.apply();*/
                        }
                    }
                    PackageInfo packageInfo = null;
                    try {
                        packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                        int versionCode = packageInfo.versionCode;
                        if (data.getAndroidVersion() != null && Long.parseLong(data.getAndroidVersion())
                                > versionCode) {
                            updateAvailable = true;
                            updateConfirmDialog(data);
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<CheckForUpdateResponse> call, Throwable t) {
                Log.e(TAG, "checkForUpdates: " + t.getMessage());
                call.cancel();
            }
        });
    }

    private void updateConfirmDialog(CheckForUpdateResponse data) {
        final Dialog dialog = new Dialog(SplashActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 85 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.yes));
        no.setText(getString(R.string.no));
        title.setText(R.string.update_des);

        if (data.getAndroidUpdate().equals("1")) {
            no.setVisibility(View.GONE);
        } else {
            no.setVisibility(View.VISIBLE);
        }

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (CallActivity.isInCall) {

                } else {
                    openActNow();
                }
            }
        });

        if (!SplashActivity.this.isDestroyed() && !dialog.isShowing())
            dialog.show();
    }

    private void openActivity() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!updateAvailable) {
                    if (CallActivity.isInCall) {

                    } else {
                        openActNow();
                    }
                }
            }
        }, SPLASH_TIME_OUT);
    }

    private void openActNow() {
        GetSet.setInviteLink(null);
        if (GetSet.isLogged()) {
            Intent i = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(i);
        } else {
            Intent j = new Intent(SplashActivity.this, WelcomeActivity.class);
            startActivity(j);
        }

        finish();
//        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void requestPermission(String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(SplashActivity.this, permissions, requestCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.v(TAG, "requestCode=" + requestCode);
        switch (requestCode) {
            case 100:
                boolean isContactEnabled = false;

                for (String permission : permissions) {
                    if (permission.equals(READ_CONTACTS)) {
                        if (ActivityCompat.checkSelfPermission(SplashActivity.this, READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                            isContactEnabled = true;
                        }
                    }
                }

                if (!isContactEnabled) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
                            requestPermission(new String[]{READ_CONTACTS}, 100);
                        } else {
                            Toast.makeText(getApplicationContext(), R.string.contact_permission_error, Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getApplication().getPackageName()));
                            intent.addCategory(Intent.CATEGORY_DEFAULT);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                } else {
                    openActivity();
                }

                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void showPermissionDialog() {
        @SuppressWarnings("LogNotTimber")
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager != null && !fragmentManager.isDestroyed()) {
            PermissionsDialog d = new PermissionsDialog.Builder(SplashActivity.this)
                    .setOnDialogActionsListener(new PermissionsDialog.DialogActionListener() {
                        @Override
                        public void affirmative() {
                            Log.d(TAG, String.format("Permission Dialog: %s", "affirmative"));
                            if (!requestPermissions()) {
                                openActivity();
                            }
                        }

                        @Override
                        public void onCanceled() {
                            Log.d(TAG, String.format("Permission Dialog: %s", "canceled"));
                            finishAndRemoveTask();
                        }
                    })
                    .build();
            d.setCancelable(false);
            d.showNow(fragmentManager, PermissionsDialog.TAG);
        }
    }

    private void checkPermissions() {
        if (!permissionsGranted())
            showPermissionDialog();
        else if (!requestPermissions()) {
            openActivity();
        }
    }

    private void getDefaultChatWallpaper() {
        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        Glide.with(getApplicationContext())
                .asBitmap()
                .load(R.drawable.chat_bg)
                .centerCrop()
                .override(displayWidth - ApplicationClass.dpToPx(getApplicationContext(), (int) Math.round((actionBarHeight + (actionBarHeight * 0.2)))), displayHeight - ApplicationClass.dpToPx(getApplicationContext(), actionBarHeight) - ApplicationClass.dpToPx(getApplicationContext(), actionBarHeight))
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap scaledBitmap, @Nullable Transition<? super Bitmap> transition) {
                        String fileName = getString(R.string.wallpaper) + ".jpg";
                        File wallpaper = storageManager.saveBitmapInExternal(scaledBitmap, fileName, StorageManager.TAG_WALLPAPER);
                        Log.d(TAG, "onResourceReady: " + wallpaper);
                        editor.putString(Constants.TAG_DEFAULT_WALLPAPER, "" + wallpaper.getAbsolutePath());
                        editor.apply();
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });
    }

    private boolean requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 100);
            return true;
        }

        return false;
    }

    private boolean permissionsGranted() {
        for (String p : REQUIRED_PERMISSIONS)
            if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_DENIED)
                return false;
        return true;
    }
}
