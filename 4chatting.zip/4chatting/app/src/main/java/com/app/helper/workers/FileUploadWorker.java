package com.app.helper.workers;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.helper.StorageManager;
import com.app.fourchattingapp.ApplicationClass;
import com.app.model.MessagesData;
import com.google.gson.Gson;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.ProgressRequestBody;
import com.app.helper.SocketConnection;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;

public class FileUploadWorker extends Worker implements ProgressRequestBody.UploadCallbacks {
    private static final String TAG = FileUploadWorker.class.getSimpleName();
    private Context mContext;
    public static boolean IS_FILE_UPLOADING = false;
    NotificationManager mNotifyManager;
    NotificationCompat.Builder mBuilder;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    StorageManager storageManager;
    String uploadFilePath, chatType, thumbnail = null;
    String messageId;
    public static int NOTIFICATION_ID = 2;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private MessagesData mdata;

    public FileUploadWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params) {
        super(context, params);
        this.mContext = context;
        this.storageManager = StorageManager.getInstance(context);
        IS_FILE_UPLOADING = true;
        dbhelper = DatabaseHandler.getInstance(context);
        socketConnection = SocketConnection.getInstance(context);
        storageManager = StorageManager.getInstance(context);
    }

    @NonNull
    @Override
    public Result doWork() {
        Result result = null;
        // Do the work here--in this case, download the file.
        String dataString = getInputData().getString(Constants.TAG_DATA);
        Log.d(TAG, "doWork: " + dataString);
        mdata = new Gson().fromJson(dataString, MessagesData.class);
        messageId = mdata.message_id;
        uploadFilePath = getInputData().getString("filepath");
        chatType = getInputData().getString("chatType");
        thumbnail = getInputData().getString(Constants.TAG_THUMBNAIL);
        //Transform a json to java object

        if (chatType.equals(Constants.TAG_CHAT)) {
            result = uploadChat();
        } else if (chatType.equals(Constants.TAG_STATUS)) {
            uploadStatus();
        }
        return result;
    }

    private Result uploadChat() {
        Log.e("checkData","-"+uploadFilePath);
        boolean blockedMe = getInputData().getBoolean(Constants.TAG_BLOCKED_ME, false);
        ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
        MultipartBody.Part filePart = MultipartBody.Part.createFormData("attachment", new File(uploadFilePath).getName(), fileBody);

        ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<Map<String, String>> call3 = apiInterface.upchat(GetSet.getToken(), filePart, userid);
        try {
            Response<Map<String, String>> response = call3.execute();

            if (response.isSuccessful()) {
                try {
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String newFileName = userdata.get(Constants.TAG_USER_IMAGE);
                        try {
                            boolean fileStatus;
                            switch (mdata.message_type) {
                                case Constants.TAG_AUDIO:
                                    fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_AUDIO);
                                    break;
                                case Constants.TAG_VIDEO:
                                    fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_VIDEO);
                                    break;
                                case Constants.TAG_DOCUMENT:
                                default:
                                    fileStatus = storageManager.renameFile(null, uploadFilePath, newFileName, StorageManager.TAG_DOCUMENT);
                                    break;
                            }
                            if (fileStatus) {
//                                            if (!blockedMe) {
                                JSONObject jobj = new JSONObject();
                                JSONObject message = new JSONObject();
                                message.put(Constants.TAG_USER_ID, mdata.user_id);
                                message.put(Constants.TAG_USER_NAME, mdata.user_name);
                                message.put(Constants.TAG_MESSAGE_TYPE, mdata.message_type);
                                message.put(Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
                                message.put(Constants.TAG_THUMBNAIL, thumbnail != null ? ApplicationClass.encryptMessage(thumbnail) : "");
                                message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(mdata.message));
                                message.put(Constants.TAG_CHAT_TIME, DateUtils.getInstance(mContext).getCurrentUTCTime());
                                message.put(Constants.TAG_CHAT_ID, mdata.chat_id);
                                message.put(Constants.TAG_MESSAGE_ID, mdata.message_id);
                                message.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
                                message.put(Constants.TAG_SENDER_ID, mdata.user_id);
                                message.put(Constants.TAG_BLOCK_STATUS, "" + blockedMe);
                                message.put(Constants.TAG_BLOCKED_BY, blockedMe ? mdata.receiver_id : "");
                                message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);
                                message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                                jobj.put(Constants.TAG_SENDER_ID, mdata.user_id);
                                jobj.put(Constants.TAG_RECEIVER_ID, mdata.receiver_id);
                                jobj.put("message_data", message);
                                socketConnection.startChat(jobj);
//                                            }

                                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_ATTACHMENT, ApplicationClass.encryptMessage(newFileName));
                                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_THUMBNAIL, ApplicationClass.encryptMessage(thumbnail));
                                dbhelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "completed");

                                mBuilder.setProgress(0, 0, false);
                                mBuilder.setContentText(mContext.getString(R.string.file_uploaded));
                                mNotifyManager.cancel("progress", 2);
                                mNotifyManager.notify(2, mBuilder.build());

                                socketConnection.setUploadingListen(chatType, mdata.message_id, newFileName, "completed", null);
                                return Result.success();
                            } else {
                                return setErrorUpload();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            return setErrorUpload();
                        }
                    } else {
                        return setErrorUpload();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return setErrorUpload();
                }
            } else {
                return setErrorUpload();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return setErrorUpload();
        }
    }

    private void uploadStatus() {
        ProgressRequestBody fileBody = new ProgressRequestBody(new File(uploadFilePath), this);
        MultipartBody.Part filePart = MultipartBody.Part.createFormData("attachment", new File(uploadFilePath).getName(), fileBody);

        ApiInterface apiInterface = ApiClient.getUploadClient().create(ApiInterface.class);
        RequestBody userid = RequestBody.create(GetSet.getUserId(), MediaType.parse("multipart/form-data"));
        Call<Map<String, String>> call = apiInterface.upchat(GetSet.getToken(), filePart, userid);
        try {
            Response<Map<String, String>> response = call.execute();
            if (response.isSuccessful()) {
                try {
                    Log.v(TAG, "uploadStatusResponse= " + response.body());
                    Log.v(TAG, "filepath= " + uploadFilePath);
                    Map<String, String> userdata = response.body();
                    if (userdata.get(Constants.TAG_STATUS).equals("true")) {
                        String apiFileName = userdata.get(Constants.TAG_USER_IMAGE);
                        File checkFile = storageManager.saveStatusFile(null, new File(uploadFilePath), apiFileName, Constants.TAG_SENT);
                        Log.e("checkData","moveodPath"+"-"+checkFile.exists()+" length "+checkFile.length());
//                                boolean fileStatus = storageManager.moveFilesToSentPath(FileUploadService.this, StorageManager.TAG_VIDEO_SENT, uploadFilePath, apiFileName);
                        mBuilder.setProgress(0, 0, false);
                        mBuilder.setContentText(mContext.getString(R.string.file_uploaded));
                        mNotifyManager.cancel("progress", 2);
                        mNotifyManager.notify(2, mBuilder.build());

                        socketConnection.setUploadingListen(chatType, "", apiFileName, "completed", apiFileName);
                        // Indicate whether the work finished successfully with the Result

                    } else {
                        setStatusErrorUpload();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    setStatusErrorUpload();
                }
            } else {
                setStatusErrorUpload();
            }
        } catch (IOException e) {
            e.printStackTrace();
            setStatusErrorUpload();
        }
    }

    private Result setErrorUpload() {
        dbhelper.updateMessageData(mdata.message_id, Constants.TAG_PROGRESS, "error");
        socketConnection.setUploadingListen(chatType, mdata.message_id, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(mContext.getString(R.string.file_upload_error));
        mNotifyManager.cancel("progress", 2);
        mNotifyManager.notify(2, mBuilder.build());
        return Result.failure();
    }

    private void setStatusErrorUpload() {
        socketConnection.setUploadingListen(chatType, messageId, uploadFilePath, "error", null);
        mBuilder.setProgress(0, 0, false);
        mBuilder.setContentText(mContext.getString(R.string.file_upload_error));
        mNotifyManager.cancel(Constants.TAG_PROGRESS, 2);
        mNotifyManager.notify(2, mBuilder.build());
    }

    @Override
    public void onProgressUpdate(int percentage) {
        Log.d(TAG, "onProgressUpdate: " + percentage);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (percentage != 100) {
                    mBuilder.setProgress(100, percentage, false)
                            .setContentText(mContext.getString(R.string.uploading));
                    mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
                }
            }
        });
    }

    @Override
    public void onError() {

    }

    @Override
    public void onFinish() {
        mBuilder.setProgress(100, 100, false)
                .setContentText(mContext.getString(R.string.file_uploaded));
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mNotifyManager.cancel(NOTIFICATION_ID);
            }
        }, 1000);
    }

    @Override
    public void uploadStart() {
        createNotification();
    }

    private void createNotification() {
        Log.d(TAG, "createNotification: " + NOTIFICATION_ID);
        mNotifyManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = mContext.getString(R.string.notification_channel_foreground_service);
        CharSequence channelName = mContext.getString(R.string.app_name);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        mBuilder = new NotificationCompat.Builder(mContext, channelId);
        mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                .setContentText(mContext.getString(R.string.uploading))
                .setSmallIcon(R.drawable.notification)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true);
        mNotifyManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

}