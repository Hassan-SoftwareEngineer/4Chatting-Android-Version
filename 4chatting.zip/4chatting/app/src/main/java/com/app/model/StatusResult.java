package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.List;

public class StatusResult {
    @SerializedName("status")
    public String status;
    @SerializedName("result")
    public HashMap<String, Result> result;

    public class Result {
        @SerializedName("user_id")
        public String userId;
        @SerializedName("device_type")
        public String deviceType;
        @SerializedName("attachment")
        public String attachment;
        @SerializedName("message")
        public String message;
        @SerializedName("receiver_id")
        public String receiverId;
        @SerializedName("sender_id")
        public String senderId;
        @SerializedName("story_id")
        public String storyId;
        @SerializedName("story_type")
        public String storyType;
        @SerializedName("thumbnail")
        public String thumbnail;
        @SerializedName("story_date")
        public String storyDate;
        @SerializedName("story_time")
        public String storyTime;
        @SerializedName("expiry_time")
        public String expiryTime;
        @SerializedName("story_members")
        public List<StoryMembers> storyMembers;

    }

    public class StoryMembers {
        @SerializedName("member_id")
        public String memberId;
    }
}
