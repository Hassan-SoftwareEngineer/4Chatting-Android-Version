package com.app.helper;

import static com.app.helper.NetworkUtil.NOT_CONNECT;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by hitasoft on 24/1/18.
 */

public class NetworkReceiver extends BroadcastReceiver {

    private static final String TAG = NetworkReceiver.class.getSimpleName();
    public static ConnectivityReceiverListener connectivityReceiverListener;
    public static Boolean connect = false;
    private static Context mContext;

    public NetworkReceiver() {
        super();
    }

    public static boolean isConnected() {
        return connect;
    }

    @Override
    public void onReceive(Context context, Intent arg1) {
        mContext = context;
        String status = NetworkUtil.getConnectivityStatusString(context);
        if (status.equals(NOT_CONNECT)) {
            Log.e(TAG, "NetworkReceiver: NOT_CONNECT");// your code when internet lost
            connect = false;
        } else
            connect = true;

        if (connectivityReceiverListener != null) {
            connectivityReceiverListener.onNetworkConnectionChanged(connect);
        }
    }

    public interface ConnectivityReceiverListener {
        void onNetworkConnectionChanged(boolean isConnected);
    }
}
