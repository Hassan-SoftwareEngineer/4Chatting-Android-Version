package com.app.fourchattingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.util.Pair;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.app.model.HelpData;
import com.app.model.TermsAndPrivacyResponse;
import com.google.gson.Gson;
import com.app.external.CirclePageIndicator;
import com.app.helper.connectivity.NetworkStatus;
import com.app.fourchattingapp.R;
import com.app.fourchattingapp.view.LinkTextView;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WelcomeActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = WelcomeActivity.class.getSimpleName();
    static ViewPager desPager;
    TextView agree;
    CheckBox btnTerms;
    CirclePageIndicator pagerIndicator;
    ProgressDialog progressDialog;
    private LinkTextView linkTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        agree = findViewById(R.id.agree);
        pagerIndicator = findViewById(R.id.pagerIndicator);
        desPager = findViewById(R.id.desPager);
        btnTerms = findViewById(R.id.btnTerms);
        linkTextView = findViewById(R.id.linkTextView);

        String termsAndConditions = getString(R.string.terms_and_conditions);
        String privacyPolicy = getString(R.string.privacy_policy);

        linkTextView.makeLinks(new ArrayList<Pair<String, View.OnClickListener>>() {{
            add(Pair.create(termsAndConditions, v -> openLegal("tos")));
            add(Pair.create(privacyPolicy, v -> openLegal("privacy")));
        }});

        agree.setEnabled(btnTerms.isChecked());
        btnTerms.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                agree.setEnabled(isChecked);
            }
        });
        agree.setOnClickListener(this);

        String[] names = {getString(R.string.welcome_des1), getString(R.string.welcome_des2), getString(R.string.welcome_des3)};
        DesPagerAdapter desPagerAdapter = new DesPagerAdapter(WelcomeActivity.this, names);
        desPager.setAdapter(desPagerAdapter);
        pagerIndicator.setViewPager(desPager);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);


    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (progressDialog != null) {
            progressDialog.dismiss();
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.agree:
                if (NetworkStatus.isConnected()) {
                    if (progressDialog != null && !progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                    startActivity(new Intent(this, MobileNumberActivity.class));
                } else {
                    makeToast(getString(R.string.no_internet_connection));
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    class DesPagerAdapter extends PagerAdapter {

        Context context;
        LayoutInflater inflater;
        String[] names;

        public DesPagerAdapter(Context act, String[] names) {
            this.names = names;
            this.context = act;
            inflater = (LayoutInflater) context
                    .getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return names.length;
        }

        @Override
        public Object instantiateItem(ViewGroup collection, final int position) {
            ViewGroup itemView = (ViewGroup) inflater.inflate(R.layout.welcome_des_text,
                    collection, false);

            TextView name = itemView.findViewById(R.id.name);
            TextView title = itemView.findViewById(R.id.title);
            ImageView image = itemView.findViewById(R.id.image);
            if (position == 0) {
                image.setImageDrawable(getResources().getDrawable(R.drawable.introscreen_01));
                title.setText(getString(R.string.welcome_title1));
            } else if (position == 1) {
                image.setImageDrawable(getResources().getDrawable(R.drawable.introscreen_02));
                title.setText(getString(R.string.favourites));
            } else if (position == 2) {
                image.setImageDrawable(getResources().getDrawable(R.drawable.introscreen_03));
                title.setText(getString(R.string.welcome_title3));
            }
            name.setText(names[position]);

            collection.addView(itemView, 0);
            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup collection, int position, Object view) {
            collection.removeView((ViewGroup) view);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Parcelable saveState() {
            return null;
        }
    }

    private void openLegal(@NonNull String type) {
        if (NetworkStatus.isConnected()) {
            if (progressDialog != null && !progressDialog.isShowing())
                progressDialog.show();
            Call<TermsAndPrivacyResponse> call = ApiClient.getClient().create(ApiInterface.class).termsAndPrivacy();
            Log.d(TAG, "termsAndPrivacy: " + call.request().url());
            call.enqueue(new Callback<TermsAndPrivacyResponse>() {
                @Override
                public void onResponse(Call<TermsAndPrivacyResponse> call, Response<TermsAndPrivacyResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        if (progressDialog != null && progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }
                        Log.i(TAG, "openLegal: " + new Gson().toJson(response.body()));
                        HelpData.Term term = new HelpData().new Term();
                        term._id = "0";
                        term.title = type.equals("tos") ? getString(R.string.terms_and_conditions) : getString(R.string.privacy_policy);
                        term.description = type.equals("tos") ? response.body().getResult().getTos() : response.body().getResult().getPrivacyPolicy();
                        term.type = type;
                        term.viewType = 0;
                        Intent web = new Intent(getApplicationContext(), HelpViewActivity.class);
                        web.putExtra("HELP", term);
                        startActivity(web);
                        //                    Intent i = new Intent(WelcomeActivity.this, AboutUs.class);
                        //                    if (type.equals("tos")) {
                        //                        i.putExtra(Constants.TAG_TITLE_M, getString(R.string.terms_and_conditions));
                        //                        i.putExtra(Constants.CONTENT, body.getResult().getTos());
                        //                    } else if (type.equals("privacy")) {
                        //                        i.putExtra(Constants.TAG_TITLE_M, getString(R.string.privacy_policy));
                        //                        i.putExtra(Constants.CONTENT, body.getResult().getPrivacyPolicy());
                        //                    }
                        //                    startActivity(i);
                    } else onFailure(call, new Exception("No response"));
                }

                @Override
                public void onFailure(Call<TermsAndPrivacyResponse> call, Throwable t) {
                    call.cancel();
                    progressDialog.dismiss();
                    Log.e(TAG, "openLegalOnFailure: " + t.getMessage());
                    Toast.makeText(getApplicationContext(), R.string.something_wrong,
                            Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            makeToast(getString(R.string.no_internet_connection));
        }
    }
}
