package com.app.helper.workers;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.app.helper.connectivity.NetworkStatus;
import com.google.gson.Gson;
import com.app.helper.DatabaseHandler;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.jetbrains.annotations.NotNull;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserIsActiveWorker extends Worker {
    private static final String TAG = UserIsActiveWorker.class.getSimpleName();
    private Context mContext;
    private DatabaseHandler dbHelper;

    public UserIsActiveWorker(
            @NonNull Context appContext,
            @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);
        mContext = appContext;
        dbHelper = DatabaseHandler.getInstance(mContext);
    }

    @NonNull
    @NotNull
    @Override
    public Result doWork() {
        if (NetworkStatus.isConnected()) {
            String contactId = getInputData().getString(Constants.TAG_USER_ID);
            ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
            Log.e("paramForUserexist","-"+contactId+" token "+GetSet.getToken());
            Call<Map<String,     String>> call3 = apiInterface.checkUserExists(GetSet.getToken(), contactId);
            call3.enqueue(new Callback<Map<String, String>>() {
                @Override
                public void onResponse(Call<Map<String, String>> call, Response<Map<String, String>> response) {
                    if (response.isSuccessful()) {
                        Map<String, String> data = response.body();
                        Log.e("checkUser","-"+new Gson().toJson(response.body()));
                        if (data.get(Constants.TAG_STATUS).equals("false")) {
                            dbHelper.updateContactInfo(contactId, Constants.TAG_DELETED_ACCOUNT, "1");
                        }
                    }
                }

                @Override
                public void onFailure(Call<Map<String, String>> call, Throwable t) {
                    call.cancel();
                }
            });
        }
        return Result.success();
    }
}
