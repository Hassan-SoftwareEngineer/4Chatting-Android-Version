package com.app.fourchattingapp;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.app.apprtc.util.AppRTCUtils;
import com.app.external.RecyclerItemClickListener;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.Utils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.connectivity.NetworkStatus;
import com.app.helper.event.UserBlockEvent;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by hitasoft on 29/7/18.
 */

public class CallFragment extends Fragment {
    private static final String TAG = CallFragment.class.getSimpleName();
    private Context mContext;
    public static CallFragment callFragment;
    ClearLogFunction clearLogFunction;
    RecyclerViewAdapter callAdapter;
    RecyclerView recyclerView;
    LinearLayout nullLay;
    TextView nullText;
    TextView title;
    LinearLayoutManager linearLayoutManager;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    boolean callLongPressed = false;
    private ArrayList<ContactsData.Result> callList = new ArrayList<>();
    private ArrayList<ContactsData.Result> selectedCallList = new ArrayList<>();
    private ActivityResultLauncher<String[]> callPermissionResult;

    public CallFragment() {
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    static CallFragment newInstance(ClearLogFunction image) {
        CallFragment fragment = new CallFragment();
        Bundle args = new Bundle();
        fragment.setClearLogFunction(image);
        return fragment;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (callList != null && !callList.isEmpty() && dbhelper != null) {
                for (ContactsData.Result map : callList) {
                    if (map.callStatus.equals(Constants.TAG_MISSED)
                            && map.isAlert.equals("0")) {
                        dbhelper.updateCallAlert(map.callId);
                    }
                }
            }
            if (SocketConnection.onUpdateTabIndication != null) {
                SocketConnection.onUpdateTabIndication.updateIndication();
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    private void setClearLogFunction(ClearLogFunction clearLogFunction) {
        this.clearLogFunction = clearLogFunction;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (mContext == null) mContext = getContext();
        View view = inflater.inflate(R.layout.fragment_group, container, false);
        nullLay = view.findViewById(R.id.nullLay);
        nullText = view.findViewById(R.id.nullText);
        recyclerView = view.findViewById(R.id.recyclerView);
        title=view.findViewById(R.id.recenttitle);
        title.setVisibility(View.VISIBLE);
        title.setText(getResources().getString(R.string.call_list));
        initPermissionLauncher();
        socketConnection = SocketConnection.getInstance(getActivity());
        dbhelper = DatabaseHandler.getInstance(getActivity());
        linearLayoutManager = new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);

        callList.clear();
        callList = dbhelper.getRecentCall();
        callAdapter = new RecyclerViewAdapter(getActivity(), callList);
        recyclerView.setAdapter(callAdapter);
        callAdapter.notifyDataSetChanged();
        nullText.setText(R.string.no_calls_yet_buddy);
        if (callList.size() == 0) {
            nullLay.setVisibility(View.VISIBLE);
        } else {
            nullLay.setVisibility(View.GONE);
        }

        /*if(!callList.isEmpty()){
            for(HashMap<String,String> map : callList){
                if(map.get(Constants.TAG_CALL_STATUS).equals("missed")
                        && map.get(Constants.TAG_IS_ALERT).equals("0")){
                    dbhelper.updateCallAlert(map.get(Constants.TAG_CALL_ID));
                }
            }
        }
        if (SocketConnection.onUpdateTabIndication != null) {
            SocketConnection.onUpdateTabIndication.updateIndication();
        }*/

        callFragment = this;

        recyclerView.addOnItemTouchListener(chatItemClick(getContext(), recyclerView));

        return view;
    }

    private void initPermissionLauncher() {
        callPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "onActivityResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) {
                        granted = false;
                        break;
                    }
                }

                if (granted) {

                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), x.getKey())) {
                                callPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
//                                makeToast(getString(R.string.call_permission_error));
                                PermissionsUtils.openPermissionDialog(mContext, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, PermissionsUtils.getCallPermissionError(mContext));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshAdapter();
    }

    public void refreshAdapter() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (callAdapter != null) {
                    callList.clear();
                    callList.addAll(dbhelper.getRecentCall());
                    callAdapter.notifyDataSetChanged();
                    if (SocketConnection.onUpdateTabIndication != null) {
                        SocketConnection.onUpdateTabIndication.updateIndication();
                    }
                }
                if (callList.size() == 0) {
                    nullLay.setVisibility(View.VISIBLE);
                } else {
                    nullLay.setVisibility(View.GONE);
                }
            }
        });
    }

    public RecyclerItemClickListener chatItemClick(Context mContext, final RecyclerView recyclerView) {
        return new RecyclerItemClickListener(mContext, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if (callLongPressed) {

                    if (callList.get(position).isSelected.equals("0")) {
                        callList.get(position).isSelected = "1";
                        selectedCallList.add(callList.get(position));
                    } else {
                        callList.get(position).isSelected = "0";
                        selectedCallList.remove(callList.get(position));
                    }
                    callAdapter.notifyItemChanged(position);
                    if (clearLogFunction != null)
                        clearLogFunction.isDeleteVisible(true, selectedCallList.size());

                    if (selectedCallList.isEmpty()) {
                        callLongPressed = false;
                        if (clearLogFunction != null)
                            clearLogFunction.isDeleteVisible(false, selectedCallList.size());
                    }
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {
                Log.d(TAG, "onItemLongClick: " + position);
                if (!callLongPressed) {
                    callLongPressed = true;
                    callList.get(position).isSelected = "1";
                    selectedCallList.add(callList.get(position));
                    callAdapter.notifyItemChanged(position);
                    if (clearLogFunction != null)
                        clearLogFunction.isDeleteVisible(true, selectedCallList.size());
                }
            }
        });
    }

    public void deleteCallLog(String type) {
        if (type.equals("delete")) {
            deleteCallConfirmDialog();
        } else {
            updateView();
        }
    }

    void updateView() {
        callLongPressed = false;
        for (int i = 0; i < callList.size(); i++) {
            ContactsData.Result map = callList.get(i);
            if (map.isSelected.equals("1")) {
                map.isSelected = "0";
                callAdapter.notifyItemChanged(i);
            }
        }
        if (!selectedCallList.isEmpty()) {
            selectedCallList.clear();
        }
    }

    private void deleteCallConfirmDialog() {
        final Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);
        yes.setText(getString(R.string.im_sure));
        no.setText(getString(R.string.nope));
        title.setText(R.string.really_delete_call_history
        );
        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                for (int i = 0; i < selectedCallList.size(); i++) {
                    ContactsData.Result map = selectedCallList.get(i);
                    dbhelper.deleteCallFromId(map.callId);
                }
                selectedCallList.clear();
                refreshAdapter();
                callLongPressed = false;
                if (clearLogFunction != null)
                    clearLogFunction.isDeleteVisible(false, selectedCallList.size());
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (clearLogFunction != null)
                    clearLogFunction.isDeleteVisible(false, selectedCallList.size());
                updateView();
            }
        });

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                updateView();
            }
        });

        dialog.show();
    }

    private void blockChatConfirmDialog(String userId) {
        final Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);

        yes.setText(getString(R.string.unblock));
        no.setText(getString(R.string.cancel));
        title.setText(R.string.unblock_message);

        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                    jsonObject.put(Constants.TAG_TYPE, "unblock");
                    Log.v(TAG, "block=" + jsonObject);
                    socketConnection.block(jsonObject);
                    dbhelper.updateBlockStatus(userId, Constants.TAG_BLOCKED_BYME, "unblock");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(UserBlockEvent event) {
        refreshAdapter();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        callFragment = null;
        EventBus.getDefault().unregister(this);
    }

    public interface ClearLogFunction {
        void isDeleteVisible(boolean isDelete, int count);
    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

        ArrayList<ContactsData.Result> callList = new ArrayList<>();
        Context mContext;
        int lastSelectedPosition = -1;
        boolean canSelect = false;

        public RecyclerViewAdapter(Context mContext, ArrayList<ContactsData.Result> callList) {
            this.callList = callList;
            this.mContext = mContext;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_call, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, int position) {
            final ContactsData.Result map = callList.get(position);
//            Log.i(TAG, "onBindViewHolder: " + new Gson().toJson(map));
            if (map.blockStatus.equals("block")) {
                Glide.with(mContext).load(R.drawable.temp).thumbnail(0.5f)
                        .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.add).override(ApplicationClass.dpToPx(mContext, 70)))
                        .into(holder.profileImage);
            } else {
                Glide.with(mContext).load(Constants.USER_IMG_PATH + map.user_image).thumbnail(0.5f)
                        .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(mContext, 70)))
                        .into(holder.profileImage);
            }
            holder.txtName.setText(map.user_name);
            if (map.callCreatedAt != null) {
                holder.txtTime.setText(DateUtils.getInstance(mContext).getRecentChatDateFromUTC(map.callCreatedAt));
            }

            if (map.type.equals("audio")) {
                holder.callType.setImageResource(R.drawable.call_blue);
            } else {
                holder.callType.setImageResource(R.drawable.video_blue);
            }

            switch ("" + map.callStatus) {
                case "incoming":
                    holder.statusIcon.setImageResource(R.drawable.incoming);
                    break;
                case Constants.TAG_MISSED:
                    holder.statusIcon.setImageResource(R.drawable.missed);
                    break;
                case "outgoing":
                    holder.statusIcon.setImageResource(R.drawable.outgoing);
                    break;
            }

            if (map.isSelected.equals("1")) {
                holder.callType.setVisibility(View.GONE);
                holder.itemView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.chat_selected));
            } else {
                holder.callType.setVisibility(View.VISIBLE);
                holder.itemView.setBackgroundColor(0);
            }

        }

        @Override
        public int getItemCount() {
            return callList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

            LinearLayout parentLay;
            TextView txtName, txtTime;
            CircleImageView profileImage;
            ImageView statusIcon, callType;
            View profileView;

            public MyViewHolder(View view) {
                super(view);

                parentLay = view.findViewById(R.id.parentLay);
                txtTime = view.findViewById(R.id.txtTime);
                txtName = view.findViewById(R.id.txtName);
                profileImage = view.findViewById(R.id.profileImage);
                profileView = view.findViewById(R.id.profileView);
                statusIcon = view.findViewById(R.id.statusIcon);
                callType = view.findViewById(R.id.callType);
                callType.setOnClickListener(this);
                profileImage.setOnClickListener(this);

            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.callType:
                        ContactsData.Result result = dbhelper.getContactDetail(callList.get(getAbsoluteAdapterPosition()).user_id);

                        if (callList.get(getAbsoluteAdapterPosition()).type.equals("audio")) {
                            if (!PermissionsUtils.checkCallPermissions(mContext, Constants.TAG_AUDIO)) {
                                callPermissionResult.launch(AppRTCUtils.MANDATORY_AUDIO_PERMISSIONS);
                            } else if (result.blockedbyme.equals("block")) {
                                blockChatConfirmDialog(result.user_id);
                            } else {
                                if (NetworkStatus.isConnected()) {
                                    ApplicationClass.preventMultiClick(callType);
                                    Utils.getInstance(CallFragment.this.mContext).makeCall(mContext, callList.get(getAbsoluteAdapterPosition()).user_id, Constants.TAG_SEND, Constants.TAG_AUDIO);
                                } else {
                                    ApplicationClass.showToast(mContext, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT);
                                }
                            }
                        } else {
                            if (!PermissionsUtils.checkCallPermissions(mContext, Constants.TAG_VIDEO)) {
                                callPermissionResult.launch(AppRTCUtils.MANDATORY_VIDEO_PERMISSIONS);
                            } else if (result.blockedbyme.equals("block")) {
                                blockChatConfirmDialog(result.user_id);
                            } else {
                                if (NetworkStatus.isConnected()) {
                                    ApplicationClass.preventMultiClick(callType);
                                    Utils.getInstance(CallFragment.this.mContext).makeCall(mContext, callList.get(getAbsoluteAdapterPosition()).user_id, Constants.TAG_SEND, Constants.TAG_VIDEO);
                                } else {
                                    ApplicationClass.showToast(mContext, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT);
                                }
                            }
                        }
                        break;
                    case R.id.profileImage:
                        break;

                }
            }
        }
    }
}
