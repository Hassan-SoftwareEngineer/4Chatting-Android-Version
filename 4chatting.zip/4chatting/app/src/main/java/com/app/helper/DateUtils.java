package com.app.helper;

import android.content.Context;
import android.util.Log;

import com.app.fourchattingapp.R;
import com.instacart.library.truetime.TrueTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {

    private static final String TAG = DateUtils.class.getSimpleName();
    private static DateUtils mInstance;
    private static Context mContext;
    private static final int SECOND_MILLIS = 1000;
    private static final int MINUTE_MILLIS = 60 * SECOND_MILLIS;
    private static final int HOUR_MILLIS = 60 * MINUTE_MILLIS;
    private static final int DAY_MILLIS = 24 * HOUR_MILLIS;
    public static final String UTC_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public DateUtils(Context mContext) {
        this.mContext = mContext;
    }

    public static DateUtils getInstance(Context mContext) {
        if (mInstance == null) {
            mInstance = new DateUtils(mContext);
        }
        return mInstance;
    }

    public String getCurrentUTCTime() {
        if (TrueTime.isInitialized()) {
            Date trueTime = TrueTime.now();
            DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN);
            TimeZone utcZone = TimeZone.getTimeZone("UTC");
            utcFormat.setTimeZone(utcZone);
            String currentUtc = utcFormat.format(trueTime);
//            Log.d(TAG, "getCurrentUTCTime:TrueTime " + currentUtc);
            return currentUtc;
        } else {
            DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, Locale.ENGLISH);
            TimeZone utcZone = TimeZone.getTimeZone("UTC");
            utcFormat.setTimeZone(utcZone);
            Date myDate = new Date();
            String currentUtc = utcFormat.format(myDate);
//            Log.d(TAG, "getCurrentUTCTime: " + currentUtc);
            return currentUtc;
        }
    }

    public Long getTimeInMillisFromUTC(String date) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, Locale.ENGLISH);
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Long tim = 0L;
        Date myDate = new Date();
        try {
            myDate = utcFormat.parse(date);
//        Log.i(TAG, "getTimeInMillisFromUTC: " + myDate.getTime());
            return myDate.getTime();
        } catch (ParseException | NullPointerException e) {
            e.printStackTrace();
            return tim;
        }
    }

    public static String getUTCFromTimeStamp(long timeStamp) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date myDate = new Date();
        myDate.setTime(timeStamp);
        return utcFormat.format(myDate);
    }

    public String getTimeFromUTC(String utcDate) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        DateFormat newFormat = new SimpleDateFormat("hh:mm a", LocaleManager.getLocale(mContext.getResources()));

        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date myDate = new Date();
        String newDate = "";
        try {
            myDate = utcFormat.parse(utcDate);
            newDate = newFormat.format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
//        Log.i(TAG, "getDateFromUTC: " + newDate);
        return newDate;
    }

    public static String getDateFromUTC(Context context, String date) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(context.getResources()));
        DateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd", LocaleManager.getLocale(context.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date myDate = new Date();
        String newDate = "";
        try {
            myDate = utcFormat.parse(date);
            newDate = newFormat.format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
//        Log.i(TAG, "getDateFromUTC: " + newDate);
        return newDate;
    }

    public String getCreatedAtDate(String utcTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date apiDate = null, utcDate = null;
        String returnDate = "";
        final String timeFormatString = "h:mm aa";
        final String dateTimeFormatString = "EEE, MMM d";
        Calendar smsTime = Calendar.getInstance();
        Calendar now = Calendar.getInstance();
        try {
            apiDate = utcFormat.parse(utcTime);
            utcDate = utcFormat.parse(getCurrentUTCTime());
            if (apiDate != null) {
                smsTime.setTime(apiDate);
            }
            if (utcDate != null) {
                now.setTime(utcDate);
            }
        } catch (ParseException | NullPointerException e) {
            e.printStackTrace();
        }
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE) &&
                now.get(Calendar.MONTH) == smsTime.get(Calendar.MONTH) &&
                now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(timeFormatString, smsTime.getTimeInMillis());
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            returnDate = mContext.getString(R.string.yesterday);
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(dateTimeFormatString, smsTime.getTimeInMillis());
        } else {
            returnDate = getDate("MMM dd yyyy", smsTime.getTimeInMillis());
        }

//        Log.i(TAG, "getCreatedAtDate: " + returnDate);
        return returnDate;
    }

    public String getChatDateFromUTC(String utcTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date apiDate, utcDate;
        String returnDate = "";
        try {
            apiDate = utcFormat.parse(utcTime);
            utcDate = utcFormat.parse(getCurrentUTCTime());
            returnDate = getChatDifference(apiDate, utcDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//        Log.i(TAG, "getChatDateFromUTC: " + returnDate);
        return returnDate;
    }

    private static String getChatDifference(Date apiDate, Date utcDate) {
        Calendar now = Calendar.getInstance();
        now.setTime(utcDate);
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTime(apiDate);
        String returnDate;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE) &&
                now.get(Calendar.MONTH) == smsTime.get(Calendar.MONTH) &&
                now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = mContext.getString(R.string.today);
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            returnDate = mContext.getString(R.string.yesterday);
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate("MMMM dd yyyy", smsTime.getTimeInMillis());
        } else {
            returnDate = getDate("MMMM dd yyyy", smsTime.getTimeInMillis());
        }
        return returnDate;
    }

    public String getRecentChatDateFromUTC(String utcTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date apiDate, utcDate;
        String returnDate = "";
        try {
            apiDate = utcFormat.parse(utcTime);
            utcDate = utcFormat.parse(getCurrentUTCTime());
            returnDate = getRecentChatDifference(apiDate, utcDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//        Log.i(TAG, "getRecentChatDateFromUTC: " + returnDate);
        return returnDate;
    }

    private String getRecentChatDifference(Date apiDate, Date utcDate) {
        final String timeFormatString = "h:mm aa";
        final String dateTimeFormatString = "EEE, MMM d";
        Calendar now = Calendar.getInstance();
        now.setTime(utcDate);
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTime(apiDate);
        String returnDate;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE) &&
                now.get(Calendar.MONTH) == smsTime.get(Calendar.MONTH) &&
                now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(timeFormatString, smsTime.getTimeInMillis());
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            returnDate = mContext.getString(R.string.yesterday);
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(dateTimeFormatString, smsTime.getTimeInMillis());
        } else {
            returnDate = getDate("MMM dd yyyy", smsTime.getTimeInMillis());
        }
//        Log.d(TAG, "getRecentChatDifference: " + returnDate);
        return returnDate;
    }

    public String getLastSeenFromUTC(String utcTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date apiDate, utcDate;
        String returnDate = "";
        try {
            apiDate = utcFormat.parse(utcTime);
            utcDate = utcFormat.parse(getCurrentUTCTime());
            returnDate = getLastSeenDifference(apiDate, utcDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

//        Log.i(TAG, "getChatDateFromUTC: " + returnDate);
        return returnDate;
    }

    private String getLastSeenDifference(Date apiDate, Date utcDate) {
        final String timeFormatString = "h:mm aa";
        final String dateTimeFormatString = "EEE, MMM d";
        Calendar now = Calendar.getInstance();
        now.setTime(utcDate);
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTime(apiDate);
        String returnDate;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE) &&
                now.get(Calendar.MONTH) == smsTime.get(Calendar.MONTH) &&
                now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(timeFormatString, smsTime.getTimeInMillis());
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            returnDate = mContext.getString(R.string.yesterday);
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            returnDate = getDate(dateTimeFormatString, smsTime.getTimeInMillis());
        } else {
            returnDate = getDate("MMM dd yyyy", smsTime.getTimeInMillis());
        }
//        Log.d(TAG, "getLastSeenDifference: " + returnDate);
        return returnDate;
    }

    private static String getDate(String format, long time) {
        java.text.DateFormat sdf = new SimpleDateFormat(format, Locale.ENGLISH);
        Date netDate = (new Date(time));
        return sdf.format(netDate);
    }

    /**
     * To convert timestamp to Time
     **/

    public String getStatusTime(String storyUTC) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date storyDate, nowDate;
        try {
            storyDate = utcFormat.parse(storyUTC);
            nowDate = utcFormat.parse(getCurrentUTCTime());
            long now = nowDate.getTime();
            long statusTime = storyDate.getTime();
            final long diff = now - statusTime;
            if (diff < MINUTE_MILLIS) {
                return mContext.getString(R.string.just_now);
            } else if (diff < 2 * MINUTE_MILLIS) {
                return " " + mContext.getString(R.string.a_minute_ago);
            } else if (diff < 50 * MINUTE_MILLIS) {
                String temp = diff / MINUTE_MILLIS + " " + mContext.getString(R.string.minutes_ago);
                Log.i(TAG, "getStatusTime: " + temp);
                return temp;
            } else if (diff < 120 * MINUTE_MILLIS) {
                return " " + mContext.getString(R.string.an_hour_ago);
            } else {
                SimpleDateFormat statusFormat = new SimpleDateFormat("h:mm a", Locale.ENGLISH);
                Calendar nowCalendar = Calendar.getInstance(Locale.ENGLISH);
                nowCalendar.setTimeZone(TimeZone.getDefault());
                nowCalendar.setTime(nowDate);
                nowCalendar.set(Calendar.HOUR_OF_DAY, 0);
                nowCalendar.set(Calendar.MINUTE, 0);
                nowCalendar.set(Calendar.SECOND, 0);
                nowCalendar.set(Calendar.MILLISECOND, 0);
                Calendar statusCalendar = Calendar.getInstance(Locale.ENGLISH);
                statusCalendar.setTimeZone(TimeZone.getDefault());
                statusCalendar.setTime(storyDate);
                statusCalendar.set(Calendar.HOUR_OF_DAY, 0);
                statusCalendar.set(Calendar.MINUTE, 0);
                statusCalendar.set(Calendar.SECOND, 0);
                statusCalendar.set(Calendar.MILLISECOND, 0);
                Date currentDate = nowCalendar.getTime();
                Date statusDate = statusCalendar.getTime();
                Date statusUIDate = new Date(statusTime);
//                Log.i(TAG, "getStatusTime: " + statusFormat.format(statusUIDate));
//                Log.i(TAG, "getStatusTime: " + currentDate);
//                Log.i(TAG, "getStatusTime: " + statusDate);
//                Log.i(TAG, "getStatusTime: " + (currentDate.compareTo(statusDate)));

                int compare = currentDate.compareTo(statusDate);
                if (compare == 0) {
                    return mContext.getString(R.string.today) + " " + statusFormat.format(statusUIDate);
                } else {
                    return mContext.getString(R.string.yesterday) + " " + statusFormat.format(statusUIDate);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }

    public String getStatusExpiryDate(String statusTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date utcDate;
        String returnDate = "";
        try {
            utcDate = utcFormat.parse(statusTime);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(utcDate);
            calendar.add(Calendar.DATE, 1);
            returnDate = getUTCFromTimeStamp(calendar.getTimeInMillis());
            Log.d(TAG, "getStatusExpiryDate: " + returnDate);
            return returnDate;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isExceedsOneHour(String utcTime) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, LocaleManager.getLocale(mContext.getResources()));
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Calendar calendar = Calendar.getInstance(utcZone);
        Date now = calendar.getTime();
        Date utcDate;
        try {
            utcDate = utcFormat.parse(utcTime);
            long diff = now.getTime() - utcDate.getTime();
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000);
            Log.d(TAG, "isExceedsOneHour: " + diffHours);
            if (diffHours > 24) {
                return true;
            } else if ((diffHours == 24) && (diffMinutes >= 1)) {
                return true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}
