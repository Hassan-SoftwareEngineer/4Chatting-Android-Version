package com.app.helper.connectivity;

import static android.net.ConnectivityManager.CONNECTIVITY_ACTION;
import static android.net.wifi.WifiManager.EXTRA_NETWORK_INFO;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.app.helper.connectivity.base.ConnectivityProvider;
import com.app.helper.connectivity.base.ConnectivityProviderBaseImpl;

public class ConnectivityProviderLegacyImpl extends ConnectivityProviderBaseImpl {

    private Context mContext;
    private ConnectivityManager cm;
    private ConnectivityReceiver receiver = new ConnectivityReceiver();

    public ConnectivityProviderLegacyImpl(Context context, ConnectivityManager connectivityManager) {
        mContext = context;
        cm = connectivityManager;
    }

    @Override
    protected void subscribe() {
        mContext.registerReceiver(receiver, new IntentFilter(CONNECTIVITY_ACTION));
    }

    @Override
    protected void unsubscribe() {
        mContext.unregisterReceiver(receiver);
    }

    public ConnectivityProvider.NetworkState getNetworkState() {
        NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            return ConnectivityProvider.NetworkState.ConnectedState.ConnectedLegacy(activeNetworkInfo);
        } else {
            return NetworkState.NotConnectedState;
        }
    }

    private class ConnectivityReceiver extends BroadcastReceiver {
        public void onReceive(Context c, Intent intent) {
            // on some devices ConnectivityManager.getActiveNetworkInfo() does not provide the correct network state
            // https://issuetracker.google.com/issues/37137911
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            NetworkInfo fallbackNetworkInfo = intent.getParcelableExtra(EXTRA_NETWORK_INFO);
            // a set of dirty workarounds
            ConnectivityProvider.NetworkState state;
            if (networkInfo.isConnectedOrConnecting()) {
                NetworkStatus.isConnected = true;
                state = ConnectivityProvider.NetworkState.ConnectedState.ConnectedLegacy(networkInfo);
            } else if (networkInfo != null && fallbackNetworkInfo != null &&
                    networkInfo.isConnectedOrConnecting() != fallbackNetworkInfo.isConnectedOrConnecting()
            ) {
                NetworkStatus.isConnected = fallbackNetworkInfo.isConnectedOrConnecting();
                state = ConnectivityProvider.NetworkState.ConnectedState.ConnectedLegacy(
                        fallbackNetworkInfo
                );
            } else {
                NetworkInfo tempState = networkInfo != null ? networkInfo : fallbackNetworkInfo;
                if (tempState != null) {
                    NetworkStatus.isConnected = tempState.isConnectedOrConnecting();
                    state = ConnectivityProvider.NetworkState.ConnectedState.ConnectedLegacy(tempState);
                } else {
                    NetworkStatus.isConnected = false;
                    state = ConnectivityProvider.NetworkState.NotConnectedState;
                }
            }
            dispatchChange(state);
        }
    }
}
