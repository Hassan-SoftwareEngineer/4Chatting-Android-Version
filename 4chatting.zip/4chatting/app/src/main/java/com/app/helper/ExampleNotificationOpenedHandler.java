package com.app.helper;

import android.content.Context;
import android.util.Log;

import com.app.fourchattingapp.CallActivity;
import com.onesignal.OSNotificationOpenedResult;
import com.onesignal.OneSignal;

public class ExampleNotificationOpenedHandler implements OneSignal.OSNotificationOpenedHandler {
    private static final String TAG = ExampleNotificationOpenedHandler.class.getSimpleName();
    private Context mContext;

    public ExampleNotificationOpenedHandler(Context mContext) {
        this.mContext = mContext;
    }

    // This fires when a notification is opened by tapping on it.
    @Override
    public void notificationOpened(OSNotificationOpenedResult result) {

        if (CallActivity.isInCall) {
            Log.e(TAG, "notificationOpened: ");
        } else {
            Log.d(TAG, "notificationOpened: ");
        }

    }
}