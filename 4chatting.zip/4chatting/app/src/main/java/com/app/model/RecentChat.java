package com.app.model;

import com.google.gson.annotations.SerializedName;

public class RecentChat {
    @SerializedName("receiver_id")
    public String receiver_id;

    @SerializedName("sender_id")
    public String sender_id;

    @SerializedName("message_data")
    public RecentMessages messagesData;
}
