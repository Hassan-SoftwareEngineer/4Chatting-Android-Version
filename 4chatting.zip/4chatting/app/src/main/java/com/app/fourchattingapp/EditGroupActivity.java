package com.app.fourchattingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.app.model.GroupData;
import com.app.model.GroupUpdateResult;
import com.app.helper.DateUtils;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.PermissionsUtils;
import com.app.helper.StorageManager;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.app.external.RandomString;
import com.app.helper.DatabaseHandler;
import com.app.helper.NetworkUtil;
import com.app.helper.SocketConnection;
import com.app.fourchattingapp.R;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.CAMERA;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_TRUE;

public class EditGroupActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    static ApiInterface apiInterface;
    TextView title, txtCount;
    EditText edtGroupName;
    ImageView backbtn;
    CircleImageView userImage;
    ImageView noImage;
    LinearLayout btnNext;
    ProgressDialog progressDialog;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    DatabaseHandler dbhelper;
    SocketConnection socketConnection;
    RecyclerView groupRecycler;
    RelativeLayout imageLayout, participantLay, mainLay;
    String _Id, updatedImage;
    GroupData groupData;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private Uri mCurrentPhotoUri;
    boolean isCameraClicked = false, isGalleryClicked = false;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);

        mContext = this;
        socketConnection = SocketConnection.getInstance(this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        dbhelper = DatabaseHandler.getInstance(this);
        initPermission();

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        _Id = getIntent().getStringExtra(TAG_GROUP_ID);

        groupData = dbhelper.getGroupData(getApplicationContext(), _Id);

        title = findViewById(R.id.title);
        txtCount = findViewById(R.id.txtCount);
        backbtn = findViewById(R.id.backbtn);
        edtGroupName = findViewById(R.id.edtGroupName);
        groupRecycler = findViewById(R.id.groupRecycler);
        imageLayout = findViewById(R.id.imageLayout);
        participantLay = findViewById(R.id.participantLay);
        userImage = findViewById(R.id.userImage);
        noImage = findViewById(R.id.noimage);
        btnNext = findViewById(R.id.btnNext);
        mainLay = findViewById(R.id.mainLay);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        groupRecycler.setVisibility(View.GONE);
        title.setText(getString(R.string.create_group));
        imageLayout.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        btnNext.setOnClickListener(this);
        edtGroupName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});

        participantLay.setVisibility(View.GONE);
        title.setText(R.string.enter_new_subject);
        edtGroupName.setText("" + groupData.groupName);

        Glide.with(getApplicationContext()).load(Constants.CHAT_IMG_PATH + groupData.groupImage)
                .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        noImage.setVisibility(View.VISIBLE);
                        userImage.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        noImage.setVisibility(View.GONE);
                        userImage.setVisibility(View.VISIBLE);
                        return false;
                    }
                }).into(userImage);

    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imageLayout:
                openPickerDialog();
                break;
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.btnNext:
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (TextUtils.isEmpty("" + edtGroupName.getText().toString().trim())) {
                        makeToast(getString(R.string.enter_group_name));
                    } else {
                        if (mCurrentPhotoUri != null) {
                            try {
                                byte[] bytes = StorageManager.getBytes(getContentResolver().openInputStream(mCurrentPhotoUri));
                                uploadImage(bytes);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else if (!groupData.groupName.equals(edtGroupName.getText().toString())) {
                            updateGroup("" + edtGroupName.getText().toString().trim());
                        } else {
                            finish();
                        }
                    }
                }
                break;
        }
    }

    private void openPickerDialog() {

        View contentView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_pick_options, findViewById(R.id.parentLay), false);
        BottomSheetDialog pickerOptionsSheet = new BottomSheetDialog(this, R.style.SimpleBottomDialog);
        pickerOptionsSheet.setCanceledOnTouchOutside(true);
        pickerOptionsSheet.setContentView(contentView);
        //    pickerOptionsSheet.setDismissWithAnimation(true);

        View layoutCamera = contentView.findViewById(R.id.container_camera_option);
        View layoutGallery = contentView.findViewById(R.id.container_gallery_option);

        layoutCamera.setOnClickListener(v -> {
            pickerOptionsSheet.dismiss();
            isCameraClicked = true;
            isGalleryClicked = false;
            if (ContextCompat.checkSelfPermission(this, CAMERA) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        takeCameraPictures();
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    takeCameraPictures();
                }
            } else {
                requestCameraPermission();
            }
        });
        layoutGallery.setOnClickListener(v -> {
            isCameraClicked = false;
            isGalleryClicked = true;
            pickerOptionsSheet.dismiss();
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                pickGalleryPictures();
            } else {
                requestStoragePermissions();
            }
        });

        pickerOptionsSheet.show();
    }

    private void takeCameraPictures() {
        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        if (captureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                //     Timber.e(ex);
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                mCurrentPhotoUri = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri);
                startActivityForResult(captureIntent, Constants.CAMERA_REQUEST_CODE);
            }
        }
    }

    private void pickGalleryPictures() {
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Intent pickIntent = new Intent(Intent.ACTION_PICK, collection);
        pickIntent.setType("image/jpeg");
        Intent chooserIntent = Intent.createChooser(pickIntent, "Select a picture");
        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(chooserIntent, Constants.CAMERA_REQUEST_CODE);
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        // Save a file: path for use with ACTION_VIEW intents
        return image;
    }

    private void initPermission() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "storagePermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isCameraClicked) {
                        takeCameraPictures();
                    } else {
                        pickGalleryPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(EditGroupActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(EditGroupActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });

        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        if (PermissionsUtils.checkStoragePermission(mContext)) {
                            takeCameraPictures();
                        } else {
                            requestStoragePermissions();
                        }
                    } else {
                        takeCameraPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(EditGroupActivity.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(EditGroupActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.camera_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void requestCameraPermission() {
        cameraPermissionResult.launch(new String[]{CAMERA});
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION13);
        }
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void updateGroup(final String groupName) {
        try {
            String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
            RandomString randomString = new RandomString(10);
            String messageId = groupData.groupId + randomString.nextString();

            JSONObject message = new JSONObject();
            message.put(Constants.TAG_GROUP_ID, groupData.groupId);
            message.put(Constants.TAG_GROUP_NAME, groupName);
            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
            message.put(Constants.TAG_ATTACHMENT, updatedImage);
            message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
            message.put(Constants.TAG_MESSAGE_ID, messageId);
            message.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
            message.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
            message.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
            message.put(Constants.TAG_MESSAGE_TYPE, "subject");
            message.put(Constants.TAG_MESSAGE, getString(R.string.changed_the_subject_to) + " \"" + groupName + "\"");

            dbhelper.updateGroupData(groupData.groupId, Constants.TAG_GROUP_NAME, groupName);
            Log.v("checkChat", "startchat=" + message);
            socketConnection.messageToGroup(message);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Call<GroupUpdateResult> call3 = apiInterface.updateGroup(GetSet.getToken(), groupData.groupId, groupName);
        call3.enqueue(new Callback<GroupUpdateResult>() {
            @Override
            public void onResponse(Call<GroupUpdateResult> call, Response<GroupUpdateResult> response) {
                Log.i(TAG, "updateGroup: " + response.isSuccessful());
            }

            @Override
            public void onFailure(Call<GroupUpdateResult> call, Throwable t) {
                Log.e(TAG, "updateGroup: " + t.getMessage());
                call.cancel();
            }
        });
        finish();
    }

    void uploadImage(byte[] imageBytes) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("group_image", "openImage.jpg", requestFile);

        final RequestBody groupId = RequestBody.create(groupData.groupId, MediaType.parse("multipart/form-data"));
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<HashMap<String, String>> call3 = apiInterface.uploadGroupImage(GetSet.getToken(), body, groupId);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                if (data.get(Constants.TAG_STATUS).equalsIgnoreCase(TAG_TRUE)) {
                    if (data.get(Constants.TAG_GROUP_IMAGE) != null) {
                        updatedImage = data.get(Constants.TAG_GROUP_IMAGE);

                        try {
                            String currentUTCTime = DateUtils.getInstance(mContext).getCurrentUTCTime();
                            RandomString randomString = new RandomString(10);
                            String messageId = groupData.groupId + randomString.nextString();
                            String groupName = edtGroupName.getText().toString().trim();

                            JSONObject message = new JSONObject();
                            message.put(Constants.TAG_GROUP_ID, groupData.groupId);
                            message.put(Constants.TAG_GROUP_NAME, groupName);
                            message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_GROUP);
                            message.put(Constants.TAG_ATTACHMENT, updatedImage);
                            message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                            message.put(Constants.TAG_MESSAGE_ID, messageId);
                            message.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                            message.put(Constants.TAG_MEMBER_NAME, GetSet.getUserName());
                            message.put(Constants.TAG_MEMBER_NO, GetSet.getphonenumber());
                            if (updatedImage != null && !updatedImage.equalsIgnoreCase("")) {
                                message.put(Constants.TAG_MESSAGE_TYPE, "group_image");
                                message.put(Constants.TAG_MESSAGE, getString(R.string.changed_group_icon));

                                dbhelper.updateGroupData(groupData.groupId, Constants.TAG_GROUP_IMAGE, updatedImage);
                            }
                            Log.v("checkChat", "startchat=" + message);
                            socketConnection.messageToGroup(message);

                            if (!groupData.groupName.equals(edtGroupName.getText().toString())) {
                                updateGroup("" + edtGroupName.getText().toString().trim());
                            } else {
                                finish();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "uploadImage " + t.getMessage());
                call.cancel();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == Constants.CAMERA_REQUEST_CODE) {
            boolean isCamera = (data == null
                    || data.getData() == null);
            if (isCamera) {     /** CAMERA **/
                Log.d(TAG, "onActivityResult: " + mCurrentPhotoUri.getPath());
            } else {            /** ALBUM **/
                String mimeType = getContentResolver().getType(data.getData());
                mCurrentPhotoUri = data.getData();
            }

//            Log.e(TAG, "onActivityResult: " + groupImageView);
            Glide.with(EditGroupActivity.this).load(mCurrentPhotoUri)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            noImage.setVisibility(View.VISIBLE);
                            userImage.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            noImage.setVisibility(View.GONE);
                            userImage.setVisibility(View.VISIBLE);
                            return false;
                        }
                    }).into(userImage);

        }
    }

}
