package com.app.fourchattingapp;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.app.helper.ThemeHelper;
import com.app.fourchattingapp.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;


/**
 * Created by hitasoft on 25/6/18.
 */

public class LocationActivity extends BaseActivity implements View.OnClickListener, AdapterView.OnItemClickListener, TextWatcher,
        OnMapReadyCallback {
    final String TAG = "LocationActivity";
    /**
     * Declare Layout Elements
     **/
    MapView mapView;
    GoogleMap googleMap;
    TextView title, setLoc, apply;
    ImageView backbtn, cancelbtn, marker;
    AutoCompleteTextView address;
    Display display;
    RelativeLayout searchLay;
    LinearLayout fabLocation;
    ProgressDialog dialog;

    private static String[] REQUIRED_PERMISSIONS = new String[]{ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION};
    FusedLocationProviderClient fusedLocationClient;
    // Keys for storing activity state in the Bundle.
    private final static String KEY_REQUESTING_LOCATION_UPDATES = "requesting-location-updates";
    private final static String KEY_LOCATION = "location";
    final static int REQUEST_CHECK_SETTINGS_GPS = 0x1, REQUEST_ID_MULTIPLE_PERMISSIONS = 0x2;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS =
            UPDATE_INTERVAL_IN_MILLISECONDS / 2;
    private SettingsClient mSettingsClient;
    private LocationRequest mLocationRequest;
    private LocationSettingsRequest mLocationSettingsRequest;
    private LocationCallback mLocationCallback;
    private boolean mRequestingLocationUpdates = true;
    LocationManager locationManager;
    private boolean myLocationClicked = false, isLocationSelected = false;
    Location mCurrentLocation;

    /**
     * Declare Varaibles
     **/
    double lat, lon;
    double sharedLat, sharedLon;
    String from = "";
    InputMethodManager imm;
    LatLng center;
    Bitmap locationMarker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Locale.setDefault(getResources().getConfiguration().locale);
        setContentView(R.layout.location_activity);

        mapView = findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        // Update values using data stored in the Bundle.
        updateValuesFromBundle(savedInstanceState);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        mSettingsClient = LocationServices.getSettingsClient(this);

        backbtn = findViewById(R.id.backbtn);
        title = findViewById(R.id.title);
        setLoc = findViewById(R.id.apply);
        address = findViewById(R.id.address);
        cancelbtn = findViewById(R.id.cancelbtn);
        fabLocation = findViewById(R.id.fablocation);
        searchLay = findViewById(R.id.searchLay);
        apply = findViewById(R.id.apply);
        marker = findViewById(R.id.marker);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }

        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        display = this.getWindowManager().getDefaultDisplay();

        dialog = new ProgressDialog(LocationActivity.this);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        int height = 100;
        int width = 80;
        BitmapDrawable bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.location_marker);
        Bitmap b = bitmapdraw.getBitmap();
        locationMarker = Bitmap.createScaledBitmap(b, width, height, false);

        from = getIntent().getExtras().getString("from");
        if (from.equals("share")) {
            apply.setVisibility(View.VISIBLE);
        } else {
            apply.setVisibility(View.GONE);
            marker.setVisibility(View.GONE);
            String sLat = getIntent().getExtras().getString("lat");
            String sLon = getIntent().getExtras().getString("lon");
            if (sLat != null && sLon != null) {
                lat = Double.parseDouble(sLat);
                lon = Double.parseDouble(sLon);
                sharedLat = lat;
                sharedLon = lon;
            }
            Log.v("lat", "lat==" + sLat);
            Log.v("lon", "lon==" + sLon);
        }

        backbtn.setVisibility(View.VISIBLE);
        title.setVisibility(View.VISIBLE);
        cancelbtn.setVisibility(View.GONE);

        title.setText(getString(R.string.location));
        backbtn.setOnClickListener(this);
        setLoc.setOnClickListener(this);
        cancelbtn.setOnClickListener(this);
        address.setOnItemClickListener(this);
        fabLocation.setOnClickListener(this);
        apply.setOnClickListener(this);
        address.addTextChangedListener(this);

        // address.setAdapter(new PlacesAutoCompleteAdapter(LocationActivity.this, R.layout.dropdown_layout));

        // Gets to GoogleMap from the MapView and does initialization stuff
        mapView.getMapAsync(this);

        //To get Latlng
        // Kick off the process of building the LocationCallback, LocationRequest, and
        // LocationSettingsRequest objects.
        createLocationCallback();
        createLocationRequest();
        buildLocationSettingsRequest();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.v("requestCode", "requestCode=" + requestCode);
        switch (requestCode) {
            case REQUEST_ID_MULTIPLE_PERMISSIONS:
                if (checkLocationPermissions()) {
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        turnGPSOn();
                    } else {
                        startLocationUpdates();
                    }
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRationale(permissions, LocationActivity.this)) {
                            ActivityCompat.requestPermissions(LocationActivity.this, permissions, REQUEST_ID_MULTIPLE_PERMISSIONS);
                        } else {
                            Toast.makeText(getApplicationContext(), getString(R.string.location_permission_error), Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivityForResult(intent, 100);
                        }
                    }
//                    makeToast(getString(R.string.location_permission_error));
//                    finish();
                }
                break;
        }
    }

    private boolean shouldShowRationale(String[] permissions, LocationActivity activity) {
        boolean showRationale = false;
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                showRationale = true;
            } else {
                showRationale = false;
                break;
            }
        }
        return showRationale;
    }


    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    @Override
    public void onMapReady(final GoogleMap map) {
        Log.v(TAG, "map=" + map);
        googleMap = map;
        if (map != null) {
            if (!from.equals("view")) {
                fabLocation.setVisibility(View.VISIBLE);
                map.getUiSettings().setMyLocationButtonEnabled(false);
                if (!checkLocationPermissions()) {
                    return;
                } else {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    map.setMyLocationEnabled(true);
                }
            } else {
                fabLocation.setVisibility(View.GONE);
            }

            SharedPreferences themePref = PreferenceManager.getDefaultSharedPreferences(this);
            String theme = themePref.getString("themePref", ThemeHelper.DEFAULT_MODE);
            if (!TextUtils.isEmpty(theme) && theme.equals(ThemeHelper.DARK_MODE)) {
                MapStyleOptions style = MapStyleOptions.loadRawResourceStyle(this, R.raw.mapstyle_night);
                googleMap.setMapStyle(style);
            } else {
                if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
                    MapStyleOptions style = MapStyleOptions.loadRawResourceStyle(this, R.raw.mapstyle_night);
                    googleMap.setMapStyle(style);
                }
            }

            map.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
                @Override
                public void onCameraMove() {
                    apply.setEnabled(false);
                    if (!from.equals("view")) {
                        map.clear();
                    }
                }
            });

            map.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
                @Override
                public void onCameraIdle() {
                    if (checkLocationPermissions()) {
                        stopLocationUpdates();
                        apply.setEnabled(true);
                        center = map.getCameraPosition().target;
                        Log.v(TAG, "setOnCameraIdleListener: " + center.latitude + ", " + center.longitude);
                        lat = center.latitude;
                        lon = center.longitude;
                        if (lat == 0 || lon == 0) {
                            if (!from.equals("view")) {
                                myLocationClicked = true;
                            }
                            getLastLocation();
                        } else {
                            if (from.equals("view")) {
//                                map.clear();
                                map.addMarker(new MarkerOptions().position(new LatLng(sharedLat, sharedLon))
                                        .icon(BitmapDescriptorFactory.fromBitmap(locationMarker))
                                        .title(""));
                            }
                        }
                    }
                }
            });

            address.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        try {
                            imm.hideSoftInputFromWindow(address.getWindowToken(), 0);
                            Double latn[] = new Double[2];
                            if (address.getText().toString().trim().length() != 0) {
//                                latn = new GetLocationFromString().execute(address.getText().toString().trim()).get();
                                latn = getGeocodeLocation(address.getText().toString().trim());
                                double lat = latn[0];
                                double lon = latn[1];

                                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15);
                                map.animateCamera(cameraUpdate);
                            }
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        return true;
                    }
                    return false;
                }
            });
        }

        /*View locationButton = ((View) mapView.findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        locationButton.setBackgroundResource(R.drawable.my_location);
        // and next place it, for exemple, on bottom right (as Google Maps app)
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
        rlp.setMargins(0, 0, 30, 30);*/

        // Needs to call MapsInitializer before doing any CameraUpdateFactory calls
        try {
            MapsInitializer.initialize(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (s.length() > 0) {
            cancelbtn.setVisibility(View.VISIBLE);
        } else {
            cancelbtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    /**
     * Updates fields based on data stored in the bundle.
     *
     * @param savedInstanceState The activity state saved in the Bundle.
     */
    private void updateValuesFromBundle(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            // Update the value of mRequestingLocationUpdates from the Bundle, and make sure that
            // the Start Updates and Stop Updates buttons are correctly enabled or disabled.
            if (savedInstanceState.keySet().contains(KEY_REQUESTING_LOCATION_UPDATES)) {
                mRequestingLocationUpdates = savedInstanceState.getBoolean(
                        KEY_REQUESTING_LOCATION_UPDATES);
            }

            // Update the value of mCurrentLocation from the Bundle and update the UI to show the
            // correct latitude and longitude.
            if (savedInstanceState.keySet().contains(KEY_LOCATION)) {
                // Since KEY_LOCATION was found in the Bundle, we can be sure that mCurrentLocation
                // is not null.
                mCurrentLocation = savedInstanceState.getParcelable(KEY_LOCATION);
            }
        }
    }

    private void createLocationRequest() {
        mLocationRequest = new LocationRequest();

        // Sets the desired interval for active location updates. This interval is
        // inexact. You may not receive updates at all if no location sources are available, or
        // you may receive them slower than requested. You may also receive updates faster than
        // requested if other applications are requesting location at a faster interval.
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);

        // Sets the fastest rate for active location updates. This interval is exact, and your
        // application will never receive updates faster than this value.
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);

        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    /**
     * Creates a callback for receiving location events.
     */
    private void createLocationCallback() {
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                mCurrentLocation = locationResult.getLastLocation();
                if (myLocationClicked) {
                    myLocationClicked = false;
                    lat = mCurrentLocation.getLatitude();
                    lon = mCurrentLocation.getLongitude();
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15);
                    googleMap.animateCamera(cameraUpdate);
                } else if (from.equals("share")) {
                    if (lat == 0 && lon == 0) {
                        if (mCurrentLocation == null) {
                            getLastLocation();
                        } else {
                            lat = mCurrentLocation.getLatitude();
                            lon = mCurrentLocation.getLongitude();
                        }
                    }
                } else if (from.equals("view")) {
                    if (sharedLat != 0 && sharedLat != 0) {
                        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(sharedLat, sharedLon), 15);
                        googleMap.animateCamera(cameraUpdate);
                    }
                }
                stopLocationUpdates();
            }
        };
    }

    private void startLocationUpdates() {
        // Begin by checking if the device has the necessary location settings.
        mSettingsClient.checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        Log.i(TAG, "All location settings are satisfied.");

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            //noinspection MissingPermission
                            if (checkSelfPermission(ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        fusedLocationClient.requestLocationUpdates(mLocationRequest,
                                mLocationCallback, Looper.myLooper());
                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                Log.i(TAG, "Location settings are not satisfied. Attempting to upgrade " +
                                        "location settings ");
                                if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                                    try {
                                        // Show the dialog by calling startResolutionForResult(), and check the
                                        // result in onActivityResult().
                                        ResolvableApiException rae = (ResolvableApiException) e;
                                        rae.startResolutionForResult(LocationActivity.this, REQUEST_CHECK_SETTINGS_GPS);
                                    } catch (IntentSender.SendIntentException sie) {
                                        Log.i(TAG, "PendingIntent unable to execute request.");
                                    }
                                } else {
                                    try {
                                        int locationMode = Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE);
                                        if (locationMode != Settings.Secure.LOCATION_MODE_HIGH_ACCURACY) {
                                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                                            Toast.makeText(getApplicationContext(), "Enable Location Access in High Accuracy Mode", Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (Settings.SettingNotFoundException e1) {
                                        e1.printStackTrace();
                                    }
                                }
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                Log.e(TAG, "Location settings are inadequate, and cannot be " +
                                        "fixed here. Fix in Settings.");
                        }
                    }
                });
    }

    /**
     * Removes location updates from the FusedLocationApi.
     */
    private void stopLocationUpdates() {
        if (!mRequestingLocationUpdates) {
            Log.d(TAG, "stopLocationUpdates: updates never requested, no-op.");
            return;
        }

        // It is a good practice to remove location requests when the activity is in a paused or
        // stopped state. Doing so helps battery performance and is especially
        // recommended in applications that request frequent location updates.
        fusedLocationClient.removeLocationUpdates(mLocationCallback)
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        mRequestingLocationUpdates = false;
                    }
                });
    }

    /**
     * Uses a {@link com.google.android.gms.location.LocationSettingsRequest.Builder} to build
     * a {@link com.google.android.gms.location.LocationSettingsRequest} that is used for checking
     * if a device has the needed location settings.
     */
    private void buildLocationSettingsRequest() {
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        mLocationSettingsRequest = builder.build();
    }

    private void getLastLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                return;
            }
        }
        fusedLocationClient.getLastLocation()
                .addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful() && task.getResult() != null) {
                            mCurrentLocation = task.getResult();
                            lat = mCurrentLocation.getLatitude();
                            lon = mCurrentLocation.getLongitude();
                            if (myLocationClicked) {
                                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15);
                                googleMap.animateCamera(cameraUpdate);
                            } else if (from.equals("share")) {
                                if (lat == 0 && lon == 0) {
                                    if (mCurrentLocation == null) {
                                        getLastLocation();
                                    } else {
                                        lat = mCurrentLocation.getLatitude();
                                        lon = mCurrentLocation.getLongitude();
                                    }
                                }
                            } else if (from.equals("view")) {
                                if (sharedLat != 0 && sharedLat != 0) {
                                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(sharedLat, sharedLon), 15);
                                    googleMap.animateCamera(cameraUpdate);
                                }
                            }
                        } else {
                            if (task.getException() != null && task.getException().getMessage() != null) {
                                Log.e(TAG, "getLastLocation:getMessage " + task.getException().getMessage());
                            } else
                                Log.e(TAG, "getLastLocation:exception " + task.getException());
                        }
                    }
                });
    }

    public void turnGPSOn() {
        mSettingsClient
                .checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(LocationActivity.this, new OnSuccessListener<LocationSettingsResponse>() {
                    @SuppressLint("MissingPermission")
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        //  GPS is already enable, callback GPS status through listener
                    }
                })
                .addOnFailureListener(LocationActivity.this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                try {
                                    // Show the dialog by calling startResolutionForResult(), and check the
                                    // result in onActivityResult().
                                    ResolvableApiException rae = (ResolvableApiException) e;
                                    rae.startResolutionForResult(LocationActivity.this, REQUEST_CHECK_SETTINGS_GPS);
                                } catch (IntentSender.SendIntentException sie) {
                                    Log.i(TAG, "PendingIntent unable to execute request.");
                                }
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                String errorMessage = "Location settings are inadequate, and cannot be " +
                                        "fixed here. Fix in Settings.";
                                Log.e(TAG, errorMessage);
                                Toast.makeText(LocationActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }

    private boolean checkLocationPermissions() {
        return ContextCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions(String[] permissionList, int requestCode) {
        ActivityCompat.requestPermissions(this, permissionList, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS_GPS:
                switch (resultCode) {
                    case RESULT_OK:
                        startLocationUpdates();
                        break;
                    case RESULT_CANCELED:
                        mRequestingLocationUpdates = true;
                        break;
                }
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        cancelbtn.setVisibility(View.VISIBLE);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        if (!checkLocationPermissions()) {
            ActivityCompat.requestPermissions(LocationActivity.this, new String[]{ACCESS_FINE_LOCATION},
                    REQUEST_ID_MULTIPLE_PERMISSIONS);
        } else if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            turnGPSOn();
        } else if (myLocationClicked) {
            mRequestingLocationUpdates = true;
            startLocationUpdates();
        } else if (mRequestingLocationUpdates) {
            startLocationUpdates();
        }
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onPause() {
        // chat.disconnect();
        super.onPause();
        stopLocationUpdates();
    }

    private Double[] getGeocodeLocation(String params) {
        final Double latn[] = new Double[2];
        Geocoder gc = new Geocoder(getApplicationContext());
        if (Geocoder.isPresent()) {
            List<Address> list = new ArrayList<>();
            try {
                list = gc.getFromLocationName(params, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (list.size() > 0) {
                Address address = list.get(0);
                latn[0] = address.getLatitude();
                latn[1] = address.getLongitude();
            }

            return latn;
        } else {
            Toast.makeText(getApplicationContext(), "No Location found", Toast.LENGTH_LONG).show();
            return latn;
        }
    }

    /**
     * Function for Onclick Events
     */

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.apply:
                // new GetLocationAsync(center.latitude, center.longitude).execute().get();
                center = googleMap.getCameraPosition().target;
                lat = center.latitude;
                lon = center.longitude;
                if (lat == 0.0 || lon == 0.0) {
                    makeToast("Location not updated");
                } else {
                    Intent i = new Intent(LocationActivity.this, ChatActivity.class);
                    i.putExtra("lat", String.valueOf(lat));
                    i.putExtra("lon", String.valueOf(lon));
                    setResult(RESULT_OK, i);
                    finish();
                }
                break;
            case R.id.cancelbtn:
                address.setText("");
                cancelbtn.setVisibility(View.GONE);
                break;
            case R.id.fablocation:
                myLocationClicked = true;
                if (checkLocationPermissions()) {
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        turnGPSOn();
                    } else {
                        getLastLocation();
                    }
                } else {
                    ActivityCompat.requestPermissions(LocationActivity.this, REQUIRED_PERMISSIONS, REQUEST_ID_MULTIPLE_PERMISSIONS);
                }
                break;
        }
    }
}
