package com.app.fourchattingapp;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.app.helper.DatabaseHandler;
import com.app.helper.StorageManager;
import com.app.fourchattingapp.R;
import com.app.model.MediaModelData;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ImageFragment extends Fragment {

    private static final String ARG_PARAM1 = "user_id";
    private static final String ARG_PARAM2 = "type";
    String userId = "", type = "", TAG = "AudioFragment";
    RecyclerView recyclerView;
    RelativeLayout imageViewLay;
    Context context;
    DatabaseHandler dbhelper;
    StorageManager storageManager;
    BottomSheetBehavior bottomSheetBehavior;
    private TextView empty_view;


    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ImageFragment() {
    }

    static ImageFragment newInstance(String param1, String param2) {
        ImageFragment fragment = new ImageFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            userId = getArguments().getString(ARG_PARAM1);
            type = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_imageitem_list, container, false);
        context = view.getContext();
        recyclerView = view.findViewById(R.id.recyclerView);
        empty_view = view.findViewById(R.id.empty_view);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 3));

        storageManager = StorageManager.getInstance(context);
        dbhelper = DatabaseHandler.getInstance(context);

        setMediaAdapter();

        return view;
    }

    private void setMediaAdapter() {
        List<MediaModelData> data = new ArrayList<>();
        try {
            for (MediaModelData messagesData : dbhelper.getMedia(userId, type, context)) {
                Log.i(TAG, "setMediaAdapter: " + new Gson().toJson(messagesData));
                if (messagesData.message_type.equals(StorageManager.TAG_IMAGE) || messagesData.message_type.equals(StorageManager.TAG_VIDEO)) {
                    data.add(messagesData);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (!data.isEmpty()) {
            GridAdapter adapter = new GridAdapter(context, data);
            recyclerView.setAdapter(adapter);
        } else {
            empty_view.setVisibility(View.VISIBLE);
        }

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private String getFileName(String url) {
        String imgSplit = url;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1);
        }
        return imgSplit;
    }

    public class GridAdapter extends RecyclerView.Adapter<GridAdapter.ViewHolder> {
        Context context;
        List<MediaModelData> mediaList;

        GridAdapter(Context context, List<MediaModelData> mediaItem) {
            this.context = context;
            this.mediaList = mediaItem;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.media_item, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            MediaModelData message = mediaList.get(position);
            holder.playLay.setVisibility(View.GONE);
            if (message.message_type.equalsIgnoreCase(StorageManager.TAG_VIDEO)) {
                holder.playLay.setVisibility(View.VISIBLE);
                File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, message.attachment, StorageManager.TAG_VIDEO);
                if (file != null) {
                    setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                        if (fileUri != null) {
                            setImage(holder.mediaItem, fileUri);
                        }
                    } else {
                        file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                        if (file != null) {
                            setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                        }
                    }
                }
            } else {
                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, message.attachment, StorageManager.TAG_IMAGE);
                if (file != null) {
                    setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        Uri fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                        if (fileUri != null) {
                            setImage(holder.mediaItem, fileUri);
                        }
                    } else {
                        file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                        if (file != null) {
                            setImage(holder.mediaItem, storageManager.getUriFromFile(file));
                        }
                    }
                }
            }
        }

        private void setImage(ImageView view, Uri file) {
            RequestOptions options = new RequestOptions().frame(1000).centerCrop();
            Glide.with(context).asBitmap()
                    .load(file)
                    .apply(options)
                    .into(view);
        }

        @Override
        public int getItemCount() {
            return mediaList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            ImageView mediaItem;
            RelativeLayout playLay;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                mediaItem = itemView.findViewById(R.id.mediaItem);
                playLay = itemView.findViewById(R.id.playLay);

                mediaItem.getLayoutParams().width = (int) ((ApplicationClass.getWidth(itemView.getContext())) * (0.33));
                mediaItem.getLayoutParams().height = (int) ((ApplicationClass.getWidth(itemView.getContext())) * (0.33));

                mediaItem.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.mediaItem) {
                    MediaModelData message = mediaList.get(getAbsoluteAdapterPosition());
                    openMedia(message);
                }
            }
        }

        private void openMedia(MediaModelData message) {
            String type = message.message_type;
            if (type.equalsIgnoreCase("video")) {
                Uri fileUri = null;
                File file = storageManager.getSrcFile(StorageManager.TAG_VIDEO_SENT, message.attachment, StorageManager.TAG_VIDEO);
                if (file != null) {
                    fileUri = storageManager.getUriFromFile(file);
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        fileUri = storageManager.getFileUri(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                    } else {
                        file = storageManager.getSrcFile(StorageManager.TAG_VIDEO, message.attachment, StorageManager.TAG_VIDEO);
                        if (file != null) {
                            fileUri = storageManager.getUriFromFile(file);
                        }
                    }
                }

                if (fileUri != null) {
                    openMediaIntent(fileUri);
                } else {
                    showToast(context, context.getString(R.string.no_media));
                }
            } else {
                Uri fileUri = null;
                File file = storageManager.getSrcFile(StorageManager.TAG_IMAGE_SENT, message.attachment, StorageManager.TAG_IMAGE);
                if (file != null) {
                    fileUri = storageManager.getUriFromFile(file);
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        fileUri = storageManager.getFileUri(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                    } else {
                        file = storageManager.getSrcFile(StorageManager.TAG_IMAGE, message.attachment, StorageManager.TAG_IMAGE);
                        if (file != null) {
                            fileUri = storageManager.getUriFromFile(file);
                        }
                    }
                }

                if (fileUri != null) {
                    openMediaIntent(fileUri);
                } else {
                    showToast(context, context.getString(R.string.no_media));
                }
            }
        }

        private void openMediaIntent(Uri fileUri) {
            try {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                MimeTypeMap mime = MimeTypeMap.getSingleton();
                String ext = storageManager.getExtension(fileUri);
                String mimeType = mime.getMimeTypeFromExtension(ext);
                intent.setDataAndType(fileUri, mimeType);
                context.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                showToast(context, context.getString(R.string.no_application));
                e.printStackTrace();
            }
        }

        void showToast(Context context, String text) {
            Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
        }
    }
}
