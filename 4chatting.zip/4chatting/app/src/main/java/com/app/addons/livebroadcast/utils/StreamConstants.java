package com.app.addons.livebroadcast.utils;

import com.app.utils.Constants;

public class StreamConstants {

    public static final String STREAM_SOCKET_IO_URL = Constants.SITE_URL + ":8083";
    public static final String STREAM_BASE_URL = "";
    public static final String STREAM_IMG_PATH = Constants.BASE_URL + "media/streams/";

    public static final String TAG_STREAM_BASE_URL = "base_url";
    public static final String TAG_API_URL = "api_url";
    public static final String TAG_VOD_URL = "vod_url";

    public static final String TAG_STREAM_NAME = "stream_name";
    public static final String TAG_STREAMED_ON = "streamed_on";
    public static final String TAG_STREAM_ID = "stream_id";
    public static final String TAG_PUBLISHER_NAME = "posted_name";
    public static final String TAG_STREAM_IMAGE = "stream_image";
    public static final String TAG_PUBLISHER_ID = "publisher_id";
    public static final String TAG_RECORDING = "recording";
    public static final String TAG_LENS_FACING = "lens_facing";
    public static String[] LIKE_COLOR = {"#05AC90", "#AC5b05", "#AC1905",
            "#AC0577", "#8305AC", "#0563aC", "#7BAC05"};
    public static final String TAG_WATCH_COUNT = "watch_count";
    public static final String TAG_LIKES = "likes";
    public static final String TAG_TITLE = "title";
    public static final String TAG_NAME = "name";
    public static final String TAG_VIDEOS_COUNT = "videos_count";
    public static final String TAG_VIEWS_COUNT = "views_count";
    public static final String TAG_PLAYBACK_URL = "playback_url";
    public static final String TAG_STREAM_DATA = "stream_data";
    public static final String TAG_RECENT = "recent";
    public static final String TAG_USER = "user";
    public static final String TAG_SUBSCRIBE = "subscribe";
    public static final String TAG_FROM = "from";
    public static final String TAG_PUBLIC = "public";
    public static final String TAG_PRIVATE = "private";
    public static final String TAG_TOKEN = "token";
    public static final String TAG_STREAM_TOKEN = "stream_token";
    public static final String TAG_LIVE = "live";

    public static final int MAX_LIMIT = 20;
    public static final long FADE_DURATION = 1000;
    public static final int DELETE_REQUEST_CODE = 100;
    public static final int STREAM_REQUEST_CODE = 114;
    public static final int CAMERA_REQUEST_CODE = 116;
    public static final int PUBLISH_REQUEST_CODE = 115;

    /*Socket Key*/
    public static final String TAG_JOIN_STREAM = "_joinStream";
    public static final String TAG_PUBLISH_STREAM = "_publishStream";
    public static final String TAG_SUBSCRIBE_STREAM = "_subscribeStream";
    public static final String TAG_UNSUBSCRIBE_STREAM = "_unsubscribeStream";
    public static final String TAG_LIKED = "liked";
    public static final String TAG_LIKE_COLOR = "like_color";
    public static final String TAG_STREAM_JOINED = "joined";
    public static final String TAG_SEND_MESSAGE = "_sendMsg";
    public static final String TAG_MESSAGE_RECEIVED = "_msgReceived";
    public static final String TAG_SUBSCRIBER_LEFT = "_subscriberLeft";
    public static final String TAG_STREAM_INFO = "_streamInfo";
    public static final String TAG_STREAM_BLOCKED = "_streamBlocked";
    public static final String TAG_GET_STREAM_INFO = "_getstreamInfo";
    public static final String TAG_START_RECORD = "_startRecordStream";
    public static final String TAG_GIFT_FROM = "gift_from";
    public static final String TAG_GIFT_TO = "gift_to";
    public static final String TAG_SEND_GIFT = "_sendGift";
}
