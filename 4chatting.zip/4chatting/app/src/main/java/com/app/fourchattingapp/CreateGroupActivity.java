package com.app.fourchattingapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.app.external.RandomString;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.NetworkUtil;
import com.app.helper.callback.OkayCancelCallback;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.utils.ApiClient;
import com.app.utils.ApiInterface;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.CAMERA;
import static com.app.helper.NetworkUtil.NOT_CONNECT;
import static com.app.utils.Constants.ADMIN;
import static com.app.utils.Constants.TAG_GROUP;
import static com.app.utils.Constants.TAG_GROUP_ID;
import static com.app.utils.Constants.TAG_GROUP_IMAGE;
import static com.app.utils.Constants.TAG_GROUP_MEMBERS;
import static com.app.utils.Constants.TAG_GROUP_NAME;
import static com.app.utils.Constants.TAG_ID;
import static com.app.utils.Constants.MEMBER;
import static com.app.utils.Constants.TAG_MEMBER_ABOUT;
import static com.app.utils.Constants.TAG_MEMBER_ID;
import static com.app.utils.Constants.TAG_MEMBER_NAME;
import static com.app.utils.Constants.TAG_MEMBER_NO;
import static com.app.utils.Constants.TAG_MEMBER_PICTURE;
import static com.app.utils.Constants.TAG_MEMBER_ROLE;
import static com.app.utils.Constants.TAG_TRUE;
import static com.app.utils.Constants.TAG_USER_ID;

public class CreateGroupActivity extends BaseActivity implements View.OnClickListener, SocketConnection.OnGroupCreatedListener {

    private final String TAG = this.getClass().getSimpleName();
    ApiInterface apiInterface;
    TextView title, txtCount;
    EditText edtGroupName;
    ImageView backbtn;
    CircleImageView userImage;
    ImageView noImage;
    LinearLayout btnNext;
    List<ContactsData.Result> groupList = new ArrayList<>();
    ProgressDialog progressDialog;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    GroupAdapter groupAdapter;
    DatabaseHandler dbhelper;
    LinearLayoutManager linearLayoutManager;
    RecyclerView groupRecycler;
    RelativeLayout imageLayout, mainLay;
    SocketConnection socketConnection;
    private ActivityResultLauncher<String[]> storagePermissionResult;
    private ActivityResultLauncher<String[]> cameraPermissionResult;
    private File currentPhotoFile;
    private Uri mCurrentPhotoUri;
    boolean isCameraClicked = false, isGalleryClicked = false;
    private static final int CAMERA_REQ_CODE = 1000;
    StorageManager storageManager;
    private DateUtils dateUtils;
    private ActivityResultLauncher<Intent> cameraResultLauncher;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);

        mContext = this;
        socketConnection = SocketConnection.getInstance(this);
        SocketConnection.getInstance(this).setOnGroupCreatedListener(this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = this.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
        dbhelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        dateUtils = DateUtils.getInstance(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.pleasewait));
        progressDialog.setCancelable(false);

        title = findViewById(R.id.title);
        txtCount = findViewById(R.id.txtCount);
        backbtn = findViewById(R.id.backbtn);
        edtGroupName = findViewById(R.id.edtGroupName);
        groupRecycler = findViewById(R.id.groupRecycler);
        imageLayout = findViewById(R.id.imageLayout);
        userImage = findViewById(R.id.userImage);
        noImage = findViewById(R.id.noimage);
        btnNext = findViewById(R.id.btnNext);
        mainLay = findViewById(R.id.mainLay);

        if (ApplicationClass.isRTL()) {
            backbtn.setRotation(180);
        } else {
            backbtn.setRotation(0);
        }
        initPermission();
        initActivityResultLauncher();
        title.setText(getString(R.string.create_group));
        imageLayout.setOnClickListener(this);
        backbtn.setOnClickListener(this);
        btnNext.setOnClickListener(this);

        if (getIntent().getSerializableExtra(Constants.TAG_GROUP_LIST) != null) {
            groupList = (List<ContactsData.Result>) getIntent().getSerializableExtra(Constants.TAG_GROUP_LIST);
        }

        txtCount.setText("" + groupList.size());
        initGroupList();

    }

    private void initPermission() {
        storagePermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "storagePermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (isCameraClicked) {
                        takeCameraPictures();
                    } else {
                        pickGalleryPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CreateGroupActivity.this, x.getKey())) {
                                storagePermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(CreateGroupActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.storage_error));
                            }
                            break;
                        }
                    }
                }

            }
        });

        cameraPermissionResult = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {
                boolean granted = true;
                Log.d(TAG, "cameraPermissionResult: " + result);
                for (Map.Entry<String, Boolean> x : result.entrySet()) {
                    if (!x.getValue()) granted = false;
                }

                if (granted) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        if (PermissionsUtils.checkStoragePermission(CreateGroupActivity.this)) {
                            takeCameraPictures();
                        } else {
                            requestStoragePermissions();
                        }
                    } else {
                        takeCameraPictures();
                    }
                } else {
                    for (Map.Entry<String, Boolean> x : result.entrySet()) {
                        if (!x.getValue()) {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(CreateGroupActivity.this, x.getKey())) {
                                cameraPermissionResult.launch(result.keySet().toArray(new String[result.size()]));
                            } else {
                                PermissionsUtils.openPermissionDialog(CreateGroupActivity.this, new OkayCancelCallback() {
                                    @Override
                                    public void onOkayClicked(Object o) {
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", BuildConfig.APPLICATION_ID, null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onCancelClicked(Object o) {

                                    }
                                }, getString(R.string.camera_error));
                            }
                            break;
                        }
                    }
                }

            }
        });
    }

    private void initActivityResultLauncher() {
        cameraResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    boolean isCamera = (data == null
                            || data.getData() == null);
                    if (isCamera) {     /** CAMERA **/
                        Log.d(TAG, "onActivityResult: " + mCurrentPhotoUri.getPath());
                    } else {            /** ALBUM **/
                        String mimeType = getContentResolver().getType(data.getData());
                        mCurrentPhotoUri = data.getData();
                    }
                    Glide.with(CreateGroupActivity.this).load(mCurrentPhotoUri)
                            .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                            .listener(new RequestListener<Drawable>() {
                                @Override
                                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                    noImage.setVisibility(View.VISIBLE);
                                    userImage.setVisibility(View.GONE);
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                    noImage.setVisibility(View.GONE);
                                    userImage.setVisibility(View.VISIBLE);
                                    return false;
                                }
                            }).into(userImage);
                }

            }
        });
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    private void initGroupList() {
        linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        groupRecycler.setLayoutManager(linearLayoutManager);
        groupRecycler.setHasFixedSize(true);

        if (groupAdapter == null) {
            groupAdapter = new GroupAdapter(this, groupList);
            groupRecycler.setAdapter(groupAdapter);
            groupAdapter.notifyDataSetChanged();
        } else {
            groupAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imageLayout:
                openPickerDialog();
                break;
            case R.id.backbtn:
                backPressed();
                break;
            case R.id.btnNext:
                ApplicationClass.preventMultiClick(btnNext);
                if (isNetworkConnected().equals(NOT_CONNECT)) {
                    networkSnack();
                } else {
                    if (TextUtils.isEmpty(("" + edtGroupName.getText()).trim())) {
                        makeToast(getString(R.string.enter_group_name));
                    } else {
                        progressDialog.show();
                        createGroup("" + edtGroupName.getText());
                    }
                }
                break;

        }
    }

    private void requestCameraPermission() {
        cameraPermissionResult.launch(new String[]{CAMERA});
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            storagePermissionResult.launch(PermissionsUtils.READ_STORAGE_PERMISSION);
        } else {
            storagePermissionResult.launch(PermissionsUtils.READ_WRITE_PERMISSIONS);
        }
    }

    private void openPickerDialog() {

        View contentView = getLayoutInflater().inflate(R.layout.bottom_sheet_image_pick_options, findViewById(R.id.parentLay), false);
        BottomSheetDialog pickerOptionsSheet = new BottomSheetDialog(this, R.style.SimpleBottomDialog);
        pickerOptionsSheet.setCanceledOnTouchOutside(true);
        pickerOptionsSheet.setContentView(contentView);
        //    pickerOptionsSheet.setDismissWithAnimation(true);

        View layoutCamera = contentView.findViewById(R.id.container_camera_option);
        View layoutGallery = contentView.findViewById(R.id.container_gallery_option);

        layoutCamera.setOnClickListener(v -> {
            pickerOptionsSheet.dismiss();
            isCameraClicked = true;
            isGalleryClicked = false;
            if (ContextCompat.checkSelfPermission(this, CAMERA) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    if (PermissionsUtils.checkStoragePermission(mContext)) {
                        takeCameraPictures();
                    } else {
                        requestStoragePermissions();
                    }
                } else {
                    takeCameraPictures();
                }
            } else {
                requestCameraPermission();
            }
        });
        layoutGallery.setOnClickListener(v -> {
            isCameraClicked = false;
            isGalleryClicked = true;
            pickerOptionsSheet.dismiss();
            if (PermissionsUtils.checkStoragePermission(mContext)) {
                pickGalleryPictures();
            } else {
                requestStoragePermissions();
            }
        });

        pickerOptionsSheet.show();
    }

    private void takeCameraPictures() {
        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        if (captureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                //     Timber.e(ex);
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                mCurrentPhotoUri = FileProvider.getUriForFile(this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        photoFile);
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri);
                cameraResultLauncher.launch(captureIntent);
            }
        }
    }

    private void pickGalleryPictures() {
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Intent pickIntent = new Intent(Intent.ACTION_PICK, collection);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(pickIntent, "Select a picture");

        if (chooserIntent.resolveActivity(getPackageManager()) != null) {
            cameraResultLauncher.launch(chooserIntent);
        }

    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoFile = image;
        return image;
    }

    private void createGroup(String groupName) {
        try {
            JSONObject jobj = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jobj.put(TAG_USER_ID, GetSet.getUserId());
            jobj.put(TAG_GROUP_NAME, groupName);
            jobj.put(TAG_GROUP_IMAGE, "");

            /*Add as Admin*/
            JSONObject group = new JSONObject();
            group.put(TAG_MEMBER_ID, GetSet.getUserId());
            group.put(TAG_MEMBER_NAME, ApplicationClass.getContactName(this, GetSet.getphonenumber(), ""));
            group.put(TAG_MEMBER_PICTURE, GetSet.getImageUrl());
            group.put(TAG_MEMBER_NO, GetSet.getphonenumber());
            group.put(TAG_MEMBER_ABOUT, GetSet.getAbout());
            group.put(TAG_MEMBER_ROLE, ADMIN);
            jsonArray.put(group);

            for (ContactsData.Result result : groupList) {
                group = new JSONObject();
                group.put(TAG_MEMBER_ID, result.user_id);
                group.put(TAG_MEMBER_NAME, result.user_name);
                group.put(TAG_MEMBER_PICTURE, result.user_image);
                group.put(TAG_MEMBER_NO, result.phone_no);
                group.put(TAG_MEMBER_ABOUT, "");
                group.put(TAG_MEMBER_ROLE, MEMBER);
                jsonArray.put(group);
            }
            jobj.put(TAG_GROUP_MEMBERS, jsonArray);
            socketConnection.createGroup(jobj);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onGroupCreated(final JSONObject data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mCurrentPhotoUri != null) {
                        try {
                            uploadImage(StorageManager.getBytes(getContentResolver().openInputStream(mCurrentPhotoUri)), data.getString(TAG_ID), data.getString(TAG_GROUP_NAME));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                        finish();
                        Intent i = new Intent(CreateGroupActivity.this, GroupChatActivity.class);
                        i.putExtra(TAG_GROUP_ID, data.getString(TAG_ID));
                        startActivity(i);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    void uploadImage(byte[] imageBytes, final String Id, final String groupName) {
        RequestBody requestFile = RequestBody.create(imageBytes, MediaType.parse("openImage/*"));
        MultipartBody.Part body = MultipartBody.Part.createFormData("group_image", "openImage.jpg", requestFile);

        final RequestBody groupId = RequestBody.create(Id, MediaType.parse("multipart/form-data"));
        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<HashMap<String, String>> call3 = apiInterface.uploadGroupImage(GetSet.getToken(), body, groupId);
        call3.enqueue(new Callback<HashMap<String, String>>() {
            @Override
            public void onResponse(Call<HashMap<String, String>> call, Response<HashMap<String, String>> response) {
                HashMap<String, String> data = response.body();
                Log.i(TAG, "uploadImage: " + data.toString());
                if (data.get(Constants.TAG_STATUS).equalsIgnoreCase(TAG_TRUE)) {
                    if (data.get(Constants.TAG_GROUP_IMAGE) != null) {
                        dbhelper.updateGroupData(Id, Constants.TAG_GROUP_IMAGE,
                                data.get(Constants.TAG_GROUP_IMAGE));
                        RandomString randomString = new RandomString(10);
                        String messageId = GetSet.getUserId() + randomString.nextString();
                        String currentUTCTime = DateUtils.getInstance(CreateGroupActivity.this).getCurrentUTCTime();
                        String textMsg = getString(R.string.changed_group_image);
                        try {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put(Constants.TAG_GROUP_ID, Id);
                            jsonObject.put(Constants.TAG_GROUP_NAME, groupName);
                            jsonObject.put(Constants.TAG_CHAT_TYPE, TAG_GROUP);
                            jsonObject.put(Constants.TAG_ATTACHMENT, data.get(Constants.TAG_GROUP_IMAGE));
                            jsonObject.put(Constants.TAG_GROUP_ADMIN_ID, GetSet.getUserId());
                            jsonObject.put(Constants.TAG_MEMBER_ID, GetSet.getUserId());
                            jsonObject.put(Constants.TAG_MESSAGE_ID, messageId);
                            jsonObject.put(Constants.TAG_MESSAGE_TYPE, "group_image");
                            jsonObject.put(Constants.TAG_MESSAGE, textMsg);
                            jsonObject.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                            socketConnection.messageToGroup(jsonObject);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                        finish();
                        Intent i = new Intent(CreateGroupActivity.this, GroupChatActivity.class);
                        i.putExtra(TAG_GROUP_ID, Id);
                        startActivity(i);
                    }
                }

            }

            @Override
            public void onFailure(Call<HashMap<String, String>> call, Throwable t) {
                Log.e(TAG, "uploadImage " + t.getMessage());
                call.cancel();
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SocketConnection.getInstance(this).setOnGroupCreatedListener(null);
    }

    public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.MyViewHolder> {

        List<ContactsData.Result> groupList;
        Context context;

        public GroupAdapter(Context context, List<ContactsData.Result> groupList) {
            this.context = context;
            this.groupList = groupList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_select_member, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, int position) {

            ContactsData.Result result = groupList.get(position);

            if (result.blockedme.equals("block")) {
                Glide.with(context).load(R.drawable.temp)
                        .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                        .into(holder.profileimage);
            } else {
                DialogActivity.setProfileImage(result, holder.profileimage, context);
            }

            holder.txtName.setText(result.user_name);
        }

        @Override
        public int getItemCount() {
            return groupList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            LinearLayout parentlay;
            AppCompatImageView btnRemove;
            CircleImageView profileimage;
            TextView txtName;

            public MyViewHolder(View view) {
                super(view);

                parentlay = view.findViewById(R.id.parentlay);
                profileimage = view.findViewById(R.id.userImage);
                txtName = view.findViewById(R.id.txtName);
                btnRemove = view.findViewById(R.id.btnRemove);

                btnRemove.setVisibility(View.GONE);
            }

        }
    }

}
