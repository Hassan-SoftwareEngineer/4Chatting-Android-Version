package com.app.helper.callback;

public interface OkayCancelCallback {
    void onOkayClicked(Object o);
    void onCancelClicked(Object o);
}
