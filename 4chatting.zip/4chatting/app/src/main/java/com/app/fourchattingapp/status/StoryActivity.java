
package com.app.fourchattingapp.status;

import static com.app.helper.NetworkUtil.NOT_CONNECT;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.ToxicBakery.viewpager.transforms.CubeInTransformer;
import com.ToxicBakery.viewpager.transforms.CubeOutTransformer;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.googlecode.mp4parser.util.Matrix;
import com.app.external.RandomString;
import com.app.external.keyboard.HeightProvider;
import com.app.helper.DatabaseHandler;
import com.app.helper.DateUtils;
import com.app.helper.DownloadFiles;
import com.app.helper.GetVideoRotationInDegrees;
import com.app.helper.ImageDownloader;
import com.app.helper.NetworkUtil;
import com.app.helper.PermissionsUtils;
import com.app.helper.SocketConnection;
import com.app.helper.StorageManager;
import com.app.helper.Utils;
import com.app.fourchattingapp.ApplicationClass;
import com.app.fourchattingapp.BaseActivity;
import com.app.fourchattingapp.DialogActivity;
import com.app.fourchattingapp.R;
import com.app.model.ContactsData;
import com.app.model.MessagesData;
import com.app.model.StatusDatas;
import com.app.utils.Constants;
import com.app.utils.GetSet;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class StoryActivity extends BaseActivity implements
        SocketConnection.StoryListener, StoryStatusView.StoriesListener {

    private static final String TAG = StoryActivity.class.getSimpleName();
    private static final ArrayList<TransformerItem> TRANSFORM_CLASSES;
    private static DefaultBandwidthMeter BANDWIDTH_METER;

    static {
        TRANSFORM_CLASSES = new ArrayList<TransformerItem>();
        TRANSFORM_CLASSES.add(new TransformerItem(CubeInTransformer.class));
        TRANSFORM_CLASSES.add(new TransformerItem(CubeOutTransformer.class));
    }

    ArrayList<ImageDownloader> listDownloadapi= new ArrayList<>();
    ArrayList<DownloadFiles> listVideoDownloadapi = new ArrayList<>();
    public StoryStatusView storyStatusView;
    public File[] files;
    // Declaration of widgets
    StyledPlayerView styledPlayerView;
    MediaSource videoSource;
    DataSource.Factory dataSourceFactory;
    private String USER_AGENT;
    ExoPlayer player;
    ProgressBar imageProgressBar;
    ViewPager viewPager;
    EditText edtMessage;
    private ImageView ivEmoji;
    TextView userTxt, timeTxt, seenCount, statusMsg;
    RelativeLayout editLay, parentLayout;
    private FrameLayout contentLay;
    LinearLayout bottomLay;
    LinearLayout statusMsgLay, statusCountLay;
    ConstraintLayout mainLay;
    TextView viewCount;
    private ImageView statusImage, userImg, btnSend;
    private FrameLayout videoFrame;
    boolean unseen  = false;
    CountDownTimer longClickTimer;
    String way = "";
    List<ContactsData.Result> statusList = new ArrayList<>();
    List<StatusDatas> statusDatas = new ArrayList<>();
    DatabaseHandler dbHelper;
    StorageManager storageManager;
    SocketConnection socketConnection;
    ViewPeopleAdapter viewPeopleAdapter;
    ArrayList<HashMap<String, String>> viewedContacts;
    private String beforeText = "";
    private int currentPlaybackPosition = 0;
    private boolean isStoryPlaying = false, isMute = false,
            isReadMore = false, playReady = false;
    private int counter = 0, pagerPosition = 0, pos = 0, posParent = 0;
    private long pressTime = 0L, limit = 500L;
    private SharedPreferences pref;
    private ViewPagerAdapter viewPagerAdapter;
    int bottomNavHeight = 0, bottomMargin = 0;
    private boolean isKeyBoardOpen = false;
    private DateUtils dateUtils;
    private Context mContext;

    private View.OnTouchListener onTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Log.i(TAG, "onTouch: " + event.getAction());
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    pressTime = System.currentTimeMillis();
                    pauseAll();
                    return false;
                }
                case MotionEvent.ACTION_UP: {
                    long now = System.currentTimeMillis();
                    resumeAll();
                    return limit < now - pressTime;
                }
                /*case MotionEvent.ACTION_MOVE:
                case MotionEvent.AXIS_SIZE: {
                    pauseAll();
                    return false;
                }*/
            }
            return false;
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        setContentView(R.layout.pager_activity);
        mContext = this;
        isMute = false;
        pref = getSharedPreferences("SavedPref", MODE_PRIVATE);
        dbHelper = DatabaseHandler.getInstance(this);
        storageManager = StorageManager.getInstance(this);
        socketConnection = SocketConnection.getInstance(this);
        socketConnection.setStoryListener(this);
        USER_AGENT = Util.getUserAgent(this, getString(R.string.app_name));
        dateUtils = DateUtils.getInstance(this);

        mainLay = findViewById(R.id.mainLay);
        viewPager = findViewById(R.id.viewPager);
        contentLay = findViewById(R.id.content_lay);
        bottomMargin = ApplicationClass.dpToPx(this, 2);

        if (getIntent().getSerializableExtra(Constants.TAG_DATA) != null) {
            statusList = (List<ContactsData.Result>) getIntent().getSerializableExtra(Constants.TAG_DATA);
            pos = getIntent().getIntExtra(Constants.TAG_POSITION, -1);
            if (statusList.get(pos).user_id.equals(GetSet.getUserId()))
                way = Constants.TAG_OWN_STORY;
        }

        mainLay.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                bottomNavHeight = view.getPaddingBottom() + windowInsets.getSystemWindowInsetBottom() + bottomMargin;
                return windowInsets.consumeSystemWindowInsets();
            }
        });

        new HeightProvider(this).init().setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                if (height > 0) {
                    isKeyBoardOpen = true;
                    if (statusMsg != null) {
                        statusMsg.setVisibility(View.GONE);
                    }
                    if (bottomLay != null)
                        bottomLay.setTranslationY(-height);
                } else {
                    isKeyBoardOpen = false;
                    if (statusMsg != null) {
                        if (!TextUtils.isEmpty(statusMsg.getText())) {
                            statusMsg.setVisibility(View.VISIBLE);
                        } else {
                            statusMsg.setVisibility(View.GONE);
                        }
                    }
                    if (bottomLay != null)
                        bottomLay.setTranslationY(0);
                }
            }
        });

        if (!way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
            if (statusList.get(0).user_id.equalsIgnoreCase(GetSet.getUserId())) {
                pagerPosition = pos - 1;
            } else pagerPosition = pos;
        }

        Log.d(TAG, "Position: " + pos + ", Way: " + way);
        viewPagerAdapter = new ViewPagerAdapter(this, statusList);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setCurrentItem(pagerPosition);
        viewPager.setOffscreenPageLimit(statusList.size());

        try {
            viewPager.setPageTransformer(true, TRANSFORM_CLASSES.get(1).clazz.newInstance());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.i(TAG, "onPageScrolled: ");
                pauseAll();
            }

            @Override
            public void onPageSelected(int position) {
                Log.i(TAG, "onPageSelected: " + position);
                pagerPosition = position;
                if (statusList.get(0).user_id.equalsIgnoreCase(GetSet.getUserId())) {
                    position++;
                    pos = position;
                } else {
                    pos = position;
                }

                statusDatas = dbHelper.getSingleUserStatus(statusList.get(position).user_id);

                counter = 0;

                if (storyStatusView != null) {
                    storyStatusView.destroy();
                    storyStatusView.setClearAnim();
                }

                for (StatusDatas datas : statusDatas) {
                    if (datas.mIsSeen.equals("0")) {
                        counter = statusDatas.indexOf(datas);
                        break;
                    }
                }

                if (counter < 1) {
                    counter = 0;
                }

                releasePlayer();

                if (statusImage != null)
                    statusImage.setVisibility(View.VISIBLE);
                init(statusList.get(pos));

            }

            @Override
            public void onPageScrollStateChanged(int state) {
                Log.i(TAG, "onPageScrollStateChanged: " + state);
                if (state == ViewPager.SCROLL_STATE_IDLE) {
                    resumeAll();
                }
                /*if (state == ViewPager.SCROLL_STATE_IDLE) {
                    if (way.equals(Constants.TAG_OWN_STORY)) {
                        if (storyStatusView != null)
                            resumeAll();
                    } else {
                        if (viewPagerAdapter.getCount() == 1 ||
                                viewPager.getCurrentItem() == 0 ||
                                viewPager.getCurrentItem() == viewPagerAdapter.getCount() - 1) {
                            if (storyStatusView != null)
                                resumeAll();
                        }
                    }
                }*/
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (statusList.size() > 0) {
                    statusDatas = dbHelper.getSingleUserStatus(statusList.get(pos).user_id);
                    init(statusList.get(pos));
                }
            }
        }, 500);
    }

    @Override
    public void onNetworkChange(boolean isConnected) {

    }

    @Override
    public void backPressed() {
        finish();
    }

    public void init(ContactsData.Result data) {

        View view = viewPager.findViewWithTag(viewPager.getCurrentItem() + "pos");

        statusImage = view.findViewById(R.id.image);
        ImageView close_img = view.findViewById(R.id.close);
        videoFrame = view.findViewById(R.id.video_frame);
        imageProgressBar = view.findViewById(R.id.imageProgressBar);
        editLay = view.findViewById(R.id.edtLay);
        edtMessage = view.findViewById(R.id.edtMessage);
        ivEmoji = view.findViewById(R.id.iv_emoji);
        userImg = view.findViewById(R.id.userImage);
        btnSend = view.findViewById(R.id.btnSend);
        userTxt = view.findViewById(R.id.user_name);
        statusMsg = view.findViewById(R.id.statusMsg);
        seenCount = view.findViewById(R.id.seenCount);
        timeTxt = view.findViewById(R.id.time);
        bottomLay = view.findViewById(R.id.bottomLay);
        statusMsgLay = view.findViewById(R.id.statusMsgLay);
        statusCountLay = view.findViewById(R.id.statusCountLay);
        parentLayout = view.findViewById(R.id.parentLay);
        storyStatusView = view.findViewById(R.id.storiesStatus);
        //Initialize simpleExoPlayerView
        styledPlayerView = view.findViewById(R.id.exoplayer);

        initTopLayPadding(pref.getInt(Constants.TAG_STATUS_HEIGHT, 0));
        if (bottomLay != null) {
            initBottomPadding(bottomNavHeight + ApplicationClass.dpToPx(StoryActivity.this, 10));
            bottomLay.setVisibility(View.VISIBLE);
        }

        if (storyStatusView != null) {
            storyStatusView.setVisibility(View.VISIBLE);
        }

        if (ApplicationClass.isRTL()) {
            btnSend.setRotation(180);
        } else {
            btnSend.setRotation(0);
        }

        setPlayer();

        statusImage.setVisibility(View.VISIBLE);
        imageProgressBar.setIndeterminate(true);

        if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
            editLay.setVisibility(View.GONE);
            setSeenCount(true);
        } else {
            editLay.setVisibility(View.VISIBLE);
            edtMessage.setError(null);
            setSeenCount(false);
        }

        counter = 0;
        for (StatusDatas datas : statusDatas) {
            if (datas.mIsSeen.equals("0")) {
                counter = statusDatas.indexOf(datas);
                break;
            }
        }

        if(counter!=0) unseen = true;



        storyStatusView.setStoriesListener(StoryActivity.this);
        if (statusDatas.get(counter).mType.equalsIgnoreCase("video")) {
            statusImage.setVisibility(View.GONE);
        } else {
            imageProgressBar.setIndeterminate(true);
            imageProgressBar.setVisibility(View.VISIBLE);
        }
        storyStatusView.setStoriesCount(statusDatas.size());
        storyStatusView.setStoryDuration(Integer.MAX_VALUE);
//        storyStatusView.setPos(counter);

        view.findViewById(R.id.skip).setOnTouchListener(onTouchListener);
        view.findViewById(R.id.reverse).setOnTouchListener(onTouchListener);
        view.findViewById(R.id.center).setOnTouchListener(onTouchListener);

        view.findViewById(R.id.skip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isKeyBoardOpen) {
                            ApplicationClass.hideSoftKeyboard(StoryActivity.this);
                        } else {
                            storyStatusView.skip();
                        }
                    }
                }, 100);
            }
        });

        view.findViewById(R.id.center).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isKeyBoardOpen) {
                            ApplicationClass.hideSoftKeyboard(StoryActivity.this);
                        } else {
                            storyStatusView.skip();
                        }
                    }
                }, 100);
            }
        });

        view.findViewById(R.id.reverse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isKeyBoardOpen) {
                            ApplicationClass.hideSoftKeyboard(StoryActivity.this);
                        } else {
                            if (statusDatas.size() != 1) {
                                storyStatusView.reverse();
                            }
                        }
                    }
                }, 100);
            }
        });

        close_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                releasePlayer();
                finish();
            }
        });

        statusMsgLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseAll();
                viewDialog();
            }
        });

        edtMessage.setOnTouchListener((view1, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                pauseAll();
            }
            return false;
        });

        edtMessage.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    resumeAll();
                }
                return false;
            }
        });

        edtMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                beforeText = "" + charSequence;
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                /*if (editable.length() > 250) {
                    ApplicationClass.showToast(StoryActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_SHORT);
                } else if ((edtMessage.getLineCount() > 6)) {
                    edtMessage.setText("" + beforeText);
                    edtMessage.setSelection(edtMessage.length() - 1);
                    ApplicationClass.showToast(StoryActivity.this, getString(R.string.maximum_characters_limit_reached), Toast.LENGTH_SHORT);
                }*/
            }
        });

        btnSend.setOnClickListener(v -> sendMessage());

        isReadMore = false;
        stopVideoView();
        setUserData(data);

        isStoryPlaying = false;
        pauseView();
        setStatus(statusDatas.get(counter).mType, statusDatas.get(counter).mAttachment);
    }

    private void addReadMore(final String text, final TextView textView) {
        SpannableString ss = new SpannableString(text.substring(0, 70) + " " + getString(R.string.read_more) + " ");
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View view) {
                isReadMore = true;
                addReadLess(text, textView);
                playVideo();
                pauseAll();
                if (player != null) {
                    player.setPlayWhenReady(false);
                }
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
                ds.setColor(ContextCompat.getColor(StoryActivity.this, R.color.colorAccent));
            }
        };
        ss.setSpan(clickableSpan, ss.length() - 10, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void addReadLess(final String text, final TextView textView) {
        SpannableString ss = new SpannableString(text + " " + getString(R.string.read_less) + " ");
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View view) {
                isReadMore = false;
                resumeAll();
                addReadMore(text, textView);
                /*if(player!=null){
                    player.setPlayWhenReady(true);
                }*/
                playVideo();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
                ds.setColor(ContextCompat.getColor(StoryActivity.this, R.color.colorAccent));
            }
        };
        ss.setSpan(clickableSpan, ss.length() - 10, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void setSeenCount(boolean isVisible) {
        if (isVisible) {
            statusMsgLay.setVisibility(View.VISIBLE);
            viewedContacts = dbHelper.getViewedContact(getApplicationContext(), statusDatas.get(counter).mStatusId);
            seenCount.setText(" " + viewedContacts.size());
        } else {
            statusMsgLay.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNext() {
        Log.e("checkHidy","-onnext "+counter);
        isStoryPlaying = false;
        counter++;
        Log.d(TAG, "onNext: " + counter);
        pauseView();
        Media();
    }

    @Override
    public void onPrev() {
        isStoryPlaying = false;
        if (counter - 1 < 0) {
            if (pagerPosition != 0) {
                pagerPosition--;
                viewPager.setCurrentItem(pagerPosition);
                Log.d(TAG, "onPrev: ");
            } else {
                if (statusDatas.get(counter).mType.contains("video")) {
                    releasePlayer();
                    setPlayer();
                }
            }
            cancelApiList();
            setStatus(statusDatas.get(counter).mType, statusDatas.get(counter).mAttachment);
            return;
        }
        cancelApiList();
        pauseView();
        counter--;
        Log.d(TAG, "onPrev: " + counter);

        Media();
    }

    @Override
    public void onComplete() {
        if ((statusDatas.size() - 1) == counter) {
            pagerPosition++;
            isReadMore = false;
            if (pagerPosition == viewPager.getAdapter().getCount()) {
                releasePlayer();
                finish();
            } else {
                if (storyStatusView != null) {
                    storyStatusView.destroy();
                    storyStatusView.setStoriesListener(null);
                }
                viewPager.setCurrentItem(pagerPosition);
            }
        }
    }

    public void Media() {
        isReadMore = false;
        if (player != null) {
            player.setPlayWhenReady(false);
        }
        releasePlayer();
        setPlayer();
        stopVideoView();
        cancelApiList();
        statusImage.setImageResource(0);
        statusImage.setVisibility(View.VISIBLE);
        imageProgressBar.setVisibility(View.VISIBLE);
        storyStatusView.setStoryDuration(Integer.MAX_VALUE);

        if (counter != -1 && counter < statusDatas.size()) {
            timeTxt.setText(dateUtils.getStatusTime(statusDatas.get(counter).mStatusTime));
            if (statusDatas.get(counter).mSenderId.equalsIgnoreCase(GetSet.getUserId())) {
                way = Constants.TAG_OWN_STORY;
            }
            if (statusDatas.get(counter).mType.contains("video")) {
                statusImage.setVisibility(View.GONE);
            } else {
                imageProgressBar.setIndeterminate(true);
                imageProgressBar.setVisibility(View.VISIBLE);
            }
            setStatus(statusDatas.get(counter).mType, statusDatas.get(counter).mAttachment);
        }

        if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
            editLay.setVisibility(View.GONE);
            setSeenCount(true);
        } else {
            editLay.setVisibility(View.VISIBLE);
            edtMessage.setError(null);
            setSeenCount(false);
        }
    }

    public void setPlayer() {
        // Create a default TrackSelector
        BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter.Builder(StoryActivity.this).build();
        TrackSelector trackSelector = new DefaultTrackSelector(this);
        LoadControl loadControl = new DefaultLoadControl();

        //Initialize the player
        player = new ExoPlayer.Builder(this)
                .setBandwidthMeter(bandwidthMeter)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .build();
        styledPlayerView.setPlayer(player);

        // Produces DataSource instances through which media data is loaded.
        dataSourceFactory = new DefaultDataSource.Factory(mContext);
        dataSourceFactory.createDataSource();
    }

    public void releasePlayer() {
        if (styledPlayerView != null) {
            styledPlayerView.getPlayer().setPlayWhenReady(false);
            styledPlayerView.getPlayer().stop();
            styledPlayerView.getPlayer().release();

            if (player != null) {
                player.clearVideoSurface();
                player.release();
            }
            if (videoSource != null) {
                videoSource = null;
            }
        }
    }

    private String isNetworkConnected() {
        return NetworkUtil.getConnectivityStatusString(this);
    }

    private void networkSnack() {
        Snackbar snackbar = Snackbar
                .make(mainLay, getString(R.string.network_failure), Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    private void setStatus(String type, String name) {
        if (!statusDatas.get(counter).mMessage.equals("")) {
            statusMsg.setVisibility(View.VISIBLE);

            statusMsg.setText(statusDatas.get(counter).mMessage);
            statusMsg.post(new Runnable() {
                @Override
                public void run() {
                    if (statusMsg != null && statusMsg.length() > 70) {
                        addReadMore(statusMsg.getText().toString(), statusMsg);
                    }
                }
            });
        } else {
            statusMsg.setVisibility(View.GONE);
        }

        if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
            if (type.equalsIgnoreCase("video")) {
                Uri fileUri = null;
                File outputFile = storageManager.getStatusFile(name, StorageManager.TAG_SENT);

                if (outputFile != null) {
                    fileUri = storageManager.getUriFromFile(outputFile);
                }

                if (fileUri != null) {
                    storyStatusView.setStoryDuration(storageManager.getMediaDuration(mContext, outputFile.getAbsolutePath()));
                    //Log.e("checkFile","-"+outputFile.getAbsolutePath()+" "+fileUri+" "+storageManager.getMediaDuration(mContext, outputFile.getAbsolutePath()));
                    playVideoInLocal(fileUri);
                } else {
                    Toast.makeText(StoryActivity.this, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                }
            } else {
                File outputFile = storageManager.getStatusFile(name, StorageManager.TAG_SENT);
                if (outputFile != null && outputFile.exists()) {
                    storyStatusView.setStoryDuration(Constants.storyDuration);
                    loadImageFile(outputFile);
                    imageProgressBar.setVisibility(View.GONE);
                    startStories(counter == 0, false);
                } else {
                    Toast.makeText(StoryActivity.this, getString(R.string.no_media), Toast.LENGTH_SHORT).show();
                    storyStatusView.skip();
                }
            }
        } else {
            if (type.equalsIgnoreCase("video")) {
                Uri fileUri = null;
                File outputFile = storageManager.getStatusFile(name, "");

//                File outputFile = storageManager.getStatusFile(/*name,*/ "attachment-1632482463688.mp4", "");
                if (outputFile != null) {
                    fileUri = storageManager.getUriFromFile(outputFile);
                }

                if (fileUri != null) {
                    storyStatusView.setStoryDuration(storageManager.getMediaDuration(mContext, outputFile.getAbsolutePath()));

//                    rotateVideo(outputFile);
                    playVideoInLocal(fileUri);
                    AddSeenToStory();
                } else {
                    if (isNetworkConnected().equals(NOT_CONNECT)) {
                        networkSnack();
                    } else {
                        storyStatusView.setStoryDuration(Constants.storyDuration);
                        if(counter==0 && !storyStatusView.getStartStory())
                            storyStatusView.startStories();
                        else if(unseen){
                            startStories(counter==0,unseen);
                        }
                        downloadFile(name, type);
                    }
                }
            } else {
                File outputFile = storageManager.getStatusFile(name, "");
                if (outputFile != null && outputFile.exists()) {
                    storyStatusView.setStoryDuration(Constants.storyDuration);

                    startStories(counter == 0, unseen);
                    loadImageFile(outputFile);
                    AddSeenToStory();
                    imageProgressBar.setVisibility(View.GONE);
                } else {
                    if (!PermissionsUtils.checkStoragePermission(mContext)) {
                        Toast.makeText(mContext, getString(R.string.storage_permission_error), Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        if (isNetworkConnected().equals(NOT_CONNECT)) {
                            networkSnack();
                        } else {

                            storyStatusView.setStoryDuration(Constants.storyDuration);
                            if(unseen){
                                startStories(counter==0,unseen);
                            }
                            else if(counter==0 && !storyStatusView.getStartStory())
                            storyStatusView.startStories();


                            pauseDelay();

                            ImageDownloader imageDownloader = new ImageDownloader(StoryActivity.this) {
                                @Override
                                protected void onPostExecute(Bitmap imgBitmap) {
                                    if (imgBitmap == null) {
                                        Toast.makeText(mContext, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                    } else {
                                        try {
                                            File savedFile = null;


                                            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                savedFile = storageManager.saveStatusFile(imgBitmap, null, name, "");
                                            } else {
                                                savedFile = storageManager.saveStatusFile(imgBitmap, null, name, "");
                                            }

                                            Log.e("checkpp","-"+savedFile.exists()+" "+storyStatusView.getStartStory());
                                            if (savedFile != null && savedFile.exists()) {
                                                //storyStatusView.setStoryDuration(Constants.storyDuration);
                                                loadImageFile(savedFile);
                                                AddSeenToStory();
                            /*                    if(counter<statusDatas.size())
                                                    startStories(!storyStatusView.isPaused(counter), unseen);
*/
                                                new Timer().schedule(
                                                        new TimerTask() {
                                                            @Override
                                                            public void run() {
                                                                runOnUiThread(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        storyStatusView.resume();
                                                                    }
                                                                });
                                                            }
                                                        }, 600);
                                                imageProgressBar.setVisibility(View.GONE);
//                                                resumeInDownloadImage();
                                            } else {
                                                Toast.makeText(StoryActivity.this, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (NullPointerException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }

                                @Override
                                protected void onProgressUpdate(String... progress) {
                                    //progressbar.setProgress(Integer.parseInt(progress[0]));
                                }
                            };
                            imageDownloader.execute(Constants.CHAT_IMG_PATH + name, Constants.TAG_STATUS);

                            listDownloadapi.add(imageDownloader);
                        }
                    }
                }
            }
        }
    }

    public void cancelApiList(){
        for(int i=0;i<listDownloadapi.size();i++){
            listDownloadapi.get(i).cancel(true);
        }
        listDownloadapi.clear();

        for(int i=0;i<listVideoDownloadapi.size();i++){
            listVideoDownloadapi.get(i).cancel(true);
        }
        listVideoDownloadapi.clear();
    }



    private void rotateVideo(File fileVideo) {
        try {
//            Movie result = MovieCreator.build(fileVideo.getAbsolutePath());
//            Matrix matrix = result.getMatrix();
            GetVideoRotationInDegrees getVideoRotationInDegrees = new GetVideoRotationInDegrees();
            Matrix matrix = getVideoRotationInDegrees.getRotation(fileVideo.getAbsolutePath());
            Log.d(TAG, "rotateVideo: " + matrix);
            /*List<TrackBox> trackBoxes = isoFile.getMovieBox().getBoxes(
                    TrackBox.class);

            for (TrackBox trackBox : trackBoxes) {
                trackBox.getTrackHeaderBox().setMatrix(com.googlecode.mp4parser.util.Matrix.ROTATE_270);
                result.addTrack(new Mp4TrackImpl("track", trackBox));
            }

            Container out = new DefaultMp4Builder().build(result);
            out.writeContainer(new FileOutputStream(inputFilePath).getChannel());*/
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private MediaMetadataRetriever getMediaRetriever(Context mContext, Uri fileUri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(mContext, fileUri);
        /*String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
        String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
        String s = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
        Log.d(TAG, "getMediaRetriever: " + height + ", " + width + ", " + s);
        Bitmap bmp = retriever.getFrameAtTime(1);
        int videoWidth = bmp.getWidth();
        int videoHeight = bmp.getHeight();
        if (videoWidth > videoHeight && Integer.parseInt(s) <= 0) {
            simpleExoPlayerView.getVideoSurfaceView().setRotation(90);
            simpleExoPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH);
        } else {
            simpleExoPlayerView.getVideoSurfaceView().setRotation(0);
            simpleExoPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH);
        }*/
        return retriever;
    }

    private void loadImageFile(File file) {
        Glide.with(getApplicationContext())
                .load(file)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .thumbnail(0.5f)
                .transition(new DrawableTransitionOptions().crossFade())
                .into(statusImage);
    }

    private void downloadFile(String fileName, String type) {
        pauseDelay();
        if (!storyStatusView.isPaused(counter)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    storyStatusView.pause();
                }
            });
        }

        DownloadFiles downloadFiles = new DownloadFiles(mContext) {
            @Override
            protected void onPostExecute(String downPath) {
                if (!TextUtils.isEmpty(downPath)) {
                    Uri uri = storageManager.getUriFromFile(new File(downPath));
                    //storyStatusView.setStoryDuration(storageManager.getMediaDuration(mContext, downPath));

                    storyStatusView.setDurationAnim(counter,storageManager.getMediaDuration(mContext, downPath));
                    new Timer().schedule(
                            new TimerTask() {
                                @Override
                                public void run() {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            storyStatusView.resume();
                                        }
                                    });
                                }
                            }, 600);
                    /*if (counter == 0) {
                        startStories(true,false);
                    } else {
                        if(counter<statusDatas.size())
                            startStories(!storyStatusView.isPaused(counter),false);
                    }*/
                    isStoryPlaying = true;
                    playVideoInLocal(uri);
                    AddSeenToStory();
                } else {
                    makeToast(getString(R.string.something_wrong));
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            storyStatusView.skip();
                        }
                    }, 500);
                }
            }
        };

        Log.e("checkDownloading","-"+Constants.CHAT_IMG_PATH + fileName);
        downloadFiles.execute(Constants.CHAT_IMG_PATH + fileName, StorageManager.TAG_STATUS);
        listVideoDownloadapi.add(downloadFiles);
    }

    private void startStories(boolean isFromStart, boolean fromUnseen) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        isStoryPlaying = true;
                        if(unseen){
                            storyStatusView.startStories(0);
                            int maincount = counter;
                            counter=0;
                            int valcount = 0;
                            while(valcount<maincount) {
                                storyStatusView.skip();
                                valcount++;
                            }

                            unseen =false;
                        }
                        else if (isFromStart) {
                            storyStatusView.startStories(0);
                        }
                        else {
                            storyStatusView.resume();

                        }
                    }
                });
            }
        }, 100);
    }

    public void pauseDelay() {
        new Timer().schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                storyStatusView.pause();
                            }
                        });
                    }
                }, 600);
    }

    public void playVideoInLocal(Uri videoUri) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {

                    MediaItem.Builder builder = new MediaItem.Builder();
                    builder.setUri(videoUri);
                    MediaItem mediaItem = builder.build();
                    videoSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem);
                    player.setMediaSource(videoSource);

                    player.prepare();
                    player.addListener(new Player.Listener() {
                        @Override
                        public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                            Log.d(TAG, "onPlayWhenReadyChanged: " + playWhenReady + ", " + reason);
                            playReady = playWhenReady;
                        }

                        @Override
                        public void onPlaybackStateChanged(int playbackState) {
                            Log.d(TAG, "onPlaybackStateChanged: " + playbackState);
                            switch (playbackState) {
                                case Player.STATE_BUFFERING:
                                    break;
                                case Player.STATE_ENDED:
                                    break;
                                case Player.STATE_IDLE:   //state_idle will call when player stop and release
                                    break;
                                default:
                                    if (playReady) {
                                        isStoryPlaying = true;
                                        startStories(counter == 0,false);
                                    }
                                    imageProgressBar.setVisibility(View.INVISIBLE); //state else will call when player is completed

                                    styledPlayerView.setVisibility(View.VISIBLE);
                                    statusImage.setVisibility(View.GONE);
                                    if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
                                        editLay.setVisibility(View.GONE);
                                        setSeenCount(true);
                                    } else {
                                        editLay.setVisibility(View.VISIBLE);
                                        edtMessage.setError(null);
                                        setSeenCount(false);
                                    }
                                    break;
                            }
                        }

                        @Override
                        public void onPlayerError(PlaybackException error) {
                            /*If File is Invalid, then delete the old and download new file*/
                            if (("" + error.getMessage()).contains("UnrecognizedInputFormatException")) {
                                pauseView();
                                imageProgressBar.setIndeterminate(true);
                                imageProgressBar.setVisibility(View.VISIBLE);
//                                storageManager.deleteFile(url);
                                downloadFile(getFileName(statusDatas.get(counter).mAttachment), statusDatas.get(counter).mType);
                            }
                        }
                    });

                    playVideo();

                    if (!isMute) {
                        player.setVolume(1.0f);
                    } else {
                        player.setVolume(0);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "playVideoInLocal: " + e.getMessage());
                }
            }
        });
    }

    void playVideo() {
        if (player != null) {
            if (!isReadMore) {
                resumeView();
                player.setPlayWhenReady(true);
            } else {
                pauseView();
                player.setPlayWhenReady(false);
            }
        }
    }

    public void setUserData(ContactsData.Result data) {
        userTxt.setText(data.user_name);
        timeTxt.setText(dateUtils.getStatusTime(statusDatas.get(counter).mStatusTime));

        /*if(!statusDatas.get(counter).mMessage.equals("")){
            statusMsg.setVisibility(View.VISIBLE);
            statusMsg.setText(statusDatas.get(counter).mMessage);
            statusMsg.post(new Runnable() {
                @Override
                public void run() {
                    if (statusMsg != null && statusMsg.length() > 70) {
                        addReadMore(statusMsg.getText().toString(), statusMsg);
                    }
                }
            });
        }*/

        if (!data.blockedme.equals("block")) {
            DialogActivity.setProfileImage(data, userImg, getApplicationContext());
        } else {
            Glide.with(getApplicationContext()).load(R.drawable.temp)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp))
                    .into(userImg);
        }
    }

    public void pauseView() {
        if (storyStatusView != null) {
            storyStatusView.pause();
        }
    }

    public void resumeView() {
        //pause functionality is working delay 100 seconds
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                if (storyStatusView != null) {
                    storyStatusView.resume();
                }
            }
        });
    }

    public void pauseAll() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (storyStatusView != null) {
                    storyStatusView.pause();
                }
                if (player != null) {
                    player.setPlayWhenReady(false);
                    player.getPlaybackState();
                }
            }
        });
    }

    public void resumeAll() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (storyStatusView != null) {
                    storyStatusView.resume();
                }

                if (player != null) {
                    player.setPlayWhenReady(true);
                    player.getPlaybackState();
                }
            }
        });
    }

    @Override
    public void onStoryViewed(String statusId) {
        if (statusDatas.size() > 0) {
            if (statusDatas.get(counter).mStatusId.equals(statusId)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (viewPeopleAdapter != null) {
                            viewedContacts.clear();
                            viewedContacts.addAll(dbHelper.getViewedContact(getApplicationContext(), statusId));
                            viewPeopleAdapter.notifyDataSetChanged();
                            if (viewCount != null) {
                                viewCount.setText(getString(R.string.viewed_by) + " " + viewedContacts.size());
                            }
                            if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY)) {
                                seenCount.setText(" " + viewedContacts.size());
                            }
                        }
                    }
                });
            }
        }
    }

    @Override
    public void onStoryDeleted(String statusId) {
        dbHelper.deleteStatus(statusId);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusDatas.get(counter).mStatusId.equals(statusId)) {
                    releasePlayer();
                    finish();
                }
            }
        });
    }

    private void blockChatConfirmDialog(String userId) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.default_popup);
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 90 / 100, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView title = dialog.findViewById(R.id.title);
        TextView yes = dialog.findViewById(R.id.yes);
        TextView no = dialog.findViewById(R.id.no);

        yes.setText(getString(R.string.unblock));
        no.setText(getString(R.string.cancel));
        title.setText(R.string.unblock_message);

        no.setVisibility(View.VISIBLE);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, userId);
                    jsonObject.put(Constants.TAG_TYPE, "unblock");
                    Log.v("block", "block=" + jsonObject);
                    socketConnection.block(jsonObject);
                    dbHelper.updateBlockStatus(userId, Constants.TAG_BLOCKED_BYME, "unblock");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void sendMessage() {
        if (isNetworkConnected().equals(NOT_CONNECT)) {
            networkSnack();
        } else if (statusList.get(pos).blockedbyme.equals("block")) {
            blockChatConfirmDialog(statusList.get(pos).user_id);
        } else {
            if (edtMessage.getText().toString().trim().length() > 0) {
                String currentUTCTime = DateUtils.getInstance(this).getCurrentUTCTime();
                String textMsg = edtMessage.getText().toString().trim();
                String chatId = GetSet.getUserId() + statusList.get(pos).user_id;
                RandomString randomString = new RandomString(10);
                String messageId = GetSet.getUserId() + randomString.nextString();
//                    if (!statusList.get(pos).blockedme.equals("block")) {
                try {
                    JSONObject jobj = new JSONObject();
                    JSONObject message = new JSONObject();
                    message.put(Constants.TAG_USER_ID, GetSet.getUserId());
                    message.put(Constants.TAG_USER_NAME, GetSet.getUserName());
                    message.put(Constants.TAG_MESSAGE_TYPE, "story");
                    message.put(Constants.TAG_MESSAGE, ApplicationClass.encryptMessage(textMsg));
                    message.put(Constants.TAG_CHAT_TIME, currentUTCTime);
                    message.put(Constants.TAG_CHAT_ID, chatId);
                    message.put(Constants.TAG_MESSAGE_ID, messageId);
                    message.put(Constants.TAG_RECEIVER_ID, statusList.get(pos).user_id);
                    message.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    message.put(Constants.TAG_CHAT_TYPE, Constants.TAG_SINGLE);
                    message.put(Constants.TAG_BLOCK_STATUS, "" + statusList.get(pos).blockedme.equals("block"));
                    message.put(Constants.TAG_BLOCKED_BY, statusList.get(pos).blockedme.equals("block") ? statusList.get(pos).user_id : "");
                    message.put(Constants.TAG_DELETE_FOR_EVERYONE, "" + false);

                    jobj.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jobj.put(Constants.TAG_RECEIVER_ID, statusList.get(pos).user_id);

                    JSONObject statusObj = new JSONObject();
                    statusObj.put(Constants.TAG_ATTACHMENT, statusDatas.get(counter).mAttachment);
                    statusObj.put(Constants.TAG_THUMBNAIL, statusDatas.get(counter).mThumbnail);
                    statusObj.put(Constants.TAG_STORY_TYPE, statusDatas.get(counter).mType);
                    statusObj.put(Constants.TAG_MESSAGE, statusDatas.get(counter).mMessage);
                    statusObj.put(Constants.TAG_STORY_ID, statusDatas.get(counter).mStatusId);

                    message.put(Constants.TAG_STATUS_DATA, ApplicationClass.encryptMessage(statusObj.toString()));
                    jobj.put("message_data", message);

                    Log.v(TAG, "startChat: " + jobj + "\n" + statusObj);
                    socketConnection.startChat(jobj);
                    MessagesData tempMessageData = Utils.getMessageData(chatId, messageId, GetSet.getUserId(), GetSet.getUserName(),
                            "story", textMsg, "", "", "", "", "", "",
                            currentUTCTime, statusList.get(pos).user_id, GetSet.getUserId(), "", "",
                            statusObj.toString(), "");
                    dbHelper.addMessageData(tempMessageData, true);
                    dbHelper.addRecentMessages(chatId, statusList.get(pos).user_id, messageId, currentUTCTime, "0");

                    Toast.makeText(StoryActivity.this, getString(R.string.sending_message), Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                    }

                edtMessage.setText("");
            } else {
                edtMessage.setError(getString(R.string.please_enter_your_message));
            }
        }

        ApplicationClass.hideSoftKeyboard(this, edtMessage);
        storyStatusView.resume();
        if (player != null) {
            player.setPlayWhenReady(true);
        }

        edtMessage.setText("");
    }

    public void AddSeenToStory() {
        try {
            if (statusDatas.get(counter).mIsSeen.equals("0")) {
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put(Constants.TAG_SENDER_ID, GetSet.getUserId());
                    jsonObject.put(Constants.TAG_RECEIVER_ID, statusDatas.get(counter).mSenderId);
                    jsonObject.put(Constants.TAG_STORY_ID, statusDatas.get(counter).mStatusId);
                    socketConnection.viewStory(jsonObject);
                    dbHelper.updateStatusSeen(statusDatas.get(counter).mStatusId);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
//        keyboardHeightProvider.setKeyboardHeightObserver(this);
        if (player != null)
            player.setPlayWhenReady(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                resumeView();
            }
        }, 200);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (player != null)
            player.setPlayWhenReady(false);

        pauseView();
    }

    @Override
    protected void onStop() {
        super.onStop();
        ApplicationClass.hideSoftKeyboard(this);
    }

    @Override
    public void onDestroy() {
        // Very important !
        storyStatusView.destroy();
        if (socketConnection != null) {
            socketConnection.setStoryListener(null);
        }
        super.onDestroy();
        if (styledPlayerView.getPlayer() != null) {
            styledPlayerView.getPlayer().setPlayWhenReady(false);
            styledPlayerView.getPlayer().stop();
            styledPlayerView.getPlayer().release();
        }

    }

    public void stopVideoView() {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                styledPlayerView.setVisibility(View.INVISIBLE);
            }
        });
    }

    /**
     * To open status viewed dialog
     */

    private void viewDialog() {
        Log.d(TAG, "viewDialog: " + new Gson().toJson(statusDatas));
        View bottomView = getLayoutInflater().inflate(R.layout.status_viewed_dialog, null);
        BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(bottomView);

        RecyclerView viewedRecyclerView = bottomView.findViewById(R.id.viewedRecyclerView);
        ImageView deleteStory = bottomView.findViewById(R.id.deleteStory);
        viewCount = bottomView.findViewById(R.id.viewCount);
        viewedContacts = dbHelper.getViewedContact(getApplicationContext(), statusDatas.get(counter).mStatusId);
        viewPeopleAdapter = new ViewPeopleAdapter(viewedContacts, getApplicationContext());
        viewedRecyclerView.setAdapter(viewPeopleAdapter);
        viewCount.setText(getString(R.string.viewed_by) + " " + viewedContacts.size());

        dialog.show();
        deleteStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                socketConnection.deleteStory(statusDatas.get(counter).mStatusId);
                storageManager.deleteStory(statusDatas.get(counter).mAttachment, statusDatas.get(counter).mThumbnail, Constants.TAG_OWN_STORY);
                dbHelper.deleteStatus(statusDatas.get(counter).mStatusId);
                releasePlayer();
                finish();

            }
        });

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if (!isReadMore) {
                    resumeAll();
                }
            }
        });
    }

    private void initTopLayPadding(int topMargin) {
        if (storyStatusView != null) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ApplicationClass.dpToPx(StoryActivity.this, 2));
            layoutParams.topMargin = topMargin + ApplicationClass.dpToPx(StoryActivity.this, 5);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
            storyStatusView.setLayoutParams(layoutParams);
        }
    }

    private void initBottomPadding(int bottomPadding) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        if (bottomLay != null) {
            bottomLay.setPadding(0, ApplicationClass.dpToPx(StoryActivity.this, 10), 0, bottomPadding);
            bottomLay.setLayoutParams(params);
        }
    }

    private static final class TransformerItem {

        final String title;
        final Class<? extends ViewPager.PageTransformer> clazz;

        public TransformerItem(Class<? extends ViewPager.PageTransformer> clazz) {
            this.clazz = clazz;
            title = clazz.getSimpleName();
        }

        @Override
        public String toString() {
            return title;
        }

    }

    public class ViewPagerAdapter extends PagerAdapter {

        List<ContactsData.Result> status;
        private Context mContext;

        public ViewPagerAdapter(Context context, List<ContactsData.Result> listDate) {
            mContext = context;
            status = listDate;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public int getCount() {
            if (way.equalsIgnoreCase(Constants.TAG_OWN_STORY))
                return 1;
            else {
                if (statusList.get(0).user_id.equalsIgnoreCase(GetSet.getUserId())) {
                    return status.size() - 1;
                } else return status.size();
            }
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            ViewGroup view = (ViewGroup) inflater.inflate(R.layout.story_pager_item, container, false);
            view.setTag(position + "pos");

            ImageView imageview = view.findViewById(R.id.image);
            imageview.setVisibility(View.VISIBLE);

            container.addView(view);
            return view;
        }
    }

    /**
     * Adapter to see people who viewed the status
     */

    class ViewPeopleAdapter extends RecyclerView.Adapter<ViewPeopleAdapter.ViewHolder> {
        ArrayList<HashMap<String, String>> items;
        Context context;

        ViewPeopleAdapter(ArrayList<HashMap<String, String>> items, Context context) {
            this.items = items;
            this.context = context;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.people_viewed_item, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            HashMap<String, String> map = items.get(position);
            holder.name.setText(map.get(Constants.TAG_USER_NAME));
            holder.message.setText(dateUtils.getStatusTime(map.get(Constants.TAG_STATUS_TIME)));
            Glide.with(context).load(Constants.USER_IMG_PATH + map.get(Constants.TAG_USER_IMAGE)).thumbnail(0.5f)
                    .apply(RequestOptions.circleCropTransform().placeholder(R.drawable.temp).error(R.drawable.temp).override(ApplicationClass.dpToPx(context, 70)))
                    .into(holder.profileimage);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            CircleImageView profileimage;
            TextView name, message;
            Context context;

            ViewHolder(View itemView) {
                super(itemView);
                profileimage = itemView.findViewById(R.id.profileimage);
                name = itemView.findViewById(R.id.name);
                message = itemView.findViewById(R.id.message);
                context = itemView.getContext();
            }
        }
    }

    private String getFileName(String url) {
        String imgSplit = url;
        int endIndex = imgSplit.lastIndexOf("/");
        if (endIndex != -1) {
            imgSplit = imgSplit.substring(endIndex + 1, imgSplit.length());
        }
        return imgSplit;
    }

}