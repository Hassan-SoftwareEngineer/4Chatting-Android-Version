package com.app.addons.livebroadcast.helper;

import android.content.Context;
import android.content.SharedPreferences;

import com.app.helper.LocaleManager;
import com.app.fourchattingapp.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import static android.content.Context.MODE_PRIVATE;

public class Utils {

    private static String TAG = Utils.class.getSimpleName();
    private static Context context;
    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;
    public static final String UTC_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public Utils(Context context) {
        this.context = context;
        pref = context.getSharedPreferences("SavedPref", MODE_PRIVATE);
        editor = pref.edit();
    }

    public String getFormattedDuration(long currentMilliSeconds) {
        String duration;
        if (TimeUnit.MILLISECONDS.toHours(currentMilliSeconds) != 0)
            duration = String.format(Locale.ENGLISH, "%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(currentMilliSeconds),
                    TimeUnit.MILLISECONDS.toMinutes(currentMilliSeconds) % TimeUnit.HOURS.toMinutes(1),
                    TimeUnit.MILLISECONDS.toSeconds(currentMilliSeconds) % TimeUnit.MINUTES.toSeconds(1));
        else
            duration = String.format(Locale.ENGLISH, "%02d:%02d",
                    TimeUnit.MILLISECONDS.toMinutes(currentMilliSeconds) % TimeUnit.HOURS.toMinutes(1),
                    TimeUnit.MILLISECONDS.toSeconds(currentMilliSeconds) % TimeUnit.MINUTES.toSeconds(1));
        return duration;
    }

    public String getCommentsDuration(long currentMilliSeconds) {
        String duration;
        duration = String.format(Locale.ENGLISH, "%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(currentMilliSeconds),
                TimeUnit.MILLISECONDS.toMinutes(currentMilliSeconds) % TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(currentMilliSeconds) % TimeUnit.MINUTES.toSeconds(1));
        return duration;
    }

    public String getRecentDate(long smsTimeInMillis) {
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTimeZone(TimeZone.getDefault());
        smsTime.setTimeInMillis(smsTimeInMillis);

        Calendar now = Calendar.getInstance();
        final long HOURS = 60 * 60 * 60;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE)) {
            SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm", Locale.ENGLISH);
            SimpleDateFormat hourFormat = new SimpleDateFormat("aa", LocaleManager.getLocale(context.getResources()));
            String recent = timeFormat.format(new Date(smsTime.getTimeInMillis())) + " " + hourFormat.format(new Date(smsTime.getTimeInMillis()));
            return context.getString(R.string.today) + ", " + recent;
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm", Locale.ENGLISH);
            SimpleDateFormat hourFormat = new SimpleDateFormat("aa", LocaleManager.getLocale(context.getResources()));
            Date date = new Date(smsTime.getTimeInMillis());
            String recent = timeFormat.format(date) + " " + hourFormat.format(date);
            return context.getString(R.string.yesterday) + ", " + recent;
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", LocaleManager.getLocale(context.getResources()));
            SimpleDateFormat dayFormat = new SimpleDateFormat("d", Locale.ENGLISH);
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm", Locale.ENGLISH);
            SimpleDateFormat hourFormat = new SimpleDateFormat("aa", LocaleManager.getLocale(context.getResources()));
            Date date = new Date(smsTime.getTimeInMillis());
            String recent = monthFormat.format(date) + " " + dayFormat.format(date) + ", " + timeFormat.format(date) + " " + hourFormat.format(date);
            return recent;
        } else {
            SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM", LocaleManager.getLocale(context.getResources()));
            SimpleDateFormat dayFormat = new SimpleDateFormat("dd yyyy", Locale.ENGLISH);
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm", Locale.ENGLISH);
            SimpleDateFormat hourFormat = new SimpleDateFormat("aa", LocaleManager.getLocale(context.getResources()));
            Date date = new Date(smsTime.getTimeInMillis());
            String recent = monthFormat.format(date) + " " + dayFormat.format(date) + ", " + timeFormat.format(date) +
                    " " + hourFormat.format(date);
            return recent;
        }
    }

    public Long getTimeFromUTC(String date) {
        DateFormat utcFormat = new SimpleDateFormat(UTC_DATE_PATTERN, Locale.ENGLISH);
        TimeZone utcZone = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcZone);
        Date myDate = new Date();
        try {
            myDate = utcFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
//        Log.i(TAG, "getTimeFromUTC: " + myDate.getTime());
        return myDate.getTime();
    }

    public static List<String> getReportList() {
        List<String> reportList = new ArrayList<>();
        reportList.add(context.getString(R.string.abuse));
        reportList.add(context.getString(R.string.in_appropriate));
        reportList.add(context.getString(R.string.adult_content));
        return reportList;
    }
}
