package com.app.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class TermsAndPrivacyResponse extends BaseResponse implements Serializable {

    @Expose
    private Result result;

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public static class Result implements Serializable {

        @Expose
        private String tos;

        @Expose
        @SerializedName("privacy_policy")
        private String privacyPolicy;

        public String getTos() {
            return tos;
        }

        public void setTos(String tos) {
            this.tos = tos;
        }

        public String getPrivacyPolicy() {
            return privacyPolicy;
        }

        public void setPrivacyPolicy(String privacyPolicy) {
            this.privacyPolicy = privacyPolicy;
        }
    }

}
