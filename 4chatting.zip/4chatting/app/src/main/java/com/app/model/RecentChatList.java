package com.app.model;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 * Created by hitasoft on 5/7/18.
 */

public class RecentChatList {

    @SerializedName("status")
    public String status;

    @SerializedName("result")
    public Map<String, RecentChat> result;
}
